//
// Created by nqhung on 10/11/2020.
//

///
/// Kiểm tra [value] có bị null hoặc rỗng không?
///
bool isNullOrEmpty(String value) {
  if (value == null || value.isEmpty) {
    return true;
  }
  return false;
}

///
/// Kiểm tra [value] có giá trị không
///
bool hasContentData(String value) {
  return !isNullOrEmpty(value);
}
