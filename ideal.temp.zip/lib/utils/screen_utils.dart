import 'package:flutter/widgets.dart';
import 'dart:ui' as ui show window;

class ScreenUtils {
  ScreenUtils._();

  static MediaQueryData mediaQuery = MediaQueryData.fromWindow(ui.window);

  static double get width {
    return mediaQuery.size.width;
  }

  static double get height {
    return mediaQuery.size.height;
  }

  static double get scale {
    return mediaQuery.devicePixelRatio;
  }

  static double get topSafeAreaHeight {
    return mediaQuery.padding.top;
  }

  static double get bottomSafeAreaHeight {
    return mediaQuery.padding.bottom;
  }

  static double get deviceHeight {
    return mediaQuery.padding.bottom +
        mediaQuery.size.height +
        mediaQuery.padding.top;
  }

  static double get contentDeviceHeight {
    return mediaQuery.size.height -
        (ScreenUtils.bottomSafeAreaHeight + ScreenUtils.topSafeAreaHeight);
  }
}
