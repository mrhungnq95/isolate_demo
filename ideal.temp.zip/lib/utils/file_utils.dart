//
// Created by  on 09/11/2020.
//

import 'package:flutter/services.dart';

class FileUtils {
  FileUtils._();

  static Future<String> readFile(String fileName) async {
    return await rootBundle.loadString("assets/raw/$fileName.json",
        cache: true);
  }
}
