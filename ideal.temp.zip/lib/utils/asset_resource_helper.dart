import 'package:flutter/cupertino.dart';
import 'package:MShopManager/app/app_config.dart';

class AssetResourceHelper {
  AssetResourceHelper._internal();

  static final AssetResourceHelper shared = AssetResourceHelper._internal();

  String getImageResource({@required String nameWithExt}) {
    return AppConfig.assetImages + nameWithExt;
  }
}
