import 'package:intl/intl.dart';
import 'package:intl/number_symbols.dart';
import 'package:intl/number_symbols_data.dart';

class NumberFormatHelper {
  static final KEY_NUMBER_SYMBOL_ESHOP_CUSTOMIZE = "vi-eshop-customize";
  static final NumberFormatHelper shared = NumberFormatHelper._internal();

  static final NumberFormat _amountFormatter =
      NumberFormat.decimalPattern(KEY_NUMBER_SYMBOL_ESHOP_CUSTOMIZE);

  static NumberSymbols _appNumberSymbol;
  static final Pattern _digitOnlyRegex = RegExp(r'\d+');

  static String decimalSeparator = '.';
  static String groupSeparator = ',';
  static String currencySymbol = 'đ';
  static int _amountDecimalDigits = 2;
  static int _quantityDecimalDigits = 2;
  static int _coefficientDecimalDigits = 2;

  NumberFormatHelper._internal() {
    _appNumberSymbol = NumberSymbols(
        NAME: KEY_NUMBER_SYMBOL_ESHOP_CUSTOMIZE,
        DECIMAL_SEP: ',',
        GROUP_SEP: '.',
        PERCENT: '%',
        ZERO_DIGIT: '0',
        PLUS_SIGN: '+',
        MINUS_SIGN: '-',
        EXP_SYMBOL: 'E',
        PERMILL: '\u2030',
        INFINITY: '\u221E',
        NAN: 'NaN',
        DECIMAL_PATTERN: '#,##0.###',
        SCIENTIFIC_PATTERN: '#E0',
        PERCENT_PATTERN: '#,##0%',
        CURRENCY_PATTERN: '#,##0.00\u00A0\u00A4',
        DEF_CURRENCY_CODE: 'VND');
    numberFormatSymbols[KEY_NUMBER_SYMBOL_ESHOP_CUSTOMIZE] = _appNumberSymbol;
  }

  int getDecimalDigits(EDoubleFormat type) {
    switch (type) {
      case EDoubleFormat.money:
        return _amountDecimalDigits;
      case EDoubleFormat.quantity:
        return _quantityDecimalDigits;
      case EDoubleFormat.percentage:
        return _coefficientDecimalDigits;
    }
    return 2;
  }

  String formatMoney(double money, [bool isShowCurrency = false]) {
    _amountFormatter.maximumFractionDigits = _amountDecimalDigits;
    return _amountFormatter.format(money ?? 0) +
        (isShowCurrency ? currencySymbol : '');
  }

  String formatQuantity(double quantity) {
    _amountFormatter.maximumFractionDigits = _quantityDecimalDigits;
    return _amountFormatter.format(quantity ?? 0);
  }

  String formatPercent(double percent) {
    _amountFormatter.maximumFractionDigits = _coefficientDecimalDigits;
    return _amountFormatter.format(percent ?? 0);
  }
}

enum EDoubleFormat { money, quantity, percentage }

extension EDoubleFormatExt on EDoubleFormat {
  int getDecimalDigits() {
    return NumberFormatHelper.shared.getDecimalDigits(this);
  }
}

extension DoubleExt on double {
  String toStringFormat(EDoubleFormat type) {
    switch (type) {
      case EDoubleFormat.money:
        return NumberFormatHelper.shared.formatMoney(this);
      case EDoubleFormat.quantity:
        return NumberFormatHelper.shared.formatQuantity(this);
      case EDoubleFormat.percentage:
        return NumberFormatHelper.shared.formatPercent(this);
    }
    return '';
  }
}
