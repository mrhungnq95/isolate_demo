import 'dart:io' show Platform;

class LocaleUtils {
  LocaleUtils._();

  ///
  /// Lấy mã ngôn ngữ
  /// -> vi
  /// Created by nqhung on 16/11/2020
  ///
  static String getLanguageCode() {
    String languageCode = Platform.localeName.split('_')[0];

    return languageCode;
  }

  ///
  /// Lấy mã quốc gia
  /// -> VN
  /// Created by nqhung on 16/11/2020
  ///
  static String getCountryCode() {
    String countryCode = Platform.localeName.split('_')[1];
    return countryCode;
  }

  ///
  /// Kiểm tra xem LanguageCode của thiết bị có phải là VN không?
  /// Created by nqhung on 16/11/2020
  ///
  static bool isVietnamLanguage() {
    return getLanguageCode().contains("vi");
  }
}
