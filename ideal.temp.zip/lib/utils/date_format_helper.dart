import 'package:date_time_format/date_time_format.dart';
import 'package:intl/intl.dart';

abstract class DateTimeFormatConstant {
  static const String DD_MM = 'dd/MM';
  static const String MM_YYYY = 'MM/yyyy';
  static const String DD_MM_YYYY = 'dd/MM/yyyy';
  static const String DD_MMMM_YYYY = 'dd/MMMM/yyyy';
  static const String HH_MM_A = 'hh:mm a';
  static const String HH_MM_24 = 'HH:mm';
  static const String DD_MM_YYYY_HH_MM_24 = 'dd/MM/yyyy HH:mm';
  static const String ISO = "yyyy-MM-dd'T'HH:mm:ss";
  static const String DATE_TIME_WITH_TIMEZONE_ISO_FORMAT =
      "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ";
  static const String DATE_TIME_WITH_TIMEZONE_FORMAT =
      "yyyy-MM-dd'T'HH:mm:ssZZ";

  /// Customize
  static const FORMAT_VI_DATE_TIME_MM_DD = "dd 'tháng' MM";
  static const FORMAT_VI_DATE_TIME_MM = "'Tháng' MM";
}

class DateTimeFormatHelper {
  ///
  /// Format Date sang dạng String với DateTimeFormat
  /// [date] obj thời gian cần convert
  /// [format] định dạng cần chuyển đổi
  ///
  static String formatDate2StringWithDTF(DateTime date,
      {String format = DateTimeFormats.commonLogFormat}) {
    if (date == null) {
      return null;
    }
    return DateTimeFormat.format(date, format: format);
  }

  ///
  /// Format từ Date sang String
  /// [date] obj Date cần format sang String
  /// [format] định dạng cần format
  /// Chú ý: Hiện tại flutter chưa support việc format Date sang
  /// String có Time Zone (z, Z) -> xử lý tay hoặc dùng lib DateTimeFormat
  ///
  ///
  static String formatDate2String(DateTime date,
      {String format = 'dd/MM/yyyy - HH:mm'}) {
    if (date == null) return null;
    try {
      if (format == DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT) {
        return DateTimeFormat.format(date,
            format: DateTimeFormats.soapExtended);
      } else if (format ==
          DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_FORMAT) {
        return DateTimeFormat.format(date, format: DateTimeFormats.iso8601);
      } else {
        DateFormat df = DateFormat(format, 'en_US');
        return df.format(date);
      }
    } catch (e) {
      print(e);
      return null;
    }
  }

  /// chuyển String sang Date
  static DateTime parseString2Date(String date) {
    if (date == null) return null;
    return DateTime.tryParse(date);
  }
}
