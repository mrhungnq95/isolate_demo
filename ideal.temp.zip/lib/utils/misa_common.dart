import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/stock.dart';
import 'package:MShopManager/utils/date_format_helper.dart';

class MISACommon {
  /// Kiểm tra xem đoạn string có hư vô hoặc rỗng hay không?
  static bool isEmpty(String input) {
    return input == null || input.isEmpty;
  }

  ///
  /// Kiểm tra dữ liệu có Null hoặc rỗng không
  /// [data] dữ liệu
  ///
  static bool isNullOrEmpty(dynamic data) {
    if (data != null) {
      if (data is Iterable) {
        return data.isEmpty;
      } else if (data is Map) {
        return data.isEmpty;
      } else if (data is String) {
        return isEmpty(data);
      } else {
        return false;
      }
    }
    return true;
  }

  /// Kiểm tra tính thoả mãn của số điện thoại
  static bool validatePhoneNumber(String phoneNumber) {
    return !isEmpty(phoneNumber) &&
        AppConstant.phoneNumberPattern.hasMatch(phoneNumber);
  }

  ///
  /// Lấy char đầu tiên của words cuối cùng từ [source]
  ///
  static String getFirstCharInString(String source) {
    if (source != null && source.isNotEmpty) {
      final sourceSeparateArr = source.split(" ");
      final lastSeparate = sourceSeparateArr.last;
      if (lastSeparate != null && lastSeparate.isNotEmpty) {
        return lastSeparate[0];
      } else {
        return source[0];
      }
    }
    return "";
  }

  ///
  /// Lấy thời gian lấy báo cáo
  ///
  static String getFetchReportDateTimeTitle(DateTime dateTime) {
    return "Cập nhật: ${DateTimeFormatHelper.formatDate2String(dateTime, format: DateTimeFormatConstant.HH_MM_24)}";
  }

  /// Chức năng: Kiểm tra xem tài khoản có được xem báo cáo toàn chuỗi hay không
  static bool isAllowViewReportAllChain() {
//      try {
//        LicenseInfo licenseInfo = GsonHelper.getInstance().fromJson(AuthCache.getInstance().getLoginInfo().getLicenseInfo(), LicenseInfo.class);
//        if (licenseInfo != null) {
//          if (TextUtils.equals(licenseInfo.getProductPackCode(), LicenseConstants.LicensePackageTrial)) {
//            return true;
//          }
//          return new LicenseBL().isLicenseChainStore(licenseInfo);
//        } else {
//          return false;
//        }
//      } catch (Exception e) {
//          MISACommon.handleException(e);
//      }
    return true;
  }

  /// lấy tất cả chi nhánh mà user hiện tại có thể thấy
  static Future<List<Branch>> getAllBranchesOfUser() {
    List<Branch> listBranch = [
      Branch()
        ..branchName = 'CN Cầu Giấy'
        ..branchId = '11',
      Branch()
        ..branchName = 'CN Nguyễn Khánh Toàn'
        ..branchId = '12',
      Branch()
        ..branchName = 'CN Trần Duy Hưng'
        ..branchId = '13',
      Branch()
        ..branchName = 'CN Trường Chinh'
        ..branchId = '14',
      Branch()
        ..branchName = 'CN Láng'
        ..branchId = '15',
      Branch()
        ..branchName = 'CN Cầu Giấy'
        ..branchId = '16',
      Branch()
        ..branchName = 'CN Nguyễn Khánh Toàn'
        ..branchId = '17',
      Branch()
        ..branchName = 'CN Trần Duy Hưng'
        ..branchId = '18',
      Branch()
        ..branchName = 'CN Trường Chinh'
        ..branchId = '19',
      Branch()
        ..branchName = 'CN Láng'
        ..branchId = '20',
      Branch()
        ..branchName = 'CN Cầu Giấy'
        ..branchId = '21',
      Branch()
        ..branchName = 'CN Nguyễn Khánh Toàn'
        ..branchId = '22',
      Branch()
        ..branchName = 'CN Trần Duy Hưng'
        ..branchId = '23',
    ];
    return Future<List<Branch>>.delayed(
        Duration(milliseconds: 0), () => listBranch);
  }

  /// lấy tất cả danh sách kho
  static Future<List<Stock>> getAllStockOfUser() {
    List<Stock> listStock = [
      Stock()
        ..stockName = 'Kho Cầu Giấy 1'
        ..branchID = '11'
        ..stockID = '11',
      Stock()
        ..stockName = 'Kho Cầu Giấy 2'
        ..branchID = '11'
        ..stockID = '31',
      Stock()
        ..stockName = 'Kho Nguyễn Khánh Toàn'
        ..branchID = '12'
        ..stockID = '12',
      Stock()
        ..stockName = 'Kho Trần Duy Hưng'
        ..branchID = '13'
        ..stockID = '13',
      Stock()
        ..stockName = 'Kho Trường Chinh'
        ..branchID = '14'
        ..stockID = '14',
      Stock()
        ..stockName = 'Kho Láng 1'
        ..branchID = '15'
        ..stockID = '15',
      Stock()
        ..stockName = 'Kho Láng 2'
        ..branchID = '15'
        ..stockID = '35',
      Stock()
        ..stockName = 'Kho Cầu Giấy'
        ..branchID = '16'
        ..stockID = '16',
      Stock()
        ..stockName = 'Kho Nguyễn Khánh Toàn'
        ..branchID = '17'
        ..stockID = '17',
      Stock()
        ..stockName = 'Kho Trần Duy Hưng'
        ..branchID = '18'
        ..stockID = '18',
      Stock()
        ..stockName = 'Kho Trường Chinh'
        ..branchID = '19'
        ..stockID = '19',
      Stock()
        ..stockName = 'Kho Láng'
        ..branchID = '20'
        ..stockID = '20',
      Stock()
        ..stockName = 'Kho Cầu Giấy'
        ..branchID = '21'
        ..stockID = '21',
      Stock()
        ..stockName = 'Kho Nguyễn Khánh Toàn'
        ..branchID = '22'
        ..stockID = '22',
      Stock()
        ..stockName = 'Kho Trần Duy Hưng'
        ..branchID = '23'
        ..stockID = '23',
    ];
    return Future<List<Stock>>.delayed(
        Duration(milliseconds: 0), () => listStock);
  }
}
