import 'package:logger/logger.dart';

class FLogger {
  Logger _logger;
  Logger _loggerNoStack;

  static final FLogger _instance = FLogger._internal();
  static FLogger get shared => _instance;

  void log(String message, {Level level = Level.info}) {
    //_logger.log(level, "[MSLogger] $message");
    print("[MSLogger] $message");
  }

  void noStack(String message, {Level level = Level.info}) {
    //_loggerNoStack.log(level, "[MSLogger] $message");
    print("[MSLogger] $message");
  }

  FLogger._internal() {
    print("_internal");
    _logger = Logger(
      printer: PrettyPrinter(printTime: true),
    );

    _loggerNoStack = Logger(
      printer: PrettyPrinter(methodCount: 0),
    );
  }
}
