import 'package:flutter/material.dart';
import 'package:MShopManager/app/app_color.dart';

extension OnPressed on Widget {
  Widget ripple(Function onPressed,
          {BorderRadiusGeometry borderRadius =
              const BorderRadius.all(Radius.circular(2))}) =>
      Stack(
        children: <Widget>[
          this,
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            child: FlatButton(
                highlightColor: AppColor.splashColor,
                splashColor: AppColor.splashColor,
                shape: RoundedRectangleBorder(borderRadius: borderRadius),
                onPressed: () {
                  if (onPressed != null) {
                    onPressed();
                  }
                },
                child: SizedBox.shrink()),
          )
        ],
      );
}
