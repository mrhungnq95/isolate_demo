
extension StringExt on String {
  bool isNullOrEmpty() => this == null || this.isEmpty;

  bool equalIgnoreCase(String other) => this?.toLowerCase() == other?.toLowerCase();
}