import 'package:MShopManager/widget/chart/line_chart_view.dart';
import 'package:flutter/widgets.dart';

extension ConnectionStateExt on ConnectionState {
  EChartState get toChartState {
    var chartState;
    switch (this) {
      case ConnectionState.none:
        chartState = EChartState.noData;
        break;
      case ConnectionState.waiting:
        chartState = EChartState.loading;
        break;
      case ConnectionState.active:
        chartState = EChartState.loading;
        break;
      case ConnectionState.done:
        chartState = EChartState.done;
        break;
    }
    return chartState;
  }
}
