///
/// Enum
///
enum EChooseProviderTypeScreen {
  normal, // Case mặc định
  returnItem, // Case trả lại hàng mua
}
