///
/// Các trạng thái của object
///
enum EOrderSourceType {
  /// Đơn từ ocm
  ocm,
  /// Đơn từ web
  website,
  /// Đơn từ tư vấn
  mobile,
}

extension EOrderSourceTypeExt on EOrderSourceType {
  static EOrderSourceType valueOf(int value) {
    switch (value) {
      case 1:
        return EOrderSourceType.ocm;
      case 2:
        return EOrderSourceType.website;
      case 3:
        return EOrderSourceType.mobile;
    }
    return null;
  }

  String getSource() {
    switch (this) {
      case EOrderSourceType.ocm:
        return "Bán hàng";
      default:
        return "ứng dụng Tư vấn";
    }
  }
}
