///
/// [Description]  enum quản lý hàng hoá
///
/// Created by TTLOI on 16/01/2021 (11:18).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
enum EManageItemType {
  /// thông thường (k theo loại hình nào)
  normal,

  /// theo lô hsd
  lot,

  /// theo serial
  serial,
}

extension EManageItemTypeExt on EManageItemType {
  int get value {
    switch (this) {
      case EManageItemType.normal:
        return 0;
      case EManageItemType.lot:
        return 1;
      case EManageItemType.serial:
        return 2;
    }
    return 0;
  }

  static EManageItemType fromValue(int rawValue) {
    switch (rawValue) {
      case 0:
        return EManageItemType.normal;
      case 1:
        return EManageItemType.lot;
      case 2:
        return EManageItemType.serial;
      default:
        return EManageItemType.normal;
    }
  }
}
