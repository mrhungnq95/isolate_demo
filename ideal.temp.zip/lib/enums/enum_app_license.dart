enum EAppLicense { OCM, MSHOP, ALL }

extension EAppLicenseExt on EAppLicense {
  int get toValue {
    switch (this) {
      case EAppLicense.OCM:
        return 0;
      case EAppLicense.MSHOP:
        return 1;
      case EAppLicense.ALL:
        return 2;
      default:
        return -1;
    }
  }

  static EAppLicense valueOf(int value) {
    switch (value) {
      case 0:
        return EAppLicense.OCM;
      case 1:
        return EAppLicense.MSHOP;
      case 2:
        return EAppLicense.ALL;
      default:
        return EAppLicense.ALL;
    }
  }
}
