///
/// Enum kiểm kê theo hàng hóa hoặc lô
///
enum EPermissionType {
  view,
  viewByPrice,
  add,
  edit,
  delete,
  export,
  printStamp,
  viewPrice,
}

extension EPermissionTypeExtension on EPermissionType {

    int get toValue {
      switch(this) {
          case EPermissionType.view:
        return 1;
      case EPermissionType.viewByPrice:
        return 128;
      case EPermissionType.add:
        return 2;
      case EPermissionType.edit:
        return 4;
      case EPermissionType.delete:
        return 8;
      case EPermissionType.export:
        return 16;
      case EPermissionType.printStamp:
        return 32;
      case EPermissionType.viewPrice:
        return 64;
      }
    }
}
