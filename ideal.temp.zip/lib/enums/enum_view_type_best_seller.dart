enum EViewTypeBestSeller { inventory_item, model }

extension EViewTypeBestSellerExt on EViewTypeBestSeller {
  String getTitle() {
    switch (this) {
      case EViewTypeBestSeller.inventory_item:
        return "Hàng hoá";
      case EViewTypeBestSeller.model:
        return "Mẫu mã";
      default:
        return "";
    }
  }

}
