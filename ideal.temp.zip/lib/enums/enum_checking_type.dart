/// 
/// Enum kiểm kê theo hàng hóa hoặc lô
/// 
enum ECheckingType {
  inventoryItem,    // Kiểm kê theo hàng hóa
  batch             // Kiểm kê lô hàng
}


extension ECheckingTypeExtension on ECheckingType {
  String get title {
    switch (this) {
      case ECheckingType.inventoryItem:
        return 'Hàng hóa';
        case ECheckingType.batch:
        return 'Lô';
    }
  }

  String get description {
    switch (this) {
      case ECheckingType.inventoryItem:
        return 'Kiểm kê hàng hóa';
        case ECheckingType.batch:
        return 'Hàng hóa trong lô';
    }
  }
}

