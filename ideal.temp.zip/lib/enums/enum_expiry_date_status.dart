import 'dart:ui';

import 'package:MShopManager/app/app_color.dart';


enum EExpiryDateStatus {
  ALL, //tất cả
  VALID, //còn hạn
  EXPIRED_SOON, //cận date
  EXPIRY, //hết hạn
}

extension EExpiryDateStatusExt on EExpiryDateStatus {

  static EExpiryDateStatus getEExpiryDateStatus(int value) {
    switch (value) {
      case 0:
        return EExpiryDateStatus.ALL;
      case 1:
        return EExpiryDateStatus.VALID;
      case 2:
        return EExpiryDateStatus.EXPIRED_SOON;
      case 3:
        return EExpiryDateStatus.EXPIRY;
    }
    return EExpiryDateStatus.ALL;
  }

  String getTitle() {
    switch (this) {
      case EExpiryDateStatus.ALL:
        return 'Tất cả';
      case EExpiryDateStatus.VALID:
        return 'Còn hạn';
      case EExpiryDateStatus.EXPIRED_SOON:
        return 'Cận date';
      case EExpiryDateStatus.EXPIRY:
        return 'Hết hạn';
    }
    return '';
  }

  Color getTitleColor() {
    switch (this) {
      case EExpiryDateStatus.ALL:
        return AppColor.primaryColor;
      case EExpiryDateStatus.VALID:
        return Color(0xFF5ACBA8);
      case EExpiryDateStatus.EXPIRED_SOON:
        return Color(0xFFFFA200);
      case EExpiryDateStatus.EXPIRY:
        return Color(0xFFFF7B7B);
    }
    return AppColor.primaryColor;
  }

  Color getBackgroundColor() {
    switch (this) {
      case EExpiryDateStatus.ALL:
        return Color(0xFF616CE6).withOpacity(0.1);
      case EExpiryDateStatus.VALID:
        return Color(0xFF3DB3A1).withOpacity(0.1);
      case EExpiryDateStatus.EXPIRED_SOON:
        return Color(0xFFFFA030).withOpacity(0.1);
      case EExpiryDateStatus.EXPIRY:
        return Color(0xFFFF936B).withOpacity(0.1);
    }
    return Color(0xFF616CE6).withOpacity(0.1);
  }
}