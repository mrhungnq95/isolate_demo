///
/// Enum 
///
enum ESellBeforeType {
  day,
  month
}

extension ESellBeforeTypeExtension on ESellBeforeType {

  int get rawValue {
    switch (this) {
      case ESellBeforeType.day:
        return 1;
      case ESellBeforeType.month:
        return 2;
    }
  }

  String get title {
    switch (this) {
      case ESellBeforeType.day:
        return 'Ngày';
      case ESellBeforeType.month:
        return 'Tháng';
    }
  }

  static ESellBeforeType fromValue(int rawValue) {
    switch (rawValue) {
      case 1:
        return ESellBeforeType.day;
      case 2:
        return ESellBeforeType.month;
      default:
        return ESellBeforeType.day;
    }
  }
}
