import 'dart:ui';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/model/notification/notification_config.dart';

///
/// Enum các type các loại thông báo
///
enum ENotificationType {
  saleInfo, // tổng doanh thu
  saInvoice, // hoá đơn
  exchange, // đổi trả
  editSAInvoice, // sửa hoá đơn
  cancelSAInvoice, // huỷ hoá đơn
  inStock, // cảnh báo tồn kho
  importInventory, // nhập hàng
  importStock, //nhập kho
  returnInventory, // trả lại hàng mua
  iSMAC,
  outward, // xuất kho
  sellBeforeDate, // thông báo cận date
  processOrder, // Xử lý đơn hàng
  rejectOrder, // Từ chối đơn hàng
  newOrder, // có đơn hàng mới từ tư vấn or trang đặt hàng
  /// vì BE bảo vậy bên phải case 2 trường hợp
  processOrderForManager, // Xử lý đơn hàng
  rejectOrderForManager, // Từ chối đơn hàng
}

extension ENotificationTypeExt on ENotificationType {
  ///
  /// Build nội dung config
  ///
  String get contentConfig {
    switch (this) {
      case ENotificationType.saleInfo:
        return 'Thông báo tổng doanh thu vào 09:00 SA';
      case ENotificationType.saInvoice:
        return 'Thông báo khi có hoá đơn mới';
      case ENotificationType.exchange:
        return 'Thông báo khi có hoá đơn đổi trả';
      case ENotificationType.editSAInvoice:
        return 'Thông báo khi sửa hoá đơn thay đổi tổng tiền';
      case ENotificationType.cancelSAInvoice:
        return 'Thông báo khi có hoá đơn huỷ';
      case ENotificationType.inStock:
        return 'Thông báo hàng hết vào 08:00 SA';
      case ENotificationType.importInventory:
        return 'Thông báo khi có phiếu nhập hàng';
      case ENotificationType.importStock:
        return 'Thông báo khi có phiếu nhập kho';
      case ENotificationType.returnInventory:
        return 'Thông báo khi có phiếu trả hàng';
      case ENotificationType.iSMAC:
        return '';
      case ENotificationType.outward:
        return 'Thông báo khi có phiếu xuất kho';
      case ENotificationType.sellBeforeDate:
        return 'Thông báo có hàng hóa cận date vào 08:30 SA';
      case ENotificationType.newOrder:
        return 'Khi có đơn hàng mới từ trang đặt hàng, App tư vấn';
      case ENotificationType.processOrder:
      case ENotificationType.processOrderForManager:
        return 'Khi thu ngân xử lý đơn hàng từ trang đặt hàng, App tư vấn';
      case ENotificationType.rejectOrder:
      case ENotificationType.rejectOrderForManager:
        return 'Khi thu ngân từ chối đơn hàng từ trang đặt hàng, App tư vấn';
      default:
        return "";
    }
  }

  ///
  /// Build tiêu đề config
  ///
  String get title {
    switch (this) {
      case ENotificationType.saleInfo:
        return 'Tình hình doanh thu';
      case ENotificationType.saInvoice:
        return 'Hóa đơn';
      case ENotificationType.exchange:
        return 'Đổi trả';
      case ENotificationType.editSAInvoice:
        return 'Sửa hóa đơn';
      case ENotificationType.cancelSAInvoice:
        return 'Hủy hóa đơn';
      case ENotificationType.inStock:
        return 'Cảnh báo tồn kho';
      case ENotificationType.importInventory:
        return 'Nhập hàng';
      case ENotificationType.importStock:
        return 'Nhập kho';
      case ENotificationType.returnInventory:
        return 'Trả lại hàng mua';
      case ENotificationType.iSMAC:
        return '';
      case ENotificationType.outward:
        return 'Xuất kho';
      case ENotificationType.sellBeforeDate:
        return 'Hàng hóa cận date';
      case ENotificationType.newOrder:
        return 'Đơn hàng mới';
      case ENotificationType.processOrder:
      case ENotificationType.processOrderForManager:
        return 'Xử lý đơn hàng';
      case ENotificationType.rejectOrder:
      case ENotificationType.rejectOrderForManager:
        return 'Từ chối đơn hàng';
      default:
        return "";
    }
  }

  static ENotificationType valueOf(int value) {
    switch (value) {
      case 0:
        return ENotificationType.saleInfo;
      case 1:
        return ENotificationType.saInvoice;
      case 2:
        return ENotificationType.exchange;
      case 3:
        return ENotificationType.editSAInvoice;
      case 4:
        return ENotificationType.cancelSAInvoice;
      case 5:
        return ENotificationType.inStock;
      case 6:
        return ENotificationType.importInventory;
      case 7:
        return ENotificationType.importStock;
      case 8:
        return ENotificationType.returnInventory;
      case 99:
        return ENotificationType.iSMAC;
      case 9:
        return ENotificationType.outward;
      case 10:
        return ENotificationType.sellBeforeDate;
      case 11:
        return ENotificationType.processOrder;
      case 12:
        return ENotificationType.rejectOrder;
      case 13:
        return ENotificationType.newOrder;
      case 14:
        return ENotificationType.processOrderForManager;
      case 15:
        return ENotificationType.rejectOrderForManager;
      default:
        return ENotificationType.saleInfo;
    }
  }

  ///
  /// Hàm lấy ảnh nền icon theo từng loại thông báo
  ///
  Color get colorBackground {
    switch (this) {
      case ENotificationType.saleInfo:
        return AppColor.indigo800;
      case ENotificationType.saInvoice:
        return AppColor.indigo800;
      case ENotificationType.exchange:
        return AppColor.green50;
      case ENotificationType.editSAInvoice:
        return AppColor.indigo800;
      case ENotificationType.cancelSAInvoice:
        return AppColor.pink50;
      case ENotificationType.inStock:
        return AppColor.pink50;
      case ENotificationType.importInventory:
        return AppColor.indigo600;
      case ENotificationType.importStock:
        return AppColor.blue;
      case ENotificationType.returnInventory:
        return AppColor.deepPurple600;
      case ENotificationType.iSMAC:
        return AppColor.indigo800;
      case ENotificationType.outward:
        return AppColor.indigo800;
      case ENotificationType.sellBeforeDate:
        return AppColor.pink50;
      case ENotificationType.processOrder:
      case ENotificationType.rejectOrder:
      case ENotificationType.newOrder:
      case ENotificationType.processOrderForManager:
      case ENotificationType.rejectOrderForManager:
        return AppColor.indigo800;
      default:
        return AppColor.indigo800;
    }
  }

  ///
  /// Hàm lấy ảnh nền icon theo từng loại thông báo
  ///
  String get getImageAssetNameNotifi {
    switch (this) {
      case ENotificationType.saleInfo:
        return AppResources.icNotificationMshop;
      case ENotificationType.saInvoice:
        return AppResources.icNotificationInvoice;
      case ENotificationType.exchange:
        return AppResources.icNotificationExchange;
      case ENotificationType.editSAInvoice:
        return AppResources.icNotificationEditInvoice;
      case ENotificationType.cancelSAInvoice:
        return AppResources.icNotificationCancelInvoice;
      case ENotificationType.inStock:
        return AppResources.icNotificationWarning;
      case ENotificationType.importInventory:
        return AppResources.icNotificationImport;
      case ENotificationType.importStock:
        return AppResources.icNotificationImportStock;
      case ENotificationType.returnInventory:
        return AppResources.icNotificationReturnInventory;
      case ENotificationType.iSMAC:
        return AppResources.icNotificationSystem;
      case ENotificationType.outward:
        return AppResources.icNotificationOutward;
      case ENotificationType.sellBeforeDate:
        return AppResources.icNotificationWarning;
      case ENotificationType.processOrder:
      case ENotificationType.rejectOrder:
      case ENotificationType.newOrder:
      case ENotificationType.processOrderForManager:
      case ENotificationType.rejectOrderForManager:
        return AppResources.icOrderWebNoti;
      default:
        return AppResources.icNotificationMshop;
    }
  }
}
