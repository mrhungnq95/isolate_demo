
///
/// Enum Type cho màn hình tình hình thu chi
///
enum ERevenueExpenditureType {
  revenueOnBranch,  // Thu tiền theo cửa hàng
  revenueByCategry, // Thu tiền theo khoản mục
}