///
/// Enum
///
enum EReturnItemType {
  reduceDebt, // Tất cả
  cash, // Tiền mặt
  bankDeposit // Tiền gửi
}

extension EReturnItemTypeExtension on EReturnItemType {
  String get title {
    switch (this) {
      case EReturnItemType.reduceDebt:
        return 'Giảm trừ công nợ';
      case EReturnItemType.cash:
        return 'Tiền mặt';
      case EReturnItemType.bankDeposit:
        return 'Tiền gửi';

      default:
        return '';
    }
  }
}
