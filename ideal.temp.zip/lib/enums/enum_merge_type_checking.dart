enum EMergeTypeChecking {
  all,                // Tất cả
  included,           // Đã gộp
  notIncluded,        // Chưa gộp
}

extension EStateCheckingExt on EMergeTypeChecking {
  String get title {
    switch (this) {
      case EMergeTypeChecking.all:
        return 'Tất cả';
      case EMergeTypeChecking.included:
        return 'Đã gộp';
      case EMergeTypeChecking.notIncluded:
        return 'Chưa gộp';
    }
  }
}