enum ECustomerTransactionHistoryViewType { createdDate, refDate }

extension ECustomerTransactionHistoryViewTypeExt
    on ECustomerTransactionHistoryViewType {
  static ECustomerTransactionHistoryViewType valueOf(int value) {
    switch (value) {
      case 1:
        return ECustomerTransactionHistoryViewType.createdDate;
      case 2:
        return ECustomerTransactionHistoryViewType.refDate;
      default:
        return ECustomerTransactionHistoryViewType.createdDate;
    }
  }

  int get rawValue {
    switch (this) {
      case ECustomerTransactionHistoryViewType.createdDate:
        return 1;
      case ECustomerTransactionHistoryViewType.refDate:
        return 2;
      default:
        return 1;
    }
  }

  String getTitle() {
    switch (this) {
      case ECustomerTransactionHistoryViewType.createdDate:
        return "Ngày tạo";
      case ECustomerTransactionHistoryViewType.refDate:
        return "Ngày hoá đơn";
      default:
        return "";
    }
  }
}
