//
// Created by nqhung on 05/11/2020.
//

enum EOverviewDrawViewType {
  header,
  chart,
  title_n_value,
  title_n_list_value,
  order_n_customer,
  inventory_item_in_store,
  quick_action
}
