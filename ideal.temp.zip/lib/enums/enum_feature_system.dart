///
/// Enum kiểm kê theo hàng hóa hoặc lô
///
enum EFeatureSystem {
  // Tổng quan
  overview,
  // Báo cáo bán hàng
  reportSales,
  // Báo cáo lợi nhuận
  reportProfit,
  // Báo cáo quỹ tiền
  reportMonetaryFlow,
  // Báo cáo kho
  reportStock,
  // Báo cáo công nợ
  reportDebt,
  // Nhập hàng
  import,
  // Trả lại hàng mua
  returnItem,
  // Nhập kho khác
  inWardOther,
  // Nhập kho điều chuyển
  inWardTransfer,
  // Xuất kho khác
  outWardOther,
  // Xuất kho điều chuyển
  outWardTransfer,
  // Hàng hóa
  inventoryItem,
  // Nhà cung cấp
  supplier,
  // Ds khách hàng
  listCustomer,
  // Kiểm kê kho
  checkingWard,
  // Nhóm hàng hóa
  categoryItem,
  // Đơn vị tính
  unit,
  // Nhóm nhà cung cấp
  categorySupplier,
  // Tồn kho ban đầu
  remainStock,
  // Giá trị khác
  none
}

extension EFeatureSystemExtension on EFeatureSystem {

    int get toValue {
      switch(this) {
          case EFeatureSystem.none:
        return 0;
      case EFeatureSystem.overview:
        return 1;
      case EFeatureSystem.reportSales:
        return 2;
      case EFeatureSystem.reportStock:
        return 4;
      case EFeatureSystem.reportDebt:
        return 5;
      case EFeatureSystem.reportMonetaryFlow:
        return 6;
      case EFeatureSystem.reportProfit:
        return 7;
      case EFeatureSystem.import:
        return 9;
      case EFeatureSystem.returnItem:
        return 10;
      case EFeatureSystem.checkingWard:
        return 14;
      case EFeatureSystem.inventoryItem:
        return 26;
      case EFeatureSystem.categoryItem:
        return 25;
      case EFeatureSystem.unit:
        return 27;
      case EFeatureSystem.listCustomer:
        return 30;
      case EFeatureSystem.categorySupplier:
        return 32;
      case EFeatureSystem.supplier:
        return 33;
      case EFeatureSystem.remainStock:
        return 45;
      case EFeatureSystem.inWardOther:
        return 99;
      case EFeatureSystem.inWardTransfer:
        return 100;
      case EFeatureSystem.outWardOther:
        return 101;
      case EFeatureSystem.outWardTransfer:
        return 102;
      }
    }

  static EFeatureSystem valueOf(int value) {
    switch (value) {
      case 0:
        return EFeatureSystem.none;
      case 1:
        return EFeatureSystem.overview;
      case 2:
        return EFeatureSystem.reportSales;
      case 4:
        return EFeatureSystem.reportStock;
      case 5:
        return EFeatureSystem.reportDebt;
      case 6:
        return EFeatureSystem.reportMonetaryFlow;
      case 7:
        return EFeatureSystem.reportProfit;
      case 9:
        return EFeatureSystem.import;
      case 10:
        return EFeatureSystem.returnItem;
      case 14:
        return EFeatureSystem.checkingWard;
      case 26:
        return EFeatureSystem.inventoryItem;
      case 25:
        return EFeatureSystem.categoryItem;
      case 27:
        return EFeatureSystem.unit;
      case 30:
        return EFeatureSystem.listCustomer;
      case 32:
        return EFeatureSystem.categorySupplier;
      case 33:
        return EFeatureSystem.supplier;
      case 45:
        return EFeatureSystem.remainStock;
      case 99:
        return EFeatureSystem.inWardOther;
      case 100:
        return EFeatureSystem.inWardTransfer;
      case 101:
        return EFeatureSystem.outWardOther;
      case 102:
        return EFeatureSystem.outWardTransfer;
    }
    return null;
  }
}
