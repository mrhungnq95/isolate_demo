enum ERevenueForInventoryMode {
  group, // tỷ trọng nhóm mặt hàng
  category, // tỷ trọng mẫu mã nhóm hàng
  detail // tỷ trọng hàng hóa
}

extension ERevenueForInventoryModeExt on ERevenueForInventoryMode {
  int get rawValue {
    switch (this) {
      case ERevenueForInventoryMode.group:
        return 1;
      case ERevenueForInventoryMode.category:
        return 2;
      case ERevenueForInventoryMode.detail:
        return 3;
      default:
        return 1;
    }
  }

  static ERevenueForInventoryMode valueOf(int value) {
    switch (value) {
      case 1:
        return ERevenueForInventoryMode.group;
      case 2:
        return ERevenueForInventoryMode.category;
      case 3:
        return ERevenueForInventoryMode.detail;
      default:
        return ERevenueForInventoryMode.group;
    }
  }
}
