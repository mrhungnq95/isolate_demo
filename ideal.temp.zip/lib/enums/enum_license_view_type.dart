enum ELicenseViewType {
  ocm_license,
  trail_license,
  branch_out_of_quota_chain_store,
  virtual_branch_trail_license
}
