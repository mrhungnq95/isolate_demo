enum EFollowStatus { all, following, unfollow }

extension EFollowStatusExt on EFollowStatus {
  int get rawValue {
    switch (this) {
      case EFollowStatus.all:
        return -1;
      case EFollowStatus.following:
        return 1;
      case EFollowStatus.unfollow:
        return 0;
      default:
        return -1;
    }
  }

  static EFollowStatus valueOf(int value) {
    switch (value) {
      case -1:
        return EFollowStatus.all;
      case 1:
        return EFollowStatus.following;
      case 0:
        return EFollowStatus.unfollow;
      default:
        return EFollowStatus.all;
    }
  }

  String getTitle() {
    switch (this) {
      case EFollowStatus.following:
        return "Đang theo dõi";
      case EFollowStatus.unfollow:
        return "Ngừng theo dõi";
      default:
        return "";
    }
  }
}
