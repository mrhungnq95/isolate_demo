//
// Created by nqhung on 11/11/2020.
//

enum ESignInErrorType {
  INVALID_GRANT, //Sai userName hoặc mật khẩu
  INVALID_CLIENT_ID, //Sai clientId
  ACCESS_DENIED, //Không có quyền truy cập
  INVALID_COMPANY_CODE //Sai companyCode
}

extension ESignInErrorTypeExt on ESignInErrorType {
  String get toValue {
    switch (this) {
      case ESignInErrorType.INVALID_GRANT:
        return "invalid_grant";
      case ESignInErrorType.INVALID_CLIENT_ID:
        return "invalid_clientId";
      case ESignInErrorType.ACCESS_DENIED:
        return "access_denied";
      case ESignInErrorType.INVALID_COMPANY_CODE:
        return "Invalid_CompanyCode";
      default:
        return null;
    }
  }

  static ESignInErrorType valueOf(String value) {
    switch (value) {
      case "invalid_grant":
        return ESignInErrorType.INVALID_GRANT;
      case "invalid_clientId":
        return ESignInErrorType.INVALID_CLIENT_ID;
      case "access_denied":
        return ESignInErrorType.ACCESS_DENIED;
      case "Invalid_CompanyCode":
        return ESignInErrorType.INVALID_COMPANY_CODE;
      default:
        return null;
    }
  }
}
