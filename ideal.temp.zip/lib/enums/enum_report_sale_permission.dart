enum EReportSalePermission {
  // Báo cáo tổng hợp doanh thu bán hàng theo thời gian - báo cáo chuỗi - doanh thu
  saleSummaryByTime, 
  // danh sách hóa đơn
  listInvoice,
  // 
  revenueByBillAndInventoryItem,
  // Doanh thu theo thời gian
  salesByTime,
  // Doanh thu theo mặt hàng
  revenueByInventoryItem,
  compareRevenueInventoryItemByTime,
  revenueByInventoryItemAndPromotion,
  salesByEmployee,
  salesByCustomer,
  // Báo cáo so sánh doanh thu theo chi nhanh - Báo cáo chuỗi doanh thu, báo cáo chuỗi lợi nhuận
  compareRevenueBranchByTime,
  orderTransferByBranch,
  deliveryBook,
  inventoryItemBySerial
}