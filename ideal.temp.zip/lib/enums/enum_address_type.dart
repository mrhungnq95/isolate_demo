enum ELocationKind { country, city, district, ward }

extension ELocationKindExt on ELocationKind {
  int get rawValue {
    switch (this) {
      case ELocationKind.country:
        return 0;
      case ELocationKind.city:
        return 1;
      case ELocationKind.district:
        return 2;
      case ELocationKind.ward:
        return 3;
      default:
        return 0;
    }
  }

  String getTitle() {
    switch (this) {
      case ELocationKind.country:
        return "Khu vực";
      case ELocationKind.city:
        return "Phường xã";
      case ELocationKind.district:
        return "Quận huyện";
      case ELocationKind.ward:
        return "Phường xã";
      default:
        return "";
    }
  }
}

enum EAddressType { area, wards }

extension EAddressTypeExt on EAddressType {
  String getTitle() {
    switch (this) {
      case EAddressType.area:
        return "Khu vực";
      case EAddressType.wards:
        return "Phường xã";
      default:
        return "";
    }
  }
}
