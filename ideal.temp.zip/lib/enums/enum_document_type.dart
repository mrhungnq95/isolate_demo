///
/// Enum
///
enum EDocumentType {
  all, // Tất cả
}

extension EDocumentTypeExtension on EDocumentType {
  String get title {
    switch (this) {
      case EDocumentType.all:
        return 'Tất cả';
          default:
        return '';
    }
  }
}
