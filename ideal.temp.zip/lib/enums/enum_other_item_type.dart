import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:flutter/painting.dart';

enum EOtherItemType {
  misaSupport,
  appSale,
  appConsultant,
  setting,
  shareToFriend,
  rateApp,
  feedBack,
  appInfo,
  policy,
  logOut
}

extension EOtherItemTypeExt on EOtherItemType {
  String getTitle() {
    switch (this) {
      case EOtherItemType.misaSupport:
        return "MISA SUPPORT";
      case EOtherItemType.appSale:
        return "Bán hàng";
      case EOtherItemType.appConsultant:
        return "Tư vấn bán hàng";
      case EOtherItemType.setting:
        return "Cài đặt";
      case EOtherItemType.shareToFriend:
        return "Giới thiệu cho bạn bè";
      case EOtherItemType.rateApp:
        return "Đánh giá ứng dụng";
      case EOtherItemType.feedBack:
        return "Góp ý nhà phát triển";
      case EOtherItemType.appInfo:
        return "Thông tin ứng dụng";
      case EOtherItemType.policy:
        return "Chính sách bảo mật";
      case EOtherItemType.logOut:
        return "Đăng xuất";
      default:
        return "";
    }
  }

  String getIconPath() {
    switch (this) {
      case EOtherItemType.misaSupport:
        return AppResources.icMisaSupportGroup;
      case EOtherItemType.appSale:
        return AppResources.icAppSale;
      case EOtherItemType.appConsultant:
        return AppResources.icAppConsultant;
      case EOtherItemType.setting:
        return AppResources.icSetting;
      case EOtherItemType.shareToFriend:
        return AppResources.icShare2;
      case EOtherItemType.rateApp:
        return AppResources.icStar;
      case EOtherItemType.feedBack:
        return AppResources.icMailGreen;
      case EOtherItemType.appInfo:
        return AppResources.icInfo;
      case EOtherItemType.policy:
        return AppResources.icPolicy;
      case EOtherItemType.logOut:
        return AppResources.icLogout;
      default:
        return AppResources.icSetting;
    }
  }

  Color getIconColorLeading() {
    switch (this) {
      case EOtherItemType.setting:
        return AppColor.primaryColor;
      case EOtherItemType.shareToFriend:
        return AppColor.deepPurple600;
      case EOtherItemType.rateApp:
        return AppColor.orange;
      case EOtherItemType.feedBack:
        return AppColor.green;
      case EOtherItemType.appInfo:
        return AppColor.pink;
      case EOtherItemType.policy:
        return AppColor.cyan;
      case EOtherItemType.logOut:
        return AppColor.pink;
      default:
        return null;
    }
  }
}
