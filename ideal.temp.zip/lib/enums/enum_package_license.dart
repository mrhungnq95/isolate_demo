enum ELicenseType {
  LicensePackageStarter,
  LicensePackagePro,
  LicensePackageChain,
  LicensePackageTrial
}

extension ELicenseTypeExt on ELicenseType {
  String get toValue {
    switch (this) {
      case ELicenseType.LicensePackageStarter:
        return "MSHOP.STA";
      case ELicenseType.LicensePackagePro:
        return "MSHOP.PRO";
      case ELicenseType.LicensePackageChain:
        return "MSHOP.CHA";
      case ELicenseType.LicensePackageTrial:
        return "MSHOP.TRL";
      default:
        return null;
    }
  }

  static ELicenseType valueOf(String value) {
    switch (value) {
      case "MSHOP.TRL":
        return ELicenseType.LicensePackageTrial;
      case "MSHOP.CHA":
        return ELicenseType.LicensePackageChain;
      case "MSHOP.PRO":
        return ELicenseType.LicensePackagePro;
      case "MSHOP.STA":
        return ELicenseType.LicensePackageStarter;
      default:
        return null;
    }
  }
}
