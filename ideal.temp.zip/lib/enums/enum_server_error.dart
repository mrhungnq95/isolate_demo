///
/// Enum
///
enum EServerError {
  none,//	Không có lỗi
  apiParameterNullOrInvalid,//Tham số khi gọi API bị null hoặc không đúng định dạng (null CompanyCode, null BranchID)
  systemIsMaintain,//	Hệ thống đang bảo trì
  tokenInvalid,//	Token không hợp lệ
  pushDataToQueueFail,//	Xảy ra lỗi khi push dữ liệu sang queue
  duplicate,//	Lỗi trùng khóa khi cất
  contraint,//	Phát sinh data Create by:dvthang:25.05.2017
  outOfRange,//	Giá trị vượt quá quy định
  usernameInvalid,//	User không hợp lệ
  emailNotFound,//	Email không tồn tại
  deadlock,//	Giao dịch bị deadlock
  recordNotExist,
  duplicateSKUCode,
  duplicateBarCode,
  passwordNotFollowStandard,
  oldPasswordNotMatch,
  internalServerError,
  arisen,
  auditProcessBefore, // khi gộp phiếu mà phiếu chọn gộp đã được xử lí
  auditMergeBefore,// khi gộp phiếu mà phiếu chọn gộp đã được gộp với phiếu khác
  deleted, // khi gộp phiếu mà phiếu chọn gộp đã bị xóa
  outwardNotExist, // Phiếu xuất kho không tồn tại
  contraintSerial, // Phát sinh data serial
  warningInward,
}

extension EServerErrorExtension on EServerError {

  static EServerError fromValue(int value) {
    switch (value) {
      case 0:
        return EServerError.none;
      case 1:
        return EServerError.apiParameterNullOrInvalid;
      case 2:
        return EServerError.systemIsMaintain;
      case 3:
        return EServerError.tokenInvalid;
      case 4:
        return EServerError.pushDataToQueueFail;
      case 5:
        return EServerError.duplicate;
      case 6:
        return EServerError.contraint;
      case 7:
        return EServerError.outOfRange;
      case 8:
        return EServerError.usernameInvalid;
      case 9:
        return EServerError.emailNotFound;
      case 10:
        return EServerError.deadlock;
      case 11:
        return EServerError.recordNotExist;
      case 12:
        return EServerError.duplicateSKUCode;
      case 13:
        return EServerError.duplicateBarCode;
      case 200:
        return EServerError.passwordNotFollowStandard;
      case 201:
        return EServerError.oldPasswordNotMatch;
      case 300:
        return EServerError.internalServerError;
      case 22:
        return EServerError.arisen;
      case 28:
        return EServerError.auditProcessBefore;
      case 29:
        return EServerError.auditMergeBefore;
      case 30:
        return EServerError.deleted;
      case 23:
        return EServerError.outwardNotExist;
      case 24:
        return EServerError.contraintSerial;
      case 405:
        return EServerError.warningInward;
      default:
        return EServerError.none;
    }
  }

  int get value {
    switch (this) {
      case EServerError.none:
        return 0;
      case EServerError.apiParameterNullOrInvalid:
        return 1;
      case EServerError.systemIsMaintain:
        return 2;
      case EServerError.tokenInvalid:
        return 3;
      case EServerError.pushDataToQueueFail:
        return 4;
      case EServerError.duplicate:
        return 5;
      case EServerError.contraint:
        return 6;
      case EServerError.outOfRange:
        return 7;
      case EServerError.usernameInvalid:
        return 8;
      case EServerError.emailNotFound:
        return 9;
      case EServerError.deadlock:
        return 10;
      case EServerError.recordNotExist:
        return 11;
      case EServerError.duplicateSKUCode:
        return 12;
      case EServerError.duplicateBarCode:
        return 13;
      case EServerError.passwordNotFollowStandard:
        return 200;
      case EServerError.oldPasswordNotMatch:
        return 201;
      case EServerError.internalServerError:
        return 300;
      case EServerError.arisen:
        return 22;
      case EServerError.auditProcessBefore:
        return 28;
      case EServerError.auditMergeBefore:
        return 29;
      case EServerError.deleted:
        return 30;
      case EServerError.outwardNotExist:
        return 23;
      case EServerError.contraintSerial:
        return 24;
      case EServerError.warningInward:
        return 405;
      default:
        return 0;
    }
  }
}
