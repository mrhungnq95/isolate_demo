/// Enum key dboption
enum EDBOptionKey {
  // Có sử dụng đơn vị chuyển đổi không
  isUseUnitConvert,
// Bắt đầu sử dụng
  isGettingStarted,
// Loại hình cửa hàng: 1 - Cửa hàng đơn, 2 - Chuỗi cửa hàng
  shopType,
//
  shopName,
//
  shopAddress,
//
  shopTel,
//
  shopEmail,
//
  shopMaster,
//
  shopGender,
// Cho phép thu ngân tặng sản phẩm/giảm giá trực tiếp khi thu tiền
  isAllowCashierDiscount,
//
  gettingStarted,
// Quốc gia
  shopCountry,
// Tỉnh/Thành phố
  shopProvince,
// Số chữ hàng thập phân (Số lượng)
  quantityDecimalDigits,
// Danh sách mệnh giá tiền mang đi có thiết lập
  denominationHasConfig,
// Danh sách mệnh giá tiền mang đi
  denomination,
// Hiển thị số tiền viết tắt
  isAbbreviateCurrency,
// Loại tiền
  mainCurrency,
// Ký hiệu tiền
  symbolCurrency,
// Vị trí hiển thị của ký hiệu tiền
  positionCurrency,
// Dấu ngăn cách hàng thập phân
  generalDecimalSeparator,
// Dấu ngăn cách hàng nghìn
  generalGroupSeparator,
// Cách hiển thị số âm
  numberNegativePattern,
// Số chữ hàng thập phân (Đơn giá)
  unitPriceDecimalDigits,
// Số chữ số hàng thập phân (Thành tiền)
  amountDecimalDigits,
// Số chữ số hàng thập phân (Hệ số/Tỷ lệ)
  coefficientDecimalDigits,
// Hiển thị số tiền viết tắt
  abbreviateCurrency,
// 0-Chỉ in tên cửa hàng, 1-chỉ in logo, 2-In cả 2
  printDisplayLogo,
// Logo nhà hàng
  printResourceLogo,
// Độ rộng logo mẫu 58
  printLogoWidth58,
// Độ rộng logo mẫu 80
  printLogoWidth80,
// Huyện/Thị trấn
  shopDistrict,
// Xã/Phường
  shopWardOrCommune,
// Đường
  shopStreet,
// Mã số thuế
  shopTaxCode,
// Độ rộng logo mẫu A5
  printLogoWidthA5,
// Vị trí của logo so với tiêu đề hóa đơn (1- Trái, 2- Phải, 3- Trên, 4- Dưới)
  printLogoPosition,
// Số lượng liên
  printQuantityLeaf,
// Font chữ của Tên cửa hàng mẫu 58
  printShopNameFont58,
// Font chữ của Tên cửa hàng mẫu 80
  printShopNameFont80,
// Font chữ của Tên cửa hàng mẫu A5
  printShopNameFontA5,
// Thông tin bổ sung
  printShopInfo,
// Font chữ của Thông tin bổ sung mẫu 58
  printShopInfoFont58,
// Font chữ của Thông tin bổ sung mẫu 80
  printShopInfoFont80,
// Font chữ của Thông tin bổ sung mẫu A5
  printShopInfoFontA5,
// Font chữ nội dung của mẫu 58
  printContentFont58,
// Font chữ nội dung của mẫu 80
  printContentFont80,
// Font chữ nội dung của mẫu A5
  printContentFontA5,
// Hiển thị giờ thanh toán
  printShowTimePayment,
// Hiển thị số thứ tụ hàng hóa trong hóa đơn
  printShowNumber,
// Hiển thị thông tin khách hàng
  printShowCustomerInfo,
// Hiển thị đường phân cách giữa các dòng
  printShowRowLine,
// Hiển thị đường phân cách giữa các cột
  printShowColumnLine,
// Font chữ cho chân hóa đơn mẫu 58
  printFooterFont58,
// Font chữ cho chân hóa đơn mẫu 80
  printFooterFont80,
// Font chữ cho chân hóa đơn mẫu A5
  printFooterFontA5,
// Nội dung chân hóa đơn
  printFooterContent,
// Hiển thị nhân viên bán hàng
  printShowSalesPerson,
// Cửa hàng truy cập gần nhất
  lastBranchID,
// Thiết lập cho phép tra cứu tồn kho của cửa hàng khác trong chuỗi
  isAllowSearchingInventoryItemOfOtherStoreInChain,
// có cho thay đổi thuế vat hay giảm giá khi nhập hàng hay không
  isDiscountAmountDisplayed,
// Kiểm tra thiết lập danh mục
// OptionID = ShareMode
// 1: dùng chung toàn chuỗi
// 2: dùng riêng cho từng cửa hàng
  shareMode,
// Cửa hàng có cho xuất kho âm trên BE không?
  outwardExceedInstock,
// Cửa hàng có cho xuất kho âm trên BE không? (với trường hợp lô/hsd)
  outwardExceedInstockByLot,
// thiết lập quản lý theo lô - hsd
  isUseLotNo,
// thiết lập quản lý theo serial - imei
  isUseSerial,
  timeZoneID,
  timeZoneValue,
  timeZoneCode,
  isUseStockLocation,
// Có sử dụng 5shop hay không?
  isUseMembership,
}

extension EDBOptionKeyEXT on EDBOptionKey {
  String get value {
    switch (this) {
      case EDBOptionKey.isUseUnitConvert:
        return "IsUseUnitConvert";

      case EDBOptionKey.isGettingStarted:
        return "IsGettingStarted";

      case EDBOptionKey.shopType:
        return "ShopType";

      case EDBOptionKey.shopName:
        return "ShopName";

      case EDBOptionKey.shopAddress:
        return "ShopAddress";

      case EDBOptionKey.shopTel:
        return "ShopTel";

      case EDBOptionKey.shopEmail:
        return "ShopEmail";

      case EDBOptionKey.shopMaster:
        return "ShopMaster";

      case EDBOptionKey.shopGender:
        return "ShopGender";

      case EDBOptionKey.isAllowCashierDiscount:
        return "IsAllowCashierDiscount";

      case EDBOptionKey.gettingStarted:
        return "GettingStarted";

      case EDBOptionKey.shopCountry:
        return "ShopCountry";

      case EDBOptionKey.shopProvince:
        return "ShopProvince";

      case EDBOptionKey.quantityDecimalDigits:
        return "QuantityDecimalDigits";

      case EDBOptionKey.denominationHasConfig:
        return "DenominationHasConfig";

      case EDBOptionKey.denomination:
        return "Denomination";

      case EDBOptionKey.isAbbreviateCurrency:
        return "IsAbbreviateCurrency";

      case EDBOptionKey.mainCurrency:
        return "MainCurrency";

      case EDBOptionKey.symbolCurrency:
        return "SymbolCurrency";

      case EDBOptionKey.positionCurrency:
        return "PositionCurrency";

      case EDBOptionKey.generalDecimalSeparator:
        return "GeneralDecimalSeparator";

      case EDBOptionKey.generalGroupSeparator:
        return "GeneralGroupSeparator";

      case EDBOptionKey.numberNegativePattern:
        return "NumberNegativePattern";

      case EDBOptionKey.unitPriceDecimalDigits:
        return "UnitPriceDecimalDigits";

      case EDBOptionKey.amountDecimalDigits:
        return "AmountDecimalDigits";

      case EDBOptionKey.coefficientDecimalDigits:
        return "CoefficientDecimalDigits";

      case EDBOptionKey.abbreviateCurrency:
        return "AbbreviateCurrency";

      case EDBOptionKey.printDisplayLogo:
        return "PrintDisplayLogo";

      case EDBOptionKey.printResourceLogo:
        return "PrintResourceLogo";

      case EDBOptionKey.printLogoWidth58:
        return "PrintLogoWidth58";

      case EDBOptionKey.printLogoWidth80:
        return "PrintLogoWidth80";

      case EDBOptionKey.shopDistrict:
        return "ShopDistrict";

      case EDBOptionKey.shopWardOrCommune:
        return "ShopWardOrCommune";

      case EDBOptionKey.shopStreet:
        return "ShopStreet";

      case EDBOptionKey.shopTaxCode:
        return "ShopTaxCode";

      case EDBOptionKey.printLogoWidthA5:
        return "PrintLogoWidthA5";

      case EDBOptionKey.printLogoPosition:
        return "PrintLogoPosition";

      case EDBOptionKey.printQuantityLeaf:
        return "PrintQuantityLeaf";

      case EDBOptionKey.printShopNameFont58:
        return "PrintShopNameFont58";

      case EDBOptionKey.printShopNameFont80:
        return "PrintShopNameFont80";

      case EDBOptionKey.printShopNameFontA5:
        return "PrintShopNameFontA5";

      case EDBOptionKey.printShopInfo:
        return "PrintShopInfo";

      case EDBOptionKey.printShopInfoFont58:
        return "PrintShopInfoFont58";

      case EDBOptionKey.printShopInfoFont80:
        return "PrintShopInfoFont80";

      case EDBOptionKey.printShopInfoFontA5:
        return "PrintShopInfoFontA5";

      case EDBOptionKey.printContentFont58:
        return "PrintContentFont58";

      case EDBOptionKey.printContentFont80:
        return "PrintContentFont80";

      case EDBOptionKey.printContentFontA5:
        return "PrintContentFontA5";

      case EDBOptionKey.printShowTimePayment:
        return "PrintShowTimePayment";

      case EDBOptionKey.printShowNumber:
        return "PrintShowNumber";

      case EDBOptionKey.printShowCustomerInfo:
        return "PrintShowCustomerInfo";

      case EDBOptionKey.printShowRowLine:
        return "PrintShowRowLine";

      case EDBOptionKey.printShowColumnLine:
        return "PrintShowColumnLine";

      case EDBOptionKey.printFooterFont58:
        return "PrintFooterFont58";

      case EDBOptionKey.printFooterFont80:
        return "PrintFooterFont80";

      case EDBOptionKey.printFooterFontA5:
        return "PrintFooterFontA5";

      case EDBOptionKey.printFooterContent:
        return "PrintFooterContent";

      case EDBOptionKey.printShowSalesPerson:
        return "PrintShowSalesPerson";

      case EDBOptionKey.lastBranchID:
        return "LastBranchID";

      case EDBOptionKey.isAllowSearchingInventoryItemOfOtherStoreInChain:
        return "IsAllowSearchingInventoryItemOfOtherStoreInChain";

      case EDBOptionKey.isDiscountAmountDisplayed:
        return "IsDiscountAmountDisplayed";

      case EDBOptionKey.shareMode:
        return "ShareMode";

      case EDBOptionKey.outwardExceedInstock:
        return "OutwardExceedInstock";

      case EDBOptionKey.outwardExceedInstockByLot:
        return "OutwardExceedInstockByLot";

      case EDBOptionKey.isUseLotNo:
        return "IsUseLotNo";

      case EDBOptionKey.isUseSerial:
        return "IsUseSerial";

      case EDBOptionKey.timeZoneID:
        return "TimeZoneID";

      case EDBOptionKey.timeZoneValue:
        return "TimeZoneValue";

      case EDBOptionKey.timeZoneCode:
        return "TimeZoneCode";

      case EDBOptionKey.isUseStockLocation:
        return "IsUseStockLocation";

      case EDBOptionKey.isUseMembership:
        return "IsUseMembership";
        break;
    }
    return '';
  }
}
