enum EInventoryItemSortType { name, sku, price }

extension EInventoryItemSortTypeExt on EInventoryItemSortType {

  static EInventoryItemSortType valueOf(int value) {
    switch (value) {
      case 1:
        return EInventoryItemSortType.name;
      case 2:
        return EInventoryItemSortType.sku;
      case 3:
        return EInventoryItemSortType.price;
      default:
        return EInventoryItemSortType.name;
    }
  }

  String getTitle() {
    switch (this) {
      case EInventoryItemSortType.name:
        return "Tên";
      case EInventoryItemSortType.sku:
        return "Sku";
      case EInventoryItemSortType.price:
        return "Giá";
      default:
        return "";
    }
  }

  int get value {
    switch (this) {
      case EInventoryItemSortType.name:
        return 1;
      case EInventoryItemSortType.sku:
        return 2;
      case EInventoryItemSortType.price:
        return 3;
    }
  }
}
