enum ESortBestSeller { byName, byRevenue, bySellNumber }

extension ESortBestSellerExt on ESortBestSeller {
  String getTitle() {
    switch (this) {
      case ESortBestSeller.byName:
        return "Theo tên";
      case ESortBestSeller.byRevenue:
        return "Doanh thu";
      case ESortBestSeller.bySellNumber:
        return "Số lượng bán";
      default:
        return "";
    }
  }
}
