import 'package:MShopManager/app/resources/resources.dart';

enum EPaymentMethod {
  cash, // Tiền mặt
  transter, // Chuyển khoản
  deposits // Tiền gửi
}

extension EEPaymentMethodExt on EPaymentMethod {
  String get title {
    switch (this) {
      case EPaymentMethod.cash:
        return 'Tiền mặt';
      case EPaymentMethod.transter:
        return 'Chuyển khoản';
      case EPaymentMethod.deposits:
        return 'Ghi nợ';
      default:
        return '';
    }
  }

  String get imageName {
    switch (this) {
      case EPaymentMethod.cash:
        return AppResources.icCashPayment;
      case EPaymentMethod.transter:
        return AppResources.icCardPayment;
      case EPaymentMethod.deposits:
        return AppResources.icPinkCash;
      default:
        return '';
    }
  }
}
