import 'package:MShopManager/enums/enum_report_period_type.dart';

/// Kỳ báo cáo
enum ETimePeriod {
  today,
  yesterday,
  thisWeek,
  lastWeek,
  thisMonth,
  lastMonth,
  thisYear,
  lastYear,
  custom
}

extension ETimePeriodEXT on ETimePeriod {
  static ETimePeriod fromValue(int value) {
    switch (value) {
      case 0:
        return ETimePeriod.today;
      case 1:
        return ETimePeriod.yesterday;
      case 2:
        return ETimePeriod.thisWeek;
      case 3:
        return ETimePeriod.lastWeek;
      case 4:
        return ETimePeriod.thisMonth;
      case 5:
        return ETimePeriod.lastMonth;
      case 6:
        return ETimePeriod.thisYear;
      case 7:
        return ETimePeriod.lastYear;
      case 8:
        return ETimePeriod.custom;
      default:
        return ETimePeriod.today;
    }
  }

  int get value {
    switch (this) {
      case ETimePeriod.today:
        return 0;
      case ETimePeriod.yesterday:
        return 1;
      case ETimePeriod.thisWeek:
        return 2;
      case ETimePeriod.lastWeek:
        return 3;
      case ETimePeriod.thisMonth:
        return 4;
      case ETimePeriod.lastMonth:
        return 5;
      case ETimePeriod.thisYear:
        return 6;
      case ETimePeriod.lastYear:
        return 7;
      case ETimePeriod.custom:
        return 8;
    }
  }

  String getTitle() {
    switch (this) {
      case ETimePeriod.today:
        return 'Hôm nay';
      case ETimePeriod.yesterday:
        return 'Hôm qua';
      case ETimePeriod.thisWeek:
        return 'Tuần này';
      case ETimePeriod.lastWeek:
        return 'Tuần trước';
      case ETimePeriod.thisMonth:
        return 'Tháng này';
      case ETimePeriod.lastMonth:
        return 'Tháng trước';
      case ETimePeriod.thisYear:
        return 'Năm này';
      case ETimePeriod.lastYear:
        return 'Năm trước';
      case ETimePeriod.custom:
        return 'Khác';
    }
    return '';
  }

  EReportPeriodType getPeriodType() {
    switch (this) {
      case ETimePeriod.today:
        return EReportPeriodType.thisDay;
      case ETimePeriod.yesterday:
        return EReportPeriodType.yesterday;
      case ETimePeriod.thisWeek:
        return EReportPeriodType.thisWeek;
      case ETimePeriod.lastWeek:
        return EReportPeriodType.lastWeek;
      case ETimePeriod.thisMonth:
        return EReportPeriodType.thisMonth;
      case ETimePeriod.lastMonth:
        return EReportPeriodType.lastMonth;
      case ETimePeriod.thisYear:
        return EReportPeriodType.thisYear;
      case ETimePeriod.lastYear:
        return EReportPeriodType.lastYear;
      case ETimePeriod.custom:
        return EReportPeriodType.custom;
        break;
    }
  }
}
