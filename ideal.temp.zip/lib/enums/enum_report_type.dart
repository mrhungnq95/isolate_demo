
import 'package:MShopManager/app/resources/resources.dart';

/// Enum Các Chức năng màn hình báo cáo
enum EReportType {
  BUSINESS,
  REVENUE,
  REVENUE_EXPEND,
  INVENTORY,
  INVENTORY_BY_LOT_DATE,
  DEBT,
  BEST_SELLER,
}

extension EReportTypeExt on EReportType {
  String getTitle() {
    switch (this) {
      case EReportType.BUSINESS:
        return 'Kinh doanh';
      case EReportType.REVENUE:
        return 'Doanh thu';
      case EReportType.REVENUE_EXPEND:
        return 'Thu, chi';
      case EReportType.INVENTORY:
        return 'Tồn kho';
      case EReportType.INVENTORY_BY_LOT_DATE:
        return 'Tồn kho theo lô-HSD';
      case EReportType.DEBT:
        return 'Công nợ';
      case EReportType.BEST_SELLER:
        return 'Hàng hoá';
    }
    return '';
  }

  String getIconPath() {
    switch (this) {
      case EReportType.BUSINESS:
        return AppResources.icBusinessStatus;
      case EReportType.REVENUE:
        return AppResources.icRevenue;
      case EReportType.REVENUE_EXPEND:
        return AppResources.icRevenueExpend;
      case EReportType.INVENTORY:
        return AppResources.icInventoryItem;
      case EReportType.INVENTORY_BY_LOT_DATE:
        return AppResources.icInventoryItemByDate;
      case EReportType.DEBT:
        return AppResources.icCod;
      case EReportType.BEST_SELLER:
        return AppResources.icMerchandise;
      default:
        return AppResources.icColumnChart;
    }
  }
}
