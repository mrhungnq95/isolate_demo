enum ERevenueDrawViewType { header, chart, items, property }
