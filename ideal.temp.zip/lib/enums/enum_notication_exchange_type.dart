enum ENoticationExchangeType {
  more, // Đổi trả thu thêm
  reduceDebt, // Đổi trả giảm nợ
  refund // Đổi trả trả lại tiền
}

extension ENoticationExchangeTypeExt on ENoticationExchangeType {
  static ENoticationExchangeType valueOf(int value) {
    switch (value) {
      case 0:
        return ENoticationExchangeType.more;
      case 1:
        return ENoticationExchangeType.reduceDebt;
      case 2:
        return ENoticationExchangeType.refund;
    }
  }
}
