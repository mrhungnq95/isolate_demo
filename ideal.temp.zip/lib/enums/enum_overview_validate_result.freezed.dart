// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'enum_overview_validate_result.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$OverviewValidateResultTearOff {
  const _$OverviewValidateResultTearOff();

// ignore: unused_element
  OK ok() {
    return const OK();
  }

// ignore: unused_element
  CustomizeDateIsNull customizeDateIsNull() {
    return const CustomizeDateIsNull();
  }

// ignore: unused_element
  FromDateIsNull fromDateIsNull() {
    return const FromDateIsNull();
  }

// ignore: unused_element
  ToDateIsNull toDateIsNull() {
    return const ToDateIsNull();
  }

// ignore: unused_element
  PrevFromDateIsNull prevFromDateIsNull() {
    return const PrevFromDateIsNull();
  }

// ignore: unused_element
  PrevToDateIsNull prevToDateIsNull() {
    return const PrevToDateIsNull();
  }
}

/// @nodoc
// ignore: unused_element
const $OverviewValidateResult = _$OverviewValidateResultTearOff();

/// @nodoc
mixin _$OverviewValidateResult {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $OverviewValidateResultCopyWith<$Res> {
  factory $OverviewValidateResultCopyWith(OverviewValidateResult value,
          $Res Function(OverviewValidateResult) then) =
      _$OverviewValidateResultCopyWithImpl<$Res>;
}

/// @nodoc
class _$OverviewValidateResultCopyWithImpl<$Res>
    implements $OverviewValidateResultCopyWith<$Res> {
  _$OverviewValidateResultCopyWithImpl(this._value, this._then);

  final OverviewValidateResult _value;
  // ignore: unused_field
  final $Res Function(OverviewValidateResult) _then;
}

/// @nodoc
abstract class $OKCopyWith<$Res> {
  factory $OKCopyWith(OK value, $Res Function(OK) then) =
      _$OKCopyWithImpl<$Res>;
}

/// @nodoc
class _$OKCopyWithImpl<$Res> extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $OKCopyWith<$Res> {
  _$OKCopyWithImpl(OK _value, $Res Function(OK) _then)
      : super(_value, (v) => _then(v as OK));

  @override
  OK get _value => super._value as OK;
}

/// @nodoc
class _$OK implements OK {
  const _$OK();

  @override
  String toString() {
    return 'OverviewValidateResult.ok()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is OK);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return ok();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ok != null) {
      return ok();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return ok(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ok != null) {
      return ok(this);
    }
    return orElse();
  }
}

abstract class OK implements OverviewValidateResult {
  const factory OK() = _$OK;
}

/// @nodoc
abstract class $CustomizeDateIsNullCopyWith<$Res> {
  factory $CustomizeDateIsNullCopyWith(
          CustomizeDateIsNull value, $Res Function(CustomizeDateIsNull) then) =
      _$CustomizeDateIsNullCopyWithImpl<$Res>;
}

/// @nodoc
class _$CustomizeDateIsNullCopyWithImpl<$Res>
    extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $CustomizeDateIsNullCopyWith<$Res> {
  _$CustomizeDateIsNullCopyWithImpl(
      CustomizeDateIsNull _value, $Res Function(CustomizeDateIsNull) _then)
      : super(_value, (v) => _then(v as CustomizeDateIsNull));

  @override
  CustomizeDateIsNull get _value => super._value as CustomizeDateIsNull;
}

/// @nodoc
class _$CustomizeDateIsNull implements CustomizeDateIsNull {
  const _$CustomizeDateIsNull();

  @override
  String toString() {
    return 'OverviewValidateResult.customizeDateIsNull()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is CustomizeDateIsNull);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return customizeDateIsNull();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (customizeDateIsNull != null) {
      return customizeDateIsNull();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return customizeDateIsNull(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (customizeDateIsNull != null) {
      return customizeDateIsNull(this);
    }
    return orElse();
  }
}

abstract class CustomizeDateIsNull implements OverviewValidateResult {
  const factory CustomizeDateIsNull() = _$CustomizeDateIsNull;
}

/// @nodoc
abstract class $FromDateIsNullCopyWith<$Res> {
  factory $FromDateIsNullCopyWith(
          FromDateIsNull value, $Res Function(FromDateIsNull) then) =
      _$FromDateIsNullCopyWithImpl<$Res>;
}

/// @nodoc
class _$FromDateIsNullCopyWithImpl<$Res>
    extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $FromDateIsNullCopyWith<$Res> {
  _$FromDateIsNullCopyWithImpl(
      FromDateIsNull _value, $Res Function(FromDateIsNull) _then)
      : super(_value, (v) => _then(v as FromDateIsNull));

  @override
  FromDateIsNull get _value => super._value as FromDateIsNull;
}

/// @nodoc
class _$FromDateIsNull implements FromDateIsNull {
  const _$FromDateIsNull();

  @override
  String toString() {
    return 'OverviewValidateResult.fromDateIsNull()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is FromDateIsNull);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return fromDateIsNull();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (fromDateIsNull != null) {
      return fromDateIsNull();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return fromDateIsNull(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (fromDateIsNull != null) {
      return fromDateIsNull(this);
    }
    return orElse();
  }
}

abstract class FromDateIsNull implements OverviewValidateResult {
  const factory FromDateIsNull() = _$FromDateIsNull;
}

/// @nodoc
abstract class $ToDateIsNullCopyWith<$Res> {
  factory $ToDateIsNullCopyWith(
          ToDateIsNull value, $Res Function(ToDateIsNull) then) =
      _$ToDateIsNullCopyWithImpl<$Res>;
}

/// @nodoc
class _$ToDateIsNullCopyWithImpl<$Res>
    extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $ToDateIsNullCopyWith<$Res> {
  _$ToDateIsNullCopyWithImpl(
      ToDateIsNull _value, $Res Function(ToDateIsNull) _then)
      : super(_value, (v) => _then(v as ToDateIsNull));

  @override
  ToDateIsNull get _value => super._value as ToDateIsNull;
}

/// @nodoc
class _$ToDateIsNull implements ToDateIsNull {
  const _$ToDateIsNull();

  @override
  String toString() {
    return 'OverviewValidateResult.toDateIsNull()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is ToDateIsNull);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return toDateIsNull();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (toDateIsNull != null) {
      return toDateIsNull();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return toDateIsNull(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (toDateIsNull != null) {
      return toDateIsNull(this);
    }
    return orElse();
  }
}

abstract class ToDateIsNull implements OverviewValidateResult {
  const factory ToDateIsNull() = _$ToDateIsNull;
}

/// @nodoc
abstract class $PrevFromDateIsNullCopyWith<$Res> {
  factory $PrevFromDateIsNullCopyWith(
          PrevFromDateIsNull value, $Res Function(PrevFromDateIsNull) then) =
      _$PrevFromDateIsNullCopyWithImpl<$Res>;
}

/// @nodoc
class _$PrevFromDateIsNullCopyWithImpl<$Res>
    extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $PrevFromDateIsNullCopyWith<$Res> {
  _$PrevFromDateIsNullCopyWithImpl(
      PrevFromDateIsNull _value, $Res Function(PrevFromDateIsNull) _then)
      : super(_value, (v) => _then(v as PrevFromDateIsNull));

  @override
  PrevFromDateIsNull get _value => super._value as PrevFromDateIsNull;
}

/// @nodoc
class _$PrevFromDateIsNull implements PrevFromDateIsNull {
  const _$PrevFromDateIsNull();

  @override
  String toString() {
    return 'OverviewValidateResult.prevFromDateIsNull()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is PrevFromDateIsNull);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return prevFromDateIsNull();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (prevFromDateIsNull != null) {
      return prevFromDateIsNull();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return prevFromDateIsNull(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (prevFromDateIsNull != null) {
      return prevFromDateIsNull(this);
    }
    return orElse();
  }
}

abstract class PrevFromDateIsNull implements OverviewValidateResult {
  const factory PrevFromDateIsNull() = _$PrevFromDateIsNull;
}

/// @nodoc
abstract class $PrevToDateIsNullCopyWith<$Res> {
  factory $PrevToDateIsNullCopyWith(
          PrevToDateIsNull value, $Res Function(PrevToDateIsNull) then) =
      _$PrevToDateIsNullCopyWithImpl<$Res>;
}

/// @nodoc
class _$PrevToDateIsNullCopyWithImpl<$Res>
    extends _$OverviewValidateResultCopyWithImpl<$Res>
    implements $PrevToDateIsNullCopyWith<$Res> {
  _$PrevToDateIsNullCopyWithImpl(
      PrevToDateIsNull _value, $Res Function(PrevToDateIsNull) _then)
      : super(_value, (v) => _then(v as PrevToDateIsNull));

  @override
  PrevToDateIsNull get _value => super._value as PrevToDateIsNull;
}

/// @nodoc
class _$PrevToDateIsNull implements PrevToDateIsNull {
  const _$PrevToDateIsNull();

  @override
  String toString() {
    return 'OverviewValidateResult.prevToDateIsNull()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is PrevToDateIsNull);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result ok(),
    @required Result customizeDateIsNull(),
    @required Result fromDateIsNull(),
    @required Result toDateIsNull(),
    @required Result prevFromDateIsNull(),
    @required Result prevToDateIsNull(),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return prevToDateIsNull();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result ok(),
    Result customizeDateIsNull(),
    Result fromDateIsNull(),
    Result toDateIsNull(),
    Result prevFromDateIsNull(),
    Result prevToDateIsNull(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (prevToDateIsNull != null) {
      return prevToDateIsNull();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result ok(OK value),
    @required Result customizeDateIsNull(CustomizeDateIsNull value),
    @required Result fromDateIsNull(FromDateIsNull value),
    @required Result toDateIsNull(ToDateIsNull value),
    @required Result prevFromDateIsNull(PrevFromDateIsNull value),
    @required Result prevToDateIsNull(PrevToDateIsNull value),
  }) {
    assert(ok != null);
    assert(customizeDateIsNull != null);
    assert(fromDateIsNull != null);
    assert(toDateIsNull != null);
    assert(prevFromDateIsNull != null);
    assert(prevToDateIsNull != null);
    return prevToDateIsNull(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result ok(OK value),
    Result customizeDateIsNull(CustomizeDateIsNull value),
    Result fromDateIsNull(FromDateIsNull value),
    Result toDateIsNull(ToDateIsNull value),
    Result prevFromDateIsNull(PrevFromDateIsNull value),
    Result prevToDateIsNull(PrevToDateIsNull value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (prevToDateIsNull != null) {
      return prevToDateIsNull(this);
    }
    return orElse();
  }
}

abstract class PrevToDateIsNull implements OverviewValidateResult {
  const factory PrevToDateIsNull() = _$PrevToDateIsNull;
}
