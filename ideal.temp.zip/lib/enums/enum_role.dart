enum EUserRole {
  QLHT, // 1
  QLTM, // 2
  QLC, // 3
  KT, //4
  QLKQKD, //5
  QLK, //6
  QLCP, //7
  MH, //8
  QLKM, //9
  QLCH, //10
  QLTG, //11
  QLHH, //12
  TN, //13
  NVBH, //14
}

extension EUserRoleExt on EUserRole {
  int value() {
    switch (this) {
      case EUserRole.QLHT:
        return 1;
      case EUserRole.QLTM:
        return 2;
      case EUserRole.QLC:
        return 3;
      case EUserRole.KT:
        return 4;
      case EUserRole.QLKQKD:
        return 5;
      case EUserRole.QLK:
        return 6;
      case EUserRole.QLCP:
        return 7;
      case EUserRole.MH:
        return 8;
      case EUserRole.QLKM:
        return 9;
      case EUserRole.QLCH:
        return 10;
      case EUserRole.QLTG:
        return 11;
      case EUserRole.QLHH:
        return 12;
      case EUserRole.TN:
        return 13;
      case EUserRole.NVBH:
        return 14;
      default:
        return -1;
    }
  }
}
