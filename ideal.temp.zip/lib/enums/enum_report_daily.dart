enum EReportDaily {
  cashInDay, // tiền thu trong ngày
  revenueEstimated, // doanh thu ước tính
  sainvoice, // hóa đơn
  totalCashInDay, // tổng tiền trong ngày
  customerAndInStock // Khách hàng + tồn kho
}

extension EReportDailyExt on EReportDaily {
  get rawValue {
    switch (this) {
      case EReportDaily.cashInDay:
        return 0;
      case EReportDaily.revenueEstimated:
        return 1;
      case EReportDaily.sainvoice:
        return 2;
      case EReportDaily.totalCashInDay:
        return 3;
      case EReportDaily.customerAndInStock:
        return 4;
      default:
        0;
    }
  }
}
