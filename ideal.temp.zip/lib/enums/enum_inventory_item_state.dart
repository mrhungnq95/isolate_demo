/// -1: Tất cả hàng hóa
/// 0: Ngừng kinh doanh
/// 1: Đang kinh doanh
enum EInventoryItemState { all, active, inactive }

extension EInventoryItemStateExt on EInventoryItemState {
  
  static EInventoryItemState valueOf(int value) {
    switch (value) {
      case -1:
        return EInventoryItemState.all;
      case 0:
        return EInventoryItemState.inactive;
      case 1:
        return EInventoryItemState.active;
    }
  }

  String getTitle() {
    switch (this) {
      case EInventoryItemState.all:
        return "Tất cả";
      case EInventoryItemState.active:
        return "Hàng hóa đang kinh doanh";
      case EInventoryItemState.inactive:
        return "Hàng hóa ngừng kinh doanh";
      default:
        return "";
    }
  }

  int get value {
    switch (this) {
      case EInventoryItemState.all:
        return -1;
      case EInventoryItemState.active:
        return 1;
      case EInventoryItemState.inactive:
        return 0;
    }
  }
}
