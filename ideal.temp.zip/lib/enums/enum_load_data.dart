enum ELoadDataType {
  RELOAD,
  UPDATE,
  LOAD_MORE,
  SEARCH,
}
