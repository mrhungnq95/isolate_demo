enum ESortCustomerStatus { customer_name, asc, desc }

extension ESortCustomerStatusExt on ESortCustomerStatus {
  int get rawValue {
    switch (this) {
      case ESortCustomerStatus.customer_name:
        return 1;
      case ESortCustomerStatus.asc:
        return 2;
      case ESortCustomerStatus.desc:
        return 3;
      default:
        return 1;
    }
  }

  static ESortCustomerStatus valueOf(int value) {
    switch (value) {
      case 1:
        return ESortCustomerStatus.customer_name;
      case 2:
        return ESortCustomerStatus.asc;
      case 3:
        return ESortCustomerStatus.desc;
      default:
        return ESortCustomerStatus.customer_name;
    }
  }

  String getTitle() {
    switch (this) {
      case ESortCustomerStatus.customer_name:
        return "Tên khách hàng";
      case ESortCustomerStatus.asc:
        return "Số lượng tăng dần";
      case ESortCustomerStatus.desc:
        return "Số lượng giảm dần";
      default:
        return "";
    }
  }
}
