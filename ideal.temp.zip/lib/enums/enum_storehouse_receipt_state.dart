
enum EStorehouseReceiptState {
  all,            // Tất cả
  other,          // Khác
  transfer,       // Điều chuyển
  checking,       // Kiểm kê
  returnedItem,   // Hàng trả lại
  import          // Nhập hàng
}


extension EStorehouseReceiptStateExt on EStorehouseReceiptState {

  String getTitle() {
    switch (this) {
      case EStorehouseReceiptState.all:
        return 'Tất cả';
      case EStorehouseReceiptState.other:
        return 'Khác';
      case EStorehouseReceiptState.transfer:
        return 'Điều chuyển';
      case EStorehouseReceiptState.checking:
        return 'Kiểm kê';
        case EStorehouseReceiptState.returnedItem:
        return 'Hàng trả lại';
        case EStorehouseReceiptState.import:
        return 'Nhập hàng';
        default:
        return '';
    }
  }
}

