///
/// Enum
///
enum EProviderViewType {
  all, // Tất cả
  active, // Đang theo dõi
  inActive // Ngừng theo dõi
}

extension EViewTypeExtension on EProviderViewType {

  static EProviderViewType fromValue(int value) {
    switch (value) {
      case 0:
        return EProviderViewType.active;
      case 1:
        return EProviderViewType.inActive;
      default:
        return EProviderViewType.all;
    }
  }

  int get value {
    switch (this) {
      case EProviderViewType.all:
        return -1;
      case EProviderViewType.active:
        return 0;
      case EProviderViewType.inActive:
        return 1;

      default:
        return -1;
    }
  }

  String get title {
    switch (this) {
      case EProviderViewType.all:
        return 'Tất cả';
      case EProviderViewType.active:
        return 'Đang theo dõi';
      case EProviderViewType.inActive:
        return 'Ngừng theo dõi';

      default:
        return '';
    }
  }
}
