enum EChooseTimeType { day, week, month, custom }

extension EChooseTimeTypeExt on EChooseTimeType {
  String getTitle() {
    switch (this) {
      case EChooseTimeType.day:
        return "Ngày";
      case EChooseTimeType.week:
        return "Tuần";
      case EChooseTimeType.month:
        return "Tháng";
      case EChooseTimeType.custom:
        return "Tuỳ chỉnh";
      default:
        return "";
    }
  }
}
