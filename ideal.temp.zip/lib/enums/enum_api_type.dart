//
// Created by nqhung on 10/11/2020.
//

enum EAPIType {
  AUTHENTICATION,
  DASH_BOARD, //API dành cho báo cáo Tổng quan
  MANAGEMENT, //API dành cho MỜI BẠN BÈ
  IMAGE, //API dành cho Ảnh
  EMPLOYEE, //API dành cho Employee
  DBOPTION, //API dành cho DBOption
  CHECK_VERSION, //API dành cho common
  FORGOT_PASSWORD, //API dành cho quên mật khẩu
  CHECK_EXIST_DOMAIN, //API dành cho kiểm tra domain
  FEEDBACK, //API feedback
  PU_INVOICE, //API Nhập hàng
  API_DOWNLOAD, //api download
  API_BE, //API be
  API_INVENTORY_ITEM, //API Hàng hóa
  API_MOBILES, 
  API_LOT, //Api lô
  API_SERIAL_IMEI, //Api serial/imei
  OUTWARD, // xuất kho
  MISA_ID,
  NOTIFICATION, // Thông báo
  MOBILE_INVENTORY_ITEMS, // API liên quan đến hàng hóa,
  INVENTORYITEM_CATEGORY, // API Liên quan đến danh mục hàng hóa
  UNIT, // API liên quan đến đơn vị tính của hàng hóa

}
