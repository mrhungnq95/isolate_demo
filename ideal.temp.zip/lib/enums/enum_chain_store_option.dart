enum EChainStoreOption { profit, revenue }

extension EChainStoreOptionExt on EChainStoreOption {
  String getTitle() {
    switch (this) {
      case EChainStoreOption.profit:
        return "Lợi nhuận";
      case EChainStoreOption.revenue:
        return "Doanh thu";
      default:
        return "";
    }
  }
}
