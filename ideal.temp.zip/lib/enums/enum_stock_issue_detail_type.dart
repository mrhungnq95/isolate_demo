enum EStockIssueDetailType {
  detail_by_property,
  detail_by_branch,
}