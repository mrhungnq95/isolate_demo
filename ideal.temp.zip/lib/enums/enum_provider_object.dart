///
/// Enum
///
enum EVendorObject {
  none,
  vendor, // NCC sản phẩm
  deliveryPartner // Đối tác giao hàng
}

extension EVendorObjectExtension on EVendorObject {

  static EVendorObject fromValue(int value) {
    switch (value) {
      case 1:
        return EVendorObject.vendor;
      case 2:
        return EVendorObject.deliveryPartner;
      default:
        return EVendorObject.none;
    }
  }

  int get value {
    switch (this) {
      case EVendorObject.vendor:
        return 1;
      case EVendorObject.deliveryPartner:
        return 2;
      default:
        return -1;
    }
  }
}
