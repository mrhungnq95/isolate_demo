enum ECategoryFilter { all, custom }

extension ECategoryFilterExt on ECategoryFilter {
  String getTitle() {
    switch (this) {
      case ECategoryFilter.all:
        return "Tất cả nhóm";
      case ECategoryFilter.custom:
        return "Khác";
      default:
        return "";
    }
  }
}
