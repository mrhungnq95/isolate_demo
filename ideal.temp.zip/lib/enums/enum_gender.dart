enum EGender { male, female, other }

extension EGenderExt on EGender {
  int get rawValue {
    switch (this) {
      case EGender.male:
        return 0;
      case EGender.female:
        return 1;
      case EGender.other:
        return 2;
      default:
        return 0;
    }
  }

  static EGender valueOf(int value) {
    switch (value) {
      case 0:
        return EGender.male;
      case 1:
        return EGender.female;
      case 2:
        return EGender.other;
      default:
        return EGender.male;
    }
  }

  String get title {
    switch (this) {
      case EGender.female:
        return "Nữ";
      case EGender.other:
        return "Khác";
      default:
        return "Nam";
    }
  }
}
