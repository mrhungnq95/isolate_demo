enum ENoticationInvoiceType {
  newInvoice, // lập hoá đơn
  compensationInvoice, // nhập bù hoá đơn
  deliveryInvoice //hoá đơn giao hàng
}

extension ENoticationInvoiceTypeExt on ENoticationInvoiceType {
  static ENoticationInvoiceType valueOf(int value) {
    switch (value) {
      case 0:
        return ENoticationInvoiceType.newInvoice;
      case 1:
        return ENoticationInvoiceType.compensationInvoice;
      case 2:
        return ENoticationInvoiceType.deliveryInvoice;
    }
  }
}
