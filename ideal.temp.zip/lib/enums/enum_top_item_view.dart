//
// Created by nqhung on 09/11/2020.
//

enum ETopItemView { top10, top15, top20 }