enum EReportItemCode {
  sale,
  receive_amount,
  deposit_amount,
  receipt_other,
  invoice_pay,
  invoice_process,
  at_branch,
  delivery,
  cash_amount,
  card_amount,
  tranfer_amount,
  voucher_amount,
  receipt_amount,
  debit_amount,
  rent_collector_amount,
  unpaid_amount,
  not_delivery_amount,
  delivery_amount,
  receive_cod_amount,
  paid_amount,
  cancel_amount,
  finish_amount,
  fail_amount,
  converting_amount,
  in_stock,
  customer
}

extension EReportItemCodeExt on EReportItemCode {
  String getTitle() {
    switch (this) {
      case EReportItemCode.sale:
        return "Bán hàng";
      case EReportItemCode.receive_amount:
        return "Thu nợ";
      case EReportItemCode.deposit_amount:
        return "Khách đặt cọc";
      case EReportItemCode.receipt_other:
        return "Thu khác";
      case EReportItemCode.invoice_pay:
        return "Hoá đơn đã thanh toán";
      case EReportItemCode.invoice_process:
        return "Hoá đơn đang xử lý";
      case EReportItemCode.at_branch:
        return "Tại cửa hàng";
      case EReportItemCode.delivery:
        return "Đang giao hàng";
      case EReportItemCode.cash_amount:
        return "Tiền mặt";
      case EReportItemCode.card_amount:
        return "Thẻ";
      case EReportItemCode.tranfer_amount:
        return "Chuyển khoản";
      case EReportItemCode.voucher_amount:
        return "Voucher";
      case EReportItemCode.receipt_amount:
        return "Đã thu được tiền";
      case EReportItemCode.debit_amount:
        return "Khách nợ";
      case EReportItemCode.rent_collector_amount:
        return "Thu hộ";
      case EReportItemCode.unpaid_amount:
        return "Chờ thanh toán";
      case EReportItemCode.not_delivery_amount:
        return "Chờ giao hàng";
      case EReportItemCode.delivery_amount:
        return "Đang giao hàng";
      case EReportItemCode.paid_amount:
        return "Đã thanh toán";
      case EReportItemCode.cancel_amount:
        return "Đã huỷ";
      case EReportItemCode.finish_amount:
        return "Đã thanh toán";
      case EReportItemCode.fail_amount:
        return "Thất bại";
      case EReportItemCode.converting_amount:
        return "Đã chuyển hoàn";
      default:
        return "";
    }
  }

  get rawValue {
    switch (this) {
      case EReportItemCode.sale:
        return "Sale";
      case EReportItemCode.receive_amount:
        return "ReceiveAmount";
      case EReportItemCode.deposit_amount:
        return "DepositAmount";
      case EReportItemCode.receipt_other:
        return "ReceiptOther";
      case EReportItemCode.invoice_pay:
        return "InvoicePay";
      case EReportItemCode.invoice_process:
        return "InvoiceProcess";
      case EReportItemCode.at_branch:
        return "AtBranch";
      case EReportItemCode.delivery:
        return "Delivery";
      case EReportItemCode.cash_amount:
        return "CashAmount";
      case EReportItemCode.card_amount:
        return "CardAmount";
      case EReportItemCode.tranfer_amount:
        return "TranferAmount";
      case EReportItemCode.voucher_amount:
        return "VoucherAmount";
      case EReportItemCode.receipt_amount:
        return "ReceiptAmount";
      case EReportItemCode.debit_amount:
        return "DebitAmount";
      case EReportItemCode.rent_collector_amount:
        return "RentCollectorAmount";
      case EReportItemCode.unpaid_amount:
        return "UnpaidAmount";
      case EReportItemCode.not_delivery_amount:
        return "NotDeliveryAmount";
      case EReportItemCode.delivery_amount:
        return "DeliveryAmount";
      case EReportItemCode.receive_cod_amount:
        return "ReceiveCODAmount";
      case EReportItemCode.paid_amount:
        return "PaidAmount";
      case EReportItemCode.cancel_amount:
        return "CancelAmount";
      case EReportItemCode.finish_amount:
        return "FinishAmount";
      case EReportItemCode.fail_amount:
        return "FailAmount";
      case EReportItemCode.converting_amount:
        return "ConvertingAmount";
      case EReportItemCode.in_stock:
        return "InStock";
      case EReportItemCode.customer:
        return "Customer";
      default:
        return "";
    }
  }

  static EReportItemCode valueOf(String value) {
    switch (value) {
      case "Sale":
        return EReportItemCode.sale;
      case "ReceiveAmount":
        return EReportItemCode.receive_amount;
      case "DepositAmount":
        return EReportItemCode.deposit_amount;
      case "ReceiptOther":
        return EReportItemCode.receipt_other;
      case "InvoicePay":
        return EReportItemCode.invoice_pay;
      case "InvoiceProcess":
        return EReportItemCode.invoice_process;
      case "AtBranch":
        return EReportItemCode.at_branch;
      case "Delivery":
        return EReportItemCode.delivery;
      case "CashAmount":
        return EReportItemCode.cash_amount;
      case "CardAmount":
        return EReportItemCode.card_amount;
      case "TranferAmount":
        return EReportItemCode.tranfer_amount;
      case "VoucherAmount":
        return EReportItemCode.voucher_amount;
      case "ReceiptAmount":
        return EReportItemCode.receipt_amount;
      case "DebitAmount":
        return EReportItemCode.debit_amount;
      case "RentCollectorAmount":
        return EReportItemCode.rent_collector_amount;
      case "UnpaidAmount":
        return EReportItemCode.unpaid_amount;
      case "NotDeliveryAmount":
        return EReportItemCode.not_delivery_amount;
      case "DeliveryAmount":
        return EReportItemCode.delivery_amount;
      case "ReceiveCODAmount":
        return EReportItemCode.receive_cod_amount;
      case "PaidAmount":
        return EReportItemCode.paid_amount;
      case "CancelAmount":
        return EReportItemCode.cancel_amount;
      case "FinishAmount":
        return EReportItemCode.finish_amount;
      case "FailAmount":
        return EReportItemCode.fail_amount;
      case "ConvertingAmount":
        return EReportItemCode.converting_amount;
      case "InStock":
        return EReportItemCode.in_stock;
      case "Customer":
        return EReportItemCode.customer;
      default:
        return null;
    }
  }
}
