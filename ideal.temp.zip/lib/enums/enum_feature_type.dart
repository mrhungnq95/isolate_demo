import 'package:MShopManager/app/resources/resources.dart';

enum EFeatureType {
  /// Nhập hàng
  /// Trả lại hàng mua
  /// Nhập Kho
  /// Xuất kho
  /// Kiểm kê
  /// Hàng hoá
  /// Khách hàng
  /// Nhà cung cấp
  /// Quỹ tiền
  /// Khuyễn mãi
  ///
  import_items,
  return_items,
  store_house,
  stock_issue,
  checking,
  items,
  customer,
  promotion,
  balance,
  provider,
  order_online,
  order_ocm,
  other
}

extension EFeatureTypeExt on EFeatureType {
  int get rawValue {
    switch (this) {
      case EFeatureType.import_items:
        return 1;
      case EFeatureType.return_items:
        return 2;
      case EFeatureType.store_house:
        return 3;
      case EFeatureType.stock_issue:
        return 4;
      case EFeatureType.checking:
        return 5;
      case EFeatureType.items:
        return 6;
      case EFeatureType.customer:
        return 7;
      case EFeatureType.promotion:
        return 8;
      case EFeatureType.balance:
        return 9;
      case EFeatureType.provider:
        return 10;
      case EFeatureType.order_online:
        return 11;
      case EFeatureType.order_ocm:
        return 12;
      case EFeatureType.other:
        return 0;
      default:
        return -1;
    }
  }

  static EFeatureType valueOf(int value) {
    switch (value) {
      case 0:
        return EFeatureType.other;
      case 1:
        return EFeatureType.import_items;
      case 2:
        return EFeatureType.return_items;
      case 3:
        return EFeatureType.store_house;
      case 4:
        return EFeatureType.stock_issue;
      case 5:
        return EFeatureType.checking;
      case 6:
        return EFeatureType.items;
      case 7:
        return EFeatureType.customer;
      case 8:
        return EFeatureType.promotion;
      case 9:
        return EFeatureType.balance;
      case 10:
        return EFeatureType.provider;
      case 11:
        return EFeatureType.order_online;
      case 12:
        return EFeatureType.order_ocm;
      default:
        return null;
    }
  }

  String getTitle() {
    switch (this) {
      case EFeatureType.import_items:
        return "Nhập hàng";
      case EFeatureType.return_items:
        return "Trả lại hàng mua";
      case EFeatureType.store_house:
        return "Nhập Kho";
      case EFeatureType.stock_issue:
        return "Xuất kho";
      case EFeatureType.checking:
        return "Kiểm kê";
      case EFeatureType.items:
        return "Hàng hoá";
      case EFeatureType.customer:
        return "Khách hàng";
      case EFeatureType.provider:
        return "Nhà cung cấp";
      case EFeatureType.balance:
        return "Quỹ tiền";
      case EFeatureType.promotion:
        return "Khuyễn mãi";
      case EFeatureType.order_ocm:
        return "Đơn từ MISA OCM";
      case EFeatureType.order_online:
        return "Đơn từ web";
      default:
        return "";
    }
  }

  String getIconPath() {
    switch (this) {
      case EFeatureType.import_items:
        return AppResources.icItemDown;
      case EFeatureType.return_items:
        return AppResources.icItemUp;
      case EFeatureType.store_house:
        return AppResources.icStorage;
      case EFeatureType.stock_issue:
        return AppResources.icStorageUp;
      case EFeatureType.checking:
        return AppResources.icStorageCheck;
      case EFeatureType.items:
        return AppResources.icItem;
      case EFeatureType.customer:
        return AppResources.icCustomerGrey;
      case EFeatureType.provider:
        return AppResources.icDelivery;
      case EFeatureType.balance:
        return AppResources.icMoneyFill2;
      case EFeatureType.promotion:
        return AppResources.icPromotion;
      case EFeatureType.order_ocm:
        return AppResources.icOrderOcm;
      case EFeatureType.order_online:
        return AppResources.icOrderOnline;
      default:
        return "";
    }
  }
}
