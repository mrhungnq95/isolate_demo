///
/// Created by nqhung on 07/11/2020.
///

enum ERefType {
  /// Với hàng hoá quản lý theo lô, serial || refType: 1. Nhập kho 2. Xuất 3. Nhập hàng
  puInvoiceLotSerialImei,
  puReturnLotSerialImei,
  inInwardLotSerialImei,
  puInvoice,

  /// Phiếu nhập hàng công nợ
  puReturn,

  ///Trả lại hàng mua - Giảm trừ công nợ
  puInvoiceBA,

  /// Phiếu nhập hàng tiền gửi
  puInvoiceCA,

  /// Phiếu nhập hàng tiền mặt
  puReturnCA,

  /// Trả lại hàng mua - Tiền mặt
  puReturnBA,

  /// Trả lại hàng mua -Tiền gửi

  totalCost,

  /// Chi phí

  saOrder,

  /// Đơn đặt hàng gửi từ OCM
  sainvoice,
  delivery,

  ///hóa đơn giao hàng
  reinvoice,

  /// Hóa đơn lập bù
  returnInvoice,

  /// hóa đơn đổi trả

  openingInventoryEntry,

  /// Nhập số tồn kho ban đầu hàng hóa
  openingAccountObjectCustomer,

  /// nhập số công nợ khách hàng
  openingAccountObjectVendor,

  /// nhập số công nợ nhà cung cấp
  openingAccountObjectShippingPartner,

  /// nhập số công nợ đối tác giao hàng
  originalCash,

  /// số dư ban đầu tiền mặt
  originalCard,

  /// số dư ban đầu tiền gửi

  caReceipt,

  /// Phiếu thu tiền mặt mục đích Khác
  depositPayinByCash,

  /// Thu đặt cọc bằng tiền mặt
  caPayment,

  /// Phiếu chi tiền mặt mục đích Khác
  supplierPayment,

  /// /// Phiếu chi trả tiền nhà cung cấp
  caAudit,

  /// Kiểm kê tiền mặt
  customerCategory,

  /// Nhóm khách hàng
  customer,

  /// Khách hàng
  employee,

  ///  Nhân viên

  inTransfer,

  /// Chuyển kho
  inAudit,

  /// Kiểm kê
  inInward,

  /// Nhập kho
  inOutward,

  /// Xuất kho khác
  inwardAudit,

  /// Nhập kho kiểm kê
  inInwardTranfer,

  /// Nhập kho từ cửa hàng khác (điều chuyển)
  inInwardOther,

  /// Nhập kho khác
  inInwardReturn,

  /// Nhập kho tự động khi có hóa đơn trả hàng
  transferOrder,

  /// Lệnh điều chuyển
  transferOrderRequest,

  /// Yêu cầu điều chuyển
  inInwardTransferStockInBranch,

  /// Nhập kho chuyển kho từ kho trong chi nhánh

  outwardSale,

  /// Xuất kho bán hàng
  outwardCash,

  /// Phiếu trả lại hàng mua - Tiền mặt (Không dùng, => chuyển 307)
  outwardSendCash,

  /// Phiếu trả lại hàng mua - Tiền gửi(Không dùng, => chuyển 308)
  outwardSubstract,

  /// Phiếu trả lại hàng mua - Giảm trừ công nợ(Không dùng, => chuyển 304)
  outwardAudit,

  /// Phiếu xuất kho kiểm kê
  outwardTransfer,

  /// Phiếu xuất kho điều chuyển sang cửa hàng khác
  outwardOther,

  /// Phiếu xuất kho khác
  outwardTransferStockInBranch,

  /// Xuất kho chuyển kho từ trong chi nhánh

  vendorShippingPartner,

  /// Đối tác giao hàng
  vendor,

  /// Nhà cung cấp

  customerAccountObjectLedger,

  /// Công nợ khách hàng
  cashDebt,

  /// Thu nợ khách hàng bằng tiền mặt
  exchangeDebt,

  /// Thu nợ khách hàng bằng chuyển khoản
  depositPayIn,

  /// Thu tiền gửi
  depositPayOut,

  /// Chi tiền gửi
  supplierPayOut,

  /// Chi tiền gửi trả nhà cung cấp
  cardDebt,

  /// Thu nợ khách hàng bằng thẻ
  depositPayinByTransfer,

  /// Thu đặt cọc bằng chuyển khoản
  depositPayinByCard,

  /// Thu đặt cọc bằng thẻ
  codCashDebt,

  /// Thu COD đối tác giao hàng bằng tiền mặt
  codTransferDebt,

  /// Thu COD đối tác giao hàng bằng chuyển khoản
  codCardDebt,

  /// Thu COD đối tác giao hàng bằng thẻ

  depositPayOutByCash,

  /// Chi đặt cọc bằng tiền mặt
  depositPayOutByTransfer,

  /// Chi đặt cọc bằng chuyển khoản
  depositPayOutByCard,

  /// Chi đặt cọc bằng thẻ
}

extension ERefTypeExt on ERefType {
  
  get toValue {
    switch (this) {
      case ERefType.puInvoiceLotSerialImei:
        return 1;
      case ERefType.puReturnLotSerialImei:
        return 2;
      case ERefType.inInwardLotSerialImei:
        return 3;
      case ERefType.puInvoice:
        return 301;
      case ERefType.puReturn:
        return 304;
      case ERefType.puInvoiceBA:
        return 305;
      case ERefType.puInvoiceCA:
        return 306;
      case ERefType.puReturnCA:
        return 307;
      case ERefType.puReturnBA:
        return 308;
      case ERefType.totalCost:
        return 400;
      case ERefType.saOrder:
        return 549;
      case ERefType.sainvoice:
        return 550;
      case ERefType.delivery:
        return 551;
      case ERefType.reinvoice:
        return 552;
      case ERefType.returnInvoice:
        return 553;
      case ERefType.openingInventoryEntry:
        return 601;
      case ERefType.openingAccountObjectCustomer:
        return 602;
      case ERefType.openingAccountObjectVendor:
        return 603;
      case ERefType.openingAccountObjectShippingPartner:
        return 604;
      case ERefType.originalCash:
        return 605;
      case ERefType.originalCard:
        return 606;
      case ERefType.caReceipt:
        return 1010;
      case ERefType.depositPayinByCash:
        return 1014;
      case ERefType.caPayment:
        return 1020;
      case ERefType.supplierPayment:
        return 1022;
      case ERefType.caAudit:
        return 1030;
      case ERefType.customerCategory:
        return 1508;
      case ERefType.customer:
        return 1503;
      case ERefType.employee:
        return 1504;
      case ERefType.inTransfer:
        return 2093;
      case ERefType.inAudit:
        return 2060;
      case ERefType.inInward:
        return 2090;
      case ERefType.inOutward:
        return 2091;
      case ERefType.inwardAudit:
        return 2092;
      case ERefType.inInwardTranfer:
        return 2094;
      case ERefType.inInwardOther:
        return 2095;
      case ERefType.inInwardReturn:
        return 2096;
      case ERefType.transferOrder:
        return 2097;
      case ERefType.transferOrderRequest:
        return 2098;
      case ERefType.inInwardTransferStockInBranch:
        return 2099;
      case ERefType.outwardSale:
        return 2900;
      case ERefType.outwardCash:
        return 2901;
      case ERefType.outwardSendCash:
        return 2902;
      case ERefType.outwardSubstract:
        return 2903;
      case ERefType.outwardAudit:
        return 2904;
      case ERefType.outwardTransfer:
        return 2905;
      case ERefType.outwardOther:
        return 2906;
      case ERefType.outwardTransferStockInBranch:
        return 2907;
      case ERefType.vendorShippingPartner:
        return 3100;
      case ERefType.vendor:
        return 3101;
      case ERefType.customerAccountObjectLedger:
        return 5501;
      case ERefType.cashDebt:
        return 5502;
      case ERefType.exchangeDebt:
        return 5503;
      case ERefType.depositPayIn:
        return 5504;
      case ERefType.depositPayOut:
        return 5505;
      case ERefType.supplierPayOut:
        return 5506;
      case ERefType.cardDebt:
        return 5507;
      case ERefType.depositPayinByTransfer:
        return 5508;
      case ERefType.depositPayinByCard:
        return 5509;
      case ERefType.codCashDebt:
        return 5510;
      case ERefType.codTransferDebt:
        return 5511;
      case ERefType.codCardDebt:
        return 5512;
      case ERefType.depositPayOutByCash:
        return 1023;
      case ERefType.depositPayOutByTransfer:
        return 5514;
      case ERefType.depositPayOutByCard:
        return 5515;

      default:
        return null;
    }
  }

  static ERefType valueOf(int value) {
    switch (value) {
      case 1:
        return ERefType.puInvoiceLotSerialImei;
      case 2:
        return ERefType.puReturnLotSerialImei;
      case 3:
        return ERefType.inInwardLotSerialImei;
      case 301:
        return ERefType.puInvoice;
      case 304:
        return ERefType.puReturn;
      case 305:
        return ERefType.puInvoiceBA;
      case 306:
        return ERefType.puInvoiceCA;
      case 307:
        return ERefType.puReturnCA;
      case 308:
        return ERefType.puReturnBA;
      case 400:
        return ERefType.totalCost;
      case 549:
        return ERefType.saOrder;
      case 550:
        return ERefType.sainvoice;
      case 551:
        return ERefType.delivery;
      case 552:
        return ERefType.reinvoice;
      case 553:
        return ERefType.returnInvoice;
      case 601:
        return ERefType.openingInventoryEntry;
      case 602:
        return ERefType.openingAccountObjectCustomer;
      case 603:
        return ERefType.openingAccountObjectVendor;
      case 604:
        return ERefType.openingAccountObjectShippingPartner;
      case 605:
        return ERefType.originalCash;
      case 606:
        return ERefType.originalCard;
      case 1010:
        return ERefType.caReceipt;
      case 1014:
        return ERefType.depositPayinByCash;
      case 1020:
        return ERefType.caPayment;
      case 1022:
        return ERefType.supplierPayment;
      case 1030:
        return ERefType.caAudit;
      case 1508:
        return ERefType.customerCategory;
      case 1503:
        return ERefType.customer;
      case 1504:
        return ERefType.employee;
      case 2093:
        return ERefType.inTransfer;
      case 2060:
        return ERefType.inAudit;
      case 2090:
        return ERefType.inInward;
      case 2091:
        return ERefType.inOutward;
      case 2092:
        return ERefType.inwardAudit;
      case 2094:
        return ERefType.inInwardTranfer;
      case 2095:
        return ERefType.inInwardOther;
      case 2096:
        return ERefType.inInwardReturn;
      case 2097:
        return ERefType.transferOrder;
      case 2098:
        return ERefType.transferOrderRequest;
      case 2099:
        return ERefType.inInwardTransferStockInBranch;
      case 2900:
        return ERefType.outwardSale;
      case 2901:
        return ERefType.outwardCash;
      case 2902:
        return ERefType.outwardSendCash;
      case 2903:
        return ERefType.outwardSubstract;
      case 2904:
        return ERefType.outwardAudit;
      case 2905:
        return ERefType.outwardTransfer;
      case 2906:
        return ERefType.outwardOther;
      case 2907:
        return ERefType.outwardTransferStockInBranch;
      case 3100:
        return ERefType.vendorShippingPartner;
      case 3101:
        return ERefType.vendor;
      case 5501:
        return ERefType.customerAccountObjectLedger;
      case 5502:
        return ERefType.cashDebt;
      case 5503:
        return ERefType.exchangeDebt;
      case 5504:
        return ERefType.depositPayIn;
      case 5505:
        return ERefType.depositPayOut;
      case 5506:
        return ERefType.supplierPayOut;
      case 5507:
        return ERefType.cardDebt;
      case 5508:
        return ERefType.depositPayinByTransfer;
      case 5509:
        return ERefType.depositPayinByCard;
      case 5510:
        return ERefType.codCashDebt;
      case 5511:
        return ERefType.codTransferDebt;
      case 5512:
        return ERefType.codCardDebt;
      case 1023:
        return ERefType.depositPayOutByCash;
      case 5514:
        return ERefType.depositPayOutByTransfer;
      case 5515:
        return ERefType.depositPayOutByCard;

      default:
        return null;
    }
  }

  int get value {
    switch (this) {
      case ERefType.puInvoiceLotSerialImei:
        return 1;
      case ERefType.puReturnLotSerialImei:
        return 2;
      case ERefType.inInwardLotSerialImei:
        return 3;
      case ERefType.puInvoice:
        return 301;
      case ERefType.puReturn:
        return 304;
      case ERefType.puInvoiceBA:
        return 305;
      case ERefType.puInvoiceCA:
        return 306;
      case ERefType.puReturnCA:
        return 307;
      case ERefType.puReturnBA:
        return 308;
      case ERefType.totalCost:
        return 400;
      case ERefType.saOrder:
        return 549;
      case ERefType.sainvoice:
        return 550;
      case ERefType.delivery:
        return 551;
      case ERefType.reinvoice:
        return 552;
      case ERefType.returnInvoice:
        return 553;
      case ERefType.openingInventoryEntry:
        return 601;
      case ERefType.openingAccountObjectCustomer:
        return 602;
      case ERefType.openingAccountObjectVendor:
        return 603;
      case ERefType.openingAccountObjectShippingPartner:
        return 604;
      case ERefType.originalCash:
        return 605;
      case ERefType.originalCard:
        return 606;
      case ERefType.caReceipt:
        return 1010;
      case ERefType.depositPayinByCash:
        return 1014;
      case ERefType.caPayment:
        return 1020;
      case ERefType.supplierPayment:
        return 1022;
      case ERefType.caAudit:
        return 1030;
      case ERefType.customerCategory:
        return 1508;
      case ERefType.customer:
        return 1503;
      case ERefType.employee:
        return 1504;
      case ERefType.inTransfer:
        return 2093;
      case ERefType.inAudit:
        return 2060;
      case ERefType.inInward:
        return 2090;
      case ERefType.inOutward:
        return 2091;
      case ERefType.inwardAudit:
        return 2092;
      case ERefType.inInwardTranfer:
        return 2094;
      case ERefType.inInwardOther:
        return 2095;
      case ERefType.inInwardReturn:
        return 2096;
      case ERefType.transferOrder:
        return 2097;
      case ERefType.transferOrderRequest:
        return 2098;
      case ERefType.inInwardTransferStockInBranch:
        return 2099;
      case ERefType.outwardSale:
        return 2900;
      case ERefType.outwardCash:
        return 2901;
      case ERefType.outwardSendCash:
        return 2902;
      case ERefType.outwardSubstract:
        return 2903;
      case ERefType.outwardAudit:
        return 2904;
      case ERefType.outwardTransfer:
        return 2905;
      case ERefType.outwardOther:
        return 2906;
      case ERefType.outwardTransferStockInBranch:
        return 2907;
      case ERefType.vendorShippingPartner:
        return 3100;
      case ERefType.vendor:
        return 3101;
      case ERefType.customerAccountObjectLedger:
        return 5501;
      case ERefType.cashDebt:
        return 5502;
      case ERefType.exchangeDebt:
        return 5503;
      case ERefType.depositPayIn:
        return 5504;
      case ERefType.depositPayOut:
        return 5505;
      case ERefType.supplierPayOut:
        return 5506;
      case ERefType.cardDebt:
        return 5507;
      case ERefType.depositPayinByTransfer:
        return 5508;
      case ERefType.depositPayinByCard:
        return 5509;
      case ERefType.codCashDebt:
        return 5510;
      case ERefType.codTransferDebt:
        return 5511;
      case ERefType.codCardDebt:
        return 5512;
      case ERefType.depositPayOutByCash:
        return 1023;
      case ERefType.depositPayOutByTransfer:
        return 5514;
      case ERefType.depositPayOutByCard:
        return 5515;
      default:
        return null;
    }
  }

  String getTitle() {
    switch (this) {
      case ERefType.depositPayinByCash:
      case ERefType.depositPayOutByCash:
      case ERefType.cashDebt:
      case ERefType.codCashDebt:
        return 'Tiền mặt';

      case ERefType.depositPayinByTransfer:
      case ERefType.depositPayOutByTransfer:
      case ERefType.exchangeDebt:
      case ERefType.codTransferDebt:
        return 'Tiền gửi';

      /// Sử dụng trong báo cáo tồn kho theo HSD
      case ERefType.openingInventoryEntry:

        /// tồn đầu kỳ
        return 'Tồn đầu kỳ';

      case ERefType.inInwardOther:

        /// nhập kho khác:
        return 'Phiếu nhập kho khác';
      case ERefType.inInwardTranfer:

        /// nhập kho điều chuyển
        return 'Phiếu nhập kho điều chuyển';
      case ERefType.inwardAudit:

        /// nhập kho kiểm kê
        return 'Phiếu nhập kho kiểm kê';
      case ERefType.inInwardReturn:

        ///nhập kho hàng trả lại
        return 'Phiếu nhập kho hàng trả lại';
      case ERefType.puInvoice:

        /// nhập hàng - ghi nợ nhà cung cấp
        return 'Phiếu nhập hàng - Ghi nợ nhà cung cấp';
      case ERefType.puInvoiceBA:

        /// nhập hàng - tiền gửi
        return 'Phiếu nhập hàng - Tiền gửi';
      case ERefType.puInvoiceCA:

        /// nhập hàng - tiền mặt
        return 'Phiếu nhập hàng - Tiền mặt';

      case ERefType.outwardTransfer:

        /// xuất điều chuyển
        return 'Phiếu xuất kho điều chuyển';
      case ERefType.outwardSale:

        /// xuất kho bán hàng
        return 'Phiếu xuất kho bán hàng';
      case ERefType.outwardAudit:

        /// xuất kiểm kê
        return 'Phiếu xuất kho kiểm kê';
      case ERefType.outwardOther:

        /// xuất khác
        return 'Phiếu xuất kho khác';
      case ERefType.puReturn:

        /// Trả lại hàng mua - giảm trừ công nợ
        return 'Phiếu trả lại hàng mua - Giảm trừ công nợ';
      case ERefType.puReturnCA:

        /// Trả lại hàng mua - tiền mặt
        return 'Phiếu trả lại hàng mua - Tiền mặt';
      case ERefType.puReturnBA:

        /// Trả lại hàng mua - tiền gửi
        return 'Phiếu trả lại hàng mua - Tiền gửi';

      case ERefType.inTransfer:

        /// chuyển kho
        return 'Phiếu chuyển kho';
      default:
        return 'Thẻ';
    }
  }
}
