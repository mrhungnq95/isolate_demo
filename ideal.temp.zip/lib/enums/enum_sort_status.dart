enum ESortStatus { asc, desc }

extension ESortStatusExt on ESortStatus {
  String getTitle() {
    switch (this) {
      case ESortStatus.asc:
        return "Số lượng tăng dần";
      case ESortStatus.desc:
        return "Số lượng giảm dần";
      default:
        return "";
    }
  }
}
