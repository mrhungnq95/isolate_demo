///
/// Enum kiểm kê theo hàng hóa hoặc lô
///
enum EApplyNumber {
  // Trước KM
  beforePromotion,
  // Sau KM
  afterPromotion,
}

extension EApplyNumberExtension on EApplyNumber {
  int get toValue {
    switch (this) {
      case EApplyNumber.beforePromotion:
        return 1;
      case EApplyNumber.afterPromotion:
        return 2;
    }
  }
}
