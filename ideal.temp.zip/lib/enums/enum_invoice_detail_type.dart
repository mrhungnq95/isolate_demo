/// 
/// Enum type các dòng trong hóa đơn
/// 
enum EInvoiceDetailType {
  header,    // Tiêu đề hóa đơn
  space,    // Space
  listDetail, // Ds các hàng hóa
  info,        // Thông tin
  divider,
}
