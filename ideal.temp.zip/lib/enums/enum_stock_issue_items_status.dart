enum EStockIssueItemsStatus {
  /// Tất cả
  all,

  /// Còn hàng
  availablle,

  /// Hết hàng
  out_of_stock
}

extension EStockIssueItemsStatusExt on EStockIssueItemsStatus {
  String getTitle() {
    switch (this) {
      case EStockIssueItemsStatus.all:
        return "Tất cả";
      case EStockIssueItemsStatus.availablle:
        return "Còn hàng";
      case EStockIssueItemsStatus.out_of_stock:
        return "Hết hàng";
      default:
        return "";
    }
  }
}
