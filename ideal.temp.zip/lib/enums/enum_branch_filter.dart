//
// Created by nqhung on 07/11/2020.
//

enum EOverviewBranchFilter {
  allBranch, //Tất cả Branch
  groupBranch //Một hoặc một nhóm Branch
}

extension EOverviewBranchFilterExt on EOverviewBranchFilter {
  String getTitle() {
    switch (this) {
      case EOverviewBranchFilter.allBranch:
        return "Toàn chuỗi";
      case EOverviewBranchFilter.groupBranch:
        return "Nhóm cửa hàng";
      default:
        return "";
    }
  }

  static valueOf(int value) {
    switch (value) {
      case 0:
        return EOverviewBranchFilter.allBranch;
      case 1:
        return EOverviewBranchFilter.groupBranch;
      default:
        return EOverviewBranchFilter.allBranch;
    }
  }

  int get rawValue {
    switch (this) {
      case EOverviewBranchFilter.allBranch:
        return 0;
      case EOverviewBranchFilter.groupBranch:
        return 1;
      default:
        return 0;
    }
  }
}
