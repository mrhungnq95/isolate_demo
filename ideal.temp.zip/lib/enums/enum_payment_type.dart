enum EPaymentType {
  cash, // Tiền mặt
  supplier, // Ghi nợ nhà cung cấp
  deposits, // Tiền gửi
  point // Điểm
}

extension EEPaymentTypeExt on EPaymentType {

  int get toValue {
    switch (this) {
      case EPaymentType.cash:
        return 1;
      case EPaymentType.supplier:
        return 2;
      case EPaymentType.deposits:
        return 3;
        case EPaymentType.point:
        return 7;
      default:
        return null;
    }
  }

  String get title {
    switch (this) {
      case EPaymentType.cash:
        return 'Tiền mặt';
      case EPaymentType.deposits:
        return 'Tiền gửi';
      case EPaymentType.supplier:
        return 'Ghi nợ nhà cung cấp';
        case EPaymentType.point:
        return 'Điểm';
      default:
        return '';
    }
  }
}
