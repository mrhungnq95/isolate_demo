///
/// Enum
///
enum EStockIssueType {
  transfer, // Điều chuyển
  checking, // Kiểm kê
  sale, // Bán hàng
  other // Khác
}

extension EStockIssueTypeExtension on EStockIssueType {
  String get title {
    switch (this) {
      case EStockIssueType.transfer:
        return 'Điều chuyển';
      case EStockIssueType.checking:
        return 'Kiểm kê';
      case EStockIssueType.sale:
        return 'Bán hàng';
      case EStockIssueType.other:
        return 'Khác';

      default:
        return '';
    }
  }
}
