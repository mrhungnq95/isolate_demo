enum EInventoryItemViewType { models, details }

extension EInventoryItemViewTypeExt on EInventoryItemViewType {
  String getTitle() {
    switch (this) {
      case EInventoryItemViewType.models:
        return "Mẫu mã";
      case EInventoryItemViewType.details:
        return "Hàng hóa chi tiết";
      default:
        return "";
    }
  }

  int get value {
    switch (this) {
      case EInventoryItemViewType.models:
        return 0;
        break;
      case EInventoryItemViewType.details:
        return 1;
      default:
        return 0;
    }
  }

  static EInventoryItemViewType valueOf(int value) {
    switch (value) {
      case 0:
        return EInventoryItemViewType.models;
      case 1:
        return EInventoryItemViewType.details;
      default:
        return EInventoryItemViewType.models;
    }
  }
}
