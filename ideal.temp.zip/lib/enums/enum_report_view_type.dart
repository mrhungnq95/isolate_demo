enum EReportViewType { viewByInventoryItem, viewByPeriodTime }

extension EReportViewTypeExt on EReportViewType {
  int get rawValue {
    switch (this) {
      case EReportViewType.viewByInventoryItem:
        return 0;
      case EReportViewType.viewByPeriodTime:
        return 1;
      default:
        return 0;
    }
  }

  static EReportViewType valueOf(int value) {
    switch (value) {
      case 0:
        return EReportViewType.viewByInventoryItem;
      case 1:
        return EReportViewType.viewByPeriodTime;
      default:
        return null;
    }
  }

  String getTitleReport() {
    switch (this) {
      case EReportViewType.viewByInventoryItem:
        return "Doanh thu theo mặt hàng";
      case EReportViewType.viewByPeriodTime:
        return "Doanh thu theo theo thời gian";
      default:
        return "";
    }
  }

  String getTitle() {
    switch (this) {
      case EReportViewType.viewByInventoryItem:
        return "Mặt hàng";
      case EReportViewType.viewByPeriodTime:
        return "Thời gian";
      default:
        return "";
    }
  }
}
