


import 'enum_ref_type.dart';

///
/// [Description]  Lỗi validate
///
/// Created by TTLOI on 13/01/2021 (11:05).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
enum EValidateSerialIMEIError {
  //-- 1.  Lỗi trùng số Serial/IMEI trong phiếu => Serial/IMEI đã có trên phiếu
  //-- 2.  Lỗi trùng số Serial/IMEI trong dữ liệu đối với phiếu nhập => Serial/IMEI đã tồn tại
  //-- 2.  Lỗi không tồn tại số Serial/IMEI trong dữ liệu đối với phiếu xuất => Serial/IMEI không tồn tại
  //-- 4.  Lỗi không tồn tại số Serial/IMEI chưa được gắn với hàng hóa đang xuất => Serial/IMEI không gắn với hàng hóa {Tên hàng hóa}
  //-- 8.  Lỗi đã xuất kho bán hàng không thể xuất kho => Serial/IMEI đã xuất kho, vui lòng kiểm tra lại.
  //-- 16. Lỗi kho hiện tại không có số Serial/IMEI => Serial/IMEI không có trong kho.
  //-- 32. Lỗi không sửa phiếu xuất kho khi đã có phát sinh phiếu nhập hoặc xuất của kho khác
  //-- 64. Lỗi đã xuất kho không thể sửa phiếu nhập kho hoặc nhập hàng => Serial/IMEI đã có phát sinh. Vui lòng xóa phát sinh và thử lại
  //-- 128.Lỗi vượt quá 50 ký tự => Serial/IMEI chỉ được nhập tối đa 50 ký tự
  duplicate,
  existOrNotExist,
  notMath,
  exported,
  notFoundInStock,
  arisen,
  checkArisenWhenEditOrDelete,
  maxLength,
}

extension EValidateSerialExt on EValidateSerialIMEIError {

  static EValidateSerialIMEIError fromValue(int value) {
    switch (value) {
      case 1:
        return EValidateSerialIMEIError.duplicate;
      case 2:
        return EValidateSerialIMEIError.existOrNotExist;
      case 4:
        return EValidateSerialIMEIError.notMath;
      case 8:
        return EValidateSerialIMEIError.exported;
      case 16:
        return EValidateSerialIMEIError.notFoundInStock;
      case 32:
        return EValidateSerialIMEIError.arisen;
      case 64:
        return EValidateSerialIMEIError.checkArisenWhenEditOrDelete;
      case 128:
        return EValidateSerialIMEIError.maxLength;
    }
    return null;
  }

  int get value {
    switch (this) {
      case EValidateSerialIMEIError.duplicate:
        return 1;
      case EValidateSerialIMEIError.existOrNotExist:
        return 2;
      case EValidateSerialIMEIError.notMath:
        return 4;
      case EValidateSerialIMEIError.exported:
        return 8;
      case EValidateSerialIMEIError.notFoundInStock:
        return 16;
      case EValidateSerialIMEIError.arisen:
        return 32;
      case EValidateSerialIMEIError.checkArisenWhenEditOrDelete:
        return 64;
      case EValidateSerialIMEIError.maxLength:
        return 128;
    }
    return 0;
  }

  ///
  /// Lấy thông báo lỗi theo loại chứng từ
  /// [serialNo] số chứng từ
  /// [inventoryItemName] Tên hàng hoá
  /// [refType] loiaj chứng từ
  ///
  String getErrorMessage(String serialNo, String inventoryItemName, ERefType refType) {
    switch (this) {
      case EValidateSerialIMEIError.duplicate:
        return 'Serial/IMEI $serialNo đã có trên phiếu';
      case EValidateSerialIMEIError.existOrNotExist:
        //case thông báo theo loại chứng từ
        if (refType == ERefType.puInvoiceLotSerialImei || refType == ERefType.inInwardLotSerialImei) {
          return 'Serial/IMEI $serialNo đã tồn tại';
        }
        return 'Serial/IMEI $serialNo không tồn tại';
      case EValidateSerialIMEIError.notMath:
        return 'Serial/IMEI $serialNo không gắn với hàng hóa $inventoryItemName';
      case EValidateSerialIMEIError.exported:
        return 'Serial/IMEI $serialNo đã xuất kho, vui lòng kiểm tra lại';
      case EValidateSerialIMEIError.notFoundInStock:
        return 'Serial/IMEI $serialNo không có trong kho';
      case EValidateSerialIMEIError.arisen:
        return 'Serial/IMEI $serialNo đã có phát sinh phiếu nhập hoặc xuất của kho khác';
      case EValidateSerialIMEIError.checkArisenWhenEditOrDelete:
        return 'Serial/IMEI $serialNo đã có phát sinh. Vui lòng xóa phát sinh và thử lại';
      case EValidateSerialIMEIError.maxLength:
        return 'Serial/IMEI chỉ được nhập tối đa 50 ký tự';
    }
    return null;
  }
}