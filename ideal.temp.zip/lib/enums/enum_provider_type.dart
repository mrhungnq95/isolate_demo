///
/// Enum
///
enum EVendorType {
  none,
  personal, // Cá nhân
  organization // tổ chức
}

extension EVendorTypeExtension on EVendorType {

  static EVendorType fromValue(int value) {
    switch (value) {
      case 1:
        return EVendorType.organization;
      case 2:
        return EVendorType.personal;
      default:
        return EVendorType.none;
    }
  }

  int get value {
    switch (this) {
      case EVendorType.organization:
        return 1;
      case EVendorType.personal:
        return 2;
      default:
        return -1;
    }
  }

  String get title {
    switch (this) {
      case EVendorType.organization:
        return 'Tổ chức';
      case EVendorType.personal:
        return 'Cá nhân';
      default:
        return '';
    }
  }
}
