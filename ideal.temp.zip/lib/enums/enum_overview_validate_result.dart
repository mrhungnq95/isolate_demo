import 'package:freezed_annotation/freezed_annotation.dart';

part 'enum_overview_validate_result.freezed.dart';

@freezed
abstract class OverviewValidateResult with _$OverviewValidateResult {
  const factory OverviewValidateResult.ok() = OK;

  const factory OverviewValidateResult.customizeDateIsNull() =
      CustomizeDateIsNull;
  const factory OverviewValidateResult.fromDateIsNull() = FromDateIsNull;
  const factory OverviewValidateResult.toDateIsNull() = ToDateIsNull;

  const factory OverviewValidateResult.prevFromDateIsNull() =
      PrevFromDateIsNull;
  const factory OverviewValidateResult.prevToDateIsNull() = PrevToDateIsNull;
}
