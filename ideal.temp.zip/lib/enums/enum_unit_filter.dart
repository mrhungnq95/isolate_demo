enum EUnitFilter { all, custom }

extension EUnitFilterExt on EUnitFilter {
  String getTitle() {
    switch (this) {
      case EUnitFilter.all:
        return "Tất cả";
      case EUnitFilter.custom:
        return "Khác";
      default:
        return "";
    }
  }
}
