///
/// Enum
///
enum EditMode {
  none,
  add,
  edit,
  delete,
}

extension EditModeExtension on EditMode {

  static EditMode fromValue(int value) {
    switch (value) {
      case 1:
        return EditMode.add;
      case 2:
        return EditMode.edit;
      case 3:
        return EditMode.delete;
      default:
        return EditMode.none;
    }
  }

  int get value {
    switch (this) {
      case EditMode.add:
        return 1;
      case EditMode.edit:
        return 2;
      case EditMode.delete:
        return 3;
      default:
        return 0;
    }
  }
}
