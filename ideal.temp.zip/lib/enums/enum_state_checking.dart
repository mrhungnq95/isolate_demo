enum EStateChecking {
  all,                // Tất cả
  notProcessing,      // Chưa xử lý
  processed,          // Đã xử lý
  noDifference,       // Không chênh lệch
}

extension EStateCheckingExt on EStateChecking {

  String getTitle() {
    switch (this) {
      case EStateChecking.all:
        return 'Tất cả';
      case EStateChecking.notProcessing:
        return 'Chưa xử lý';
      case EStateChecking.processed:
        return 'Đã xử lý';
      case EStateChecking.noDifference:
        return 'Không có chênh lệch';
        default:
        return '';
    }
  }
}