import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

enum EReportPeriodType {
  custom,

  // Các tháng trong năm
  january,
  february,
  march,
  april,
  may,
  june,
  july,
  august,
  september,
  october,
  november,
  december,

  // Các quý trong năm
  fiscalI,
  fiscalII,
  fiscalIII,
  fiscalIV,

  // Ngày
  thisDay,
  yesterday,
  tomorrow,

  // Tuần
  thisWeek,
  lastWeek,
  nextWeek,
  fourLastWeek,

  // Tháng
  thisMonth,
  lastMonth,
  nextMonth,

  // Quý
  thisQuarter,
  lastQuarter,
  sixLastMonth, // 6 thang truoc

  // Năm
  thisYear,
  lastYear,
  threeLastYear, // 3 nam gan day

  /// Các enum define dưới local cho các dạng
  /// range date customize không có trên BE
  lastDay, // Ngày trước đó
  lastSevenDay, // 7 ngày gần đây
  lastThirtyDay, // 30 ngày gần đây
  fromDateCustomize,
  toDateCustomize,
  yesterdayFromDate, // Lấy 1 ngày trước đó từ ngày truyền vào
  lastWeekFromDate, // Tuần trước đó từ ngày
  fourlastWeekFromDate, // 4 tuần trước đó từ ngày
  lastMonthFromDate, // Tháng trước đó từ ngày
}

extension EReportPeriodTypeExt on EReportPeriodType {
  static EReportPeriodType valueOf(int value) {
    switch (value) {
      case 0:
        return EReportPeriodType.custom;
      case 1:
        return EReportPeriodType.january;
      case 2:
        return EReportPeriodType.february;
      case 3:
        return EReportPeriodType.march;
      case 4:
        return EReportPeriodType.april;
      case 5:
        return EReportPeriodType.may;
      case 6:
        return EReportPeriodType.june;
      case 7:
        return EReportPeriodType.july;
      case 8:
        return EReportPeriodType.august;
      case 9:
        return EReportPeriodType.september;
      case 10:
        return EReportPeriodType.october;
      case 11:
        return EReportPeriodType.november;
      case 12:
        return EReportPeriodType.september;
      case 100:
        return EReportPeriodType.fiscalI;
      case 200:
        return EReportPeriodType.fiscalII;
      case 300:
        return EReportPeriodType.fiscalIII;
      case 400:
        return EReportPeriodType.fiscalIV;
      case 20:
        return EReportPeriodType.thisDay;
      case 21:
        return EReportPeriodType.yesterday;
      case 25:
        return EReportPeriodType.tomorrow;
      case 30:
        return EReportPeriodType.thisWeek;
      case 35:
        return EReportPeriodType.lastWeek;
      case 40:
        return EReportPeriodType.nextWeek;
      case 41:
        return EReportPeriodType.fourLastWeek;
      case 45:
        return EReportPeriodType.thisMonth;
      case 50:
        return EReportPeriodType.lastMonth;
      case 55:
        return EReportPeriodType.nextMonth;
      case 60:
        return EReportPeriodType.thisQuarter;
      case 65:
        return EReportPeriodType.lastQuarter;
      case 70:
        return EReportPeriodType.sixLastMonth;
      case 500:
        return EReportPeriodType.thisYear;
      case 80:
        return EReportPeriodType.lastYear;
      case 85:
        return EReportPeriodType.threeLastYear;
      case 86:
        return EReportPeriodType.yesterdayFromDate;
      case 87:
        return EReportPeriodType.lastWeekFromDate;
      case 88:
        return EReportPeriodType.fourlastWeekFromDate;
      case 89:
        return EReportPeriodType.lastMonthFromDate;
      case 1000:
        return EReportPeriodType.lastDay;
      case 1001:
        return EReportPeriodType.lastSevenDay;
      case 1002:
        return EReportPeriodType.lastThirtyDay;
      case 1003:
        return EReportPeriodType.fromDateCustomize;
      case 1004:
        return EReportPeriodType.toDateCustomize;
      default:
        return null;
    }
  }

  int get rawValue {
    switch (this) {
      case EReportPeriodType.custom:
        return 0;
      case EReportPeriodType.january:
        return 1;
      case EReportPeriodType.february:
        return 2;
      case EReportPeriodType.march:
        return 3;
      case EReportPeriodType.april:
        return 4;
      case EReportPeriodType.may:
        return 5;
      case EReportPeriodType.june:
        return 6;
      case EReportPeriodType.july:
        return 7;
      case EReportPeriodType.august:
        return 8;
      case EReportPeriodType.september:
        return 9;
      case EReportPeriodType.october:
        return 10;
      case EReportPeriodType.november:
        return 11;
      case EReportPeriodType.december:
        return 12;
      case EReportPeriodType.fiscalI:
        return 100;
      case EReportPeriodType.fiscalII:
        return 200;
      case EReportPeriodType.fiscalIII:
        return 300;
      case EReportPeriodType.fiscalIV:
        return 400;
      case EReportPeriodType.thisDay:
        return 20;
      case EReportPeriodType.yesterday:
        return 21;
      case EReportPeriodType.tomorrow:
        return 25;
      case EReportPeriodType.thisWeek:
        return 30;
      case EReportPeriodType.lastWeek:
        return 35;
      case EReportPeriodType.nextWeek:
        return 40;
      case EReportPeriodType.fourLastWeek:
        return 41;
      case EReportPeriodType.thisMonth:
        return 45;
      case EReportPeriodType.lastMonth:
        return 50;
      case EReportPeriodType.nextMonth:
        return 55;
      case EReportPeriodType.thisQuarter:
        return 60;
      case EReportPeriodType.lastQuarter:
        return 65;
      case EReportPeriodType.sixLastMonth:
        return 70;
      case EReportPeriodType.thisYear:
        return 500;
      case EReportPeriodType.lastYear:
        return 80;
      case EReportPeriodType.threeLastYear:
        return 85;
      case EReportPeriodType.yesterdayFromDate:
        return 86;
      case EReportPeriodType.lastWeekFromDate:
        return 87;
      case EReportPeriodType.fourlastWeekFromDate:
        return 88;
      case EReportPeriodType.lastMonthFromDate:
        return 89;
      case EReportPeriodType.lastDay:
        return 1000;
      case EReportPeriodType.lastSevenDay:
        return 1001;
      case EReportPeriodType.lastThirtyDay:
        return 1002;
      case EReportPeriodType.fromDateCustomize:
        return 1003;
      case EReportPeriodType.toDateCustomize:
        return 1004;
      default:
        return 0;
    }
  }

  String get title {
    switch (this) {
      case EReportPeriodType.custom:
        return "Khác";
      case EReportPeriodType.january:
        return "Tháng 1";
      case EReportPeriodType.february:
        return "Tháng 2";
      case EReportPeriodType.march:
        return "Tháng 3";
      case EReportPeriodType.april:
        return "Tháng 4";
      case EReportPeriodType.may:
        return "Tháng 5";
      case EReportPeriodType.june:
        return "Tháng 6";
      case EReportPeriodType.july:
        return "Tháng 7";
      case EReportPeriodType.august:
        return "Tháng 8";
      case EReportPeriodType.september:
        return "Tháng 9";
      case EReportPeriodType.october:
        return "Tháng 10";
      case EReportPeriodType.november:
        return "Tháng 11";
      case EReportPeriodType.december:
        return "Tháng 12";
      case EReportPeriodType.fiscalI:
        return "Quý I";
      case EReportPeriodType.fiscalII:
        return "Quý II";
      case EReportPeriodType.fiscalIII:
        return "Quý III";
      case EReportPeriodType.fiscalIV:
        return "Quý IV";
      case EReportPeriodType.thisDay:
        return "Hôm nay";
      case EReportPeriodType.yesterday:
        return "Hôm qua";
      case EReportPeriodType.tomorrow:
        return "Ngày mai";
      case EReportPeriodType.thisWeek:
        return "Tuần này";
      case EReportPeriodType.lastWeek:
        return "Tuần trước";
      case EReportPeriodType.nextWeek:
        return "Tuần sau";
      case EReportPeriodType.fourLastWeek:
        return "4 tuần gần đây";
      case EReportPeriodType.thisMonth:
        return "Tháng này";
      case EReportPeriodType.lastMonth:
        return "Tháng trước";
      case EReportPeriodType.nextMonth:
        return "Tháng sau";
      case EReportPeriodType.thisQuarter:
        return "Quý này";
      case EReportPeriodType.lastQuarter:
        return "Quý trước";
      case EReportPeriodType.sixLastMonth:
        return "6 tháng gần đây";
      case EReportPeriodType.thisYear:
        return "Năm nay";
      case EReportPeriodType.lastYear:
        return "Năm trước";
      case EReportPeriodType.threeLastYear:
        return "3 năm gần đây";
      case EReportPeriodType.lastSevenDay:
        return "7 ngày gần đây";
      case EReportPeriodType.lastThirtyDay:
        return "30 ngày gần đây";
      default:
        return "";
    }
  }

  ///
  /// Lấy Date Title của kỳ chọn báo cáo
  /// VD: 08/02/2020
  /// [dateRange] obj Khoảng thời gian
  ///
  String getPeriodDateTitle(DateRange dateRange) {
    if (dateRange == null) {
      return "";
    }

    final fromDate = DateTimeFormatHelper.formatDate2String(dateRange.startDate,
        format: DateTimeFormatConstant.DD_MM_YYYY);

    final toDate = DateTimeFormatHelper.formatDate2String(dateRange.endDate,
        format: DateTimeFormatConstant.DD_MM_YYYY);

    if (this == EReportPeriodType.thisDay ||
        this == EReportPeriodType.yesterday) {
      return "$fromDate";
    }

    final dateRangeDesc = "$fromDate - $toDate";

    return dateRangeDesc;
  }

  ///
  /// Lấy Title của kỳ chọn báo cáo
  /// VD: Tháng này (12/2020)
  /// [dateRange] obj Khoảng thời gian
  ///
  String getPeriodTitle(DateRange dateRange) {
    if (dateRange == null) {
      return "";
    }

    final fromDate = DateTimeFormatHelper.formatDate2String(dateRange.startDate,
        format: DateTimeFormatConstant.DD_MM_YYYY);

    final toDate = DateTimeFormatHelper.formatDate2String(dateRange.endDate,
        format: DateTimeFormatConstant.DD_MM_YYYY);

    final dateRangeDesc = "($fromDate - $toDate)";
    switch (this) {
      case EReportPeriodType.custom:
        return "$fromDate - $toDate";
      case EReportPeriodType.january:
        return "Tháng 1 $dateRangeDesc";
      case EReportPeriodType.february:
        return "Tháng 2 $dateRangeDesc";
      case EReportPeriodType.march:
        return "Tháng 3 $dateRangeDesc";
      case EReportPeriodType.april:
        return "Tháng 4 $dateRangeDesc";
      case EReportPeriodType.may:
        return "Tháng 5 $dateRangeDesc";
      case EReportPeriodType.june:
        return "Tháng 6 $dateRangeDesc";
      case EReportPeriodType.july:
        return "Tháng 7 $dateRangeDesc";
      case EReportPeriodType.august:
        return "Tháng 8 $dateRangeDesc";
      case EReportPeriodType.september:
        return "Tháng 9 $dateRangeDesc";
      case EReportPeriodType.october:
        return "Tháng 10 $dateRangeDesc";
      case EReportPeriodType.november:
        return "Tháng 11 $dateRangeDesc";
      case EReportPeriodType.december:
        return "Tháng 12 $dateRangeDesc";
      case EReportPeriodType.thisDay:
        return "Hôm nay ($fromDate)";
      case EReportPeriodType.yesterday:
        return "Hôm qua ($fromDate)";
      case EReportPeriodType.thisWeek:
        return "Tuần này $dateRangeDesc";
      case EReportPeriodType.lastWeek:
        return "Tuần trước $dateRangeDesc";
      case EReportPeriodType.fourLastWeek:
        return "4 tuần gần đây $dateRangeDesc";
      case EReportPeriodType.thisMonth:
        return "Tháng này ($fromDate)";
      case EReportPeriodType.lastMonth:
        return "Tháng trước ($fromDate)";
      case EReportPeriodType.thisQuarter:
        return "Quý này $dateRangeDesc";
      case EReportPeriodType.lastQuarter:
        return "Quý trước $dateRangeDesc";
      case EReportPeriodType.sixLastMonth:
        return "6 tháng gần đây $dateRangeDesc";
      case EReportPeriodType.thisYear:
        return "Năm nay $dateRangeDesc";
      case EReportPeriodType.lastYear:
        return "Năm trước $dateRangeDesc";
      case EReportPeriodType.threeLastYear:
        return "3 năm gần đây $dateRangeDesc";
      case EReportPeriodType.lastSevenDay:
        return "7 ngày gần đây $dateRangeDesc";
      case EReportPeriodType.lastThirtyDay:
        return "30 ngày gần đây $dateRangeDesc";
      default:
        return "";
    }
  }
}
