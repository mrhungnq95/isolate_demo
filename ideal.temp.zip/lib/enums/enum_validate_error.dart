///
/// [Description] enum các lỗi khi validate
///
/// Created by TTLOI on 12/01/2021 (11:35).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
enum EValidateError {
  empty, invalid,
}