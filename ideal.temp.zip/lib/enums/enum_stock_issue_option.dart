enum EStockIssueOption { stock_issue, tranfering, incomming }

extension StockIssueOptionExt on EStockIssueOption {
  String getTitle() {
    switch (this) {
      case EStockIssueOption.stock_issue:
        return "Tồn kho";
      case EStockIssueOption.tranfering:
        return "Đang chuyển đi";
      case EStockIssueOption.incomming:
        return "Sắp nhận về";
      default:
        return "";
    }
  }
}
