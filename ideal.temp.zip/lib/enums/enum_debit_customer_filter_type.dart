///
/// Enum
///
enum EDebitCustomerFilterType {
  nameCustomer, // Kiểm kê theo hàng hóa
  decrease, // Doanh thu giảm dần
  ascending // Doanh thu tăng dần
}

extension EDebitCustomerFilterTypeExtension on EDebitCustomerFilterType {

  String get title {
    switch (this) {
      case EDebitCustomerFilterType.nameCustomer:
        return 'Tên khách hàng';
      case EDebitCustomerFilterType.decrease:
        return 'Nợ giảm dần';
      case EDebitCustomerFilterType.ascending:
        return 'Nợ tăng dần';
    }
  }

  int get rawValue {
    switch (this) {
      case EDebitCustomerFilterType.nameCustomer:
        return 1;
      case EDebitCustomerFilterType.decrease:
        return 2;
      case EDebitCustomerFilterType.ascending:
        return 3;
    }
  }

  static EDebitCustomerFilterType fromValue (int value) {
    switch (value) {
      case 1:
        return EDebitCustomerFilterType.nameCustomer;
      case 2:
        return EDebitCustomerFilterType.decrease;
      case 3:
        return EDebitCustomerFilterType.ascending;
    }
  }

}
