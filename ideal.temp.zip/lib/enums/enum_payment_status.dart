import 'dart:ui';

import 'package:MShopManager/app/app_color.dart';

enum EPaymentStatus {
  all,

  /// Tất cả
  notpay,

  /// Chưa thanh toán
  debit,

  /// Ghi nợ
  payed,

  /// Đã thanh TOÁN
  cancelled,

  /// Đã bị hủy
  waitDelivery,

  /// Chờ giao hàng
  delivering,

  /// Đang giao hàng
  fail,

  /// Thất bại
  invoiceDone,

  /// Hoàn thành
  refund,

  /// Đã chuyển hoàn
  waitReceiveCOD

  /// Đã thu COD Loại riêng không có trên BE dùng định nghĩa cho hóa đơn đã hoàn thành nhưng đang chờ thu COD
}

extension EPaymentStatusExt on EPaymentStatus {
  int get rawValue {
    switch (this) {
      case EPaymentStatus.all:
        return 0;
      case EPaymentStatus.notpay:
        return 1;
      case EPaymentStatus.debit:
        return 2;
      case EPaymentStatus.payed:
        return 3;
      case EPaymentStatus.cancelled:
        return 4;
      case EPaymentStatus.waitDelivery:
        return 5;
      case EPaymentStatus.delivering:
        return 6;
      case EPaymentStatus.fail:
        return 7;
      case EPaymentStatus.invoiceDone:
        return 8;
      case EPaymentStatus.refund:
        return 9;
      case EPaymentStatus.waitReceiveCOD:
        return 10;
    }
    return 0;
  }

  static EPaymentStatus fromValue(int value) {
    switch (value) {
      case 0:
        return EPaymentStatus.all;
      case 1:
        return EPaymentStatus.notpay;
      case 2:
        return EPaymentStatus.debit;
      case 3:
        return EPaymentStatus.payed;
      case 4:
        return EPaymentStatus.cancelled;
      case 5:
        return EPaymentStatus.waitDelivery;
      case 6:
        return EPaymentStatus.delivering;
      case 7:
        return EPaymentStatus.fail;
      case 8:
        return EPaymentStatus.invoiceDone;
      case 9:
        return EPaymentStatus.refund;
      case 10:
        return EPaymentStatus.waitReceiveCOD;
    }
    return EPaymentStatus.all;
  }

  String getTitle() {
    switch (this) {
      case EPaymentStatus.all:
        return 'Tất cả';
      case EPaymentStatus.notpay:
        return 'Chưa thanh toán';
      case EPaymentStatus.debit:
        return 'Ghi nợ';
      case EPaymentStatus.payed:
        return 'Đã thu tiền';
      case EPaymentStatus.cancelled:
        return 'Đã hủy';
      case EPaymentStatus.waitDelivery:
        return 'Chờ giao hàng';
      case EPaymentStatus.delivering:
        return 'Đang GH';
      case EPaymentStatus.fail:
        return 'Thất bại';
      case EPaymentStatus.invoiceDone:
        return 'Hoàn thành';
      case EPaymentStatus.refund:
        return 'Đã chuyển hoàn';
      case EPaymentStatus.waitReceiveCOD:
        return 'Chờ thu COD';
    }
    return '';
  }

  Color getTitleColor() {
    switch (this) {
      case EPaymentStatus.all:
        return Color(0xFF2B3173);
      case EPaymentStatus.notpay:
        return Color(0xFFFFA200);
      case EPaymentStatus.debit:
        return Color(0xFFD571B0);
      case EPaymentStatus.payed:
        return Color(0xFF5ACBA8);
      case EPaymentStatus.cancelled:
        return Color(0xFFFF3030);
      case EPaymentStatus.waitDelivery:
        return Color(0xFFFFA200);
      case EPaymentStatus.delivering:
        return Color(0xFF616CE6);
      case EPaymentStatus.fail:
        return Color(0xFFFF3030);
      case EPaymentStatus.invoiceDone:
        return Color(0xFF5ACBA8);
      case EPaymentStatus.refund:
        return Color(0xFF2B3173);
      case EPaymentStatus.waitReceiveCOD:
        return Color(0xFFB17DFF);
    }
    return AppColor.primaryColor;
  }

  Color getBackgroundColor() {
    switch (this) {
      case EPaymentStatus.all:
        return Color(0xFF616CE6).withOpacity(0.1);
      case EPaymentStatus.notpay:
        return Color(0xFFFFA200).withOpacity(0.1);
      case EPaymentStatus.debit:
        return Color(0xFFD571B0).withOpacity(0.1);
      case EPaymentStatus.payed:
        return Color(0xFF5ACBA8).withOpacity(0.1);
      case EPaymentStatus.cancelled:
        return Color(0xFFFF3030).withOpacity(0.1);
      case EPaymentStatus.waitDelivery:
        return Color(0xFFFFA200).withOpacity(0.1);
      case EPaymentStatus.delivering:
        return Color(0xFF616CE6).withOpacity(0.1);
      case EPaymentStatus.fail:
        return Color(0xFFFF3030).withOpacity(0.1);
      case EPaymentStatus.invoiceDone:
        return Color(0xFF5ACBA8).withOpacity(0.1);
      case EPaymentStatus.refund:
        return Color(0xFF2B3173).withOpacity(0.1);
      case EPaymentStatus.waitReceiveCOD:
        return Color(0xFFB17DFF).withOpacity(0.1);
    }
    return Color(0xFF616CE6).withOpacity(0.1);
  }
}
