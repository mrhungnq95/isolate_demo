///
/// Enum
///
enum EProviderSortType {
  name, // Tên
  code, // Mã
}

extension EProviderSortTypeExtension on EProviderSortType {

  static EProviderSortType fromValue(int value) {
    switch (value) {
      case 1:
        return EProviderSortType.name;
      case 2:
        return EProviderSortType.code;
      default:
        return EProviderSortType.name;
    }
  }

  int get value {
    switch (this) {
      case EProviderSortType.name:
        return 1;
      case EProviderSortType.code:
        return 2;
      default:
        return 1;
    }
  }

  String get title {
    switch (this) {
      case EProviderSortType.name:
        return 'Tên nhà cung cấp';
      case EProviderSortType.code:
        return 'Mã nhà cung cấp';

      default:
        return '';
    }
  }
}
