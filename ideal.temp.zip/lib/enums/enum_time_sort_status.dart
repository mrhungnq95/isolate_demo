enum ETimeSortStatus { asc, desc }

extension ETimeSortStatusExt on ETimeSortStatus {
  int get rawValue {
    switch (this) {
      case ETimeSortStatus.asc:
        return 1;
      case ETimeSortStatus.desc:
        return 2;
      default:
        return 1;
    }
  }

  static ETimeSortStatus valueOf(int value) {
    switch (value) {
      case 1:
        return ETimeSortStatus.asc;
      case 2:
        return ETimeSortStatus.desc;
      default:
        return ETimeSortStatus.asc;
    }
  }

  String getTitle() {
    switch (this) {
      case ETimeSortStatus.asc:
        return "Thời gian tăng dần";
      case ETimeSortStatus.desc:
        return "Thời gian giảm dần";
      default:
        return "";
    }
  }
}
