///
/// Enum
///
enum EObjectType {
  all, // Tất cả
  supply, // NCC
  customer, // KH
  deliveryPartner, // Đối tác giao hàng
  employee // Nhân viên
}

extension EObjectTypeExtension on EObjectType {
  String get title {
    switch (this) {
      case EObjectType.all:
        return 'Tất cả';
      case EObjectType.supply:
        return 'Nhà cung cấp';
      case EObjectType.customer:
        return 'Khách hàng';
      case EObjectType.deliveryPartner:
        return 'Đối tác giao hàng';
      case EObjectType.employee:
        return 'Nhân viên';
      default:
        return '';
    }
  }
}
