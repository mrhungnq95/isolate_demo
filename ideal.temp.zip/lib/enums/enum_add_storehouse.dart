enum EAddStorehouse {
  other, // Khác
  transfer // Điều chuyển
}

extension EAddStorehouseReceiptExt on EAddStorehouse {
  String get title {
    switch (this) {
      case EAddStorehouse.other:
        return 'Khác';
      case EAddStorehouse.transfer:
        return 'Điều chuyển';
      default:
        return '';
    }
  }

  static EAddStorehouse valueOf(int value) {
    switch (value) {
      case 0:
        return EAddStorehouse.other;
      case 1:
        return EAddStorehouse.transfer;
        return EAddStorehouse.other;
    }
  }
}
