enum EDateFilterType { day, week, month, custom }

extension EDateFilterTypeExt on EDateFilterType {
  String getTitle() {
    switch (this) {
      case EDateFilterType.day:
        return "Ngày";
      case EDateFilterType.week:
        return "Tuần";
      case EDateFilterType.month:
        return "Tháng";
      case EDateFilterType.custom:
        return "Tuỳ chỉnh";
      default:
        return null;
    }
  }

  static EDateFilterType valueOf(int value) {
    switch (value) {
      case 0:
        return EDateFilterType.day;
      case 1:
        return EDateFilterType.week;
      case 2:
        return EDateFilterType.month;
      case 3:
        return EDateFilterType.custom;
      default:
        return EDateFilterType.day;
    }
  }

  int get rawValue {
    switch (this) {
      case EDateFilterType.day:
        return 0;
      case EDateFilterType.week:
        return 1;
      case EDateFilterType.month:
        return 2;
      case EDateFilterType.custom:
        return 3;
      default:
        return 0;
    }
  }
}
