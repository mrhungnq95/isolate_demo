// BY_HOUR(0, R.string.common_label_by_hours),
//   BY_DAY_OF_WEEK(1, R.string.common_label_by_day_of_week),
//   BY_DAY(2, R.string.common_label_by_day),
//   BY_WEEK(3, R.string.common_label_by_week),
//   BY_MONTH(4, R.string.common_label_by_month),
//   BY_QUARTER(5, R.string.common_label_by_quarter),
//   BY_YEARS(6, R.string.common_label_by_year),
//   CUSTOM(-1, R.string.common_label_other);

enum ERevenueReportType {
  byHour,
  byDateOfWeek,
  byDay,
  byWeek,
  byMonth,
  byQuarter,
  byYear,
  custom
}

extension ERevenueReportTypeExt on ERevenueReportType {
  static ERevenueReportType valueOf(int value) {
    switch (value) {
      case 0:
        return ERevenueReportType.byHour;
      case 1:
        return ERevenueReportType.byDateOfWeek;
      case 2:
        return ERevenueReportType.byDay;
      case 3:
        return ERevenueReportType.byWeek;
      case 4:
        return ERevenueReportType.byMonth;
      case 5:
        return ERevenueReportType.byQuarter;
      case 6:
        return ERevenueReportType.byYear;
      case -1:
        return ERevenueReportType.custom;
      default:
        return null;
    }
  }

  int get rawValue {
    switch (this) {
      case ERevenueReportType.byHour:
        return 0;
      case ERevenueReportType.byDateOfWeek:
        return 1;
      case ERevenueReportType.byDay:
        return 2;
      case ERevenueReportType.byWeek:
        return 3;
      case ERevenueReportType.byMonth:
        return 4;
      case ERevenueReportType.byQuarter:
        return 5;
      case ERevenueReportType.byYear:
        return 6;
      case ERevenueReportType.custom:
        return -1;
      default:
        return -1;
    }
  }

  String getTitle() {
    switch (this) {
      case ERevenueReportType.byHour:
        return "Theo giờ";
      case ERevenueReportType.byDateOfWeek:
        return "Theo thứ";
      case ERevenueReportType.byDay:
        return "Theo ngày";
      case ERevenueReportType.byWeek:
        return "Theo tuần";
      case ERevenueReportType.byMonth:
        return "Theo tháng";
      case ERevenueReportType.byQuarter:
        return "Theo quý";
      case ERevenueReportType.byYear:
        return "Theo năm";
      case ERevenueReportType.custom:
        return "Khác";
      default:
        return "Khác";
    }
  }

  ///
  /// Lấy title của đơn vị Ox
  ///
  String getAxisTitle() {
    switch (this) {
      case ERevenueReportType.byHour:
        return "Giờ";
      case ERevenueReportType.byDateOfWeek:
        return "Thứ";
      case ERevenueReportType.byDay:
        return "Ngày";
      case ERevenueReportType.byWeek:
        return "Tuần";
      case ERevenueReportType.byMonth:
        return "Tháng";
      case ERevenueReportType.byQuarter:
        return "Quý";
      case ERevenueReportType.byYear:
        return "Năm";
      case ERevenueReportType.custom:
        return "Ngày";
      default:
        return "";
    }
  }
}
