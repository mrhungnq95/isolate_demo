enum ELicenseNegativeButton {
  skip, 
  close,
  signout
}