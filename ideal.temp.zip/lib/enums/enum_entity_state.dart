///
/// Các trạng thái của object
///
enum EEntityState { none, add, update, delete, duplicate }

extension ENotificationTypeExt on EEntityState {
static EEntityState valueOf(int value) {
    switch (value) {
      case 0:
        return EEntityState.none;
      case 1:
        return EEntityState.add;
      case 2:
        return EEntityState.update;
      case 3:
        return EEntityState.delete;
      case 4:
        return EEntityState.duplicate;
    }
  }
}