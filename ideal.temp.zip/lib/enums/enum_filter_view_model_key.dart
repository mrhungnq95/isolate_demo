enum EFilterViewModelKey {
  overview,
  revenue,
  inventoryItem, // ds Hàng hóa
  listInvoice, // Ds hóa đơn
  customer,
  customer_transaction_history,
  listVendor,
  listItemNoteReceipt,
  debtCustomer, // Công nợ khách hàng
  overview_chain
}
