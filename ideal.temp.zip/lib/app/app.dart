import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class MSApplication {
  MSApplication._internal();

  static final MSApplication shared = MSApplication._internal();

  Future<void> initialize() async {
    WidgetsFlutterBinding.ensureInitialized();

    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.transparent, // status bar color
      statusBarIconBrightness: Brightness.dark, // status bar icon color
      systemNavigationBarIconBrightness:
          Brightness.light, // color of navigation controls
    ));

    _configFlutterLoading();

    //init firebase sdk
    await LocalStorage.initialize();
    await setupDependencies();
  }

  ///
  /// Config chung cho Flutter Easy Loading
  ///
  void _configFlutterLoading() {
    EasyLoading.instance
      ..displayDuration = const Duration(milliseconds: 2000)
      ..indicatorType = EasyLoadingIndicatorType.fadingCircle
      ..loadingStyle = EasyLoadingStyle.custom
      ..indicatorSize = 45.0
      ..radius = 10.0
      ..progressColor = AppColor.white
      ..backgroundColor = AppColor.indigo900
      ..indicatorColor = Colors.white
      ..textColor = Colors.white
      ..maskColor = Colors.blue.withOpacity(0.5)
      ..maskType = EasyLoadingMaskType.black
      ..userInteractions = true
      ..dismissOnTap = false;
  }
}
