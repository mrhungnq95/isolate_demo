import 'dart:ui';
import 'package:flutter/material.dart';

import 'app_color.dart';

class AppTheme {
  //Private constructor without body
  AppTheme._internal();

  static const String _fontNameNormal = 'OpenSans';
  static const String _fontNameBold = 'OpenSans-Bold';
  static const String _fontNameItalic = 'OpenSans-Italic';

  static final AppTheme shared = AppTheme._internal();

  TextTheme _getTextTheme(TextTheme base) {
    //final openSansTextStyle = GoogleFonts.openSans();

    return base.copyWith(
      button: TextStyle(
          color: AppColor.textColor,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          fontFamily: _fontNameBold),
      caption: TextStyle(
        color: AppColor.textCaptionColor,
        fontFamily: _fontNameNormal,
        fontSize: 12,
      ),
      bodyText1: TextStyle(
          color: AppColor.textColor, fontSize: 14, fontFamily: _fontNameNormal),
      bodyText2: TextStyle(
          color: AppColor.textColor, fontSize: 16, fontFamily: _fontNameBold),
      subtitle1: TextStyle(
          color: AppColor.textColor,
          fontSize: 16,
          fontFamily: _fontNameNormal), //SubHeader
      subtitle2: TextStyle(
          color: AppColor.textColor,
          fontSize: 18,
          fontFamily: _fontNameBold), //Body 3
      headline1: TextStyle(
          color: AppColor.textColor, fontSize: 24, fontFamily: _fontNameNormal),
      headline2: TextStyle(
          color: AppColor.textColor, fontSize: 24, fontFamily: _fontNameBold),
    );
  }

  ThemeData getLightTheme() {
    final ColorScheme colorScheme = const ColorScheme.light().copyWith(
      primary: AppColor.primaryColor,
      secondary: AppColor.secondaryColor,
    );
    final ThemeData base = ThemeData.light();
    return base.copyWith(
      colorScheme: colorScheme,
      primaryColor: AppColor.primaryColor,
      buttonColor: AppColor.primaryColor,
      primaryColorDark: AppColor.primaryColor,
      indicatorColor: Colors.white,
      splashColor: Colors.white24,
      floatingActionButtonTheme: base.floatingActionButtonTheme.copyWith(
          foregroundColor: Colors.white,
          backgroundColor: AppColor.primaryColor),
      splashFactory: InkRipple.splashFactory,
      accentColor: AppColor.secondaryColor,
      canvasColor: Colors.white,
      backgroundColor: AppColor.white,
      scaffoldBackgroundColor: AppColor.white,
      errorColor: const Color(0xFFB00020),
      buttonTheme: ButtonThemeData(
        colorScheme: colorScheme,
        textTheme: ButtonTextTheme.primary,
      ),
      textTheme: _getTextTheme(base.textTheme),
      primaryTextTheme: _getTextTheme(base.primaryTextTheme),
      accentTextTheme: _getTextTheme(base.accentTextTheme),
      platform: TargetPlatform.iOS,
      unselectedWidgetColor: AppColor.grey600.withOpacity(0.6),
    );
  }
}
