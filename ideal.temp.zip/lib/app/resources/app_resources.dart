part of 'resources.dart';

class AppResources {
  static const String icInvoiceFill = 'assets/images/ic_invoice_fill.png';
  static const String icCustomerGrey = 'assets/images/ic_customer_grey.png';
  static const String icMailGreen = 'assets/images/ic_mail_green.png';
  static const String icNotificationSetting =
      'assets/images/ic_notification_setting.png';
  static const String icMoneyFill2 = 'assets/images/ic_money_fill_2.png';
  static const String icCustomer = 'assets/images/ic_customer.png';
  static const String icPinkCash = 'assets/images/ic_pink_cash.png';
  static const String icTrash = 'assets/images/ic_trash.png';
  static const String icCashDollar = 'assets/images/ic_cash_dollar.png';
  static const String bgSplash = 'assets/images/bg_splash.jpg';
  static const String icPassword = 'assets/images/ic_password.png';
  static const String icNavReport = 'assets/images/ic_nav_report.png';
  static const String icComponentOther = 'assets/images/ic_component_other.png';
  static const String icGuideLongClick =
      'assets/images/ic_guide_long_click.png';
  static const String icCalendar = 'assets/images/ic_calendar.png';
  static const String icNotification = 'assets/images/ic_notification.png';
  static const String icCircleDelete = 'assets/images/ic_circle_delete.png';
  static const String bgAvt2 = 'assets/images/bg_avt2.png';
  static const String icCod = 'assets/images/ic_cod.png';
  static const String icRefresh = 'assets/images/ic_refresh.png';
  static const String icLogoWithText = 'assets/images/icLogoWithText.png';
  static const String icImage = 'assets/images/ic_image.png';
  static const String icCashPayment = 'assets/images/ic_cash_payment.png';
  static const String icSetting = 'assets/images/ic_setting.png';
  static const String bgAvt1 = 'assets/images/bg_avt1.png';
  static const String icShortcutOther = 'assets/images/ic_shortcut_other.png';
  static const String icCardPayment = 'assets/images/ic_card_payment.png';
  static const String icStockGrey = 'assets/images/ic_stock_grey.png';
  static const String icBarcode = 'assets/images/ic_barcode.png';
  static const String icNotificationImport =
      'assets/images/ic_notification_import.png';
  static const String icCamera = 'assets/images/ic_camera.png';
  static const String icFaceid = 'assets/images/ic_faceid.png';
  static const String icSale = 'assets/images/ic_sale.png';
  static const String bgPassword = 'assets/images/bg_password.png';
  static const String bgAboutLogo = 'assets/images/bg_about_logo.png';
  static const String icAvatarPlaceHolder =
      'assets/images/ic_avatar_place_holder.png';
  static const String icInvoice = 'assets/images/ic_invoice.png';
  static const String icStorageUp = 'assets/images/ic_storage_up.png';
  static const String icNotificationExchange =
      'assets/images/ic_notification_exchange.png';
  static const String icDateTime = 'assets/images/ic_date_time.png';
  static const String icBranch = 'assets/images/ic_branch.png';
  static const String icOrderOnline = 'assets/images/ic_order_online.png';
  static const String icNavInvoice = 'assets/images/ic_nav_invoice.png';
  static const String bgEshopLogo = 'assets/images/bg_eshop_logo.png';
  static const String icNotificationReturnInventory =
      'assets/images/ic_notification_return_inventory.png';
  static const String icInfo = 'assets/images/ic_info.png';
  static const String icNotificationSystem =
      'assets/images/ic_notification_system.png';
  static const String icFilledFilter = 'assets/images/ic_filled_filter.png';
  static const String bgChecking = 'assets/images/bg_checking.png';
  static const String icItemUp = 'assets/images/ic_item_up.png';
  static const String icOtherDineIn = 'assets/images/ic_other_dine_in.png';
  static const String icMoney = 'assets/images/ic_money.png';
  static const String icNotificationCancelInvoice =
      'assets/images/ic_notification_cancel_invoice.png';
  static const String icMisaSupportGroup =
      'assets/images/ic_misa_support_group.png';
  static const String icItemDown = 'assets/images/ic_item_down.png';
  static const String icAppConsultant = 'assets/images/ic_app_consultant.png';
  static const String icGuideSwipe = 'assets/images/ic_guide_swipe.png';
  static const String icMail = 'assets/images/ic_mail.png';
  static const String icStorage = 'assets/images/ic_storage.png';
  static const String icFilter = 'assets/images/ic_filter.png';
  static const String icShare = 'assets/images/ic_share.png';
  static const String icDuplicate2 = 'assets/images/ic_duplicate_2.png';
  static const String icTime = 'assets/images/ic_time.png';
  static const String icNotificationInvoice =
      'assets/images/ic_notification_invoice.png';
  static const String icPhone = 'assets/images/ic_phone.png';
  static const String icKey = 'assets/images/ic_key.png';
  static const String icMoneyCircle = 'assets/images/ic_money_circle.png';
  static const String icLogout = 'assets/images/ic_logout.png';
  static const String icCoinCard = 'assets/images/ic_coin_card.png';
  static const String icNotificationOutward =
      'assets/images/ic_notification_outward.png';
  static const String icShare2 = 'assets/images/ic_share_2.png';
  static const String icInventoryEmpty = 'assets/images/ic_inventory_empty.png';
  static const String icStar = 'assets/images/ic_star.png';
  static const String icEdit = 'assets/images/ic_edit.png';
  static const String icOrderWebNoti = 'assets/images/ic_order_web_noti.png';
  static const String icCircleEdit = 'assets/images/ic_circle_edit.png';
  static const String icFlatSetting = 'assets/images/ic_flat_setting.png';
  static const String icCalendarFill = 'assets/images/ic_calendar_fill.png';
  static const String icFlashSaleItem = 'assets/images/ic_flash_sale_item.png';
  static const String bgKey = 'assets/images/bg_key.png';
  static const String icSearch = 'assets/images/ic_search.png';
  static const String bgHeaderPage = 'assets/images/bg_header_page.png';
  static const String icContact = 'assets/images/ic_contact.png';
  static const String icNotificationMshop =
      'assets/images/ic_notification_mshop.png';
  static const String bgInventoryItemInStore =
      'assets/images/bg_inventory_item_in_store.png';
  static const String icNavOverview = 'assets/images/ic_nav_overview.png';
  static const String icCheckItem = 'assets/images/ic_check_item.png';
  static const String icEmptyChart = 'assets/images/ic_empty_chart.png';
  static const String imageDefault = 'assets/images/image_default.png';
  static const String icSettingNotification =
      'assets/images/ic_setting_notification.png';
  static const String icAppSale = 'assets/images/ic_app_sale.png';
  static const String icBill = 'assets/images/ic_bill.png';
  static const String icCoin = 'assets/images/ic_coin.png';
  static const String icOrderOcm = 'assets/images/ic_order_ocm.png';
  static const String icRedCircleRemove =
      'assets/images/ic_red_circle_remove.png';
  static const String icHelp = 'assets/images/ic_help.png';
  static const String icCashReceiptToday =
      'assets/images/ic_cash_receipt_today.png';
  static const String icDelivery = 'assets/images/ic_delivery.png';
  static const String icMisaSupport = 'assets/images/ic_misa_support.png';
  static const String icNotificationEditInvoice =
      'assets/images/ic_notification_edit_invoice.png';
  static const String icEstimateRevenue =
      'assets/images/ic_estimate_revenue.png';
  static const String icUserName = 'assets/images/ic_user_name.png';
  static const String icStorageCheck = 'assets/images/ic_storage_check.png';
  static const String icGlobal = 'assets/images/ic_global.png';
  static const String icSecurityLock = 'assets/images/ic_security_lock.png';
  static const String icItem = 'assets/images/ic_item.png';
  static const String icEdit2 = 'assets/images/ic_edit_2.png';
  static const String icPromotion = 'assets/images/ic_promotion.png';
  static const String icPolicy = 'assets/images/ic_policy.png';
  static const String icNotificationWarning =
      'assets/images/ic_notification_warning.png';
  static const String icQuickMenuSettings =
      'assets/images/ic_quick_menu_settings.png';
  static const String icSort = 'assets/images/ic_sort.png';
  static const String icColumnChart = 'assets/images/ic_column_chart.png';
  static const String icGreenCircleAdd =
      'assets/images/ic_green_circle_add.png';
  static const String icOrder = 'assets/images/ic_order.png';
  static const String icRevenueToday = 'assets/images/ic_revenue_today.png';
  static const String icInvoiceFillPending =
      'assets/images/ic_invoice_fill_pending.png';
  static const String icCalendarPurple = 'assets/images/ic_calendar_purple.png';
  static const String icDuplicate = 'assets/images/ic_duplicate.png';
  static const String icNotificationImportStock =
      'assets/images/ic_notification_import_stock.png';
  static const String icBusinessStatus = 'assets/images/ic_business_status.png';
  static const String icRevenue = 'assets/images/ic_revenue.png';
  static const String icRevenueExpend = 'assets/images/ic_revenue_expend.png';
  static const String icMerchandise = 'assets/images/ic_merchandise.png';
  static const String icInventoryItem = 'assets/images/ic_inventory_item.png';
  static const String icInventoryItemByDate =
      'assets/images/inventory_item_by_date.png';
}
