import 'package:MShopManager/utils/screen_utils.dart';
import 'package:flutter/material.dart';

const double kVerticalSpaceTiny = 4.0;
const double kVerticalSpaceSmall = 6.0;
const double kVerticalSpaceOverSmall = 8.0;
const double kVerticalSpaceMedium = 12.0;
const double kVerticalSpaceLarge = 16.0;
const double kVerticalSpaceBig = 20.0;
const double kVerticalSpaceHuge = 24.0;

const double kHorizontalSpaceTiny = 4.0;
const double kHorizontalSpaceSmall = 6.0;
const double kHorizontalSpaceOverSmall = 8.0;
const double kHorizontalSpaceMedium = 12.0;
const double kHorizontalSpaceLarge = 16.0;
const double kHorizontalSpaceBig = 20.0;
const double kHorizontalSpaceHuge = 24.0; 

const double kNavPaddingContent = 120.0;

const EdgeInsets kPaddingScreen = EdgeInsets.all(16.0);
double kVerticalSpaceWithSafeArea = ScreenUtils.bottomSafeAreaHeight > 0 ? ScreenUtils.bottomSafeAreaHeight : kVerticalSpaceMedium;

const Widget kSpaceShrinkBox = SizedBox.shrink();
const Widget kVerticalSpaceSmallBox = SizedBox(height: kVerticalSpaceSmall);
const Widget kVerticalSpaceOverSmallBox =
    SizedBox(height: kVerticalSpaceOverSmall);
const Widget kVerticalSpaceTinyBox = SizedBox(height: kVerticalSpaceTiny);
const Widget kVerticalSpaceMediumBox = SizedBox(height: kVerticalSpaceMedium);
const Widget kVerticalSpaceLargeBox = SizedBox(height: kVerticalSpaceLarge);
const Widget kVerticalSpaceBigBox = SizedBox(height: kHorizontalSpaceBig);
const Widget kVerticalSpaceHugeBox = SizedBox(height: kVerticalSpaceHuge);
const Widget kHorizontalSpaceSmallBox = SizedBox(width: kHorizontalSpaceSmall);
const Widget kHorizontalSpaceTinyBox = SizedBox(width: kHorizontalSpaceTiny);
const Widget kHorizontalSpaceOverSmallBox = SizedBox(width: kHorizontalSpaceSmall);
const Widget kHorizontalSpaceMediumBox =
    SizedBox(width: kHorizontalSpaceMedium);
const Widget kHorizontalSpaceLargeBox = SizedBox(width: kHorizontalSpaceLarge);
Widget kSpaceWithSafeAreaBox = SizedBox(height: ScreenUtils.bottomSafeAreaHeight > 0 ? ScreenUtils.bottomSafeAreaHeight : kVerticalSpaceMedium);
