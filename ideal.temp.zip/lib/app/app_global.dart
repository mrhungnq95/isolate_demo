import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/base/ms_base_float_modal_bottom_sheet.dart';
import 'package:MShopManager/widget/date_time/date_view_picker.dart';
import 'package:MShopManager/widget/date_time/range_date_view_picker.dart';
import 'package:MShopManager/widget/date_time/time_view_picker.dart';
import 'package:android_intent/android_intent.dart';
import 'package:device_apps/device_apps.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_color.dart';

///
/// Hiển thị bottom sheet dạng floating trên màn hình
///
Future<T> showFloatingModalBottomSheet<T>({
  @required BuildContext context,
  @required WidgetBuilder builder,
  final String title,
  Color backgroundColor,
}) async {
  final result = await showCustomModalBottomSheet(
      context: context,
      builder: builder,
      containerWidget: (_, animation, child) => MSBaseFloatingModalBottomSheet(
            title: title,
            child: child,
          ),
      expand: false);

  return result;
}

///
/// Hiển thị dialog chọn ngày
///
Future<T> showDatePickerDialog<T>(
    {@required BuildContext context,
    @required DateTime initDateTime,
    String title,
    bool useRootNavigator = true,
    final VoidCallback onClose,
    @required Function(DateTime date) onConfirm}) async {
  return await showGeneralDialog(
    context: context,
    useRootNavigator: false,
    barrierDismissible: false,
    barrierColor: Colors.black.withOpacity(0.5),
    pageBuilder: (_context, anim1, anim2) {
      return DateViewPicker(
          title: title,
          date: initDateTime,
          onClose: onClose,
          onConfirm: onConfirm);
    },
  );
}

///
/// Hiển thị dialog chọn thời gian
///
Future<T> showTimePickerDialog<T>(
    {@required BuildContext context,
    @required DateTime initDateTime,
    String title,
    bool useRootNavigator = true,
    final VoidCallback onClose,
    @required Function(DateTime date) onConfirm}) async {
  return await showGeneralDialog(
    context: context,
    useRootNavigator: false,
    barrierDismissible: false,
    barrierColor: Colors.black.withOpacity(0.5),
    pageBuilder: (_context, anim1, anim2) {
      return TimeViewPicker(
          title: title,
          date: initDateTime,
          onClose: onClose,
          onConfirm: onConfirm);
    },
  );
}

///
/// Hiển thị dialog chọn khoảng thời gian
///
Future<T> showDateRangePickerDialog<T>(
    {@required BuildContext context,
    @required DateTime fromDate,
    @required DateTime toDate,
    String title,
    bool useRootNavigator = true,
    final VoidCallback onClose,
    @required Function(DateTime fromDate, DateTime toDate) onConfirm}) async {
  return await showGeneralDialog(
    context: context,
    useRootNavigator: false,
    barrierDismissible: false,
    barrierColor: Colors.black.withOpacity(0.5),
    pageBuilder: (_context, anim1, anim2) {
      return DateRangeViewPicker(
        title: title,
        fromDate: fromDate,
        toDate: toDate,
        onClose: onClose,
        onConfirm: onConfirm,
      );
    },
  );
}

/// show thông báo dialog
Future<T> showMessageDialog<T>({
  @required BuildContext context,
  String title = 'MISA eShop',
  @required String content,
  Function onOKPressed,
}) {
  return showConfirmDialog(
    context: context,
    title: title,
    content: content,
    actions: <Widget>[
      TextButton(
        child: Text(
          'OK',
          style: Theme.of(context).textTheme.bodyText2,
        ),
        onPressed: () {
          onOKPressed?.call();
          NavigationHelper.shared.maybePop();
        },
      ),
    ],
  );
}

/// show confirm dialog
Future<T> showConfirmDialog<T>({
  @required BuildContext context,
  String title = 'MISA eShop',
  @required String content,
  List<Widget> actions,
  String negativeTextButtonTitle,
  String positiveTextButtonTitle,
  Function onAcceptPressed,
  Function onCancelPressed,
}) {
  return showDialog<T>(
    context: context,
    builder: (BuildContext context) {
      if (actions == null) {
        actions = <Widget>[
          TextButton(
            child: Text(
              negativeTextButtonTitle ?? 'Không',
              style: Theme.of(context).textTheme.bodyText2,
            ),
            onPressed: onCancelPressed,
          ),
          TextButton(
            child: Text(
              positiveTextButtonTitle ?? 'Có',
              style: Theme.of(context).textTheme.bodyText2,
            ),
            onPressed: onAcceptPressed,
          ),
        ];
      }
      return AlertDialog(
        title: Text(title),
        titleTextStyle: Theme.of(context).textTheme.subtitle2,
        titlePadding: EdgeInsets.all(kHorizontalSpaceLarge),
        contentPadding: EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        buttonPadding: EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        insetPadding:
            EdgeInsets.symmetric(horizontal: ScreenUtils.width * 0.05),
        actionsPadding: EdgeInsets.zero,
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              HtmlWidget(
                content,
                textStyle: Theme.of(context).textTheme.bodyText1,
              ),
            ],
          ),
        ),
        actions: actions,
      );
    },
  );
}

/// Hiển thị toast
void showToast(String msg) {
  Fluttertoast.showToast(
      msg: msg,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: AppColor.grey700,
      textColor: Colors.white,
      fontSize: 16.0);
}

///
/// Hiển thị tính năng đang phát triển
///
void showToastFeatureDeveloping() {
  showToast('Tính năng đang phát triển');
}

///
/// Show form số điện thoại để gọi
/// TODO - VNLONG Cần viết
///
void callPhoneNumber({String phoneNumber}) {}

///
/// Mở app với nền tảng ios
/// [urlSchemaIos]: Id app để mở với trường hợp đã cài sẵn
/// [urlAppStore]: Url để mở lên store với trường hợp chưa cài app
/// VNLONG - 28/01/2021
///
void openOtherAppOnPlatformIos(
    {@required String urlSchemaIos, @required String urlAppStore}) async {
  final result = await launch(urlSchemaIos);

  /// Kiểm tra xem app đã cài lên thiết bị hay chưa?
  if (!result) {
    // Mở app bằng link trên store
    openAppOnAppStore(urlAppStore: urlAppStore);
  }
}

///
/// Mở app trên AppStore
/// [urlAppStore]: Url để mở lên store với trường hợp chưa cài app
/// VNLONG - 28/01/2021
///
void openAppOnAppStore({@required String urlAppStore}) async {
  if (await canLaunch(urlAppStore)) {
    await launch(urlAppStore);
  } else {
    showToast('Không thể mở ứng dụng. Vui lòng thử lại sau.');
  }
}

///
/// Mở app với android
/// [packageNameAndroid]: Tên gói android cần mở
/// VNLONG - 28/01/2021
///
void openAppOnPlatformAndroid({@required String packageNameAndroid}) async {
  final String urlApp = 'https://play.google.com/store/apps/details?'
      'id=${packageNameAndroid}';
  bool isInstalled = await DeviceApps.isAppInstalled(packageNameAndroid);
  if (isInstalled) {
    /// Mở app
    AndroidIntent intent = AndroidIntent(action: 'action_view', data: urlApp);
    await intent.launch();
  } else {
    openAppOnPlayStore(packageNameAndroid: packageNameAndroid);
  }
}

///
/// Mở app trên google play
/// [packageNameAndroid]: Tên gói android cần mở
/// VNLONG - 28/01/2021
///
void openAppOnPlayStore({@required String packageNameAndroid}) async {
  String url = 'market://details?id=${packageNameAndroid}';
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    showToast('Không thể mở ứng dụng. Vui lòng thử lại sau.');
  }
}

///
/// Mở url bất kỳ qua trình duyệt mặc định
/// [url] url muốn mở
///
Future<bool> launchUrl(String url) async {
  if (await canLaunch(url)) {
    return launch(url);
  }
  return false;
}
