import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/utils/logger_utils.dart';
import 'package:flutter/material.dart';

class NavigationHelper {
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static final NavigationHelper shared = NavigationHelper._();

  NavigationHelper._();

  Future<dynamic> navigateTo(
      {@required AppRouterName routeName, dynamic argument}) {
    FLogger.shared.log("navigateTo to ${routeName} with args $argument");
    return navigatorKey?.currentState
            ?.pushNamed(routeName.value(), arguments: argument) ??
        Future.value(null);
  }

  Future<dynamic> navigateReplacementNamed(
      {@required AppRouterName routeName,
      RoutePredicate predicate,
      dynamic argument}) {
    FLogger.shared
        .log("pushNamedAndRemoveUntil to ${routeName} with args $argument");

    return navigatorKey?.currentState?.pushNamedAndRemoveUntil(
            routeName.value(),
            predicate == null
                ? (route) {
                    return false;
                  }
                : predicate,
            arguments: argument) ??
        Future.value(null);
  }

  void pop({dynamic data}) {
    FLogger.shared.log("pop and return data: $data");
    navigatorKey?.currentState?.pop(data);
  }

  Future<bool> maybePop({dynamic obj}) async {
    FLogger.shared.log("maybePop and return data: $obj");
    final result = navigatorKey?.currentState?.maybePop(obj) ?? false;
    return result;
  }

  void popUntil(RoutePredicate predicate) {
    FLogger.shared.log("popUntil");
    navigatorKey?.currentState?.popUntil(predicate);
  }
}
