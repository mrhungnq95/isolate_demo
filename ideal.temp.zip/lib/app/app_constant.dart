abstract class AppConstant {
  static const String UUID_EMPTY = "00000000-0000-0000-0000-000000000000";
  static const int LOAD_MORE_THRESHOLD = 100;

  /// Mã NCC pattern
  static final RegExp phoneNumberPattern = RegExp(r'^[0-9+\s()._-]{8,15}$');

  /// Link chính sách bảo mật
  static const String privacy_policy_vn =
      "https://www.mshopkeeper.vn/chinh-sach-bao-mat";
  static const String privacy_policy_com =
      "https://mshopkeeper.com/privacy-policy";

  /// Link help
  static const String link_help_vn =
      "http://mhelp.mshopkeeper.vn/categories/quan-ly-cua-hang";
  static const String link_help_com = "https://help.mshopkeeper.com/";

  /// Id app misa support
  static const String misa_support_android_package_name =
      'vn.com.misa.misasupport';
  static const String url_schema_ios_misa_support =
      'vn.com.misa.customersupport.app://';
  static const String url_misa_support_app_store =
      'https://itunes.apple.com/us/app/misa-support/id1401468223';

  /// Id app eshop-sale
  static const String sale_android_package_name = 'vn.com.misa.mshopsalephone';
  static const String url_schema_ios_eshop_sale =
      'vn.com.misa.qlchsalephone://';
  static const String url_eshop_sale_app_store =
      'itms-apps://itunes.apple.com/app/id1444979592';

  /// Id app eshop-consultant
  static const String consultant_android_package_name =
      'vn.com.misa.qlchconsultant';
  static const String url_schema_ios_eshop_consultant =
      'vn.com.misa.qlchconsultant://';
  static const String url_eshop_consultant_app_store =
      'itms-apps://itunes.apple.com/app/id1299030722';
}
