//
// Created by  on 30/10/2020.
//
import 'package:MShopManager/app/app_nested_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/features/about/page/about_page.dart';
import 'package:MShopManager/features/customer/page/add_customer_page.dart';
import 'package:MShopManager/features/customer/page/customer_category_page.dart';
import 'package:MShopManager/features/customer/page/customer_detail_page.dart';
import 'package:MShopManager/features/customer/page/customer_filter_page.dart';
import 'package:MShopManager/features/customer/page/customer_list_page.dart';
import 'package:MShopManager/features/customer/page/select_customer_address_page.dart';
import 'package:MShopManager/features/overview/page/overview_chain_page.dart';
import 'package:MShopManager/features/overview/page/overview_filter_page.dart';
import 'package:MShopManager/features/overview/page/overview_page.dart';
import 'package:MShopManager/features/inventory_item/add_inventory_item/page/add_inventory_item_page.dart';
import 'package:MShopManager/features/inventory_item/category_inventory_item/page/category_inventory_item_page.dart';
import 'package:MShopManager/features/inventory_item/declaration_inventory_item/page/declaration_inventory_item_page.dart';
import 'package:MShopManager/features/inventory_item/list_inventory_item/page/inventory_item_filter_page.dart';
import 'package:MShopManager/features/inventory_item/list_inventory_item/page/inventory_item_page.dart';
import 'package:MShopManager/features/inventory_item_in_store/page/inventory_item_in_store_detail_page.dart';
import 'package:MShopManager/features/inventory_item_in_store/page/inventory_item_in_store_filter_page.dart';
import 'package:MShopManager/features/inventory_item_in_store/page/inventory_item_in_store_page.dart';
import 'package:MShopManager/features/invoice/list_invoice_filter_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/page/add_import_inventory_item_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/page/choose_employee_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/detail/detail_import_item_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/filter/import_inventory_item_filter_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/list/import_inventory_item_page.dart';
import 'package:MShopManager/features/other/import_inventory_item/page/payment_method_page.dart';
import 'package:MShopManager/features/other/provider/choose/choose_provider_page.dart';
import 'package:MShopManager/features/other/provider/detail/detail_provider_page.dart';
import 'package:MShopManager/features/other/provider/filter/provider_filter_page.dart';
import 'package:MShopManager/features/other/provider/list/provider_page.dart';
import 'package:MShopManager/features/invoice/list_invoice_page.dart';
import 'package:MShopManager/features/notification/page/notification_setting_page.dart';
import 'package:MShopManager/features/other/language_setting/page/language_setting_page.dart';
import 'package:MShopManager/features/other/other_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/add_return_inventory_item_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/choose_import_item_return_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/choose_inventory_item_return_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/detail_return_inventory_item_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/payment_info_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/return_inventory_item_filter_page.dart';
import 'package:MShopManager/features/other/return_inventory_item/page/return_inventory_item_page.dart';
import 'package:MShopManager/features/other/sercurity_setting/page/sercurity_setting_page.dart';
import 'package:MShopManager/features/other/setting/page/setting_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/add_storehouse_receipt_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/choose_branch_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/choose_transfer_document_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/detail_inventory_item_storehouse_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/detail_storehouse_receipt_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/storehouse_receipt_filter_page.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/storehouse_receipt_page.dart';
import 'package:MShopManager/features/notification/page/notification_page.dart';
import 'package:MShopManager/features/overview/provider/overview_chain_view_model.dart';
import 'package:MShopManager/features/recoverypassword/presentation/page/recovery_password_page.dart';
import 'package:MShopManager/features/report/best_seller/page/best_seller_filter_page.dart';
import 'package:MShopManager/features/report/best_seller/page/best_seller_page.dart';
import 'package:MShopManager/features/report/business_situation/page/business_situation_filter_page.dart';
import 'package:MShopManager/features/report/business_situation/page/business_situation_page.dart';
import 'package:MShopManager/features/report/chain_store/page/chain_store_detail_page.dart';
import 'package:MShopManager/features/report/chain_store/page/chain_store_page.dart';
import 'package:MShopManager/features/report/choose_inventory_item/page/choose_inventory_item_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/detail/report_inventories_by_exp_detail_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/filter/report_inventories_by_exp_filter.dart';
import 'package:MShopManager/features/report/debt_customer/page/debt_customer_filter_page.dart';
import 'package:MShopManager/features/report/checking/page/add_checking_page.dart';
import 'package:MShopManager/features/report/checking/page/checking_filter_page.dart';
import 'package:MShopManager/features/report/checking/page/checking_page.dart';
import 'package:MShopManager/features/report/debt_customer/page/debt_customer_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/report_inventories_by_exp_screen.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/page/inventories_in_lot_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/page/report_inventories_by_lot_detail_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/page/report_inventories_by_lot_filter_page.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/page/report_inventories_by_lot_page.dart';
import 'package:MShopManager/features/report/report_menu_page.dart';
import 'package:MShopManager/features/report/revenue/page/report_revenue_detail_page.dart';
import 'package:MShopManager/features/report/revenue/page/report_revenue_filter_page.dart';
import 'package:MShopManager/features/report/revenue/page/report_revenue_page.dart';
import 'package:MShopManager/features/signin/page/signin_page.dart';
import 'package:MShopManager/features/report/revenueandexpenditure/page/revenue_and_expenditure_detail_page.dart';
import 'package:MShopManager/features/report/revenueandexpenditure/page/revenue_and_expenditure_page.dart';
import 'package:MShopManager/features/splash/page/splash_page.dart';
import 'package:MShopManager/features/transaction_history/page/customer_transaction_history_filter.dart';
import 'package:MShopManager/features/transaction_history/page/customer_transaction_history_page.dart';
import 'package:MShopManager/main_page.dart';
import 'package:MShopManager/widget/unit/selectunit/page/select_unit_page.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/features/other/stock_issue/stock_issue_expose.dart'
    as vnlong;

class AppRouterHandler {
  static Route<dynamic> handleRouterNavigate(RouteSettings routeSetting) {
    final appRoute = AppRouterNameStringExt.valueOf(routeSetting.name);
    switch (appRoute) {
      case AppRouterName.root:
        return MaterialWithModalsPageRoute(builder: (_) => SplashPage());
      case AppRouterName.signin:
        return MaterialWithModalsPageRoute(
            builder: (_) => SignInPage(), settings: routeSetting);
      case AppRouterName.main:
        return MaterialWithModalsPageRoute(
            builder: (_) => MainPage(), settings: routeSetting);
      case AppRouterName.revenue_expenditure:
        return MaterialWithModalsPageRoute(
            builder: (_) => RevenueAndExpenditurePage(),
            settings: routeSetting);
      case AppRouterName.revenue_expenditure_detail:
        return MaterialWithModalsPageRoute(
            settings: routeSetting,
            builder: (_) => RevenueAndExpenditureDetailPage());
      case AppRouterName.list_invoice_filter:
        return MaterialWithModalsPageRoute(
          builder: (_) => ListInvoiceFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.report_inventories_by_expiry:
        return MaterialWithModalsPageRoute(
          builder: (_) => ReportInventoriesByExpScreen(),
          settings: routeSetting,
        );
      case AppRouterName.report_inventories_by_expiry_detail:
        return MaterialWithModalsPageRoute(
          builder: (_) => ReportInventoriesByExpDetailPage(),
          settings: routeSetting,
        );
      case AppRouterName.business_situation:
        return MaterialWithModalsPageRoute(
          builder: (_) => BusinessSituationPage(),
          settings: routeSetting,
        );
      case AppRouterName.business_situation_filter:
        return MaterialWithModalsPageRoute(
          builder: (_) => BusinessSituationFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.inventory_item_filter:
        return MaterialWithModalsPageRoute(
          builder: (_) => InventoryItemFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.inventory_item:
        return MaterialWithModalsPageRoute(
          builder: (_) => InventoryItemPage(),
          settings: routeSetting,
        );
      case AppRouterName.report_inventories_by_expiry_filter:
        return MaterialWithModalsPageRoute(
          builder: (_) => ReportInventoriesByExpFilterScreen(),
          settings: routeSetting,
        );
      case AppRouterName.select_unit:
        return MaterialWithModalsPageRoute(
            builder: (_) => SelectUnitPage(), settings: routeSetting);
      case AppRouterName.add_inventory_item:
        return MaterialWithModalsPageRoute(
          builder: (_) => AddInventoryItemPage(),
          settings: routeSetting,
        );
      case AppRouterName.category_inventory_item:
        return MaterialWithModalsPageRoute(
          builder: (_) => CategoryInventoryItemPage(),
          settings: routeSetting,
        );
      case AppRouterName.declaration_inventory_item:
        return MaterialWithModalsPageRoute(
          builder: (_) => DeclarationInventoryItemPage(),
          settings: routeSetting,
        );
      case AppRouterName.add_checking_page:
        return MaterialWithModalsPageRoute(
            settings: routeSetting, builder: (_) => AddCheckingPage());
      case AppRouterName.checking_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => CheckingFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.checking_page:
        return MaterialWithModalsPageRoute(
            settings: routeSetting, builder: (_) => CheckingPage());
      case AppRouterName.debt_customer_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => DebtCustomerFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.debt_customer_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => DebtCustomerPage(),
          settings: routeSetting,
        );
      case AppRouterName.storehouse_receipt_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => StorehouseReceiptPage(),
          settings: routeSetting,
        );
      case AppRouterName.storehouse_receipt_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => StorehouseReceiptFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_branch_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => ChooseBranchPage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_transfer_document_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => ChooseTransferDocumentPage(),
          settings: routeSetting,
        );
      case AppRouterName.add_storehouse_receipt_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => AddStorehouseReceiptPage(),
          settings: routeSetting,
        );
      case AppRouterName.detail_inventory_item_storehouse_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => DetailInventoryItemStorehousePage(),
          settings: routeSetting,
        );
      case AppRouterName.detail_storehouse_receipt_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => DetailStorehouseReceiptPage(),
          settings: routeSetting,
        );
      case AppRouterName.stock_issue_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.StockIssuePage(),
          settings: routeSetting,
        );
      case AppRouterName.stock_issue_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.StockIssueFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.add_stock_issue_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.AddStockIssuePage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_import_item_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.ChooseImportItemPage(),
          settings: routeSetting,
        );
      case AppRouterName.detail_stock_issue_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.DetailStockIssuePage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_import_item_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.ChooseImportItemFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_importer_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.ChooseImporterFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.choose_importer_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => vnlong.ChooseImporterPage(),
          settings: routeSetting,
        );
      case AppRouterName.provider_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => ProviderPage(),
          settings: routeSetting,
        );
      case AppRouterName.provider_filter_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => ProviderFilterPage(),
          settings: routeSetting,
        );
      case AppRouterName.detail_provider_page:
        return MaterialWithModalsPageRoute(
          builder: (_) => DetailProviderPage(),
          settings: routeSetting,
        );
      case AppRouterName.revenue:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportRevenuePage(), settings: routeSetting);
      case AppRouterName.report_revenue_detail:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportRevenueDetailPage(), settings: routeSetting);
      case AppRouterName.report_revenue_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportRevenueFilterPage(), settings: routeSetting);
      case AppRouterName.customer_list:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerListPage(), settings: routeSetting);
      case AppRouterName.customer_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerFilterPage(), settings: routeSetting);
      case AppRouterName.customer_detail:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerDetailPage(), settings: routeSetting);
      case AppRouterName.add_customer:
        return MaterialWithModalsPageRoute(
            builder: (_) => AddCustomerPage(), settings: routeSetting);
      case AppRouterName.customer_transaction_history:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerTransactionHistoryPage(),
            settings: routeSetting);
      case AppRouterName.customer_transaction_history_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerTransactionHistoryFilterPage(),
            settings: routeSetting);
      case AppRouterName.inventory_item_in_store:
        return MaterialWithModalsPageRoute(
            builder: (_) => InventoryItemInStorePage(), settings: routeSetting);
      case AppRouterName.inventory_item_in_store_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => InventoryItemInStoreFilterPage(),
            settings: routeSetting);
      case AppRouterName.inventory_item_detail_in_store:
        return MaterialWithModalsPageRoute(
            builder: (_) => InventoryItemInStoreDetailPage(),
            settings: routeSetting);
      case AppRouterName.chain_store:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChainStorePage(), settings: routeSetting);
      case AppRouterName.chain_store_detail:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChainStoreDetailPage(), settings: routeSetting);
      case AppRouterName.sercurity_setting:
        return MaterialWithModalsPageRoute(
            builder: (_) => SercuritySettingPage(), settings: routeSetting);
      case AppRouterName.notification_setting:
        return MaterialWithModalsPageRoute(
            builder: (_) => NotificationSettingPage(), settings: routeSetting);
      case AppRouterName.report_inventories_by_lot:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportInventoriesByLotPage(),
            settings: routeSetting);
      case AppRouterName.report_inventories_by_lot_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportInventoriesByLotFilterPage(),
            settings: routeSetting);
      case AppRouterName.inventories_in_lot_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => InventoriesInLotPage(), settings: routeSetting);
      case AppRouterName.report_inventories_by_lot_detail_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReportInventoriesByLotDetailPage(),
            settings: routeSetting);
      case AppRouterName.return_inventory_item_filter_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReturnInventoryItemFilterPage(),
            settings: routeSetting);
      case AppRouterName.return_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ReturnInventoryItemPage(), settings: routeSetting);
      case AppRouterName.payment_info_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => PaymentInfoPage(), settings: routeSetting);
      case AppRouterName.select_customer_address:
        return MaterialWithModalsPageRoute(
            builder: (_) => SelectCustomerAddressPage(),
            settings: routeSetting);
      case AppRouterName.best_seller:
        return MaterialWithModalsPageRoute(
            builder: (_) => BestSellerPage(), settings: routeSetting);
      case AppRouterName.best_seller_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => BestSellerFilterPage(), settings: routeSetting);
      case AppRouterName.recovery_password:
        return MaterialWithModalsPageRoute(
            builder: (_) => RecoveryPasswordPage(), settings: routeSetting);
      case AppRouterName.about:
        return MaterialWithModalsPageRoute(
            builder: (_) => AboutPage(), settings: routeSetting);
      case AppRouterName.language_setting:
        return MaterialWithModalsPageRoute(
            builder: (_) => LanguageSettingPage(), settings: routeSetting);
      case AppRouterName.setting:
        return MaterialWithModalsPageRoute(
            builder: (_) => SettingPage(), settings: routeSetting);
      case AppRouterName.choose_provider_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChooseProviderPage(), settings: routeSetting);
      case AppRouterName.choose_import_item_return_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChooseImportItemReturnPage(),
            settings: routeSetting);
      case AppRouterName.choose_inventory_item_return_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChooseInventoryItemReturnPage(),
            settings: routeSetting);
      case AppRouterName.add_return_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => AddReturnInventoryItemPage(),
            settings: routeSetting);
      case AppRouterName.import_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ImportInventoryItemPage(), settings: routeSetting);
      case AppRouterName.import_inventory_item_filter_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ImportInventoryItemFilterPage(),
            settings: routeSetting);
      case AppRouterName.payment_method_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => PaymentMethodPage(), settings: routeSetting);
      case AppRouterName.choose_employee_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChooseEmployeePage(), settings: routeSetting);
      case AppRouterName.add_import_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => AddImportInventoryItemPage(),
            settings: routeSetting);
      case AppRouterName.overview_date_filter:
        return MaterialWithModalsPageRoute(
            builder: (_) => OverviewFilterPage(), settings: routeSetting);
      case AppRouterName.choose_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => ChooseInventoryItemPage(), settings: routeSetting);
      case AppRouterName.detail_import_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => DetailImportItemPage(), settings: routeSetting);
      case AppRouterName.detail_return_inventory_item_page:
        return MaterialWithModalsPageRoute(
            builder: (_) => DetailReturnInventoryItemPage(),
            settings: routeSetting);
      case AppRouterName.customer_category:
        return MaterialWithModalsPageRoute(
            builder: (_) => CustomerCategoryPage(), settings: routeSetting);
      default:
        return MaterialWithModalsPageRoute(builder: (_) => SignInPage());
    }
  }

  static Route<dynamic> handleRouterNestedNavigate(
      ETabItemType tabItemType, RouteSettings routeSetting) {
    final appRoute = AppRouterNameStringExt.valueOf(routeSetting.name);
    switch (appRoute) {
      case AppRouterName.root:
        switch (tabItemType) {
          case ETabItemType.overview:
            return MaterialWithModalsPageRoute(builder: (context) {
              return OverviewPage();
            });
          case ETabItemType.invoice:
            return MaterialWithModalsPageRoute(builder: (context) {
              return ListInvoiceScreen();
            });
          case ETabItemType.report:
            return MaterialWithModalsPageRoute(builder: (context) {
              return ReportMenuPage();
            });
          case ETabItemType.notification:
            return MaterialWithModalsPageRoute(builder: (context) {
              return NotificationPage();
            });
          case ETabItemType.profile:
            return MaterialWithModalsPageRoute(builder: (context) {
              return OtherPage();
            });
          default:
            return MaterialWithModalsPageRoute(builder: (context) {
              return OverviewPage();
            });
        }
        break;

      default:
        return handleRouterNavigate(routeSetting);
    }
  }
}
