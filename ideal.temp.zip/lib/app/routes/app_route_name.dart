enum AppRouterName {
  unknow,
  root,
  signin,
  signup,
  main,
  revenue_expenditure,
  revenue_expenditure_detail,
  revenue,
  report_revenue_filter,
  business_situation,
  business_situation_filter,
  list_invoice_filter,
  report_inventories_by_expiry,
  report_inventories_by_expiry_detail,
  report_inventories_by_expiry_filter,
  report_inventories_by_lot,
  report_inventories_by_lot_filter,
  select_unit,
  inventory_item,
  inventory_item_filter,
  add_inventory_item,
  category_inventory_item,
  declaration_inventory_item,
  add_checking_page,
  checking_filter_page,
  checking_page,
  debt_customer_filter_page,
  debt_customer_page,
  storehouse_receipt_filter_page,
  storehouse_receipt_page,
  choose_branch_page,
  choose_transfer_document_page,
  add_storehouse_receipt_page,
  inventory_item_in_store,
  inventory_item_in_store_filter,
  inventory_item_detail_in_store,
  chain_store,
  chain_store_detail,
  detail_inventory_item_storehouse_page,
  detail_storehouse_receipt_page,
  stock_issue_page,
  stock_issue_filter_page,
  add_stock_issue_page,
  choose_import_item_page,
  filter_choose_import_item_page,
  detail_stock_issue_page,
  choose_import_item_filter_page,
  choose_importer_page,
  choose_importer_filter_page,
  provider_page,
  provider_filter_page,
  detail_provider_page,
  customer_list,
  customer_filter,
  customer_detail,
  add_customer,
  customer_category,
  customer_transaction_history,
  customer_transaction_history_filter,
  sercurity_setting,
  notification_setting,
  report_revenue_detail,
  inventories_in_lot_page,
  report_inventories_by_lot_detail_page,
  return_inventory_item_filter_page,
  return_inventory_item_page,
  payment_info_page,
  select_customer_address,
  best_seller,
  best_seller_filter,
  recovery_password,
  about,
  setting,
  language_setting,
  choose_provider_page,
  choose_import_item_return_page,
  choose_inventory_item_return_page,
  add_return_inventory_item_page,
  import_inventory_item_page,
  import_inventory_item_filter_page,
  payment_method_page,
  choose_employee_page,
  add_import_inventory_item_page,
  overview_date_filter,
  choose_inventory_item_page,
  detail_import_item_page,
  detail_return_inventory_item_page,
}

extension AppRouterNameStringExt on AppRouterName {
  static AppRouterName valueOf(String value) {
    switch (value) {
      case "/":
        return AppRouterName.root;
      case "/main":
        return AppRouterName.main;
      case "/revenue-expenditure":
        return AppRouterName.revenue_expenditure;
      case "/revenue-expenditure-detail":
        return AppRouterName.revenue_expenditure_detail;
      case "/signin":
        return AppRouterName.signin;
      case "/revenue":
        return AppRouterName.revenue;
      case "/report-revenue-filter":
        return AppRouterName.report_revenue_filter;
      case "/business-situation":
        return AppRouterName.business_situation;
      case "/business-situation-filter":
        return AppRouterName.business_situation_filter;
      case "/list-invoice-filter":
        return AppRouterName.list_invoice_filter;
      case "/report-inventories-by-expiry":
        return AppRouterName.report_inventories_by_expiry;
      case "/report-inventories-by-expiry-detail":
        return AppRouterName.report_inventories_by_expiry_detail;
      case "/inventory-item":
        return AppRouterName.inventory_item;
      case "/inventory-item-filter":
        return AppRouterName.inventory_item_filter;
      case "/report-inventories-by-expiry-filter":
        return AppRouterName.report_inventories_by_expiry_filter;
      case "/select-unit-screen":
        return AppRouterName.select_unit;
      case "/add-inventory-item":
        return AppRouterName.add_inventory_item;
      case "/category-inventory-item":
        return AppRouterName.category_inventory_item;
      case "/declaration-inventory-item":
        return AppRouterName.declaration_inventory_item;
      case "/inventory-item-in-store":
        return AppRouterName.inventory_item_in_store;
      case "/inventory-item-in-store-filter":
        return AppRouterName.inventory_item_in_store_filter;
      case "/inventory-item-detail-in-store":
        return AppRouterName.inventory_item_detail_in_store;
      case "/chain-store":
        return AppRouterName.chain_store;
      case "/chain-store-detail":
        return AppRouterName.chain_store_detail;
      case "/add-checking-page":
        return AppRouterName.add_checking_page;
      case "/checking-filter-page":
        return AppRouterName.checking_filter_page;
      case "/checking-page":
        return AppRouterName.checking_page;
      case "/debt-customer-filter-page":
        return AppRouterName.debt_customer_filter_page;
      case "/debt-customer-page":
        return AppRouterName.debt_customer_page;
      case "/storehouse-receipt-filter-page":
        return AppRouterName.storehouse_receipt_filter_page;
      case "/storehouse-receipt-page":
        return AppRouterName.storehouse_receipt_page;
      case "/choose-branch-page":
        return AppRouterName.choose_branch_page;
      case "/choose-transfer-document-page":
        return AppRouterName.choose_transfer_document_page;
      case "/add-storehouse-receipt-page":
        return AppRouterName.add_storehouse_receipt_page;
      case "/detail-inventory-item-storehouse-page":
        return AppRouterName.detail_inventory_item_storehouse_page;
      case "/detail-storehouse-receipt-page":
        return AppRouterName.detail_storehouse_receipt_page;
      case "/stock-issue-page":
        return AppRouterName.stock_issue_page;
      case "/stock-issue-filter-page":
        return AppRouterName.stock_issue_filter_page;
      case "/add-stock-issue-page":
        return AppRouterName.add_stock_issue_page;
      case "/choose-import-item-page":
        return AppRouterName.choose_import_item_page;
      case "/filter-choose-import-item-page":
        return AppRouterName.filter_choose_import_item_page;
      case "/detail-stock-issue-page":
        return AppRouterName.detail_stock_issue_page;
      case "/choose-import-item-filter-page":
        return AppRouterName.choose_import_item_filter_page;
      case "/choose-importer-filter-page":
        return AppRouterName.choose_importer_filter_page;
      case "/choose-importer-page":
        return AppRouterName.choose_importer_page;
      case "/provider-page":
        return AppRouterName.provider_page;
      case "/provider-filter-page":
        return AppRouterName.provider_filter_page;
      case "/detail-provider-page":
        return AppRouterName.detail_provider_page;
      case "/report-revenue-detail":
        return AppRouterName.report_revenue_detail;
      case "/customer-list":
        return AppRouterName.customer_list;
      case "/customer-filter":
        return AppRouterName.customer_filter;
      case "/customer-detail":
        return AppRouterName.customer_detail;
      case "/add-customer":
        return AppRouterName.add_customer;
      case "/customer-transaction-history":
        return AppRouterName.customer_transaction_history;
      case "/customer-transaction-history-filter":
        return AppRouterName.customer_transaction_history_filter;
      case "/sercurity_setting":
        return AppRouterName.sercurity_setting;
      case "/notification-setting":
        return AppRouterName.notification_setting;
      case "/report-inventories-by-lot":
        return AppRouterName.report_inventories_by_lot;
      case "/report-inventories-by-lot-filter":
        return AppRouterName.report_inventories_by_lot_filter;
      case "/inventories-in-lot-page":
        return AppRouterName.inventories_in_lot_page;
      case "/report-inventories-by-lot-detail-page":
        return AppRouterName.report_inventories_by_lot_detail_page;
      case "/return-inventory-item-filter-page":
        return AppRouterName.return_inventory_item_filter_page;
      case "/return-inventory-item-page":
        return AppRouterName.return_inventory_item_page;
      case "/payment-info-page":
        return AppRouterName.payment_info_page;
      case "/select-customer-address":
        return AppRouterName.select_customer_address;
      case "/best-seller":
        return AppRouterName.best_seller;
      case "/best-seller-filter":
        return AppRouterName.best_seller_filter;
      case "/recovery-password":
        return AppRouterName.recovery_password;
      case "/about":
        return AppRouterName.about;
      case "/language-setting":
        return AppRouterName.language_setting;
      case "/setting":
        return AppRouterName.setting;
      case "/choose-provider-page":
        return AppRouterName.choose_provider_page;
      case "/choose-import-item-return-page":
        return AppRouterName.choose_import_item_return_page;
      case "/choose-inventory-item-return-page":
        return AppRouterName.choose_inventory_item_return_page;
      case "/add-return-inventory-item-page":
        return AppRouterName.add_return_inventory_item_page;
      case "/import-inventory-item-page":
        return AppRouterName.import_inventory_item_page;
      case "/import-inventory-item-filter-page":
        return AppRouterName.import_inventory_item_filter_page;
      case "/payment-method-page":
        return AppRouterName.payment_method_page;
      case "/choose-employee-page":
        return AppRouterName.choose_employee_page;
      case "/add-import-inventory-item-page":
        return AppRouterName.add_import_inventory_item_page;
      case "/overview-date-filter":
        return AppRouterName.overview_date_filter;
      case "/choose-inventory-item-page":
        return AppRouterName.choose_inventory_item_page;
      case "/detail-import-item-page":
        return AppRouterName.detail_import_item_page;
      case "/detail-return-inventory-item-page":
        return AppRouterName.detail_return_inventory_item_page;
      case "/customer-category":
        return AppRouterName.customer_category;
      default:
        return AppRouterName.unknow;
    }
  }

  String value() {
    switch (this) {
      case AppRouterName.root:
        return "/";
      case AppRouterName.main:
        return "/main";
      case AppRouterName.revenue_expenditure:
        return "/revenue-expenditure";
      case AppRouterName.revenue_expenditure_detail:
        return "/revenue-expenditure-detail";
      case AppRouterName.signin:
        return "/signin";
      case AppRouterName.revenue:
        return "/revenue";
      case AppRouterName.report_revenue_filter:
        return "/report-revenue-filter";
      case AppRouterName.business_situation:
        return "/business-situation";
      case AppRouterName.business_situation_filter:
        return "/business-situation-filter";
      case AppRouterName.list_invoice_filter:
        return "/list-invoice-filter";
      case AppRouterName.report_inventories_by_expiry:
        return "/report-inventories-by-expiry";
      case AppRouterName.report_inventories_by_expiry_detail:
        return "/report-inventories-by-expiry-detail";
      case AppRouterName.inventory_item:
        return "/inventory-item";
      case AppRouterName.inventory_item_filter:
        return "/inventory-item-filter";
      case AppRouterName.report_inventories_by_expiry_filter:
        return "/report-inventories-by-expiry-filter";
      case AppRouterName.select_unit:
        return "/select-unit-screen";
      case AppRouterName.add_inventory_item:
        return "/add-inventory-item";
      case AppRouterName.category_inventory_item:
        return "/category-inventory-item";
      case AppRouterName.declaration_inventory_item:
        return "/declaration-inventory-item";
      case AppRouterName.inventory_item_in_store:
        return "/inventory-item-in-store";
      case AppRouterName.inventory_item_in_store_filter:
        return "/inventory-item-in-store-filter";
      case AppRouterName.inventory_item_detail_in_store:
        return "/inventory-item-detail-in-store";
      case AppRouterName.chain_store:
        return "/chain-store";
      case AppRouterName.chain_store_detail:
        return "/chain-store-detail";
      case AppRouterName.add_checking_page:
        return "/add-checking-page";
      case AppRouterName.checking_filter_page:
        return "/checking-filter-page";
      case AppRouterName.checking_page:
        return "/checking-page";
      case AppRouterName.debt_customer_filter_page:
        return "/debt-customer-filter-page";
      case AppRouterName.debt_customer_page:
        return "/debt-customer-page";
      case AppRouterName.storehouse_receipt_filter_page:
        return "/storehouse-receipt-filter-page";
      case AppRouterName.storehouse_receipt_page:
        return "/storehouse-receipt-page";
      case AppRouterName.choose_branch_page:
        return "/choose-branch-page";
      case AppRouterName.choose_transfer_document_page:
        return "/choose-transfer-document-page";
      case AppRouterName.add_storehouse_receipt_page:
        return "/add-storehouse-receipt-page";
      case AppRouterName.detail_inventory_item_storehouse_page:
        return "/detail-inventory-item-storehouse-page";
      case AppRouterName.detail_storehouse_receipt_page:
        return "/detail-storehouse-receipt-page";
      case AppRouterName.stock_issue_page:
        return "/stock-issue-page";
      case AppRouterName.stock_issue_filter_page:
        return "/stock-issue-filter-page";
      case AppRouterName.add_stock_issue_page:
        return "/add-stock-issue-page";
      case AppRouterName.choose_import_item_page:
        return "/choose-import-item-page";
      case AppRouterName.filter_choose_import_item_page:
        return "/filter-choose-import-item-page";
      case AppRouterName.detail_stock_issue_page:
        return "/detail-stock-issue-page";
      case AppRouterName.choose_import_item_filter_page:
        return "/choose-import-item-filter-page";
      case AppRouterName.choose_importer_filter_page:
        return "/choose-importer-filter-page";
      case AppRouterName.choose_importer_page:
        return "/choose-importer-page";
      case AppRouterName.provider_page:
        return "/provider-page";
      case AppRouterName.provider_filter_page:
        return "/provider-filter-page";
      case AppRouterName.detail_provider_page:
        return "/detail-provider-page";
      case AppRouterName.report_revenue_detail:
        return "/report-revenue-detail";
      case AppRouterName.customer_list:
        return "/customer-list";
      case AppRouterName.customer_filter:
        return "/customer-filter";
      case AppRouterName.customer_detail:
        return "/customer-detail";
      case AppRouterName.add_customer:
        return "/add-customer";
      case AppRouterName.customer_transaction_history:
        return "/customer-transaction-history";
      case AppRouterName.customer_transaction_history_filter:
        return "/customer-transaction-history-filter";
      case AppRouterName.sercurity_setting:
        return "/sercurity_setting";
      case AppRouterName.notification_setting:
        return "/notification-setting";
      case AppRouterName.report_inventories_by_lot:
        return "/report-inventories-by-lot";
      case AppRouterName.report_inventories_by_lot_filter:
        return "/report-inventories-by-lot-filter";
      case AppRouterName.inventories_in_lot_page:
        return "/inventories-in-lot-page";
      case AppRouterName.report_inventories_by_lot_detail_page:
        return "/report-inventories-by-lot-detail-page";
      case AppRouterName.return_inventory_item_filter_page:
        return "/return-inventory-item-filter-page";
      case AppRouterName.return_inventory_item_page:
        return "/return-inventory-item-page";
      case AppRouterName.payment_info_page:
        return "/payment-info-page";
      case AppRouterName.select_customer_address:
        return "/select-customer-address";
      case AppRouterName.best_seller:
        return "/best-seller";
      case AppRouterName.best_seller_filter:
        return "/best-seller-filter";
      case AppRouterName.recovery_password:
        return "/recovery-password";
      case AppRouterName.about:
        return "/about";
      case AppRouterName.language_setting:
        return "/language-setting";
      case AppRouterName.setting:
        return "/setting";
      case AppRouterName.choose_provider_page:
        return "/choose-provider-page";
      case AppRouterName.choose_import_item_return_page:
        return "/choose-import-item-return-page";
      case AppRouterName.choose_inventory_item_return_page:
        return "/choose-inventory-item-return-page";
      case AppRouterName.add_return_inventory_item_page:
        return "/add-return-inventory-item-page";
      case AppRouterName.import_inventory_item_page:
        return "/import-inventory-item-page";
      case AppRouterName.import_inventory_item_filter_page:
        return "/import-inventory-item-filter-page";
      case AppRouterName.payment_method_page:
        return "/payment-method-page";
      case AppRouterName.choose_employee_page:
        return "/choose-employee-page";
      case AppRouterName.add_import_inventory_item_page:
        return "/add-import-inventory-item-page";
      case AppRouterName.overview_date_filter:
        return "/overview-date-filter";
      case AppRouterName.choose_inventory_item_page:
        return "/choose-inventory-item-page";
      case AppRouterName.detail_import_item_page:
        return "/detail-import-item-page";
      case AppRouterName.detail_return_inventory_item_page:
        return "/detail-return-inventory-item-page";
      case AppRouterName.customer_category:
        return "/customer-category";
      default:
        return "/unknow";
    }
  }
}
