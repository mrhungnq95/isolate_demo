enum Env { product, test, test_local }

abstract class AppConfig {
  static final bool isRelease = true;
  static final String FE_VERSION = "34.0.0.1000";

  static final assetPath = "assets";
  static final assetImages = "$assetPath/images/";
}
