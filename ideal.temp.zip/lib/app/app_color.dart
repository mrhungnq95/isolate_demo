import 'package:flutter/material.dart';

abstract class AppColor {
  static const Color primaryColor = Color(0xFF2B3173);
  static const Color primaryColorDark = primaryColor;
  static const Color secondaryColor = primaryColor;
  static const Color accentColor = primaryColorDark;
  static const Color backgroundColor = white;
  static const Color scaffoldBackgroundColor = white;

  static const Color splashColor = Color(0x33616CE6);
  static const Color textBoldColor = Color(0xFF000000);
  static const Color textColor = Color(0xFF000000);
  static const Color textCaptionColor = Color(0xFF161616);
  static const Color textDisableColor = Color(0xFF9E9E9E);
  static const Color textSecondaryColor = Color(0xFF7B7B7B);
  static const Color borderColor = Color(0xFFEEEEEE);
  static const Color backgroundTextField = Color(0xFFF5F5F5);

  //Define các màu mè khác ở đây
  static const Color orange = Color(0xFFFFA030);
  static const Color indigo600 = Color(0xFF7D8AFF);
  static const Color orange100 = Color(0xFFFF9872);

  static const Color indigo700 = Color(0xFF565EBC);
  static const Color indigo800 = Color(0xFF434CAD);
  static const Color indigo900 = Color(0xFF2B3173);
  static const Color indigoA50 = Color(0xFFE8EAFF);
  static const Color indigoA200 = Color(0xFF616CE6);
  static const Color deepPurple200 = Color(0xFFB1B6F1);
  static const Color deepPurple500 = Color(0xFFC7A2FF);
  static const Color deepPurple600 = Color(0xFFB17DFF);
  static const Color purple200 = Color(0xFFB1B6F1);
  static const Color pink = Color(0xFFFF7D7D);
  static const Color pink50 = Color(0xFFFF7B7B);
  static const Color purple600 = Color(0xFFD571B0);

  static const Color grey50 = Color(0xFFFBFBFB);
  static const Color grey100 = Color(0xFFFDFEFF);
  static const Color grey200 = Color(0xFFF2F2F2);
  static const Color grey300 = Color(0xFFE0E0E0);
  static const Color grey350 = Color(0xFF5E5E5E);
  static const Color grey400 = Color(0xFFEEEEEE);
  static const Color grey600 = Color(0xFF9E9E9E);
  static const Color grey700 = Color(0xFF757575);

  static const Color black = Color(0xFF212121);
  static const Color white = Color(0xFFFFFFFF);
  static const Color brown = Color(0xFF707070);
  static const Color cyan = Color(0xFF3DB3A1);
  static const Color green = Color(0xFF2CA434);
  static const Color green50 = Color(0xFF08D62F);
  static const Color green600 = Color(0xFF16C01F);
  static const Color teal = Color(0xFF5ACBA8);
  static const Color blue = Color(0xFF009AFF);

  //Chart
  static const Color yellow = Color(0xFFFFCC00);
  static const Color borderAxisLeftColor = Color(0xFFC5C5C5);

  static const List<Color> pieChartColor = [
    Color(0xFFdf5c5c),
    Color(0xFF0066CC),
    Color(0xFF05a6a2),
    Color(0xFFDB7816),
    Color(0xFFecdf4f),
    Color(0xFFf53232),
    Color(0xFF75429c),
    Color(0xFF358fd5),
    Color(0xFFe0e0e0),
    Color(0xFF36237B),
    Color(0xFFF0EFF8),
    Color(0xFFA451C4),
  ];

  static const Color pieChartOtherColor = Color(0xFFABB4BD);

  //Ungroup
  static const Color licenseBackground = Color(0xFFF88232);

  static final LinearGradient gradient1 =
      LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFE2E2E2)]);
  static final LinearGradient gradient2 =
      LinearGradient(colors: <Color>[Color(0xFFFFFFFF), Color(0xFFEDEDED)]);
  static final LinearGradient gradient3 = LinearGradient(
      colors: [purple200.withOpacity(0.3), purple200.withOpacity(0.01)],
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter);
  static final LinearGradient gradientGreen = LinearGradient(
      colors: [green600.withOpacity(0.2), green600.withOpacity(0.01)],
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter);
  static final LinearGradient gradientOrange = LinearGradient(
      colors: [orange100.withOpacity(0.2), orange100.withOpacity(0.01)],
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter);
}
