import 'dart:convert';

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:MShopManager/model/role_permission.dart';
import 'package:MShopManager/model/service/login_response.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/utils/shared_pref_utils.dart';

class UserCredential {
  bool _isAuth;
  String _token;
  String _refreshToken;
  LoginResponse _loginResponse;
  List<Branch> _branchList;
  List<Branch> _branchAndStorehouseSortedList;
  List<RolePermission> _permissionRoleList;
  LicenseInfo _licenseInfo;

  static SharedPrefUtil _sharedPrefUtil = SharedPrefUtil.sharedSync;
  static UserCredential _instance;
  static UserCredential get currentSession => _getInstance();

  static bool isNewSession = false;

  UserCredential.newSession() {
    isNewSession = true;

    _isAuth = false;
    _token = null;
    _refreshToken = null;
    _loginResponse = null;
    _permissionRoleList = null;
    _licenseInfo = null;
    _branchList = null;
    _branchAndStorehouseSortedList = null;
  }

  UserCredential._session() {
    isNewSession = false;
    print("UserCredential._session() $_sharedPrefUtil");
    _isAuth = _sharedPrefUtil
            .getBool(LocalStorageKey.PREF_AUTH_KEY_IS_AUTHORIZATION) ??
        false;
    _token = _sharedPrefUtil?.getString(LocalStorageKey.PREF_AUTH_KEY_TOKEN);
    _refreshToken =
        _sharedPrefUtil?.getString(LocalStorageKey.PREF_AUTH_KEY_REFRESH_TOKEN);

    _loginResponse = _getLoginResponse();
    _branchList = _getBranchList();
    _branchAndStorehouseSortedList = _getBranchAndMainStorehouseSortedList();
    _permissionRoleList = _getCurrentUserPermissionList();
    _licenseInfo = _getLicenseInfo();
  }

  static UserCredential _getInstance() {
    if (_instance == null || isNewSession) {
      _instance = UserCredential._session();
    }
    return _instance;
  }

  ///
  /// Private ==================================================================
  ///

  LoginResponse _getLoginResponse() {
    final loginResponse =
        _sharedPrefUtil?.getString(LocalStorageKey.PREF_AUTH_KEY_LOGIN_INFO);
    if (loginResponse != null) {
      return LoginResponse.fromJson(loginResponse);
    }
    return null;
  }

  ///
  /// Lấy DS Branch mà User đang đăng nhập có quyền
  ///
  List<Branch> _getBranchList() {
    final jsonList =
        _sharedPrefUtil?.getString(LocalStorageKey.PREF_BRANCH_GRANT_USER_LIST);
    if (jsonList != null) {
      final branchDecoded =
          jsonDecode(jsonList).map((json) => Branch.fromJson(json));
      if (branchDecoded != null) {
        return List<Branch>.from(branchDecoded);
      }
    }
    return null;
  }

  ///
  /// Lấy toàn bộ Branch đã sắp xếp, bao gồm cả Branch inactive và kho tổng
  ///
  List<Branch> _getBranchAndMainStorehouseSortedList() {
    final jsonList = _sharedPrefUtil
        ?.getString(LocalStorageKey.PREF_ALL_BRANCH_GRANT_USER_LIST);
    if (jsonList != null) {
      final branchDecoded =
          jsonDecode(jsonList).map((json) => Branch.fromJson(json));
      if (branchDecoded != null) {
        return List<Branch>.from(branchDecoded);
      }
    }
    return null;
  }

  ///
  /// Lấy DS RolePermission hiện tại của user
  ///
  List<RolePermission> _getCurrentUserPermissionList() {
    final jsonPermissionList =
        _sharedPrefUtil?.getString(LocalStorageKey.PREF_USER_PERMISSION_LIST);

    if (jsonPermissionList != null) {
      final permissionDecoded = jsonDecode(jsonPermissionList)
          .map((json) => RolePermission.fromJson(json));

      if (permissionDecoded != null) {
        return List<RolePermission>.from(permissionDecoded);
      }
    }

    return null;
  }

  ///
  /// Lấy object thông tin License
  ///
  LicenseInfo _getLicenseInfo() {
    final licenseInfo =
        _sharedPrefUtil?.getString(LocalStorageKey.PREF_LICENSE_INFO);

    if (licenseInfo != null) {
      return LicenseInfo.fromJson(licenseInfo);
    }
    return null;
  }

  ///
  /// Private ==================================================================
  ///

  ///
  /// Getter ===================================================================
  ///

  bool get isAuth => _isAuth;

  String get token => _token;

  String get refreshToken => _refreshToken;

  LoginResponse get loginResponse => _loginResponse;
  List<Branch> get branchList => _branchList;
  List<Branch> get branchAndStorehouseSortedList =>
      _branchAndStorehouseSortedList;
  List<RolePermission> get rolePermissionList => _permissionRoleList;
  LicenseInfo get licenseInfo => _licenseInfo;

  ///
  /// Getter ===================================================================
  ///

  ///
  /// Setter ===================================================================
  ///
  set auth(newValue) {
    _isAuth = newValue;
    _sharedPrefUtil?.putBool(
        LocalStorageKey.PREF_AUTH_KEY_IS_AUTHORIZATION, _isAuth);
  }

  set token(String newValue) =>
      _sharedPrefUtil?.putString(LocalStorageKey.PREF_AUTH_KEY_TOKEN, newValue);
  set refreshToken(String newValue) => _sharedPrefUtil?.putString(
      LocalStorageKey.PREF_AUTH_KEY_REFRESH_TOKEN, newValue);
  set loginResponse(LoginResponse newValue) => _sharedPrefUtil?.putString(
      LocalStorageKey.PREF_AUTH_KEY_LOGIN_INFO, newValue.toJson());
  set branchList(List<Branch> newValue) {
    final jsonList = jsonEncode(newValue.map((e) => e.toJson()).toList());
    _sharedPrefUtil?.putString(
        LocalStorageKey.PREF_BRANCH_GRANT_USER_LIST, jsonList);
  }

  set branchAndStorehouseSortedList(List<Branch> newValue) {
    final jsonList = jsonEncode(newValue.map((e) => e.toJson()).toList());
    _sharedPrefUtil?.putString(
        LocalStorageKey.PREF_ALL_BRANCH_GRANT_USER_LIST, jsonList);
  }

  set rolePermissionList(List<RolePermission> newValue) {
    if (newValue != null && newValue.isNotEmpty) {
      var json = jsonEncode(newValue.map((e) => e.toJson()).toList());
      _sharedPrefUtil?.putString(
          LocalStorageKey.PREF_USER_PERMISSION_LIST, json);
    }
  }

  set licenseInfo(LicenseInfo newValue) => _sharedPrefUtil?.putString(
      LocalStorageKey.PREF_LICENSE_INFO, newValue.toJson());

  ///
  /// Setter ===================================================================
  ///

  ///
  /// Public function ==========================================================
  ///

  ///
  /// Đăng xuất
  ///
  void signOut() {
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_AUTH_KEY_IS_AUTHORIZATION);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_AUTH_KEY_TOKEN);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_AUTH_KEY_REFRESH_TOKEN);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_AUTH_KEY_LOGIN_INFO);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_BRANCH_GRANT_USER_LIST);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_ALL_BRANCH_GRANT_USER_LIST);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_USER_PERMISSION_LIST);
    _sharedPrefUtil?.remove(LocalStorageKey.PREF_LICENSE_INFO);
  }

  ///
  /// Kiểm tra User của session hiện tại có phải là ADMIN không?
  ///
  bool isAdmin() {
    final roleList =
        UserPermissionUtils.convertRoleValueToList(_loginResponse.roles);
    return UserPermissionUtils.hasAdminPermissionByRoleList(roleList);
  }

  ///
  /// Kiểm tra User của session hiện tại có phải là Kho tổng không?
  ///
  bool isVirtualBranchAdmin() {
    return isAdmin() &&
        _branchList.length == 1 &&
        _branchList.first?.isVirtualBranch() == true;
  }

  ///
  /// Kiểm tra User của session hiện tại có quyền QLHT hoặc QLC không>
  ///
  bool isChainOrSystemAdmin() {
    final roleList =
        UserPermissionUtils.convertRoleValueToList(_loginResponse.roles);
    return UserPermissionUtils.hasSystemAdminOrChainManagerPermission(roleList);
  }

  ///
  /// Lấy danh sách chi nhánh có thêm item Toàn chuỗi
  /// VNLONG - 14/01/2021
  ///
  List<Branch> getListBranchWithAllChain() {
    final listBranch = [
      Branch(branchId: AppConstant.UUID_EMPTY, branchName: 'Toàn chuỗi')
    ];
    listBranch.addAll(_branchList ?? []);
    return listBranch;
  }
}
