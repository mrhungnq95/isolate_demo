import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:flutter/cupertino.dart';

import 'routes/app_router.dart';

enum ETabItemType {
  overview, //Trang chủ
  invoice, //DS Hoá đơn
  report, //Báo cáo
  notification, //Thông báo
  profile, //Thông tin
}

class NestedNavigationHelper {
  //Hash map chứa các NavigatorState của các màn hình con của TabBar,
  //cho việc navigate bên trong mỗi tab
  final Map<ETabItemType, GlobalKey<NavigatorState>> nestedNavigatorKey = {
    ETabItemType.overview: GlobalKey<NavigatorState>(),
    ETabItemType.invoice: GlobalKey<NavigatorState>(),
    ETabItemType.report: GlobalKey<NavigatorState>(),
    ETabItemType.notification: GlobalKey<NavigatorState>(),
    ETabItemType.profile: GlobalKey<NavigatorState>(),
  };

  static final NestedNavigationHelper shared = NestedNavigationHelper._();

  NestedNavigationHelper._() {
    print("NestedNavigationHelper");
  }

  Future<dynamic> navigateTo(
      {@required ETabItemType tabItemType,
      @required AppRouterName routeName,
      dynamic argument}) {
    return nestedNavigatorKey[tabItemType]
        .currentState
        .pushNamed(routeName.value(), arguments: argument);
  }

  Future<dynamic> navigateReplacementNamed(
      {@required ETabItemType tabItemType,
      @required routeName,
      dynamic argument}) {
    return nestedNavigatorKey[tabItemType].currentState.pushNamedAndRemoveUntil(
        routeName, (Route<dynamic> route) => false,
        arguments: argument);
  }

  void pop({@required ETabItemType tabItemType, dynamic data}) {
    return nestedNavigatorKey[tabItemType].currentState.pop(data);
  }
}
