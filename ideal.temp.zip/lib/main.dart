import 'package:MShopManager/app/app.dart';
import 'package:MShopManager/app/app_page_manager.dart';
import 'package:MShopManager/my_app.dart';
import 'package:MShopManager/utils/autoscale/auto_size.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() async {
  await MSApplication.shared.initialize();
  //runApp(MyApp());
  runAutoSizeApp(MyApp(), width: 375, height: 812); //IPornX
  //runAutoSizeApp(MyApp(), width: 414, height: 736); //IPorn6
}

class MainNavigatorPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<PageManager>(
      // using provider here, but it could be bloc,
      // setState or any other way to notify about the changes
      builder: (context, pageManager, _) {
        // This is required to handle back button on Android
        // The same navigator key must be used to check WillPopScope's condition
        // and provided to Navigator widget
        return WillPopScope(
          onWillPop: () async =>
              !await pageManager.navigatorKey.currentState.maybePop(),
          child: Navigator(
            key: pageManager.navigatorKey,
            pages: pageManager.pages,
            onPopPage: (route, result) =>
                _onPopPage(route, result, pageManager),

            /// You can provide your own [TransitionDelegate] implementation
            /// to decide if navigation operation should be animated
            ///
            /// Note that it's not specifying the animation itself
            //transitionDelegate: const CustomTransitionDelegate(),
          ),
        );
      },
    );
  }

  /// You need to provide `onPopPage` to [Navigator]
  /// to properly clean up `pages` list if a page has been popped.
  bool _onPopPage(
      Route<dynamic> route, dynamic result, PageManager pageManager) {
    pageManager.didPop(route.settings);
    return route.didPop(result);
  }
}
