abstract class Failure {}

class ServerResponseFailure extends Failure {}

class LocalCacheFailure extends Failure {}