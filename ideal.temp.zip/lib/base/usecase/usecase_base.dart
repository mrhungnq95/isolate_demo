import 'usecase_result.dart';

class NoParam {}

abstract class UseCase<Type, Params> {
  Future<UseCaseResult<Type>> call(Params params);
}
