import 'package:MShopManager/base/usecase/failures.dart';

class UseCaseResult<Type> {
  Type data;
  Failure failure;

  UseCaseResult(this.failure, this.data);
}
