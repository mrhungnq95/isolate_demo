import 'package:MShopManager/utils/logger_utils.dart';
import 'package:flutter/widgets.dart';
import 'ms_base_vm.dart';
import 'package:stacked/stacked.dart';

abstract class MSBaseBlankViewModelBuilder<T extends MSBaseViewModel>
    extends ViewModelBuilderWidget<T> {
  T onCreateViewModel(BuildContext context);

  /// Trigger khi ViewMode được khởi tạo
  /// Hàm này có thể bị trigger nhiều lần nếu [createNewModelOnInsert] là true
  void onViewModelCreated(T model);

  Widget onBuildUI(BuildContext context, T model, Widget child);

  Widget onBuildStaticChild(BuildContext context);

  @override
  Widget builder(BuildContext context, T model, Widget child) {
    FLogger.shared.log("onBuildUI: - model: $model");
    return onBuildUI(context, model, child);
  }

  @override
  void onViewModelReady(T model) {
    FLogger.shared.log("[BASE] $T is created!");
    return onViewModelCreated(model);
  }

  @override
  T viewModelBuilder(BuildContext context) {
    return onCreateViewModel(context);
  }

  @override
  Widget staticChildBuilder(BuildContext context) {
    return onBuildStaticChild(context);
  }
}
