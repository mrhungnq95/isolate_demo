import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

mixin MSStateMixin<T> on MSBaseViewModel {
  T _value;
  ViewStatus _status;

  T get value => _value;

  bool get isValueNotNull => _value != null;

  ViewStatus get status {
    return _status ??= _status = ViewStatus.loading();
  }

  @protected
  set value(T newValue) {
    if (_value == newValue) return;
    _value = newValue;
    notifyListeners();
  }

  @protected
  void changeState(T newState, {ViewStatus status}) {
    var _canUpdate = false;
    if (status != null) {
      _status = status;
      _canUpdate = true;
    }

    if (newState != _value) {
      _value = newState;
      _canUpdate = true;
    }

    if (_canUpdate) {
      notifyListeners();
    }
  }
}

typedef StateNotifierBuilder<T> = Widget Function(T state);

extension MSStateMixinExt<T> on MSStateMixin<T> {
  Widget obs({
    @required StateNotifierBuilder<T> widget,
    bool useSliverWidget = false,
    Function onReloadData,
    Widget Function(String error) onError,
    Widget onLoading,
    Widget onEmpty,
  }) {
    assert(widget != null);
    return Builder(builder: (_) {
      if (status.isLoading) {
        return onLoading ?? _renderLoadingView(useSliverWidget);
      } else if (status.isError) {
        return onError != null
            ? onError(status.errorMessage)
            : _renderDescriptionView(
                useSliverWidget, "Có lỗi xảy ra, vui lòng thử lại!", onReloadData);

        /// "Có lỗi xảy ra: ${status.errorMessage}"
      } else if (status.isEmpty) {
        return onEmpty != null
            ? onEmpty
            : _renderDescriptionView(useSliverWidget, "Không có dữ liệu!", onReloadData);
      }
      return widget(_value);
    });
  }

  Widget _renderLoadingView(bool useSliverWidget) {
    return Builder(
      builder: (c) {
        return (useSliverWidget
            ? SliverFillRemaining(
                child: Center(child: CircularProgressIndicator()),
              )
            : Center(child: CircularProgressIndicator()));
      },
    );
  }

  Widget _renderDescriptionView(bool useSliverWidget, String message, Function onReloadData) {
    return Builder(builder: (c) {
      return (useSliverWidget
          ? SliverFillRemaining(
              child: Center(
                  child: _EmptyStateView(
                message: message,
                onRetry: onReloadData,
              )),
            )
          : Center(
              child: _EmptyStateView(
              message: message,
              onRetry: onReloadData,
            )));
    });
  }
}

class _EmptyStateView extends StatelessWidget {

  final String message;
  final Function onRetry;

  _EmptyStateView({this.message, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          AppResources.icEmptyChart,
          isAntiAlias: true,
          height: 50,
        ),
        kVerticalSpaceTinyBox,
        Text(message),
        kVerticalSpaceMediumBox,
        InkWellView(
          onPressed: onRetry,
          borderRadius: 10,
          child: Container(
            constraints: BoxConstraints(minWidth: 150, minHeight: 44),
            decoration: BoxDecoration(
                border: Border.all(color: AppColor.accentColor),
                borderRadius: BorderRadius.circular(10)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                kHorizontalSpaceMediumBox,
                Image.asset(
                  AppResources.icRefresh,
                  isAntiAlias: true,
                  width: 18,
                  height: 18,
                ),
                kHorizontalSpaceMediumBox,
                Text(
                  'Thử lại',
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(color: AppColor.accentColor),
                ),
                kHorizontalSpaceMediumBox
              ],
            ),
          ),
        )
      ],
    );
  }
}

class ViewStatus {
  final bool isLoading;
  final bool isError;
  final bool isSuccess;
  final bool isEmpty;
  final String errorMessage;

  ViewStatus._({
    this.isEmpty,
    this.isLoading,
    this.isError,
    this.isSuccess,
    this.errorMessage,
  });

  factory ViewStatus.loading() {
    return ViewStatus._(
      isLoading: true,
      isError: false,
      isSuccess: false,
      isEmpty: false,
    );
  }

  factory ViewStatus.success() {
    return ViewStatus._(
      isLoading: false,
      isError: false,
      isSuccess: true,
      isEmpty: false,
    );
  }

  factory ViewStatus.error([String message]) {
    return ViewStatus._(
      isLoading: false,
      isError: true,
      isSuccess: false,
      isEmpty: false,
      errorMessage: message,
    );
  }

  factory ViewStatus.empty() {
    return ViewStatus._(
      isLoading: false,
      isError: false,
      isSuccess: false,
      isEmpty: true,
    );
  }
}
