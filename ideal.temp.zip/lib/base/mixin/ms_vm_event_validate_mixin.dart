import 'dart:async';

import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

mixin MSEventValidateMixin<T> on MSBaseViewModel {
  StreamController _eventValidateController;
  StreamController get eventValidateController => _eventValidateController;

  /// True nếu cho phép nhiều view khác cũng có thể lắng nghe
  @protected
  bool get sync;

  init() {
    _eventValidateController = StreamController.broadcast(sync: sync);
  }

  ///
  /// Lấy stream để lắng nghe
  ///
  Stream<T> get eventValidate {
    //if (T == dynamic) {
    //  return eventValidateController?.stream;
    //} else {
    return eventValidateController?.stream
        ?.where((event) => event is T)
        ?.cast<T>();
    //}
  }

  ///
  /// Bắn event
  /// [event] object muốn emit đi
  /// [result] giá trị trả về cho validate, mặc định là [false]
  ///          nếu [event] thể hiện case không có lỗi => để [result] là [true]
  ///
  @protected
  bool validate(T event, {bool result = false}) {
    if (event != null) {
      _eventValidateController?.add(event);
    }
    return result;
  }

  @override
  void dispose() {
    _eventValidateController?.close();
    super.dispose();
  }
}

typedef OnEventValidateListener<T> = Function(BuildContext context, T event);

mixin MSEventValidateListenerMixin<T1 extends StatefulWidget, T2,
    T3 extends MSEventValidateMixin<T2>> on State<T1> {
  StreamSubscription<T2> _eventValidateSubcription;

  @protected
  OnEventValidateListener<T2> get validateEvent;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      assert(context != null);

      /// Lấy ViewModel
      final MSEventValidateMixin<T2> model =
          Provider.of<T3>(context, listen: false);

      assert(model != null, MSEventValidateMixinNotFoundException.message);

      /// Check
      if (model == null) {
        throw MSEventValidateMixinNotFoundException(
            T3, context.widget.runtimeType);
      }

      /// StreamSubscription
      _eventValidateSubcription = model?.eventValidate?.listen((event) {
        validateEvent?.call(context, event);
      });
    });
  }

  @override
  void dispose() {
    _eventValidateSubcription?.cancel();
    super.dispose();
  }
}

class MSEventValidateMixinNotFoundException implements Exception {
  final Type valueType;

  final Type widgetType;

  MSEventValidateMixinNotFoundException(
    this.valueType,
    this.widgetType,
  );

  static String get message {
    return '''
            Anh Hưng có lời khen bạn: "VL luôn đầu cắt moi". 
            - ViewModel đã mixin với MSEventValidateMixin chưa?
            - Nếu rồi thì xem lại Widget hiện tại có ở trong nhánh với Widget cha 
            đang comsumer không?. 
            ''';
  }

  @override
  String toString() {
    return message;
  }
}
