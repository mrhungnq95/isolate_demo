import 'dart:async';
import 'dart:developer';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/utils/network_info.dart';

mixin PageStateMixin<T extends StatefulWidget> on State<T> {

  bool _isConnected = true;
  bool get isConnected => _isConnected;

  StreamSubscription<DataConnectionStatus> _streamSubscription;
  final NetworkInfo _networkInfo = LocatorService.shared.get<NetworkInfo>();

  void onConnected();
  void onDisconnected();

  @override
  void initState() {
    super.initState();

    _streamSubscription = _networkInfo.onConnectionChanged().listen((event) {
      handleNetworkState(event);
    });
  }

  @override
  void dispose() {
    try {
      _streamSubscription?.cancel();
    } catch (e) {
      log(e.toString());
    }
    super.dispose();
  }

  void handleNetworkState(DataConnectionStatus status) {
    if (status == DataConnectionStatus.connected) {
      _isConnected = true;
      onConnected();
    } else {
      _isConnected = false;
      onDisconnected();
    }
  }
}
