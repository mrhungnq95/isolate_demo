import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/branch_business.dart';
import 'package:MShopManager/business/license_info_business.dart';
import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:flutter/foundation.dart';

///
/// Class add-on, bổ sung chức năng mở rộng cho ViewModel
/// của những màn hình Thiết lập báo cáo
///
mixin FilterFeatureMixin<T> on MSBaseViewModel {
  ///
  /// Object để kiểm tra các vấn đề về license
  ///
  @protected
  LicenseInfoBusiness licenseInfoBusiness;

  ///
  /// True nếu cho phép chọn cửa hàng theo nhóm
  ///
  @protected
  bool isAllowChooseGroupStore = false;

  ///
  /// DS cửa hàng hiển thị trong filter
  ///
  @protected
  List<Branch> branchList;

  ///
  /// Object thiết lập báo cáo
  ///
  @protected
  T filterSetting;

  ///
  /// Enum key lấy thiết lập báo cáo
  ///
  @protected
  EFilterViewModelKey get filterViewModelKey;

  ///
  /// Tạo mới object Thiết lập lấy báo cáo
  ///
  @protected
  T createDefaultFilterSetting();

  ///
  /// Load dữ liệu filter sau khi lấy thành công
  ///
  @protected
  void filterSettingLoaded(T filterSetting);


  /// có lấy kho tổng không?
  bool get isDisplayVirtualBranch => true;

  /// có lấy chuỗi cửa hàng không?
  bool get isGetAllChainBranch => !isAllowChooseGroupStore;

  @mustCallSuper
  void init() {
    print("[BASE] FilterFeatureMixin init!");
    licenseInfoBusiness = LicenseInfoBusiness.cached();

    final isChainStore = licenseInfoBusiness.isLicenseForChainStore();
    isAllowChooseGroupStore = BranchBusiness.isAllowChooseGroupStore(
        isDisplayVirtualBranch: isChainStore, isGetAllChainBranch: false);

    /// Load danh sách cửa hàng
    _loadBranchList();

    /// Load và tạo filter setting default nếu chưa có
    _loadOrCreateDefaultFilterSetting();

    /// Bind dữ liệu filter setting
    filterSettingLoaded(filterSetting);
  }

  ///
  /// Load dữ liệu cửa hàng
  ///
  void _loadBranchList() {
    branchList = BranchBusiness.getBranchList(
        UserCredential.currentSession.branchList,
        isDisplayVirtualBranch: isDisplayVirtualBranch,
        isGetAllChainBranch: isGetAllChainBranch);

    print("[BASE] FilterFeatureMixin Branch data init!");
  }

  ///
  /// Load thiết lập từ cache hoặc khởi tạo mới
  ///
  void _loadOrCreateDefaultFilterSetting() {
    filterSetting =
        filterSettingRepository.getFilterSettings(filterViewModelKey);

    if (filterSetting == null) {
      filterSetting = createDefaultFilterSetting();

      print("[BASE] FilterFeatureMixin $filterSetting created with default!");
    } else {
      print("[BASE] FilterFeatureMixin $filterSetting loaded!");
    }
  }

  ///
  /// Reload lại data của thiết lập báo cáo
  ///
  @protected
  void reloadFilterSetting() {
    _loadOrCreateDefaultFilterSetting();
  }

  ///
  /// Lưu thiết lập
  ///
  @protected
  void saveFilterSetting() {
    filterSettingRepository.saveFilterSettings(
        filterViewModelKey, filterSetting);

    // final filterSettingAssert =
    //     filterSettingRepository.getFilterSettings(filterViewModelKey);
    // assert(filterSettingAssert != null);

    print("[BASE] FilterFeatureMixin $filterSetting saved!");
  }

  @override
  @mustCallSuper
  void dispose() {
    super.dispose();
  }
}
