import 'package:flutter/cupertino.dart';

mixin PageStateless on StatelessWidget {
  Widget buildPageWidget(BuildContext context);

  @override
  Widget build(BuildContext context) {
    return buildPageWidget(context);
  }
}
