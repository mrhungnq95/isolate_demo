import 'dart:async';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/app_nested_navigation.dart';
import 'package:MShopManager/data/repository/common_data_repository.dart';
import 'package:MShopManager/data/repository/filter_setting_data_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_data_view_state.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:flutter/cupertino.dart';
import 'package:MShopManager/utils/network_info.dart';
import 'package:stacked/stacked.dart';

abstract class MSBaseViewModel extends BaseViewModel {
  bool isConnectionConnected = true;
  StreamSubscription<DataConnectionStatus> _streamSubscription;
  //final PageManager pageManager = LocatorService.shared.get<PageManager>();
  final NavigationHelper navigationService =
      NavigationHelper.shared; //locator<NavigationHelper>();
  final NestedNavigationHelper nestedNvigationService =
      NestedNavigationHelper.shared;
  final NetworkInfo _networkInfo = LocatorService.shared.get<NetworkInfo>();

  EDataViewState _viewState = EDataViewState.idle;
  EDataViewState get viewState => _viewState;
  set viewState(EDataViewState newValue) {
    _viewState = newValue;
    notifyListeners();
  }

  //final NestedNavigationHelper nestedNavigationService = locator<NestedNavigationHelper>();

  /// Repository
  CommonDataRepository commonDataRepository =
      LocatorService.shared.get<CommonDataRepository>();

  FilterSettingRepository filterSettingRepository =
      LocatorService.shared.get<FilterSettingRepository>();

  @mustCallSuper
  MSBaseViewModel() {
    init();
  }

  void init() {
    print("[BASE] $this init!");
    //Sặp cờ rai sự kiện thay đổi trạng thái mạng để handle trạng thái
    _streamSubscription = _networkInfo.onConnectionChanged().listen((event) {
      _handleConnectionChange(event);
    });
  }

  /// ****
  /// Xử lý kết nối internet khi có thay đổi
  /// ****
  void _handleConnectionChange(DataConnectionStatus event) {
    isConnectionConnected = event == DataConnectionStatus.connected;
    notifyListeners();
  }

  @override
  @mustCallSuper
  void dispose() {
    print("[BASE] $this dispose called!");
    _streamSubscription?.cancel();
    super.dispose();
  }
}
