import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MSBaseFloatingModalBottomSheet extends StatelessWidget {
  final Widget child;
  final String title;
  final Color backgroundColor;

  const MSBaseFloatingModalBottomSheet({
    Key key,
    @required this.child,
    @required this.title,
    this.backgroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Material(
              color: backgroundColor,
              clipBehavior: Clip.antiAlias,
              borderRadius: BorderRadius.circular(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(
                      title,
                      textAlign: TextAlign.center,
                      style: Theme.of(context)
                          .textTheme
                          .bodyText2
                          .copyWith(color: AppColor.textCaptionColor),
                    ),
                  ),
                  Divider(
                    height: 1,
                    thickness: 1,
                  ),
                  child,
                ],
              ),
            ),
            kVerticalSpaceLargeBox,
            Material(
              color: backgroundColor,
              clipBehavior: Clip.antiAlias,
              borderRadius: BorderRadius.circular(12),
              child: ListTile(
                title: Text(
                  "Huỷ",
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(color: AppColor.primaryColor),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}

class ListItemModalFit<T> extends StatelessWidget {
  final List<T> itemList;
  final Widget Function(T item) itemTitleBuilder;
  final Function(T item) itemSelected;

  const ListItemModalFit({
    Key key,
    @required this.itemList,
    @required this.itemTitleBuilder,
    @required this.itemSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
        child: SafeArea(
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = itemList[index];
          return ListTile(
            title: itemTitleBuilder(item),
            onTap: () {
              itemSelected?.call(item);
              Navigator.of(context).pop();
            },
          );
        },
        itemCount: itemList.length,
        separatorBuilder: (BuildContext context, int index) {
          return Divider(
            height: 1,
            thickness: 1,
          );
        },
      ),
    ));
  }
}
