//
// Created by nqhung on 11/11/2020.
//

import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

class ComputeDataTransformer extends DefaultTransformer {
  ComputeDataTransformer() : super(jsonDecodeCallback: _parseJson);
}

// Must be top-level function
_parseAndDecode(String response) {
  return jsonDecode(response);
}

_parseJson(String text) {
  return compute(_parseAndDecode, text);
}
