import 'dart:io';

import 'package:MShopManager/base/service/interceptor/refresh_token_interceptor.dart';
import 'package:MShopManager/base/service/compute_data_transformer.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:flutter/foundation.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

abstract class BaseDio {
  Dio _dio;
  CancelToken _cancelToken;

  String getServiceUrl();

  Map<String, String> getQueryParameters();

  Map<String, String> getHeader();

  bool useRefreshTokenInterceptor() {
    return true;
  }

  List<Interceptor> provideInterceptor() {
    return null;
  }

  int getConnectTimeOut() {
    return 30000;
  }

  int getReceiverTimeOut() {
    return 30000;
  }

  BaseDio() {
    _dio = Dio();
    _cancelToken = CancelToken();
    _dio.transformer = ComputeDataTransformer();

    final url = getServiceUrl();
    _dio.options.baseUrl = url;
    _dio.options.connectTimeout = getConnectTimeOut();
    _dio.options.receiveTimeout = getReceiverTimeOut();

    if (getQueryParameters() != null) {
      _dio.options.queryParameters = getQueryParameters();
    }

    if (getHeader() != null) {
      _dio.options.headers = getHeader();
    }

    //Accept all cookies
    _dio.interceptors.add(CookieManager(CookieJar()));
    //_dio.interceptors.add(CookieManager(PersistCookieJar()));
    //_dio.interceptors.add(LogInterceptor(responseBody: false));
    _dio.interceptors.add(PrettyDioLogger(
      requestHeader: true,
      requestBody: true,
      responseBody: true,
      responseHeader: false,
      compact: false,
    ));
    if (provideInterceptor() != null) {
      print("[BASE] $url --- Add custom Interceptors!");
      _dio.interceptors.addAll(provideInterceptor());
    }
    if (useRefreshTokenInterceptor()) {
      print("[BASE] $url --- useRefreshTokenInterceptor!");
      _dio.interceptors.add(RefreshTokenInterceptor(dio: _dio));
    }
  }

  @mustCallSuper
  void resetService() {
    //Cancel tất cả request của instance này
    _cancelToken?.cancel();

    _dio = null;

    print("[BASE] ${getServiceUrl()} --- Dio reset!");
  }

  Future<dynamic> get(String path,
      {Map<String, dynamic> queryParameters,
      Options options,
      CancelToken cancelToken,
      ProgressCallback onReceiveProgress}) async {
    try {
      if (cancelToken == null) {
        cancelToken = _cancelToken;
      }

      final response = await _dio.get(path,
          queryParameters: queryParameters,
          options: options,
          cancelToken: cancelToken,
          onReceiveProgress: onReceiveProgress);

      return response.data;
    } on SocketException catch (e) {
      throw SocketException(e.toString());
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      rethrow;
    }
  }

  Future<dynamic> post(
    String path, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
    ProgressCallback onSendProgress,
    ProgressCallback onReceiveProgress,
  }) async {
    try {
      if (cancelToken == null) {
        cancelToken = _cancelToken;
      }

      final response = await _dio.post(path,
          queryParameters: queryParameters,
          options: options,
          cancelToken: cancelToken,
          onSendProgress: onSendProgress,
          onReceiveProgress: onReceiveProgress);

      return response.data;
    } on SocketException catch (e) {
      throw SocketException(e.toString());
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      rethrow;
    }
  }

  Future<dynamic> put(
    String path, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
    ProgressCallback onSendProgress,
    ProgressCallback onReceiveProgress,
  }) async {
    try {
      if (cancelToken == null) {
        cancelToken = _cancelToken;
      }

      final response = await _dio.put(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress,
      );
      return response.data;
    } on SocketException catch (e) {
      throw SocketException(e.toString());
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      rethrow;
    }
  }

  Future<dynamic> delete(
    String path, {
    data,
    Map<String, dynamic> queryParameters,
    Options options,
    CancelToken cancelToken,
  }) async {
    try {
      if (cancelToken == null) {
        cancelToken = _cancelToken;
      }

      final response = await _dio.delete(
        path,
        data: data,
        queryParameters: queryParameters,
        options: options,
        cancelToken: cancelToken,
      );
      return response.data;
    } on SocketException catch (e) {
      throw SocketException(e.toString());
    } on FormatException catch (_) {
      throw FormatException("Unable to process the data");
    } catch (e) {
      rethrow;
    }
  }

  // Future<Response<T>> get<T>(String path,
  //     {Map<String, dynamic> queryParameters,
  //     Options options,
  //     CancelToken cancelToken,
  //     ProgressCallback onReceiveProgress}) {
  //   if (cancelToken == null) {
  //     cancelToken = _cancelToken;
  //   }

  //   return _dio.get(path,
  //       queryParameters: queryParameters,
  //       options: options,
  //       cancelToken: cancelToken,
  //       onReceiveProgress: onReceiveProgress);
  // }

  // Future<Response<T>> post<T>(
  //   String path, {
  //   data,
  //   Map<String, dynamic> queryParameters,
  //   Options options,
  //   CancelToken cancelToken,
  //   ProgressCallback onSendProgress,
  //   ProgressCallback onReceiveProgress,
  // }) {
  //   if (cancelToken == null) {
  //     cancelToken = _cancelToken;
  //   }

  //   return _dio.post(path,
  //       queryParameters: queryParameters,
  //       options: options,
  //       cancelToken: cancelToken,
  //       onSendProgress: onSendProgress,
  //       onReceiveProgress: onReceiveProgress);
  // }

  // Future<Response<T>> put<T>(
  //   String path, {
  //   data,
  //   Map<String, dynamic> queryParameters,
  //   Options options,
  //   CancelToken cancelToken,
  //   ProgressCallback onSendProgress,
  //   ProgressCallback onReceiveProgress,
  // }) {
  //   if (cancelToken == null) {
  //     cancelToken = _cancelToken;
  //   }

  //   return _dio.put(
  //     path,
  //     data: data,
  //     queryParameters: queryParameters,
  //     options: options,
  //     cancelToken: cancelToken,
  //     onSendProgress: onSendProgress,
  //     onReceiveProgress: onReceiveProgress,
  //   );
  // }

  // Future<Response<T>> delete<T>(
  //   String path, {
  //   data,
  //   Map<String, dynamic> queryParameters,
  //   Options options,
  //   CancelToken cancelToken,
  // }) {
  //   if (cancelToken == null) {
  //     cancelToken = _cancelToken;
  //   }

  //   return _dio.delete(
  //     path,
  //     data: data,
  //     queryParameters: queryParameters,
  //     options: options,
  //     cancelToken: cancelToken,
  //   );
  // }
}
