//
// Created by nqhung on 10/11/2020.
//

class EndpointConfig {
  ///Authen: Áp dụng cho release và local
  static const String URL_LOGIN = "/auth/token";

  ///Authen Test: Áp dụng cho các domain test
  ///static const String URL_LOGIN_TEST = "/authtest/token";

  ///ENDPOINT BASE API ============================================================================
  static const String URL_ENDPOINT_DASH_BOARDS = "/Dashboards";
  static const String URL_ENDPOINT_IMAGE = "/Image";
  static const String URL_ENDPOINT_DBOPTIONS = "/DBOptions";
  static const String URL_ENDPOINT_EMPLOYEE = "/Employee";
  static const String URL_ENDPOINT_FORGET_PASSWORD = "/ForgotPassword";
  static const String URL_ENDPOINT_CHECK_EXIST_DOMAIN = "/Common";
  static const String URL_ENDPOINT_FEEDBACK = "/Feedback";
  static const String URL_ENDPOINT_CHECK_VERSION = "/Version";
  static const String URL_ENDPOINT_PU_INVOICE = "/";
  static const String URL_ENDPOINT_MANAGEMENT = "/registerv2api";
  static const String URL_ENDPOINT_INVENTORY_ITEM = "/MobileInventoryItems";
  static const String URL_INVENTORY_ITEM = "/MobileInventoryItems";
  static const String URL_UPLOAD_IMAGE = "/Image/MobileUploadImage";
  static const String URL_MOBILES = "/Mobiles";
  static const String URL_NOTIFICATION = "/Notification";

  ///ENDPOINT API URL_ENDPOINT_DASH_BOARDS=========================================================
  ///Hoạt động trong ngày
  static const String URL_REPORT_DRAW_DASH_BOARD = "/DrawDashboarForMobile";

  ///Doanh thu theo thời gian
  static const String URL_REPORT_DASH_BOARD_REVENUE_BY_TIME = "/RevenueByTime";
  static const String URL_REPORT_DASH_BOARD_CUSTOMER =
      "/CustomerMobilePagingFromDateToDate";

  ///Doanh thu theo hàng hóa
  static const String URL_REPORT_DASH_BOARD_REVENUE_BY_ITEMS =
      "/ReportBestRevenue";

  ///Tình hình thu chi
  static const String URL_REPORT_DASH_BOARD_RECEIPT_EXPEND =
      "ReceiptAndPayment";

  ///Tình hình kinh doanh
  static const String URL_REPORT_DASH_BOARD_BUSINESS_STATUS = "/BusinessStatus";

  ///Chuỗi cửa hàng
  static const String URL_REPORT_DASH_BOARD_REVENUE_AMOUNT = "/RevenueAmount";

  ///ENDPOINT API URL_ENDPOINT_EMPLOYEE=========================================
  ///Đổi mật khẩu
  static const String URL_EMPLOYEE_CHANGE_PASSWORD = "/ChangePassword";
  static const String URL_COMMON_CHECK_VERSION = "/CheckForceVersion";

  ///Quên mật khẩu
  static const String URL_SEND_FEEDBACK = "/Send";
  static const String URL_FEEDBACK_HISTORY = "/History";

  ///Feedback
  static const String URL_FORGET_PASSWORD = "/ConfirmMobile";
  static const String URL_CHECK_EXIST_DOMAIN = "/CheckExistsCompanyCode";

  ///ENDPOINT API URL_ENDPOINT_DBOPTIONS========================================
  ///Lấy DBOption theo Branch
  static const String URL_DBOPTION_GET_DBOPTION_BY_BRANCH_ID =
      "/DBOptionMobileByBranchID";
  static const String URL_DBOPTION_IS_CALCULATING_PRICE = "/IsCalculatingPrice";

  /// Hóa đơn===========================================================
  ///Lấy danh sách hóa đơn
  static const String URL_GET_LIST_BILL = "/ListSAInvoiceForMobile";
  static const String URL_GET_LIST_SAINVOICE = "/ListSAInvoice";
  static const String URL_GET_BILL_DETAIL = "/SAInvoiceDetailForMobile";
  static const String URL_GET_SEARCH_BILL_DETAIL = "/SearchSAInvoiceForMobile";

  /// Thông báo
  static const String URL_FCM_NOTIFICATION = "/MobileDevice";
  static const String URL_FCM_UPDATE_NOTIFICATION = "/\UpdateDeviceSettings";
  static const String URL_INFORMATION_MOBILE_DEVICE_SETTING =
      "MobileDeviceSettings";
  static const String URL_READ_NOTIFICATION = "/ReadNoti";
  static const String URL_GET_LIST_NOTIFICATION = "/ListNoti";
  static const String URL_GET_NOTIFICATION_CONFIG = "/GetNotificationConfig";
  static const String URL_SAVE_NOTIFICATION_CONFIG = "/SaveNotificationConfig";

  /// Nhập hàng
  static const String URL_PU_INVOICE = "/PUInvoices";
  static const String URL_GET_LIST_PUINVOICE =
      "PUInvoices/GetListPUInvoiceMobile";
  static const String URL_GET_NEW_REFNO = "/invoices/GetNewRefNo";
  static const String URL_VALIDATE_SERIAL_IMEI = "/ValidateSerialIMEI";

  static const String URL_GET_NEW_REFNO_ININWARD = "/ININwards/GetNewRefNo/%s";

  static const String URL_GET_DETAIL_PUINVOICE =
      "PUInvoices/GetDetailPUInvoiceMobile";
  static const String URL_GET_DETAIL_OUTWARD = "/DetailOutward";
  static const String URL_GET_LIST_INWARD_TRANSFER = "/InwardTransfer";
  static const String URL_VENDORS = "/Vendors";
  static const String URL_GET_VENDORS = "/Vendors/GetAll";
  static const String URL_GET_LIST_VENDOR = "/Vendors/GetVendortPagingMobile";
  static const String URL_DELETE_VENDORS = "/Vendors/DeleteListID";
  static const String URL_VENDOR_CATEGORYS = "/VendorCategorys";
  static const String URL_GET_LIST_INVENTORYITEM =
      "/GetListInventoryItemMobile";
  static const String URL_GET_LIST_INVENTORYITEM_BARCODE =
      "InventoryItemMobile/Barcode";

  ///static const String URL_ADD_INVENTORYITEM = "/InventoryItemMobile";
  static const String URL_ADD_INVENTORYITEM = "/MobileInventoryItems";
  static const String URL_ADD_INVENTORYITEM_CATEGORY = "/InventoryItemCategory";
  static const String URL_GET_INVENTORYITEM_CATEGORY = "/InventoryItemCategory/GetActiveList";
  static const String URL_GET_LIST_UNIT = "/Unit/GetActiveList";
  static const String URL_GET_LIST_UNIT_BY_INVENTORYITEM_ID =
      "UnitConverts/GetUnitsByInventoryItemID";
  static const String URL_GET_LIST_UNIT_CONVERT =
      "/UnitConverts/GetUnitConvert";
  static const String URL_GET_LIST_EMPLOYEE = "/Employee/GetByBranchID";
  static const String URL_CHECK_PUINVOICE_IS_ARISEN =
      "/PUInvoices/CheckIsArisen";

  //chia sẻ với bạn bè
  //Lấy danh sách sự kiện chia sẻ
  static const String URL_MANAGEMENT_LIST_EVENT_MANAGER = "/ListEventManager";
  //Lấy danh sách lịch sử đã chia sẻ
  static const String URL_MANAGEMENT_LIST_SHARE_MANAGER = "/ListShareManager";
  //Lưu chia sẻ
  static const String URL_MANAGEMENT_SAVE_SHARE_MANAGER = "/SaveShareManager";
  // Báo cáo công nợ
  static const String URL_GET_DEBIT_REPORT = "/CustomerDebt";

  // Lấy danh sách hàng hóa tồn kho
  static const String URL_GET_QUANTITY_IN_OUT_STOCK = "/QuantityInOutStock";
  // Dùng cho màn hình xem chi tiết tồn kho của từng hàng hóa
  static const String URL_GET_IN_OUT_STOCK_BY_MODEL_ID = "/InOutStockByMoldeID";
  // Lây danh sách hàng hóa tồn kho ở các kho trong cửa hàng
  static const String URL_GET_IN_OUT_STOCK_BY_INVENTORYITEM_ID =
      "/InOutStockByInventoryItemID";
  // Báo cáo công nợ
  static const String URL_GET_IN_BRANCH_BY_INVENTORYITEM_ID =
      "/InBranchByInventoryItemID";
  // Ds Hàng hóa
  static const String URL_GET_LIST_INVENTORY_ITEM = "/GetInventoryItems";
  static const String URL_CHECK_INCURRED = "/CheckIncurred";
  static const String URL_CHECK_INCURRED_UNIT_CONVERT =
      "/CheckIncurredUnitConvert";
  static const String URL_GET_INVENTORY_ITEM_DETAIL = "/GetItemDetail";

  //nhập kho
  static const String URL_GET_LIST_INWARD = "/GetInwards";
  static const String URL_GET_DETAIL_INWARD = "/DetailInward";
  static const String URL_DELETE_INWARD = "/DeleteListIDInward";
  static const String URL_GET_OBJECTS = "/GetObjects";
  static const String URL_GET_OUTWARD_DETAIL = "/OutwardDetails";
  static const String URL_GET_OUTWARD_INACTIVE_ITEM = "/OutwardInactiveItem";
  static const String URL_GET_OUTWARD_EXISTS = "/OutwardExists";
  static const String URL_INSERT_INVENTORY_ITEM_BY_OUTWARD_ID =
      "/InsertInventoryItemByOutwardID";
  static const String URL_ACTIVE_ITEM = "/OutwardDetailsInactive";
  static const String URL_ADD_INWARD = "/AddInward";
  static const String URL_EDIT_INWARD = "/EditInward";

  //kiểm kê
  static const String URL_GET_AUDIT_PAGING = "/GetAuditsPaging";
  static const String URL_GET_INVENTORY_ITEM_FOR_AUDIT =
      "/GetInventoryItemsForAudit";
  static const String URL_SEARCH_ITEM_BY_BARCODE_FOR_AUDIT = "/BarcodeINAudit";
  static const String URL_GET_NEW_REFNO_FOR_AUDIT = "/INAudits/GetNewRefNo/%s";
  static const String URL_ADD_IN_AUDIT = "/AddINAudit";
  static const String URL_EDIT_IN_AUDIT = "/EditINAudit";
  //static const String URL_AUDITS_DETAIL = "/AuditsDetail";
  static const String URL_AUDITS_DETAIL = "/DetailAudit";
  static const String URL_DELETE_AUDIT = "/DeleteListIDINAudit";
  static const String URL_PROCESS_AUDIT = "/ExecuteINAudit";
  static const String URL_MERGE_AUDIT = "/MergeAudit";

  ///trả lại hàng mua
  static const String URL_GET_RETURN_PAGING = "/GetPUReturnsPaging";
  static const String URL_GET_RETURN_DETAIL = "/PUReturnDetail";
  static const String URL_ADD_PU_RETURN = "/AddPUReturn";
  static const String URL_EDIT_PU_RETURN = "/EditPUReturn";
  static const String URL_DELETE_PU_RETURN = "/DeleteListIDPUReturn";
  static const String URL_VALIDATE_QUANTITY_INSTOCK =
      "/quantitybylistidLotNumber";
  static const String URL_GET_NEW_REFNO_PU_RETURN = "/PUReturns/GetNewRefNo/%s";
  static const String URL_GET_INWARD_FOR_PU_RETURN = "/GetInwardsForPuReturn";
  static const String URL_GET_DETAIL_INWARD_FOR_PU_RETURN =
      "/GetDetailInwardsForPuReturn";

  ///notify
  static const String URL_GET_LIST_NOTIFY = "/ListNoti";

  ///danh sanh thiết lập
  static const String URL_GET_LIST_SETTING_NOTI = "/GetNotificationConfig";

  ///lưu lại thiết lập
  static const String URL_SAVE_LIST_SETTING_NOTI = "/SaveNotificationConfig";

  ///lấy danh sách đặt cọc của hóa đơn
  static const String URL_GET_LIST_DEPOSIT = "/SAInvoices/GetListDeposit";

  ///url Lấy danh sách hàng hóa tồn kho theo lô
  static const String URL_GET_QUANTITY_IN_OUT_STOCK_BY_LOT = "/InOutStockByLot";

  /// url Lấy báo cáo danh sách hàng hóa trong lô
  static const String URL_GET_IN_OUT_STOCK_LOT_BY_INVENTORY_ITEM =
      "/InOutStockLotByInventoryItem";

  /// Lấy báo cáo chi tiết hàng hóa trong lô
  static const String URL_GET_IN_OUT_STOCK_LOT_INVENTORY_ITEM_DETAIL =
      "/InOutStockLotInventoryItemDetail";

  /// Lấy báo cáo theo HSD
  static const String URL_GET_IN_OUT_STOCK_BY_EXPIRY_DATE =
      "/InstockByExpiryDate";

  /// Lấy chi tiết báo cáo theo HSD
  static const String URL_GET_IN_OUT_STOCK_BY_EXPIRY_DATE_DETAIL =
      "/InstockByExpiryDateDetail";

  static const String URL_GET_COMBO_BY_INVENTORY_ITEM_ID =
      "/InventoryItems/GetComboByInventoryItemID";
  static const String URL_LOT = "/Lot";
  static const String URL_GET_LOT_BY_INVENTORY_ITEM_ID =
      "/GetLotByInventoryItemID";

  static const String URL_SERIAL_IMEI = "/Serial";
  static const String URL_GET_SERIAL_BY_INVENTORY_ITEM_ID =
      "/GetSerialByInventoryItemID";
  static const String URL_GET_LOT_BY_BRANCH = "/GetLotByBranchID";
  static const String URL_GET_LOT_DETAIL_BY_LOT_WITH_QUANTITY =
      "/GetLotDetailByLotWithQuantity";

  static const String URL_GET_LIST_OUTWARD = "/GetOutwards";
  static const String URL_OUTWARD = "/Outwards";
  static const String URL_GET_NEW_REFNO_OUTWARD = "/GetNewRefNo/%s";
  static const String URL_ADD_EDIT_OUTWARD = "/AddEditOutward";
  static const String URL_GET_ROLES_PERMISSON = "/rolesPermission";
  static const String URL_DELETE_OUTWARD_DETAIL = "/DeleteListIDOutward";
  static const String URL_GET_VOUCHERS_FOR_OUTWARD = "/GetVouchersForOutward";
  static const String URL_GET_VOUCHERS_DETAIL_FOR_OUTWARD =
      "/GetVoucherDetailsForOutward";

  static const String URL_GET_ALL_BRANCH = "/getAllBranch";

  ///xác thực misa id
  static const String URL_GET_ALLOW_MISA_ID_STATUS = "/GetAllowMISAIDStatus";
  static const String URL_VERIFY_ACCOUNT_STEP_1 = "/VerifyStep1";
  static const String URL_VERIFY_ACCOUNT_STEP_2 = "/VerifyStep2";
  static const String URL_RESEND_VERIFY_CODE = "/ResendCode";
  static const String URL_LOGIN_MISA_ID = "/VerifyLoginMISAID";

  static const String MISA_ID = "/misaid";

  ///khảo sát
  static const String URL_GET_LIST_SURVEY_FOR_USER =
      "Survey/GetListServeyForUser";
  static const String URL_UPDATE_CANCEL_COUNT = "/Survey/UpdateCancelCount";

  ///Kháchh hàng
  static const String URL_GET_LIST_CUSTOMER = "/CustomerMobilePaging";
  static const String URL_GET_DETAIL_CUSTOMER = "/CustomerDetailForMobile";

  static const String URL_GET_LIST_ORDER_FOR_CUSTOMER =
      "/SaleHistoryMobilePaging";

  static const String URL_GET_LIST_CUSTOMER_CATEGORY =
      "/MobileCommon/GetCustomerCategory";
  static const String URL_CUSTOMER = "/Customer";
  static const String URL_ADD_CUSTOMER = "/MobileCommon/AddCustomers";
  static const String URL_GET_MEMBER_LEVEL_DEFAULT =
      "/fiveshops/membershipcard/GetCardDefault";
  static const String URL_DELETE_CUSTOMER = "/MobileCommon/DeleteCustomerByID";
  static const String URL_GET_MEMBERSHIP = "/MemberLevels";

  ///url Lấy danh sách order từ website
  static const String URL_GET_LIST_ORDER_FROM_WEBSITE =
      "/MobileSAOrder/GetSAOrderForMobilePaging";
  static const String URL_GET_LIST_ORDER_DETAIL_FROM_WEBSITE =
      "/MobileSAOrder/GetSAOrderDetail";
}
