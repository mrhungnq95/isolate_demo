//
// Created by nqhung on 11/11/2020.
//

class AuthConst {
  static const GRANT_TYPE_PASSWORD = "password";
  static const GRANT_TYPE_REFRESH = "refresh_token";
  static const CLIENT_ID = "qlch-native";
  static const CLIENT_SECRET = "pNeqP6ESxZ8gFNmYsvc5m4gjHdqgaWFzvzoS5+gjAHM=";
}
