//
// Created by nqhung on 10/11/2020.
//

import 'package:MShopManager/app/app_config.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/enums/enum_api_type.dart';
import 'package:MShopManager/utils/global_utils.dart';
import 'package:flutter/cupertino.dart';

import 'endpoint_config.dart';

class UrlHelper {
  static const String _PROTOCOL_HTTPS = "https://";
  static const String _PROTOCOL_HTTP = "http://";

  static const String INTERNET_HOST_VN = ".mshopkeeper.vn";
  static const String INTERNET_HOST_COM = ".mshopkeeper.com";
  static const String LOCAL_HOST_VN = ".mshopkeeper.misa.local";
  static const String LOCAL_HOST_COM = ".mshopkeeper.com.local";

  static const String _URL_DOMAIN_API = "api";
  static const String _URL_DOMAIN_LOCAL_API = "apibe";
  static const String _URL_DOMAIN_TEST_API = "testapi";

  static final isTest = false;

  String _environment = "g1";
  String _subDomain;
  String _branchCode;
  bool _isAuthInternet = true;

  static UrlHelper _instance;
  static UrlHelper get shared => _getInstance();

  UrlHelper._internal() {
    _init();
  }

  static UrlHelper _getInstance() {
    if (_instance == null) {
      _instance = UrlHelper._internal();
    }
    return _instance;
  }

  void _init() {
    updateConfig();
  }

  /// Cập nhật các config cho việc build Url
  ///
  /// Created by nqhung on 10/11/2020
  void updateConfig() {
    _branchCode = LocalStorage.shared.getBranchCode();
    _subDomain = LocalStorage.shared.getSubDomain();
    _environment = LocalStorage.shared.getEnvironment();
    _isAuthInternet = UserCredential.currentSession.isAuth;

    print(
        "[BASE] Url Helper updateConfig! {$_branchCode - $_subDomain - $_environment}");
  }

  /// Reset các config của Instance hiện tại
  ///
  /// Created by nqhung on 10/11/2020
  static void resetInstance() {
    _instance = null;

    print("[BASE] Url Helper reset!");
  }

  String getUrl(
      {String branchCode, @required EAPIType apiType, String methodName}) {
    String localBranchCode = branchCode;

    if (isNullOrEmpty(localBranchCode)) {
      //Nếu không truyền param: branchCode thì lấy từ local storage ra.
      localBranchCode = _branchCode;
    }

    if (hasContentData(methodName)) {
      final url = _getFullApiUrlByEndPointType(localBranchCode, apiType);
      return "$url/$methodName";
    }
    return _getFullApiUrlByEndPointType(localBranchCode, apiType);
  }

  /// Lấy Full API của EndPoint
  /// [branchCode] mã nhà hàng
  /// [apiType] type của EndPoint
  /// Created by nqhung on 10/11/2020
  String _getFullApiUrlByEndPointType(String branchCode, EAPIType apiType) {
    switch (apiType) {
      case EAPIType.AUTHENTICATION:
        return _getAuthAPIUrl();
      case EAPIType.DASH_BOARD:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_DASH_BOARDS;
      case EAPIType.IMAGE:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_IMAGE;
      case EAPIType.DBOPTION:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_DBOPTIONS;
      case EAPIType.EMPLOYEE:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_EMPLOYEE;
      case EAPIType.CHECK_VERSION:
        return _getCommonAPIUrl();
      case EAPIType.FORGOT_PASSWORD:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_FORGET_PASSWORD;
      case EAPIType.CHECK_EXIST_DOMAIN:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_CHECK_EXIST_DOMAIN;
      case EAPIType.FEEDBACK:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_FEEDBACK;
      case EAPIType.PU_INVOICE:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_PU_INVOICE;
      case EAPIType.MANAGEMENT:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_MANAGEMENT;
      case EAPIType.API_BE:
        return _getAPIUrl(branchCode: branchCode);
      case EAPIType.API_INVENTORY_ITEM:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_ENDPOINT_INVENTORY_ITEM;
      case EAPIType.API_MOBILES:
        return _getAPIUrl(branchCode: branchCode) + EndpointConfig.URL_MOBILES;
      case EAPIType.API_LOT:
        return _getAPIUrl(branchCode: branchCode) + EndpointConfig.URL_LOT;
      case EAPIType.API_SERIAL_IMEI:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_SERIAL_IMEI;
      case EAPIType.API_DOWNLOAD:
        return _getAPIUrl(branchCode: branchCode);
      case EAPIType.OUTWARD:
        return _getAPIUrl(branchCode: branchCode) + EndpointConfig.URL_OUTWARD;
      case EAPIType.MISA_ID:
        return _getAPIUrl(branchCode: branchCode) + EndpointConfig.MISA_ID;
      case EAPIType.NOTIFICATION:
        return _getAPIUrl(branchCode: branchCode) +
            EndpointConfig.URL_NOTIFICATION;

      default:
        return _getAPIUrl(branchCode: branchCode);
    }
  }

  /// Lấy url Internet
  ///
  /// Created by nqhung on 10/11/2020
  String _getInternetHost({@required String prefix}) {
    if (hasContentData(_subDomain)) {
      return "$prefix$_subDomain";
    } else {
      return "$prefix$INTERNET_HOST_VN";
    }
  }

  /// Lấy url Local dev
  ///
  /// Created by nqhung on 10/11/2020
  String _getLocalHost({@required String prefix}) {
    if (hasContentData(_subDomain)) {
      return "$prefix$_subDomain";
    } else {
      return "$prefix$LOCAL_HOST_VN";
    }
  }

  String _getEnvAPI() {
    if (AppConfig.isRelease) {
      return "backend${_environment}/api";
    } else {
      return "api";
    }
  }

  /// Lấy Url chung với [branchCode]
  /// [branchCode] mã nhà hàng
  /// Created by nqhung on 10/11/2020
  String _getAPIUrl({@required String branchCode}) {
    String envAPI = _getEnvAPI();
    final api = _getAPIByPrefixUrl(branchCode: branchCode);
    return "$api/$envAPI";
  }

  /// Lấy Url Authen
  ///
  /// Created by nqhung on 10/11/2020
  String _getAuthAPIUrl() {
    if (AppConfig.isRelease) {
      var prefixUrl = isTest ? _URL_DOMAIN_TEST_API : _URL_DOMAIN_API;
      //https://api.mshopkeeper.vn or https://api.mshopkeeper.com
      return "$_PROTOCOL_HTTPS${_getInternetHost(prefix: prefixUrl)}";
    } else {
      if (_isAuthInternet) {
        return "$_PROTOCOL_HTTPS${_getInternetHost(prefix: _URL_DOMAIN_API)}";
      } else {
        return "$_PROTOCOL_HTTP${_getLocalHost(prefix: _URL_DOMAIN_API)}";
      }
    }
  }

  /// Lấy API endpoint base
  /// [branchCode] mã nhà hàng
  /// Created by nqhung on 10/11/2020
  ///
  /// Url endpoint base dùng để build lên các API cụ thể. domain.mshopkeeper.vn
  /// Local:  http://company.mshopkeeper.misa.local/api/*
  /// Test: http://apibetest.mshopkeeper.vn/api/*
  /// Release: http://api.mshopkeeper.vn/backend{g1|g2}/api/*
  String _getAPIByPrefixUrl({@required String branchCode}) {
    if (AppConfig.isRelease) {
      //https://api.mshopkeeper.vn or https://api.mshopkeeper.com
      return "$_PROTOCOL_HTTPS${_getInternetHost(prefix: branchCode)}";
    } else {
      if (_isAuthInternet) {
        return "$_PROTOCOL_HTTPS${_getInternetHost(prefix: branchCode)}";
      } else {
        return "$_PROTOCOL_HTTP${_getLocalHost(prefix: _URL_DOMAIN_LOCAL_API)}";
      }
    }
  }

  String _getCommonAPIUrl() {
    var endPointName = isTest ? "testcommonapi" : "commonapi";
    if (AppConfig.isRelease) {
      //https://api.mshopkeeper.vn or https://api.mshopkeeper.com
      return "$_PROTOCOL_HTTPS${_getInternetHost(prefix: endPointName)}/api";
    } else {
      return "$_PROTOCOL_HTTP${_getLocalHost(prefix: _URL_DOMAIN_API)}/api";
    }
  }

  ///
  ///
  ///
  String _getBackEndAPIUrl() {
    String envAPI = _getEnvAPI();

    String url;
    if (AppConfig.isRelease) {
      //https://api.mshopkeeper.vn or https://api.mshopkeeper.com
      url = "$_PROTOCOL_HTTPS${_getInternetHost(prefix: 'api')}";
    } else {
      if (_isAuthInternet) {
        url = "$_PROTOCOL_HTTPS${_getInternetHost(prefix: 'api')}";
      } else {
        url = "$_PROTOCOL_HTTP${_getLocalHost(prefix: 'api')}";
      }
    }
    return "$url/$envAPI";
  }

  String _getUrlAPIDownload() {}

  String _getUrlAPIMisaID() {}

  ///
  /// Build Url hình ảnh hàng hóa
  /// [pictureId]: Id của hình ảnh
  /// [ext]: Đuôi .png, .jpg
  /// [pictureType]: 1 là loại ảnh người dùng tự upload cho sản phẩm
  /// [width]: chiều dài
  /// [height]: Chiều cao của ảnh
  /// [Return String]: Url load ảnh của sản phẩm
  ///
  String getUrlInventoryItemImage(
      {String pictureId,
      String ext = '.png',
      int pictureType,
      int width,
      int height}) {
    String filename = pictureId ?? '';
    // 1 là loại ảnh người dùng tự upload cho sản phẩm
    if (pictureType == 1) {
      filename = '$filename${ext ?? '.png'}';
    }
    final widthStr = width != null ? '&w=$width' : '';
    final heighStr = height != null ? '&h=$height' : '';
    return '${_getAPIUrl(branchCode: _branchCode)}/Image?id=${filename}&type=${(pictureType ?? 1).toString()}&mode=pad&CompanyCode=${_branchCode}$widthStr$heighStr}';
  }

  ///
  /// Build url cho avatar
  ///
  /// [companyCode] mã cửa hàng
  /// [avatarId] id của ảnh
  /// [ext] kiểu ảnh (đuôi mở rộng)
  ///
  String getUrlAvatar(
      {String companyCode,
      @required String avatarId,
      String ext = '.jpg',
      int pictureType = 0}) {
    String localBranchCode = companyCode;

    if (isNullOrEmpty(localBranchCode)) {
      //Nếu không truyền param: branchCode thì lấy từ local storage ra.
      localBranchCode = _branchCode;
    }

    /// Tên ảnh
    String filename = avatarId ?? '';

    /// 1 là loại ảnh người dùng tự upload cho sản phẩm
    if (pictureType == 1) {
      filename = '$filename${ext ?? '.png'}';
    }

    /// /Image?id="+photoId+"&type=0&mode=pad&temp=False&w=250&h=250&CompanyCode=
    return '${_getBackEndAPIUrl()}/Image?id=$avatarId&type=0&mode=pad&temp=False&w=250&h=250&CompanyCode=$localBranchCode';
  }
}
