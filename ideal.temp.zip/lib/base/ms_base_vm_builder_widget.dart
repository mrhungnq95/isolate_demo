import 'package:flutter/material.dart';

import 'ms_base_scaffold_vm_builder_widget.dart';
import 'ms_base_vm.dart';

abstract class MSBaseViewModelBuilder<T extends MSBaseViewModel>
    extends MSBaseScaffoldViewModelBuilder<T> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  Widget onBuildBody(BuildContext context, T model, Widget child);
  Widget onBuildAppBar(BuildContext context, T model);
  Widget onBuildBottomNavigationBar(BuildContext context, T model);
  Widget onBuildBottomSheet(BuildContext context, T model);
  Widget onBuildFloatingButton(BuildContext context, T model);

  @override
  Scaffold onBuildScaffold(BuildContext context, T model, Widget child) {
    return Scaffold(
        key: scaffoldKey,
        appBar: onBuildAppBar(context, model),
        body: onBuildBody(context, model, child),
        bottomSheet: onBuildBottomSheet(context, model),
        floatingActionButton: onBuildFloatingButton(context, model),
        bottomNavigationBar: onBuildBottomNavigationBar(context, model));
  }
}
