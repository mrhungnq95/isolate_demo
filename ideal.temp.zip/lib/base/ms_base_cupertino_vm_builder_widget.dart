import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/app/app_color.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import 'ms_base_scaffold_vm_builder_widget.dart';
import 'ms_base_vm.dart';

abstract class MSBaseCupertinoViewModelBuilder<T extends MSBaseViewModel>
    extends MSBaseScaffoldViewModelBuilder<T> {
  Color provideBackgroundColor() {
    return AppColor.white;
  }

  FloatingActionButtonLocation provideFloatingActionButtonLocation() {
    return FloatingActionButtonLocation.endFloat;
  }

  bool resizeToAvoidBottomInset() {
    return true;
  }

  ObstructingPreferredSizeWidget onBuildAppBar(BuildContext context, T model) {
    return null;
  }

  Widget onBuildBody(BuildContext context, T model, Widget child);

  Widget onBuildFloatingButton(BuildContext context, T model) {
    return null;
  }

  @override
  Scaffold onBuildScaffold(BuildContext context, T model, Widget child) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: provideBackgroundColor(),
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset(),
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(0),
          child: AppBar(
            brightness: provideBrightnessColor(context),
            elevation: 0,
            backgroundColor: provideStatusBarColor(),
          )),
      body: CupertinoScaffold(
        body: CupertinoPageScaffold(
            resizeToAvoidBottomInset: resizeToAvoidBottomInset(),
            backgroundColor: provideBackgroundColor(),
            navigationBar: onBuildAppBar(context, model),
            child: onBuildBody(context, model, child)),
      ),
      floatingActionButton: onBuildFloatingButton(context, model),
      floatingActionButtonLocation: provideFloatingActionButtonLocation(),
    );
  }
}
