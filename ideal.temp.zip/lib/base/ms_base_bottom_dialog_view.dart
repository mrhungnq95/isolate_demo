import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:keyboard_attachable/keyboard_attachable.dart';
import 'package:MShopManager/app/app_spacing.dart';

class ColorsList extends StatelessWidget {
  @override
  Widget build(BuildContext context) => ListView.builder(
        itemExtent: 66,
        itemCount: Colors.primaries.length,
        itemBuilder: (_, i) => Container(
          color: Colors.primaries[i].withOpacity(0.2),
        ),
      );
}

/// Builds a footer that animates its bottom space when the keyboard is shown.
class KeyboardAttachableFooter extends StatelessWidget {
  @override
  Widget build(BuildContext context) => KeyboardAttachable(
        backgroundColor: Colors.blue,
        child: Container(
          padding: const EdgeInsets.all(16),
          color: Colors.blue,
          child: const TextField(
            decoration: InputDecoration(
              hintText: "Tap me!",
              fillColor: Colors.white,
              filled: true,
              border: OutlineInputBorder(),
            ),
          ),
        ),
      );
}

abstract class MSBaseBottomDialogView extends StatelessWidget {
  Widget builder(BuildContext context);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: false,
      body: FooterLayout(
        footer: KeyboardAttachable(
          backgroundColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(kVerticalSpaceLarge),
            child: Material(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 1.0,
              child: builder(context),
            ),
          ),
        ),
        child: Container(
          color: Colors.transparent,
        ),
      ),
    );

    // final mq = MediaQuery.of(context);
    // //final bottomOffset = mq.viewInsets.bottom + mq.padding.bottom;
    // final bottomOffset = mq.padding.bottom;
    // // You can play with some different Curves:
    // const curve = Curves.easeOutQuad;
    // // and timings:
    // const durationMS = 400;
    //
    // return Scaffold(
    //   backgroundColor: Colors.transparent,
    //   // !!! Important part > to disable default scaffold insets (which is not animated)
    //   resizeToAvoidBottomInset: false,
    //   body: AnimatedContainer(
    //     curve: curve,
    //     duration: const Duration(milliseconds: durationMS),
    //     padding: EdgeInsets.only(bottom: bottomOffset),
    //     child: SafeArea(
    //       bottom:
    //           false, // !!! Important part > we are adding SafeArea.bottom above with " + mq.padding.bottom"
    //       child: Stack(
    //         children: [
    //           Positioned(
    //               left: 0,
    //               right: 0,
    //               bottom: 0,
    //               child: Dialog(
    //                 insetPadding: EdgeInsets.all(kVerticalSpaceLarge),
    //                 shape: RoundedRectangleBorder(
    //                   borderRadius: BorderRadius.circular(16),
    //                 ),
    //                 elevation: 1.0,
    //                 child: contentView(context),
    //               ))
    //         ],
    //       ),
    //     ),
    //   ),
    // );

    return GestureDetector(
      onTap: () {},
      child: Scaffold(
        backgroundColor: Colors.transparent,
        //resizeToAvoidBottomInset: true,
        body: CustomScrollView(
          reverse: true,
          slivers: [
            SliverToBoxAdapter(
              child: Dialog(
                insetPadding: EdgeInsets.all(kVerticalSpaceLarge),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 1.0,
                child: builder(context),
              ),
            )
          ],
        ),
      ),
    );
  }
}
