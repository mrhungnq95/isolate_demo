import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';
import 'package:keyboard_attachable/keyboard_attachable.dart';

class MSBaseBottomDialogV2 extends StatelessWidget {
  final Widget Function(BuildContext context) builder;

  const MSBaseBottomDialogV2({Key key, this.builder}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: false,
      body: FooterLayout(
        footer: KeyboardAttachable(
          backgroundColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(kVerticalSpaceLarge),
            child: Material(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(13),
              ),
              elevation: 1.0,
              child: builder(context),
            ),
          ),
        ),
        child: Container(
          color: Colors.transparent,
        ),
      ),
    );
  }
}
