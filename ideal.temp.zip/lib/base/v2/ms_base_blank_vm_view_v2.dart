import 'package:flutter/widgets.dart';
import '../ms_base_vm.dart';
import 'package:stacked/stacked.dart';

class MSBaseBlankViewModelViewV2<T extends MSBaseViewModel>
    extends StatelessWidget {
  final Widget Function(
    BuildContext context,
    T model,
    Widget child,
  ) builder;

  final T Function(BuildContext context) viewModelBuilder;

  final bool reactive;

  final bool createNewModelOnInsert;

  final bool disposeViewModel;

  final bool initialiseSpecialViewModelsOnce;

  final bool fireOnModelReadyOnce;

  final void Function(T model) onViewModelReady;

  final Widget Function(BuildContext context) staticChildBuilder;

  const MSBaseBlankViewModelViewV2(
      {Key key,
      @required this.builder,
      @required this.viewModelBuilder,
      this.reactive = false,
      this.createNewModelOnInsert = false,
      this.disposeViewModel = true,
      this.initialiseSpecialViewModelsOnce = false,
      this.fireOnModelReadyOnce = false,
      this.onViewModelReady,
      this.staticChildBuilder})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (reactive) {
      return ViewModelBuilder<T>.reactive(
        builder: builder,
        viewModelBuilder: () => viewModelBuilder(context),
        staticChild:
            staticChildBuilder != null ? staticChildBuilder(context) : null,
        onModelReady: onViewModelReady,
        disposeViewModel: disposeViewModel,
        createNewModelOnInsert: createNewModelOnInsert,
        initialiseSpecialViewModelsOnce: initialiseSpecialViewModelsOnce,
        fireOnModelReadyOnce: fireOnModelReadyOnce,
      );
    } else {
      return ViewModelBuilder<T>.nonReactive(
        builder: builder,
        viewModelBuilder: () => viewModelBuilder(context),
        onModelReady: onViewModelReady,
        disposeViewModel: disposeViewModel,
        createNewModelOnInsert: createNewModelOnInsert,
      );
    }
  }
}
