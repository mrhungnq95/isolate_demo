import 'package:MShopManager/base/v2/ms_base_blank_vm_view_v2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../ms_base_vm.dart';

//Class triển khai một Model Bottom Sheet và được sử dụng bằng showCupertinoModalBottomSheet
// Example
// showCupertinoModalBottomSheet(
//        expand: true,
//        context: context,
//        backgroundColor: Colors.transparent,
//        builder: (context, scrollController) =>
//        ModalWithNavigator(
//        scrollController: scrollController),
// );
// https://pub.dev/packages/modal_bottom_sheet
class MSBaseModalViewModelWidgetV2<T extends MSBaseViewModel>
    extends StatelessWidget {
  final Widget Function(
    BuildContext context,
    T model,
    Widget child,
  ) builder;
  final T Function(BuildContext context) viewModelBuilder;

  final bool reactive;

  final bool createNewModelOnInsert;

  final bool disposeViewModel;

  final bool initialiseSpecialViewModelsOnce;

  final bool fireOnModelReadyOnce;

  final void Function(T model) onViewModelReady;

  final Widget Function(BuildContext context) staticChildBuilder;

  final Widget Function(BuildContext context, T model) appBarBuilder;

  const MSBaseModalViewModelWidgetV2(
      {Key key,
      this.builder,
      this.viewModelBuilder,
      this.reactive = false,
      this.createNewModelOnInsert = false,
      this.disposeViewModel = true,
      this.initialiseSpecialViewModelsOnce = false,
      this.fireOnModelReadyOnce = false,
      this.onViewModelReady,
      this.staticChildBuilder,
      this.appBarBuilder})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSBaseBlankViewModelViewV2<T>(
      reactive: reactive ?? true,
      staticChildBuilder: (context) => staticChildBuilder(context),
      onViewModelReady: onViewModelReady,
      disposeViewModel: disposeViewModel,
      createNewModelOnInsert: createNewModelOnInsert,
      initialiseSpecialViewModelsOnce: initialiseSpecialViewModelsOnce,
      fireOnModelReadyOnce: fireOnModelReadyOnce,
      viewModelBuilder: viewModelBuilder,
      builder: (BuildContext context, T model, Widget child) {
        return Material(
            child: Navigator(
                onGenerateRoute: (_) => MaterialPageRoute(
                    builder: (context) => Builder(
                        builder: (context) => CupertinoPageScaffold(
                            navigationBar: appBarBuilder(context, model),
                            child: SafeArea(
                                bottom: false,
                                child: builder(context, model, child)))))));
      },
    );
  }
}
