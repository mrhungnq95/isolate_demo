import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/v2/ms_base_scaffold_vm_widget_v2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/app/app_color.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class MSBaseCupertinoWidgetBuilderV2<T extends MSBaseViewModel>
    extends StatelessWidget {

  final GlobalKey<ScaffoldState> scaffoldKey;
  final Widget Function(
    BuildContext context,
    T model,
    Widget child,
  ) builder;
  final T Function(BuildContext context) viewModelBuilder;
  final bool reactive;

  final bool createNewModelOnInsert;

  final bool disposeViewModel;

  final bool initialiseSpecialViewModelsOnce;

  final bool fireOnModelReadyOnce;

  final void Function(T model) onViewModelReady;

  final Widget Function(BuildContext context) staticChildBuilder;

  /// return ObstructingPreferredSizeWidget;
  final Widget Function(BuildContext context, T model) appBarBuilder;
  final Widget Function(BuildContext context, T model) floatingButtonBuilder;
  final FloatingActionButtonLocation floatingActionButtonLocation;
  final Brightness brightnessColor;
  final Color backgroundColor;
  final Color statusBarColor;
  final bool resizeToAvoidBottomInset;

  const MSBaseCupertinoWidgetBuilderV2({
    Key key,
    this.scaffoldKey,
    @required this.builder,
    @required this.viewModelBuilder,
    this.reactive = true,
    this.createNewModelOnInsert = false,
    this.disposeViewModel = true,
    this.initialiseSpecialViewModelsOnce = false,
    this.fireOnModelReadyOnce = false,
    @required this.onViewModelReady,
    this.staticChildBuilder,
    this.appBarBuilder,
    this.statusBarColor,
    this.brightnessColor,
    this.floatingButtonBuilder,
    this.floatingActionButtonLocation = FloatingActionButtonLocation.endFloat,
    this.backgroundColor = AppColor.white,
    this.resizeToAvoidBottomInset = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSBaseScaffoldViewModelBuilderV2<T>(
      scaffoldKey: scaffoldKey,
      reactive: reactive,
      staticChildBuilder: (context) =>
          staticChildBuilder != null ? staticChildBuilder(context) : null,
      onViewModelReady: onViewModelReady,
      disposeViewModel: disposeViewModel,
      createNewModelOnInsert: createNewModelOnInsert,
      initialiseSpecialViewModelsOnce: initialiseSpecialViewModelsOnce,
      fireOnModelReadyOnce: fireOnModelReadyOnce,
      viewModelBuilder: viewModelBuilder,
      builder: (BuildContext context, T model, Widget child) {
        return CupertinoScaffold(
          body: CupertinoPageScaffold(
              resizeToAvoidBottomInset: resizeToAvoidBottomInset,
              backgroundColor: backgroundColor,
              navigationBar:
                  appBarBuilder != null ? appBarBuilder(context, model) : null,
              child: builder(context, model, child)),
        );
      },
      
      floatingButtonBuilder: floatingButtonBuilder,
      floatingActionButtonLocation: floatingActionButtonLocation,
      resizeToAvoidBottomInset: resizeToAvoidBottomInset,
      statusBarColor: statusBarColor,
      backgroundColor: backgroundColor,
      brightnessColor: brightnessColor,
    );
  }
}
