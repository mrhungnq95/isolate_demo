import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/v2/ms_base_blank_vm_view_v2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

class MSBaseScaffoldViewModelBuilderV2<T extends MSBaseViewModel>
    extends StatelessWidget {
  final Widget Function(
    BuildContext context,
    T model,
    Widget child,
  ) builder;

  final T Function(BuildContext context) viewModelBuilder;

  final bool reactive;

  final bool createNewModelOnInsert;

  final bool disposeViewModel;

  final bool initialiseSpecialViewModelsOnce;

  final bool fireOnModelReadyOnce;

  final void Function(T model) onViewModelReady;

  final Widget Function(BuildContext context) staticChildBuilder;

  /// ==========================================================================
  /// return ObstructingPreferredSizeWidget;
  final GlobalKey<ScaffoldState> scaffoldKey;
  final Widget Function(BuildContext context, T model) floatingButtonBuilder;
  final FloatingActionButtonLocation floatingActionButtonLocation;
  final Brightness brightnessColor;
  final Color backgroundColor;
  final Color statusBarColor;
  final bool resizeToAvoidBottomInset;

  const MSBaseScaffoldViewModelBuilderV2({
    Key key,
    this.scaffoldKey,
    this.builder,
    this.viewModelBuilder,
    this.reactive = true,
    this.createNewModelOnInsert = false,
    this.disposeViewModel = true,
    this.initialiseSpecialViewModelsOnce = false,
    this.fireOnModelReadyOnce = false,
    this.onViewModelReady,
    this.staticChildBuilder,
    this.floatingButtonBuilder,
    this.floatingActionButtonLocation,
    this.brightnessColor,
    this.backgroundColor,
    this.statusBarColor,
    this.resizeToAvoidBottomInset,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSBaseBlankViewModelViewV2<T>(
      reactive: reactive ?? true,
      staticChildBuilder: (context) => staticChildBuilder(context),
      onViewModelReady: onViewModelReady,
      disposeViewModel: disposeViewModel,
      createNewModelOnInsert: createNewModelOnInsert,
      initialiseSpecialViewModelsOnce: initialiseSpecialViewModelsOnce,
      fireOnModelReadyOnce: fireOnModelReadyOnce,
      viewModelBuilder: viewModelBuilder,
      builder: (BuildContext context, T model, Widget child) {
        return AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle(
              statusBarColor: statusBarColor,
              statusBarIconBrightness: brightnessColor,
            ),
            child: Scaffold(
              key: scaffoldKey,
              backgroundColor: backgroundColor,
              extendBodyBehindAppBar: true,
              resizeToAvoidBottomInset: resizeToAvoidBottomInset,
              appBar: PreferredSize(
                  preferredSize: Size.fromHeight(0),
                  child: AppBar(
                    brightness: brightnessColor,
                    elevation: 0,
                    backgroundColor: statusBarColor,
                  )),
              body: builder(context, model, child),
              floatingActionButton: floatingButtonBuilder != null
                  ? floatingButtonBuilder(context, model)
                  : null,
              floatingActionButtonLocation: floatingActionButtonLocation,
            ));
      },
    );
  }
}
