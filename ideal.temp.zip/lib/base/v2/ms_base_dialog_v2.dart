import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';

class MSBaseDialogV2 extends StatelessWidget {
  final Color backgroundColor;
  final BorderRadius borderRadius;
  final Widget Function(BuildContext context) builder;

  static final BorderRadius _defaultBorderRadius = BorderRadius.circular(13);

  const MSBaseDialogV2(
      {Key key,
      @required this.builder,
      this.backgroundColor = Colors.white,
      this.borderRadius})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Dialog(
        insetPadding: const EdgeInsets.all(kVerticalSpaceMedium),
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: borderRadius ?? _defaultBorderRadius),
          child: ClipRRect(
            borderRadius: borderRadius ?? _defaultBorderRadius,
            child: builder(context),
          ),
        ),
      ),
    );
  }
}
