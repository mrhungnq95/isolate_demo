// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'ms_base_result.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$MSBaseResultTearOff {
  const _$MSBaseResultTearOff();

// ignore: unused_element
  Success<T> success<T>({@required T data}) {
    return Success<T>(
      data: data,
    );
  }

// ignore: unused_element
  CommonError<T> commonError<T>({@required Exception error}) {
    return CommonError<T>(
      error: error,
    );
  }

// ignore: unused_element
  ApiError<T> apiError<T>(
      {ErrorData errorData, @required NetworkExceptions error}) {
    return ApiError<T>(
      errorData: errorData,
      error: error,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $MSBaseResult = _$MSBaseResultTearOff();

/// @nodoc
mixin _$MSBaseResult<T> {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result success(T data),
    @required Result commonError(Exception error),
    @required Result apiError(ErrorData errorData, NetworkExceptions error),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result success(T data),
    Result commonError(Exception error),
    Result apiError(ErrorData errorData, NetworkExceptions error),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result success(Success<T> value),
    @required Result commonError(CommonError<T> value),
    @required Result apiError(ApiError<T> value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result success(Success<T> value),
    Result commonError(CommonError<T> value),
    Result apiError(ApiError<T> value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $MSBaseResultCopyWith<T, $Res> {
  factory $MSBaseResultCopyWith(
          MSBaseResult<T> value, $Res Function(MSBaseResult<T>) then) =
      _$MSBaseResultCopyWithImpl<T, $Res>;
}

/// @nodoc
class _$MSBaseResultCopyWithImpl<T, $Res>
    implements $MSBaseResultCopyWith<T, $Res> {
  _$MSBaseResultCopyWithImpl(this._value, this._then);

  final MSBaseResult<T> _value;
  // ignore: unused_field
  final $Res Function(MSBaseResult<T>) _then;
}

/// @nodoc
abstract class $SuccessCopyWith<T, $Res> {
  factory $SuccessCopyWith(Success<T> value, $Res Function(Success<T>) then) =
      _$SuccessCopyWithImpl<T, $Res>;
  $Res call({T data});
}

/// @nodoc
class _$SuccessCopyWithImpl<T, $Res> extends _$MSBaseResultCopyWithImpl<T, $Res>
    implements $SuccessCopyWith<T, $Res> {
  _$SuccessCopyWithImpl(Success<T> _value, $Res Function(Success<T>) _then)
      : super(_value, (v) => _then(v as Success<T>));

  @override
  Success<T> get _value => super._value as Success<T>;

  @override
  $Res call({
    Object data = freezed,
  }) {
    return _then(Success<T>(
      data: data == freezed ? _value.data : data as T,
    ));
  }
}

/// @nodoc
class _$Success<T> with DiagnosticableTreeMixin implements Success<T> {
  const _$Success({@required this.data}) : assert(data != null);

  @override
  final T data;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'MSBaseResult<$T>.success(data: $data)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'MSBaseResult<$T>.success'))
      ..add(DiagnosticsProperty('data', data));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Success<T> &&
            (identical(other.data, data) ||
                const DeepCollectionEquality().equals(other.data, data)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(data);

  @override
  $SuccessCopyWith<T, Success<T>> get copyWith =>
      _$SuccessCopyWithImpl<T, Success<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result success(T data),
    @required Result commonError(Exception error),
    @required Result apiError(ErrorData errorData, NetworkExceptions error),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return success(data);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result success(T data),
    Result commonError(Exception error),
    Result apiError(ErrorData errorData, NetworkExceptions error),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (success != null) {
      return success(data);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result success(Success<T> value),
    @required Result commonError(CommonError<T> value),
    @required Result apiError(ApiError<T> value),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return success(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result success(Success<T> value),
    Result commonError(CommonError<T> value),
    Result apiError(ApiError<T> value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class Success<T> implements MSBaseResult<T> {
  const factory Success({@required T data}) = _$Success<T>;

  T get data;
  $SuccessCopyWith<T, Success<T>> get copyWith;
}

/// @nodoc
abstract class $CommonErrorCopyWith<T, $Res> {
  factory $CommonErrorCopyWith(
          CommonError<T> value, $Res Function(CommonError<T>) then) =
      _$CommonErrorCopyWithImpl<T, $Res>;
  $Res call({Exception error});
}

/// @nodoc
class _$CommonErrorCopyWithImpl<T, $Res>
    extends _$MSBaseResultCopyWithImpl<T, $Res>
    implements $CommonErrorCopyWith<T, $Res> {
  _$CommonErrorCopyWithImpl(
      CommonError<T> _value, $Res Function(CommonError<T>) _then)
      : super(_value, (v) => _then(v as CommonError<T>));

  @override
  CommonError<T> get _value => super._value as CommonError<T>;

  @override
  $Res call({
    Object error = freezed,
  }) {
    return _then(CommonError<T>(
      error: error == freezed ? _value.error : error as Exception,
    ));
  }
}

/// @nodoc
class _$CommonError<T> with DiagnosticableTreeMixin implements CommonError<T> {
  const _$CommonError({@required this.error}) : assert(error != null);

  @override
  final Exception error;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'MSBaseResult<$T>.commonError(error: $error)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'MSBaseResult<$T>.commonError'))
      ..add(DiagnosticsProperty('error', error));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is CommonError<T> &&
            (identical(other.error, error) ||
                const DeepCollectionEquality().equals(other.error, error)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(error);

  @override
  $CommonErrorCopyWith<T, CommonError<T>> get copyWith =>
      _$CommonErrorCopyWithImpl<T, CommonError<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result success(T data),
    @required Result commonError(Exception error),
    @required Result apiError(ErrorData errorData, NetworkExceptions error),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return commonError(error);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result success(T data),
    Result commonError(Exception error),
    Result apiError(ErrorData errorData, NetworkExceptions error),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (commonError != null) {
      return commonError(error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result success(Success<T> value),
    @required Result commonError(CommonError<T> value),
    @required Result apiError(ApiError<T> value),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return commonError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result success(Success<T> value),
    Result commonError(CommonError<T> value),
    Result apiError(ApiError<T> value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (commonError != null) {
      return commonError(this);
    }
    return orElse();
  }
}

abstract class CommonError<T> implements MSBaseResult<T> {
  const factory CommonError({@required Exception error}) = _$CommonError<T>;

  Exception get error;
  $CommonErrorCopyWith<T, CommonError<T>> get copyWith;
}

/// @nodoc
abstract class $ApiErrorCopyWith<T, $Res> {
  factory $ApiErrorCopyWith(
          ApiError<T> value, $Res Function(ApiError<T>) then) =
      _$ApiErrorCopyWithImpl<T, $Res>;
  $Res call({ErrorData errorData, NetworkExceptions error});

  $NetworkExceptionsCopyWith<$Res> get error;
}

/// @nodoc
class _$ApiErrorCopyWithImpl<T, $Res>
    extends _$MSBaseResultCopyWithImpl<T, $Res>
    implements $ApiErrorCopyWith<T, $Res> {
  _$ApiErrorCopyWithImpl(ApiError<T> _value, $Res Function(ApiError<T>) _then)
      : super(_value, (v) => _then(v as ApiError<T>));

  @override
  ApiError<T> get _value => super._value as ApiError<T>;

  @override
  $Res call({
    Object errorData = freezed,
    Object error = freezed,
  }) {
    return _then(ApiError<T>(
      errorData:
          errorData == freezed ? _value.errorData : errorData as ErrorData,
      error: error == freezed ? _value.error : error as NetworkExceptions,
    ));
  }

  @override
  $NetworkExceptionsCopyWith<$Res> get error {
    if (_value.error == null) {
      return null;
    }
    return $NetworkExceptionsCopyWith<$Res>(_value.error, (value) {
      return _then(_value.copyWith(error: value));
    });
  }
}

/// @nodoc
class _$ApiError<T> with DiagnosticableTreeMixin implements ApiError<T> {
  const _$ApiError({this.errorData, @required this.error})
      : assert(error != null);

  @override
  final ErrorData errorData;
  @override
  final NetworkExceptions error;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'MSBaseResult<$T>.apiError(errorData: $errorData, error: $error)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'MSBaseResult<$T>.apiError'))
      ..add(DiagnosticsProperty('errorData', errorData))
      ..add(DiagnosticsProperty('error', error));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is ApiError<T> &&
            (identical(other.errorData, errorData) ||
                const DeepCollectionEquality()
                    .equals(other.errorData, errorData)) &&
            (identical(other.error, error) ||
                const DeepCollectionEquality().equals(other.error, error)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(errorData) ^
      const DeepCollectionEquality().hash(error);

  @override
  $ApiErrorCopyWith<T, ApiError<T>> get copyWith =>
      _$ApiErrorCopyWithImpl<T, ApiError<T>>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result success(T data),
    @required Result commonError(Exception error),
    @required Result apiError(ErrorData errorData, NetworkExceptions error),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return apiError(errorData, error);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result success(T data),
    Result commonError(Exception error),
    Result apiError(ErrorData errorData, NetworkExceptions error),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (apiError != null) {
      return apiError(errorData, error);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result success(Success<T> value),
    @required Result commonError(CommonError<T> value),
    @required Result apiError(ApiError<T> value),
  }) {
    assert(success != null);
    assert(commonError != null);
    assert(apiError != null);
    return apiError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result success(Success<T> value),
    Result commonError(CommonError<T> value),
    Result apiError(ApiError<T> value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (apiError != null) {
      return apiError(this);
    }
    return orElse();
  }
}

abstract class ApiError<T> implements MSBaseResult<T> {
  const factory ApiError(
      {ErrorData errorData, @required NetworkExceptions error}) = _$ApiError<T>;

  ErrorData get errorData;
  NetworkExceptions get error;
  $ApiErrorCopyWith<T, ApiError<T>> get copyWith;
}
