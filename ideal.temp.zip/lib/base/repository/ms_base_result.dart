import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/error_result.dart';
import 'package:flutter/foundation.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'ms_base_result.freezed.dart';

@freezed
abstract class MSBaseResult<T> with _$MSBaseResult<T> {
  const factory MSBaseResult.success({@required T data}) = Success<T>;

  const factory MSBaseResult.commonError({@required Exception error}) =
      CommonError<T>;

  const factory MSBaseResult.apiError(
      {ErrorData errorData, @required NetworkExceptions error}) = ApiError<T>;
}
