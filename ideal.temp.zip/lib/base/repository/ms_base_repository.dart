import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/utils/network_info.dart';

abstract class MSBaseRepository {
  final NetworkInfo networkInfo = LocatorService.shared.get<NetworkInfo>();
}
