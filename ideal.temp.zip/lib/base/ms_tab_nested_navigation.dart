import 'package:MShopManager/app/app_nested_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/app/routes/app_router.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NestedNavigationManager extends MSBaseViewModel {
  final GlobalKey<NavigatorState> _nestedNavigatorKey;
  GlobalKey<NavigatorState> get nestedNavigatorKey => _nestedNavigatorKey;

  NestedNavigationManager(this._nestedNavigatorKey);

  Future<dynamic> navigateTo(
      {@required AppRouterName routeName, dynamic argument}) {
    return _nestedNavigatorKey?.currentState
            ?.pushNamed(routeName.value(), arguments: argument) ??
        Future.value(null);
  }

  Future<dynamic> navigateReplacementNamed(
      {@required routeName, dynamic argument}) {
    return _nestedNavigatorKey.currentState.pushNamedAndRemoveUntil(
        routeName, (Route<dynamic> route) => false,
        arguments: argument);
  }

  void pop({dynamic data}) {
    _nestedNavigatorKey?.currentState?.pop(data);
  }
}

class TabNestedNavigation extends StatefulWidget {
  const TabNestedNavigation({@required this.tabItemType});

  final ETabItemType tabItemType;

  @override
  _TabNestedNavigationState createState() => _TabNestedNavigationState();
}

class _TabNestedNavigationState extends State<TabNestedNavigation>
    with AutomaticKeepAliveClientMixin<TabNestedNavigation> {
  NestedNavigationManager _tabViewModel;

  @override
  void initState() {
    NestedNavigationHelper nestedNavigationService =
        NestedNavigationHelper.shared;
    _tabViewModel = NestedNavigationManager(
        nestedNavigationService.nestedNavigatorKey[widget.tabItemType]);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    //return Provider<NestedNavigationManager>(create: (c) => c.read());
    return ChangeNotifierProvider<NestedNavigationManager>.value(
      value: _tabViewModel,
      builder: (context, child) {
        return Consumer<NestedNavigationManager>(
            builder: (context, model, child) {
          return Navigator(
            //key: locator<NestedNavigationHelper>()
            //    .nestedNavigatorKey[widget.tabItemType],
            key: model.nestedNavigatorKey,
            initialRoute: AppRouterName.root.value(),
            onGenerateRoute: (routeSetting) {
              return AppRouterHandler.handleRouterNestedNavigate(
                  widget.tabItemType, routeSetting);
            },
          );
        });
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}
