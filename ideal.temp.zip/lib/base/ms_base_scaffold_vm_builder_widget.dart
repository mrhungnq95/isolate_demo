import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/base/ms_base_blank_vm_builder_widget.dart';
import 'ms_base_vm.dart';

abstract class MSBaseScaffoldViewModelBuilder<T extends MSBaseViewModel>
    extends MSBaseBlankViewModelBuilder<T> {
      
  bool get reactive => false;

  final GlobalKey<ScaffoldState> scaffoldKey =  GlobalKey<ScaffoldState>();

  Scaffold onBuildScaffold(BuildContext context, T model, Widget child);

  Color provideStatusBarColor() {
    return AppColor.primaryColor;
  }

  Brightness provideBrightnessColor(BuildContext context) {
    return Theme.of(context).brightness;
  }

  @override
  Widget onBuildUI(BuildContext context, T model, Widget child) {
    return AnnotatedRegion<SystemUiOverlayStyle>(value: SystemUiOverlayStyle(
      statusBarColor: provideStatusBarColor(),
      statusBarIconBrightness: provideBrightnessColor(context),
    ), child: onBuildScaffold(context, model, child));
  }
}
