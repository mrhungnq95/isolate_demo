import 'package:MShopManager/app/app_navigation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'ms_base_blank_vm_builder_widget.dart';
import 'ms_base_vm.dart';

//Class triển khai một Model Bottom Sheet và được sử dụng bằng showCupertinoModalBottomSheet
// Example
// showCupertinoModalBottomSheet(
//        expand: true,
//        context: context,
//        backgroundColor: Colors.transparent,
//        builder: (context, scrollController) =>
//        ModalWithNavigator(
//        scrollController: scrollController),
// );
// https://pub.dev/packages/modal_bottom_sheet
abstract class MSBaseModalViewModelBuilder<T extends MSBaseViewModel>
    extends MSBaseBlankViewModelBuilder<T> {
  CupertinoNavigationBar onBuildModelAppBar(BuildContext context, T model);
  Widget onBuildModalBody(BuildContext context, T model, Widget child);

  @override
  Widget onBuildUI(BuildContext contextRoot, T model, Widget child) {
    return Material(
        child: Navigator(
            onGenerateRoute: (_) => MaterialPageRoute(
                builder: (context) => Builder(
                    builder: (context) => CupertinoPageScaffold(
                        navigationBar: onBuildModelAppBar(contextRoot, model),
                        child: SafeArea(
                            bottom: false,
                            child:
                                onBuildModalBody(context, model, child)))))));
  }

  void navPush(BuildContext context, CupertinoPageScaffold widget) {
    Navigator.of(context).push(MaterialPageRoute(builder: (context) => widget));
  }

  void navPop(BuildContext context) async {
    await Navigator.of(context).maybePop();
  }

  void popMe() {
    NavigationHelper.shared.pop();
  }
}
