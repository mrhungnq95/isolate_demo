import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/main_page.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_eshop_appbar.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

enum EMSScrollContainerStatus { idle, expand, collapse }

class MSScrollContainerAnimated extends StatefulWidget {
  ///
  /// Đánh dấu có phải màn hình chính không?
  ///
  /// Nếu [true] => sẽ có background màu xanh
  /// và [expandedHeight] default sẽ là 40
  ///
  /// Nếu [false] => background màu trắng và
  /// và [expandedHeight] default sẽ là 0
  ///
  /// Mặc định là [true]
  ///
  final bool isPrimary;

  ///
  /// True nếu tiêu đề title khi collapse nằm giữa Toolbar
  /// Mặc định là [true]
  ///
  final bool isCenterTitleCollapsed;

  ///
  /// Customize toolbar nếu cần thiết, nếu null sẽ chỉ hiển thị title của màn hình
  /// theo [titleCollapsed], nếu [titleCollapsed] null sẽ lấy [titleExpanded]
  ///
  final Widget customFloatingToolbar;

  ///
  /// Chiều cao của toolbar, mặc định sẽ là [kToolbarHeight], nếu tự Customize
  /// toolbar khi dùng [customFloatingToolbar] sẽ phải define lại thông tin này
  ///
  final double heightToolbar;

  ///
  /// Title của màn hình khi Scroll ở trạng thái offset = 0
  ///
  final String titleExpanded;

  ///
  /// Title của màn hình trên toolbar khi Scroll offset > 50
  ///
  final String titleCollapsed;

  ///
  /// View bên dưới toolbar khi Scrollview ở trạng thái offset = 0,
  /// có thể nói là Header của SrollView
  ///
  final Widget bottomExpanded;

  ///
  /// Button Trailing của Toolbar
  ///
  final List<Widget> actions;

  ///
  /// Content của màn hình
  ///
  final Widget body;

  final Widget bottomContainer;

  ///
  /// True nếu hiển thị Toolbar
  ///
  final bool isAlwaysShowToolbar;

  ///
  /// True nếu ẩn/hiển BottomNavigationBar khi scroll xuống dưới
  ///
  final bool reactiveNavigationBottomBar;

  ///
  /// Sự kiện khi tap vào Button
  ///
  final VoidCallback onLeadingTap;

  ///
  /// Sự kiện khi tap vào Button
  ///
  final VoidCallback onTrailingTap;

  ///
  /// True nếu hiển thị Toolbar Floating
  /// khi ở trạng thái [EMSScrollContainerStatus.collapse]
  ///
  final bool isToolbarFloating;

  ///
  /// Màu sắc của tiêu đề ở trạng thái [EMSScrollContainerStatus.expand]
  ///
  final Color titleExpandedColor;

  /// Chiều cao của phần mở rộng khi Toolbar ở trạng thái Expanded
  /// chiều cao này không được bao gồm StatusBar, Toolbar
  /// Nếu chiều cao này Null hoặc lớn hơn chiều cao Expanded mặc định
  /// thì sẽ được gán về giá trị mặc định
  final double expandedHeight;

  /// Callback trả về trạng thái của Scroll
  final Function(EMSScrollContainerStatus status) onScrollStatus;

  final Widget Function(BuildContext context) floatingButtonBuilder;

  const MSScrollContainerAnimated(
      {Key key,
      this.isPrimary = true,
      this.isCenterTitleCollapsed = true,
      this.customFloatingToolbar,
      @required this.body,
      @required this.titleExpanded,
      this.bottomContainer,
      this.titleCollapsed,
      this.bottomExpanded,
      this.expandedHeight,
      this.actions,
      this.isAlwaysShowToolbar = true,
      this.reactiveNavigationBottomBar = false,
      this.heightToolbar = kToolbarHeight,
      this.onLeadingTap,
      this.onTrailingTap,
      this.titleExpandedColor = Colors.white,
      this.isToolbarFloating = true,
      this.onScrollStatus,
      this.floatingButtonBuilder})
      : super(key: key);

  static _MSScrollContainerAnimatedState of(BuildContext context,
          {bool root = false}) =>
      root
          ? context
              .findRootAncestorStateOfType<_MSScrollContainerAnimatedState>()
          : context.findAncestorStateOfType<_MSScrollContainerAnimatedState>();

  @override
  _MSScrollContainerAnimatedState createState() =>
      _MSScrollContainerAnimatedState();
}

class _MSScrollContainerAnimatedState extends State<MSScrollContainerAnimated> {
  ScrollController _scrollController = ScrollController();
  double _heightToolbarDefault;
  double _heightToolbarFloating;
  double _expandedHeight;
  double _elevation = 0;
  bool _isToolbarFloatingVisible = false;
  dynamic scrollAnimateToRunning;

  @override
  void initState() {
    var tempExpandedHeight = widget.expandedHeight;

    if (tempExpandedHeight == null) {
      if (widget.isPrimary == true) {
        tempExpandedHeight = widget.bottomExpanded != null ? 40 : 0;
      } else {
        tempExpandedHeight = 0;
      }
    }

    final initExpandedHeight = _calExpandedHeightDefault();
    final expandedHeightCustomize =
        _calExpandedHeightManual(tempExpandedHeight);

    if (tempExpandedHeight > initExpandedHeight) {
      _expandedHeight = initExpandedHeight;
    } else {
      _expandedHeight = expandedHeightCustomize;
    }

    final topSafeHeight =
        widget.isAlwaysShowToolbar ? 0 : ScreenUtils.topSafeAreaHeight;
    _heightToolbarDefault =
        ((widget.heightToolbar ?? kToolbarHeight) + topSafeHeight);

    _heightToolbarFloating = widget.isAlwaysShowToolbar == true
        ? (_heightToolbarDefault + ScreenUtils.topSafeAreaHeight)
        : _heightToolbarDefault;

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _scrollController.addListener(_onScroll);
    });
  }

  _onScroll() {
    double offSetScrollSnapTo = _expandedHeight - kToolbarHeight;

    if (_scrollController.offset >= offSetScrollSnapTo ||
        _scrollController.offset >=
            _scrollController.position.maxScrollExtent) {
      if (!_isToolbarFloatingVisible) {
        setState(() {
          _isToolbarFloatingVisible = true;
          _elevation = 1;

          widget.onScrollStatus?.call(EMSScrollContainerStatus.collapse);
        });
      }
    } else {
      if ((_scrollController.offset <= 0 ||
              _scrollController.offset <= _expandedHeight) &&
          _isToolbarFloatingVisible == true) {
        setState(() {
          _isToolbarFloatingVisible = false;
          _elevation = 0;
        });

        widget.onScrollStatus?.call(EMSScrollContainerStatus.expand);
      }
    }
  }

  @override
  void dispose() {
    _scrollController?.dispose();
    super.dispose();
  }

  ///
  /// Handle sự kiện khi ScrollView thay đổi
  ///
  bool _OnNotificationChanged(ScrollNotification scrollInfo) {
    if (widget.reactiveNavigationBottomBar) {
      final mainPageViewModel = context.read<MainPageViewModel>();
      mainPageViewModel?.scrollSubject?.add(ScrollDataObs(
          offset: _scrollController.offset,
          scrollPosition: _scrollController.position));
    }

    if (_scrollController.position.userScrollDirection ==
        ScrollDirection.idle) {
      if (scrollInfo is UserScrollNotification) {
        Future.delayed(Duration.zero, () async {
          if (scrollAnimateToRunning != null) {
            await scrollAnimateToRunning;
          }

          double offSetScrollSnapTo = _expandedHeight - kToolbarHeight;

          print(''' Currrent offset ${_scrollController.offset}
          + Snap to $offSetScrollSnapTo
          + Snap maxScrollExtent ${_scrollController.position.maxScrollExtent}
          ''');

          if (_scrollController.offset >= 5 &&
              _scrollController.offset < offSetScrollSnapTo &&
              _scrollController.position.userScrollDirection ==
                  ScrollDirection.idle) {
            if (offSetScrollSnapTo >
                _scrollController.position.maxScrollExtent) {
              offSetScrollSnapTo = _scrollController.position.maxScrollExtent;
            }
            scrollAnimateToRunning = _scrollController.animateTo(
              //widget.heightToolbar - 10,
              offSetScrollSnapTo,
              duration: Duration(milliseconds: 200),
              curve: Curves.linear,
            );

            widget.onScrollStatus?.call(EMSScrollContainerStatus.collapse);
          }

          widget.onScrollStatus?.call(EMSScrollContainerStatus.idle);
        });
        return false;
      }
    }
    return true;
  }

  ///
  /// Tính chiều cao của phần Header khi Expanded (bao gồm:
  /// Status bar, AppBar, Bottom AppBar)
  /// Xem chi tiết tại GuideStyle
  /// [expandedHeight] chiều cao của phần mở rộng
  ///
  ///
  double _calExpandedHeightManual(double expandedHeight) {
    /// Status bar + Toolbar (bao gồm cả Big title) + Bottom view
    /// + 16 (view bên dưới cùng expandedView: top left, top right để fake header
    /// của phần nội dung)

    double radiusViewHeight =
        widget.bottomExpanded == null ? 0 : 16; //widget.isPrimary ? 16 : 0;
    return ScreenUtils.topSafeAreaHeight +
        56 + //kToolbarHeight +
        expandedHeight +
        24 + //Padding bottom
        radiusViewHeight;
  }

  ///
  /// Chiều cao của phần Header khi Expanded (bao gồm:
  /// Status bar, AppBar, Bottom AppBar)
  /// Xem chi tiết tại GuideStyle
  ///
  double _calExpandedHeightDefault() {
    double radiusViewHeight = 16; //widget.isPrimary ? 16 : 0;

    if (widget.bottomExpanded == null) {
      radiusViewHeight = 0;

      /// Status bar + Toolbar (bao gồm cả Big title) + Bottom view
      /// + 16 (view bên dưới cùng expandedView: top left, top right để fake header
      /// của phần nội dung)
      return ScreenUtils.topSafeAreaHeight + 56.0 + radiusViewHeight;
    }
    //return widget.bottomExpandedHeight;

    /// Status bar + Toolbar (bao gồm cả Big title) + Bottom view
    /// + padding bottom + 12 (padding giữa 40 và 24)
    /// + 16 (view bên dưới cùng expandedView: top left, top right để fake header
    /// của phần nội dung)
    return ScreenUtils.topSafeAreaHeight +
        56.0 +
        40.0 +
        24 +
        12 +
        radiusViewHeight;
  }

  ///
  /// Chiều cao của Toolbar dạng floating khi collapse
  ///
  double _getFloatingToolbarHeight() {
    if (widget.isToolbarFloating == true) {
      return _isToolbarFloatingVisible ? _heightToolbarFloating : 0.0;
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    //print(topPosition);
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        floatingActionButton: widget.floatingButtonBuilder != null
            ? widget.floatingButtonBuilder(context)
            : null,
        backgroundColor: Colors.transparent,
        body: Stack(
          children: <Widget>[
            Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: NotificationListener(
                      onNotification: (ScrollNotification scrollInfo) =>
                          _OnNotificationChanged(scrollInfo),
                      child: NestedScrollView(
                        physics: ClampingScrollPhysics(),
                        controller: _scrollController,
                        floatHeaderSlivers: false,
                        headerSliverBuilder:
                            (BuildContext context, bool innerBoxIsScrolled) {
                          return [
                            _AppBarView(
                              widget: widget,
                              expandedHeight: _expandedHeight,
                              elevation: _elevation,
                            )
                          ];
                        },
                        body: widget.body,
                      )),
                ),
                widget.bottomContainer ?? kSpaceShrinkBox
              ],
            ),
            Positioned(
                //top: topPosition,
                top: 0,
                left: 0,
                right: 0,
                //left: widget.isAlwaysShowToolbar ? kToolbarHeight : 0,
                //right: widget.isAlwaysShowToolbar ? kToolbarHeight : 0,
                child: AnimatedContainer(
                  color: Colors.white,
                  alignment: Alignment.center,
                  duration: Duration(milliseconds: 0),
                  height: _getFloatingToolbarHeight(),
                  child: Wrap(
                    children: [
                      Material(
                        //elevation: widget.isAlwaysShowToolbar ? 0 : 1,
                        elevation: 1,
                        color: Colors.white,
                        //color: widget.isAlwaysShowToolbar
                        //    ? Colors.transparent
                        //    : Colors.white,
                        child: Container(
                            height: _isToolbarFloatingVisible
                                ? _heightToolbarFloating
                                : 0.0,
                            //padding: EdgeInsets.only(
                            //    top: ScreenUtils.topSafeAreaHeight),
                            alignment: Alignment.center,
                            child: widget.customFloatingToolbar ??
                                MSEShopAppBar(
                                    elevation: 0,
                                    isCenterTitle:
                                        widget.isCenterTitleCollapsed ?? true,
                                    automaticallyImplyLeading:
                                        widget.onLeadingTap == null,
                                    automaticallyImplyTrailing:
                                        widget.onTrailingTap == null,
                                    onLeadingTap: widget.onLeadingTap,
                                    onTrailingTap: widget.onTrailingTap,
                                    actions: _renderMappingActionTrailing(
                                        widget.actions),
                                    title: widget.titleCollapsed ??
                                        widget.titleExpanded)),
                      )
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }

  ///
  /// Render các action button bổ sung thêm Padding
  ///
  List<Widget> _renderMappingActionTrailing(List<Widget> actions) {
    return actions?.map((e) {
      if (e is MSCircleButton) {
        return Padding(
          padding: const EdgeInsets.only(left: kHorizontalSpaceLarge),
          child: MSCircleButton(
              elevation: 5,
              color: null,
              size: 40,
              imageAsset: e.imageAsset,
              imageAssetColor: AppColor.indigo900,
              onTap: e.onTap),
        );
      }
      return e;
    })?.toList();
  }
}

class _AppBarView extends StatelessWidget {
  final MSScrollContainerAnimated widget;
  final double expandedHeight;
  final double elevation;

  const _AppBarView(
      {Key key,
      @required this.widget,
      this.elevation = 0,
      @required this.expandedHeight})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    if (widget.isAlwaysShowToolbar == true) {
      return MSEShopSliverAppBar(
        pinned: true,
        floating: false,
        stretch: true,
        title: "",
        automaticallyImplyLeading: widget.onLeadingTap == null,
        automaticallyImplyTrailing: widget.onTrailingTap == null,
        elevation: elevation,
        onLeadingTap: widget.onLeadingTap,
        onTrailingTap: widget.onTrailingTap,
        iconLeadingColor:
            widget.isPrimary == true ? Colors.white : Colors.black,
        actions: _renderMappingActionTrailing(widget.actions),
        expandedHeight: expandedHeight,
        flexibleSpace: FlexibleSpaceBar(
            collapseMode: CollapseMode.parallax,
            titlePadding: EdgeInsets.zero,
            stretchModes: [
              //StretchMode.blurBackground,
              StretchMode.fadeTitle,
              StretchMode.zoomBackground,
            ],
            background: _AppBarViewExpanded(
              widget: widget,
              expandedHeight: expandedHeight,
            )),
      );
    } else {
      return _AppBarViewExpanded(
        widget: widget,
        expandedHeight: expandedHeight,
      );
    }
  }

  ///
  /// Render các action button bổ sung thêm Padding
  ///
  List<Widget> _renderMappingActionTrailing(List<Widget> actions) {
    return actions
        ?.map((e) => Padding(
              padding: const EdgeInsets.only(right: kHorizontalSpaceLarge),
              child: e,
            ))
        ?.toList();
  }
}

class _AppBarViewExpanded extends StatelessWidget
    implements PreferredSizeWidget {
  final MSScrollContainerAnimated widget;
  final double expandedHeight;

  const _AppBarViewExpanded({
    Key key,
    @required this.widget,
    @required this.expandedHeight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: widget.isPrimary == true ? Colors.transparent : Colors.white,
        image: widget.isPrimary == true
            ? DecorationImage(
                image: AssetImage(AppResources.bgHeaderPage),
                fit: BoxFit.fill,
              )
            : null,
      ),
      //color: Colors.transparent,
      width: ScreenUtils.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(
                bottom: kVerticalSpaceHuge,
                left: kHorizontalSpaceLarge,
                right: kHorizontalSpaceLarge,
                top: widget.isAlwaysShowToolbar == true
                    ? 0
                    : ScreenUtils.topSafeAreaHeight
                //top: ScreenUtils.topSafeAreaHeight,
                ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                widget.titleExpanded != null
                    ? Text(
                        widget.titleExpanded ?? "",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.headline2.copyWith(
                            color: widget.isPrimary == true
                                ? widget.titleExpandedColor
                                : AppColor.textColor),
                      )
                    : kSpaceShrinkBox,
                SizedBox(height: widget.bottomExpanded != null ? 12 : 0),
                widget.bottomExpanded ?? kSpaceShrinkBox,
              ],
            ),
          ),
          Container(
              height: 10,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12)))),
        ],
      ),
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(expandedHeight); // Size.fromHeight(87);
}
