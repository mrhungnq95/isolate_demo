import 'dart:async';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:flutter_state_notifier/flutter_state_notifier.dart';
import 'package:stacked/stacked.dart';
import 'package:state_notifier/state_notifier.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

enum MSSearchEvent { open, close }

class MSSearchableNotifier<T> extends MSBaseViewModel
    with MSStateMixin<List<T>> {
  MSSearchableNotifier() {
    changeState([], status: ViewStatus.success());
  }

  ///
  /// update state là đang search
  ///
  void startSearch() {
    changeState([], status: ViewStatus.loading());
  }

  ///
  /// update state như lúc ban đầu
  ///
  void resetSearch() {
    changeState([], status: ViewStatus.success());
  }

  ///
  /// Cập nhật data
  ///
  void updateData(List<T> data) {
    ViewStatus viewStatus;

    if (data != null && data.isNotEmpty) {
      viewStatus = ViewStatus.success();
    } else if (data.isEmpty) {
      viewStatus = ViewStatus.empty();
    }

    changeState(data, status: viewStatus);
  }
}

class MSSearchableController {
  StreamController<MSSearchEvent> _event = StreamController();
  StreamController<MSSearchEvent> get event => _event;

  ///
  /// set State mở search
  ///
  void openSearch() {
    print("openSearch");
    _event.add(MSSearchEvent.open);
  }

  ///
  /// set State đóng search
  /// Đóng search
  ///
  void closeSearch() {
    _event.add(MSSearchEvent.close);
  }

  ///
  /// dispose resource
  ///
  void dispose() {
    _event?.close();
  }
}

class MSBaseSearchableWidget<T> extends StatefulWidget {
  final MSSearchableController controller;
  final Widget Function(int index, T item) itemResultBuilder;
  final Future<List<T>> Function(String item) searchTask;

  final Widget child;
  final Widget emptyData;
  final String searchHint;

  const MSBaseSearchableWidget(
      {Key key,
      @required this.controller,
      @required this.child,
      @required this.itemResultBuilder,
      @required this.searchTask,
      this.emptyData,
      this.searchHint})
      : super(key: key);

  @override
  _MSBaseSearchableWidgetState<T> createState() =>
      _MSBaseSearchableWidgetState<T>();
}

class _MSBaseSearchableWidgetState<T> extends State<MSBaseSearchableWidget<T>> {
  GlobalKey _globalKeyParent = GlobalKey();
  OverlayEntry _overlayEntry;
  FocusNode _focusNode = FocusNode();
  TextEditingController _editingController = TextEditingController();
  bool _isVisible = false;
  int indexStack = 0;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      widget?.controller?.event?.stream?.listen((event) {
        if (event == MSSearchEvent.open) {
          //_showOverlay();
          _showSearch();
        } else if (event == MSSearchEvent.close) {
          //_hideOverlay(true);
          _closeSearch();
        }
      });
    });
  }

  @override
  void dispose() {
    /// widget?.controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: indexStack,
        children: [
          widget.child,
          _overlayBody(),
        ],
      ),
    );

    // return Container(
    //   key: _globalKeyParent,
    //   child: widget.body,
    // );
  }

  ///
  /// Hiện search
  ///
  void _showSearch() {
    setState(() {
      indexStack = 1;

      _isVisible = true;

      Future.delayed(
          Duration(milliseconds: 500), () => _focusNode?.requestFocus());
    });
  }

  ///
  /// Đóng search
  ///
  void _closeSearch() {
    setState(() {
      indexStack = 0;

      WidgetsBinding.instance.focusManager.primaryFocus?.unfocus();

      _editingController?.clear();
      _isVisible = false;
    });
  }

  ///
  /// show overlay
  ///
  void _showOverlay() {
    if (_overlayEntry != null) {
      _overlayEntry.remove();
      _overlayEntry = null;
    }

    _overlayEntry = _overlay();
    Overlay.of(context).insert(_overlayEntry);
    _isVisible = true;

    Future.delayed(
        Duration(milliseconds: 500), () => _focusNode?.requestFocus());
  }

  ///
  /// hide overlay
  ///
  void _hideOverlay(removeFocus) {
    _overlayEntry?.remove();
    _overlayEntry = null;

    if (removeFocus) {
      WidgetsBinding.instance.focusManager.primaryFocus?.unfocus();
    }
    _editingController?.clear();
    _isVisible = false;
  }

  ///
  /// Xử lý search khi gõ
  /// [context] context của widget cha
  /// [textSearch] giá trị search
  ///
  void _onTypingSearchHanldler(BuildContext context, String textSearch) async {
    final realValue = _editingController?.text;

    final model = context.read<MSSearchableNotifier<T>>();
    if ((realValue == null || realValue.isEmpty)) {
      model.resetSearch();
    } else {
      model.startSearch();
      final dataList =
          widget?.searchTask != null ? await widget.searchTask(textSearch) : [];
      model.updateData(dataList);
    }
  }

  OverlayEntry _overlay() => OverlayEntry(builder: (context) {
        if (_globalKeyParent.currentContext != null) {
          return _overlayBody();
        } else {
          return kSpaceShrinkBox;
        }
      });

  Widget _overlayBody() {
    return ViewModelBuilder.reactive(
        builder: (context, model, child) {
          return Container(
            color: AppColor.white,
            child: SafeArea(
              bottom: false,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: kHorizontalSpaceLarge),
                    child: Row(
                      children: [
                        Expanded(
                          child: SearchBox(
                            controller: _editingController,
                            nodeFocus: _focusNode,
                            borderColor: AppColor.grey200,
                            backgroundColor: AppColor.grey200,
                            height: 40,
                            textInputAction: TextInputAction.done,
                            placeholder: widget.searchHint ?? "",
                            onSearch: (textSearch) =>
                                _onTypingSearchHanldler(context, textSearch),
                          ),
                        ),
                        TextButton(
                            onPressed: () {
                              //_hideOverlay(true);
                              widget.controller?.closeSearch();

                              context
                                  .read<MSSearchableNotifier<T>>()
                                  .resetSearch();
                            },
                            child: Text("Huỷ",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText2
                                    .copyWith(
                                      color: AppColor.indigo900,
                                    )))
                      ],
                    ),
                  ),
                  Divider(
                    thickness: 2,
                    color: AppColor.grey300,
                  ),
                  _ContentView<T>(widget: widget)
                ],
              ),
            ),
          );
        },
        viewModelBuilder: () => MSSearchableNotifier<T>());
  }
}

class _ContentView<T> extends ViewModelWidget<MSSearchableNotifier<T>> {
  final MSBaseSearchableWidget<T> widget;

  const _ContentView({Key key, this.widget}) : super(key: key);

  @override
  Widget build(BuildContext context, MSSearchableNotifier<T> model) {
    return Expanded(child: Builder(builder: (c) {
      return model.obs(
          widget: (state) {
            if (state.isEmpty) {
              return kSpaceShrinkBox;
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(kVerticalSpaceLarge),
                  child: Text(
                    "Kết quả tìm kiếm",
                    style: Theme.of(context).textTheme.bodyText2,
                  ),
                ),
                Expanded(
                    child: ListView.builder(
                  padding: const EdgeInsets.symmetric(
                      horizontal: kHorizontalSpaceLarge),
                  itemBuilder: (context, index) {
                    final item = state[index];
                    return widget?.itemResultBuilder(index, item) ??
                        kSpaceShrinkBox;
                  },
                  itemCount: state?.length ?? 0,
                ))
              ],
            );
          },
          onError: (_) => kSpaceShrinkBox,
          onEmpty: widget.emptyData ?? _EmptyDataView());
    }));
  }
}

class _EmptyDataView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Không có kết quả",
          style: Theme.of(context)
              .textTheme
              .headline1
              .copyWith(color: AppColor.textCaptionColor)),
    );
  }
}
