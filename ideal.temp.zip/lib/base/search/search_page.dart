import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tuple/tuple.dart';

// class SearchPage<T extends MSBaseViewModel> extends StatefulWidget {
//   @override
//   _SearchPageState createState() => _SearchPageState();
// }

// class _SearchPageState<T> extends State<SearchPage> {
//   @override
//   Widget build(BuildContext context) {
//     return MSBaseCupertinoWidgetBuilderV2<T>(
//         viewModelBuilder: (context) =>
//             LocatorService.shared.get<T>(),
//         reactive: true,
//         onViewModelReady: (model) {
//           /// TODO - VNLONG Thêm đoạn check quyền hiển thị ds hóa đơn
//         },
//         backgroundColor: Colors.white,
//         brightnessColor: Brightness.light,
//         statusBarColor: Colors.transparent,
//         builder: (context, model, child) {
//           return MSScrollContainerAnimated(
//             reactiveNavigationBottomBar: true,
//             isAlwaysShowToolbar: true,
//             titleExpanded: "Search",
//             bottomExpanded: _BottomAppBar(),
//             slivers: [],
//           );
//         });
//   }
// }


// class _BottomAppBar extends StatelessWidget with PreferredSizeWidget {
//   @override
//   Size get preferredSize => const Size.fromHeight(98.0);

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: kVerticalSpaceLarge),
//       child: Column(
//         children: [
//           SearchBox(
//             height: 40,
//             placeholder: 'Nhập tên khách hàng, SĐT, số hóa đơn...',
//             onSearch: (value) {
             
//             },
//           ),
//           kVerticalSpaceLargeBox,
//         ],
//       ),
//     );
//   }
// }
