//
// Created by nqhung on 10/11/2020.
//

import 'dart:convert';

import 'package:MShopManager/model/customer/list_customer_debt_filter_setting.dart';
import 'package:MShopManager/model/invoice/list_invoice_filter_setting.dart';
import 'package:MShopManager/model/customer/customer_list_filter_setting.dart';
import 'package:MShopManager/model/customer_transaction_history/customer_transaction_history_filter_setting.dart';
import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/model/item_receipt_note_filter_setting.dart';
import 'package:MShopManager/model/inventory_item/list_inventory_item_filter_setting.dart';
import 'package:MShopManager/model/location_client.dart';
import 'package:MShopManager/model/overview/overview_chain_filter_setting.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/model/revenue/revenue_filter_setting.dart';
import 'package:MShopManager/model/vendor_filter_setting.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_param.dart';
import 'package:MShopManager/utils/shared_pref_utils.dart';

class LocalStorageKey {
  LocalStorageKey._internal();

  static const String CACHE_SUB_DOMAIN = "PREF_CACHE_SUB_DOMAIN";

  /// AUTHENTICATE =========================================================
  static const String PREF_AUTH_KEY_IS_AUTHORIZATION =
      "PREF_AUTH_KEY_IS_AUTHORIZATION";
  static const String PREF_KEY_ENVIRONMENT = "PREF_KEY_ENVIRONMENT";
  static const String PREF_AUTH_KEY_BRANCH_CODE = "PREF_AUTH_KEY_BRANCH_CODE";
  static const String PREF_AUTH_KEY_LOGIN_INFO = "PREF_AUTH_KEY_LOGIN_INFO";
  static const String PREF_AUTH_KEY_TOKEN = "PREF_AUTH_KEY_TOKEN";
  static const String PREF_AUTH_KEY_REFRESH_TOKEN =
      "PREF_AUTH_KEY_REFRESH_TOKEN";

  ///
  /// License
  ///
  static const String PREF_LICENSE_INFO = "PREF_LICENSE_INFO";

  ///
  /// DS Role Permission
  ///
  static const String PREF_USER_PERMISSION_LIST = "PREF_USER_PERMISSION_LIST";

  ///
  /// DS Role Permission
  ///
  static const String PREF_DBOPTION_LIST = "PREF_DBOPTION_LIST";

  ///
  /// Thiết lập Filter Tổng quan
  ///
  static const String PREF_FILTER_SETTINGS_OVERVIEW =
      "PREF_FILTER_SETTINGS_OVERVIEW";

  ///
  /// Thiết lập Filter Doanh thu
  ///
  static const String PREF_FILTER_SETTINGS_REVENUE =
      "PREF_FILTER_SETTINGS_REVENUE";

  ///
  /// Thiết lập Filter Danh sách hàng hóa
  ///
  static const String PREF_FILTER_SETTINGS_INVENTORY_ITEM =
      "PREF_FILTER_SETTINGS_INVENTORY_ITEM";

  /// Thiết lập Filter Khách hàng
  ///
  static const String PREF_FILTER_SETTINGS_CUSTOMER_LIST =
      "PREF_FILTER_SETTINGS_CUSTOMER_LIST";

  ///
  /// Thiết lập Filter Khách hàng
  ///
  static const String PREF_FILTER_SETTINGS_CUSTOMER_TRANSACTION_HISTORY =
      "PREF_FILTER_SETTINGS_CUSTOMER_TRANSACTION_HISTORY";

  ///
  /// Thiết lập danh sách hóa đơn
  ///
  static const String PREF_FILTER_SETTINGS_INVOICE =
      "PREF_FILTER_SETTINGS_INVOICE";

    ///
  /// Thiết lập danh sách công nợ
  ///
  static const String PREF_FILTER_SETTINGS_DEBT_CUSTOMER =
      "PREF_FILTER_SETTINGS_DEBT_CUSTOMER";

  ///
  /// DS Branch mà User đang đăng nhập có quyền thao tác
  ///
  static const String PREF_BRANCH_GRANT_USER_LIST =
      "PREF_BRANCH_GRANT_USER_LIST";

  ///
  /// DS Branch mà User đang đăng nhập có quyền thao tác,
  /// bao gồm cả Kho tổng, DS cửa hàng đã được sort theo A-Z
  ///
  static const String PREF_ALL_BRANCH_GRANT_USER_LIST =
      "PREF_ALL_BRANCH_GRANT_USER_LIST";

  ///
  /// DS Thành phố - Quận huyện đã merge vào với nhau
  ///
  static const String PREF_DISTRICT_MERGE_LIST = "PREF_DISTRICT_MERGE_LIST";

  ///
  /// DS Xã phường
  ///
  static const String PREF_WARDS_LIST = "PREF_WARDS_LIST";

  ///
  /// Filter danh sách nhà cung cấp
  ///
  static const String PREF_FILTER_SETTINGS_LIST_VENDOR =
      "PREF_FILTER_SETTINGS_LIST_VENDOR";

  ///
  /// Filter danh sách phiếu nhập hàng
  ///
  static const String PREF_FILTER_SETTINGS_LIST_ITEM_RECEIPT_NOTE =
      "PREF_FILTER_SETTINGS_LIST_ITEM_RECEIPT_NOTE";

  ///
  /// Filter báo cáo Tổng quan cho chuỗi
  ///
  static const String PREF_FILTER_SETTINGS_OVERVIEW_CHAIN =
      "PREF_FILTER_SETTINGS_OVERVIEW_CHAIN";

  ///
  /// Thiết lập User: Phím tắt
  ///
  static const String PREF_USER_SETTINGS_QUICK_ACTION =
      "PREF_USER_SETTINGS_QUICK_ACTION";
}

class LocalStorage {
  static SharedPrefUtil _sharedPrefUtil;

  static LocalStorage _instance;
  LocalStorage._internal() {
    print("LocalStorage init!");
  }

  static LocalStorage get shared {
    if (_instance == null) {
      throw UnimplementedError('LocalStorage.initialize() has not been call.');
    }
    return _instance;
  }

  static Future<LocalStorage> initialize() async {
    if (_instance == null) {
      _instance = LocalStorage._internal();
    }
    if (_sharedPrefUtil == null) {
      _sharedPrefUtil = await SharedPrefUtil.shared;
    }
    return Future.value(_instance);
  }

  //===============================================================

  /// Lấy đuôi subDomain trong local
  ///
  /// Created by nqhung on 10/11/2020
  String getSubDomain() {
    return _sharedPrefUtil.getString(LocalStorageKey.CACHE_SUB_DOMAIN);
  }

  /// Cất đuôi subDomain trong local
  ///
  /// Created by nqhung on 10/11/2020
  void setSubDomain(String value) {
    _sharedPrefUtil.putString(LocalStorageKey.CACHE_SUB_DOMAIN, value);
  }

  void setEnvironment(String value) {
    _sharedPrefUtil.putString(LocalStorageKey.PREF_KEY_ENVIRONMENT, value);
  }

  String getEnvironment() {
    return _sharedPrefUtil.getString(LocalStorageKey.PREF_KEY_ENVIRONMENT);
  }

  void setBranchCode(String value) {
    _sharedPrefUtil.putString(LocalStorageKey.PREF_AUTH_KEY_BRANCH_CODE, value);
  }

  String getBranchCode() {
    return _sharedPrefUtil.getString(LocalStorageKey.PREF_AUTH_KEY_BRANCH_CODE);
  }

  ///
  /// Set DS DBOption vào cache
  ///
  void setDBOptionList(List<DBOption> dbOptionList) {
    if (dbOptionList != null && dbOptionList.isNotEmpty) {
      final json = jsonEncode(dbOptionList.map((e) => e.toJson()).toList());
      _sharedPrefUtil.putString(LocalStorageKey.PREF_DBOPTION_LIST, json);
    }
  }

  ///
  /// Lấy DS DBOption hiện tại của nhà hàng
  ///
  List<DBOption> getDBOptionList() {
    final jsonList =
        _sharedPrefUtil.getString(LocalStorageKey.PREF_DBOPTION_LIST);

    if (jsonList != null) {
      return List<DBOption>.from(
          jsonDecode(jsonList).map((json) => DBOption.fromJson(json)));
    }
    return null;
  }

  ///
  /// Lấy filter Tổng quan từ cache
  ///
  dynamic getOverViewFilterSettings() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_OVERVIEW);

    if (json != null) {
      return OverViewFilterSettings.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter Tổng quan xuống cache
  ///
  void saveOverViewFilterSettings(OverViewFilterSettings param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_OVERVIEW, param.toJson());
  }

  ///
  /// Lấy filter báo cáo Doanh thu từ cache
  ///
  dynamic getRevenueFilterSettings() {
    final json =
        _sharedPrefUtil.getString(LocalStorageKey.PREF_FILTER_SETTINGS_REVENUE);

    if (json != null) {
      return RevenueFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter báo cáo Doanh thu xuống cache
  ///
  void saveRevenueFilterSettings(RevenueFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_REVENUE, param.toJson());
  }

  ///
  /// Lấy filter danh sách nhà cung cấp
  ///
  dynamic getListVendorFilterSettings() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_LIST_VENDOR);

    if (json != null) {
      return VendorFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter danh sách nhà cung cấp
  ///
  void saveListVendorFilterSettings(VendorFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_LIST_VENDOR, param.toJson());
  }

  ///
  /// Cất filter danh sách phiếu nhập hàng
  ///
  void saveItemReceiptNoteFilterSettings(ItemReceiptNoteFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_LIST_ITEM_RECEIPT_NOTE,
        param.toJson());
  }

  ///
  /// Lấy filter danh sách phiếu nhập hàng
  ///
  dynamic getItemReceiptNoteFilterSettings() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_LIST_ITEM_RECEIPT_NOTE);
    if (json != null) {
      return ItemReceiptNoteFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// lưu filter báo cáo Ds hàng hóa
  ///
  void saveListInventoryItemFilterSetting(
      ListInventoryItemFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_INVENTORY_ITEM, param.toJson());
  }

  ///
  /// Lấy filter Ds hàng hóa từ cache
  ///
  dynamic getListInventoryItemFilterSetting() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_INVENTORY_ITEM);

    if (json != null) {
      return ListInventoryItemFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// lưu filter báo cáo Ds Hóa đơn
  ///
  void saveListInvoiceFilterSetting(
      ListInvoiceFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_INVOICE, param.toJson());
  }

  ///
  /// Lấy filter Ds hóa đơn từ cache
  ///
  dynamic getListInvoiceFilterSetting() {
    final json =
        _sharedPrefUtil.getString(LocalStorageKey.PREF_FILTER_SETTINGS_INVOICE);

    if (json != null) {
      return ListInvoiceFilterSetting.fromJson(json);
    }
    return null;
  }


  ///
  /// lưu filter báo cáo Ds Công nợ
  ///
  void saveListDebtCustomerFilterSetting(
      ListCustomerDebtFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_DEBT_CUSTOMER, param.toJson());
  }

  ///
  /// Lấy filter Ds công nợ từ cache
  ///
  dynamic getListDebtCustomerFilterSetting() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_DEBT_CUSTOMER);

    if (json != null) {
      return ListCustomerDebtFilterSetting.fromJson(json);
    }
    return null;
  }
  

  ///
  /// Lấy filter thiết lập Khách hàng từ cache
  ///
  dynamic getCustomerListFilterSettings() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_CUSTOMER_LIST);

    if (json != null) {
      return CustomerListFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter theo Khách hàng
  ///
  void saveCustomerListFilterSettings(CustomerListFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_CUSTOMER_LIST, param.toJson());
  }

  ///
  /// Lấy filter thiết lập Lịch sử giao dịch của KH
  ///
  dynamic getCustomerTransactionHistoryFilterSettings() {
    final json = _sharedPrefUtil.getString(
        LocalStorageKey.PREF_FILTER_SETTINGS_CUSTOMER_TRANSACTION_HISTORY);

    if (json != null) {
      return CustomerTransactionHistoryFilterSetting.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter theo Khách hàng
  ///
  void saveCustomerTransactionHistoryFilterSettings(
      CustomerTransactionHistoryFilterSetting param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_CUSTOMER_TRANSACTION_HISTORY,
        param.toJson());
  }

  ///
  /// Cất DS dữ liệu Thành phố - Quận huyện
  ///
  void saveDistrictMergeList(List<LocationClientMerge> districtList) {
    if (districtList != null && districtList.isNotEmpty) {
      final json = jsonEncode(districtList.map((e) => e.toJson()).toList());
      _sharedPrefUtil.putString(LocalStorageKey.PREF_DISTRICT_MERGE_LIST, json);
    }
  }

  ///
  /// Lấy DS TỈnh thành phố - Quận huyện
  ///
  List<LocationClientMerge> getDistrictMergeList() {
    final jsonList =
        _sharedPrefUtil.getString(LocalStorageKey.PREF_DISTRICT_MERGE_LIST);

    if (jsonList != null) {
      return List<LocationClientMerge>.from(jsonDecode(jsonList)
          .map<LocationClientMerge>(
              (json) => LocationClientMerge.fromJson(json)));
    }
    return null;
  }

  ///
  /// Cất DS dữ liệu Xã phường
  ///
  void saveWardLocationList(List<LocationClient> wardList) {
    if (wardList != null && wardList.isNotEmpty) {
      final json = jsonEncode(wardList.map((e) => e.toJson()).toList());
      _sharedPrefUtil.putString(LocalStorageKey.PREF_WARDS_LIST, json);
    }
  }

  ///
  /// Lấy DS Xã phường
  ///
  List<LocationClient> getWardLocationList() {
    final jsonList = _sharedPrefUtil.getString(LocalStorageKey.PREF_WARDS_LIST);

    if (jsonList != null) {
      return List<LocationClient>.from(jsonDecode(jsonList)
          .map<LocationClient>((json) => LocationClient.fromJson(json)));
    }
    return null;
  }

  ///
  /// Lấy filter Tổng quan chuỗi từ cache
  ///
  dynamic getOverViewChainFilterSettings() {
    final json = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_FILTER_SETTINGS_OVERVIEW_CHAIN);

    if (json != null) {
      return OverViewChainFilterSettings.fromJson(json);
    }
    return null;
  }

  ///
  /// Cất filter Tổng quan của chuỗi xuống cache
  ///
  void saveOverViewChainFilterSettings(OverViewChainFilterSettings param) {
    _sharedPrefUtil.putString(
        LocalStorageKey.PREF_FILTER_SETTINGS_OVERVIEW_CHAIN, param.toJson());
  }

  ///
  /// Lưu lối tắt các chức năng người dùng đã chọn
  ///
  void saveQuickActionItemListByUser(String actionList) {
    if (actionList != null && actionList.isNotEmpty) {
      //final json = jsonEncode(actionList.map((e) => e.toJson()).toList());
      _sharedPrefUtil.putString(
          LocalStorageKey.PREF_USER_SETTINGS_QUICK_ACTION, actionList);
    }
  }

  ///
  /// Lấy DS lối tắt các chức năng người dùng đã chọn
  ///
  String getQuickActionItemListByUser() {
    String jsonList = _sharedPrefUtil
        .getString(LocalStorageKey.PREF_USER_SETTINGS_QUICK_ACTION);
    // if (jsonList != null && jsonList.isNotEmpty) {
    //   return List<QuickActionItem>.from(jsonDecode(jsonList)
    //       .map<QuickActionItem>((x) => QuickActionItem.fromJson(x))
    //       .toList());
    // }
    return jsonList;
  }
}
