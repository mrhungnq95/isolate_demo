//
// Created by nqhung on 11/11/2020.
//

import 'package:MShopManager/base/service/base_dio.dart';
import 'package:MShopManager/base/service/interceptor/common_interceptor.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/enums/enum_api_type.dart';
import 'package:dio/dio.dart';

class DashboardAPI extends BaseDio {
  @override
  List<Interceptor> provideInterceptor() {
    return [CommonInterceptor()];
  }

  @override
  Map<String, String> getHeader() {
    return null;
  }

  @override
  Map<String, String> getQueryParameters() {
    return null;
  }

  @override
  String getServiceUrl() {
    return UrlHelper.shared.getUrl(apiType: EAPIType.DASH_BOARD);
  }
}
