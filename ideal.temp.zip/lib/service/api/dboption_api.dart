import 'package:MShopManager/base/service/base_dio.dart';
import 'package:MShopManager/base/service/interceptor/common_interceptor.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/enums/enum_api_type.dart';
import 'package:dio/dio.dart';

class DBOptionAPI extends BaseDio {
  @override
  int getConnectTimeOut() {
    return 60000;
  }

  List<Interceptor> provideInterceptor() {
    return [CommonInterceptor()];
  }

  @override
  Map<String, String> getHeader() {
    return null;
  }

  @override
  Map<String, String> getQueryParameters() {
    return null;
  }

  @override
  String getServiceUrl() {
    return UrlHelper.shared.getUrl(apiType: EAPIType.DBOPTION);
  }
}
