import 'package:MShopManager/base/service/base_dio.dart';
import 'package:MShopManager/base/service/interceptor/common_interceptor.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/enums/enum_api_type.dart';
import 'package:dio/dio.dart';

/// API liên quan đến đơn vị tính của hàng hóa
class UnitAPI extends BaseDio {

    @override
  List<Interceptor> provideInterceptor() {
    return [CommonInterceptor()];
  }

  @override
  Map<String, String> getHeader() {
    return null;
  }

  @override
  Map<String, String> getQueryParameters() {
    return null;
  }

  @override
  String getServiceUrl() {
    return UrlHelper.shared.getUrl(apiType: EAPIType.UNIT);
  }
  
}