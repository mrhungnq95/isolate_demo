//
// Created by nqhung on 09/11/2020.
//

import 'package:MShopManager/base/service/base_dio.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/enums/enum_api_type.dart';

class AuthenticateAPI extends BaseDio {
  AuthenticateAPI() : super();

  @override
  Map<String, String> getQueryParameters() {
    return null;
  }

  @override
  Map<String, String> getHeader() {
    return null;
  }

  @override
  bool useRefreshTokenInterceptor() {
    return false;
  }

  @override
  int getConnectTimeOut() {
    return 30000;
  }

  @override
  int getReceiverTimeOut() {
    return 30000;
  }

  @override
  String getServiceUrl() {
    return UrlHelper.shared.getUrl(apiType: EAPIType.AUTHENTICATION);
  }

  @override
  void resetService() {
    super.resetService();
  }
}
