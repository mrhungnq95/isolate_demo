import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/enums/enum_package_license.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:flutter/foundation.dart';

class LicenseInfoBusiness {
  LicenseInfo _licenseInfo;

  LicenseInfoBusiness.newInstance(LicenseInfo licenseInfo) {
    this._licenseInfo = licenseInfo;
  }

  factory LicenseInfoBusiness.cached() {
    return LicenseInfoBusiness.newInstance(
        UserCredential.currentSession.licenseInfo);
  }

  ///
  /// License không có dùng chuỗi và không dùng thử
  ///
  bool isNotTrailLicenseForChainStore() {
    return !isTrialLicense() && !isLicenseForChainStore();
  }

  ///
  /// Kiểm tra gói license đang dùng có dành cho Chuỗi không?
  ///
  bool isLicenseForChainStore() {
    return _licenseInfo?.subApp?.toLowerCase()?.contains("chainstore") == true;
  }

  ///
  /// Kiểm tra gói License là Dùng thử
  ///
  bool isTrialLicense() {
    return ELicenseTypeExt.valueOf(_licenseInfo?.productPackCode) ==
        ELicenseType.LicensePackageTrial;
  }

  ///
  /// Kiểm tra gói License là mua theo chuỗi nhưng vượt quá định mức cho phép
  /// của License
  ///
  bool isChainStoreOutOfQuota({@required int numBranchActive}) {
    return isTrialLicense() &&
        numBranchActive > ((_licenseInfo?.numberOfBranch) ?? 0);
  }

  ///
  /// Kiểm tra xem có cần show View thông báo dùng thử không?
  ///
  bool isShowLicenseTrial() {
    if (_licenseInfo != null) {
      if (isTrialLicense()) {
        //nếu còn hạn
        if (_licenseInfo.status == 0) {
          if (_licenseInfo.remain <= 15) {
            //hiển thị dialog dùng thử
            return true;
          }
        } else {
          //hiển thị dialog dùng thử
          return true;
        }
      } else {
        //nếu còn hạn
        if (_licenseInfo.status == 0) {
          if (_licenseInfo.remain <= 30) {
            //hiển thị dialog dùng thử
            return true;
          }
        } else {
          //hiển thị dialog dùng thử
          return true;
        }
      }
    }
    return false;
  }
}
