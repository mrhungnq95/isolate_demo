import 'package:MShopManager/business/license_info_business.dart';
import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/model/branch.dart';

class BranchBusiness {
  BranchBusiness._internal();

  ///
  /// Kiểm tra có được phép chọn Nhóm cửa hàng hàng không?
  /// ĐK: License chuỗi + số lượng cửa hàng active và inacive > 1
  ///
  /// [isDisplayVirtualBranch] true nếu thêm cả Kho tổng vào nếu quyền granted
  /// [isGetAllChainBranch] true nếu thêm cả Toàn chuỗi vào
  ///
  static isAllowChooseGroupStore(
      {bool isDisplayVirtualBranch = false, bool isGetAllChainBranch = true}) {
    final isLicenseForChainStore =
        LicenseInfoBusiness.cached().isLicenseForChainStore();

    final activeBranchCount = getBranchList(
            UserCredential.currentSession.branchList,
            isDisplayVirtualBranch: isDisplayVirtualBranch,
            isGetAllChainBranch: isGetAllChainBranch)
        .length;
    final inActiveBranchCount = getInactiveBranchList().length;

    return isLicenseForChainStore &&
        (activeBranchCount + inActiveBranchCount) > 1;
  }

  ///
  /// Lấy các Branch bị inActive
  ///
  static List<Branch> getInactiveBranchList() {
    final allBranch =
        UserCredential.currentSession.loginResponse?.branchAllList;
    return allBranch?.where((element) => element.inActive == 1)?.toList() ??
        [];
  }

  ///
  /// Lấy DS cửa hàng từ Toàn bộ DS cửa hàng theo quyền
  /// và theo option
  /// [allBranchList] DS toàn bộ cửa hàng
  /// [isDisplayVirtualBranch] true nếu thêm cả Kho tổng vào nếu quyền granted
  /// [isGetAllChainBranch] true nếu thêm cả Toàn chuỗi vào
  ///
  static List<Branch> getBranchList(List<Branch> allBranchList,
      {bool isDisplayVirtualBranch = false, bool isGetAllChainBranch = true}) {
    List<Branch> outputBranchList = [];

    if (UserCredential.currentSession.isVirtualBranchAdmin() ||
        UserCredential.currentSession.isChainOrSystemAdmin() ||
        isDisplayVirtualBranch) {
      outputBranchList = allBranchList
          .where(
              (element) => UserPermissionUtils.hasSystemRoleByBranch(element))
          .toList();

      if (!isDisplayVirtualBranch) {
        outputBranchList = outputBranchList
            .where((element) => !element.isVirtualBranch())
            .toList();
      }
    } else {
      outputBranchList = allBranchList
          .where((element) =>
              !element.isVirtualBranch() &&
              UserPermissionUtils.hasSystemRoleByBranch(element))
          .toList();
    }

    /// Sort lại theo A - Z
    if (outputBranchList.length > 1) {
      outputBranchList.sort((branchA, branchB) =>
          branchA.branchName.length.compareTo(branchB.branchName.length));

      /// Tìm vị trí của Kho tổng nếu có
      final indexVirtualBranch =
          outputBranchList.indexWhere((element) => element.isVirtualBranch());

      /// Nếu kho tổng có index khác 0 => remove nó đi và insert về vị trí đầu tiên
      if (indexVirtualBranch > 0) {
        final virtualBranch = outputBranchList[indexVirtualBranch];
        outputBranchList.removeAt(indexVirtualBranch);
        outputBranchList.insert(0, virtualBranch);
      }
    }

    /// Thêm chuỗi nhà hàng
    if (isGetAllChainBranch &&
        outputBranchList.length > 1 &&
        UserCredential.currentSession.isChainOrSystemAdmin()) {
      outputBranchList.insert(0, Branch.systemBranch());
    }

    return outputBranchList;
  }
}
