import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/service/storage/local_storage.dart';

class DboptionUtils {
  DboptionUtils._internal();

  ///
  /// Lấy giá trị của dboption
  /// VNLONG - 07/01/2021
  ///
  static bool getDBOptionValueByKey(String keyDbOption) {
    final localStorage = LocalStorage.shared;
    final dboptionList = localStorage.getDBOptionList() ?? [];
    final dbOption = dboptionList.firstWhere(
        (dboption) => (dboption?.optionID ?? '').compareTo(keyDbOption) == 0, orElse: () => null);
    return ((dbOption?.optionValue ?? '').compareTo('true') == 0);
  }
}
