import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/enums/enum_role.dart';
import 'package:MShopManager/model/branch.dart';

class UserPermissionUtils {
  UserPermissionUtils._internal();

  static List<int> convertRoleValueToList(String strRoleArray) {
    return (strRoleArray
            ?.split(";")
            ?.map((e) => int.tryParse(e))
            ?.toList()
            ?.where((element) => element != null)
            ?.toList()) ??
        [];
  }

  ///
  /// Kiểm tra role array có quyền Admin không?
  ///
  static bool isAdmin(String strRoleArray) {
    List<int> roleList = convertRoleValueToList(strRoleArray);
    return hasAdminPermissionByRoleList(roleList);
  }

  ///
  /// Kiểm tra có quyền Quản lý hệ thống hoặc chuỗi không?
  ///
  static bool hasSystemAdminOrChainManagerPermission(List<int> roleList) {
    for (int integer in roleList) {
      if (integer == EUserRole.QLHT.value() ||
          integer == EUserRole.QLC.value()) {
        return true;
      }
    }
    return false;
  }

  ///
  /// Kiểm tra các id role có quyền admin không?
  ///
  static bool hasAdminPermissionByRoleList(List<int> roleList) {
    if (roleList != null) {
      for (int integer in roleList) {
        if (integer == EUserRole.QLHT.value() ||
            integer == EUserRole.QLC.value() ||
            integer == EUserRole.QLCH.value()) {
          return true;
        }
      }
    }
    return false;
  }

  ///
  /// Lấy DS các Branch được cấp quyền
  ///
  static List<Branch> selectBranchsGranted(List<Branch> allBranchList) {
    final result = <Branch>[];

    allBranchList?.forEach((branch) {
      if (hasAdminPermissionByRoleList(branch.roles)) {
        result.add(branch);
      }
    });

    return result;
  }

  ///
  /// Kiểm tra User tại branch cần kiểm tra có quyền QLCH, QLC, QLHT
  /// [branch] cửa hàng cần kiểm tra
  ///
  static bool hasSystemRoleByBranch(Branch branch) {
    return (branch.roles?.contains(EUserRole.QLCH.value()) == true ||
        branch.roles?.contains(EUserRole.QLC.value()) == true ||
        branch.roles?.contains(EUserRole.QLHT.value()) == true);
  }

  ///
  /// Check quyền của vai trò
  /// featureSystemValue: Chức năng
  /// permissionTypeValue: Giá trị kiểu quyền ( Xem., thêm, xem báo cáo,...)
  /// VNLONG - 30/12/2020
  ///
  static bool checkPermission(int featureSystemValue, int permissionTypeValue) {
    final userCredential = UserCredential.currentSession;
    
    final permissionValue =
        userCredential?.rolePermissionList[featureSystemValue]?.Permission;

    return permissionTypeValue == permissionValue;
  }
}
