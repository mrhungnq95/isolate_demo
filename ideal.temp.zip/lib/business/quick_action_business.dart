import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/model/quick_action_item.dart';

class QuickActionBusiness {
  List<QuickActionItem> createDefaultQuickAction() {
    return <QuickActionItem>[
      QuickActionItem(
          title: "Nhập hàng",
          imageAssets: AppResources.icItemDown,
          sortOrder: 1,
          type: EFeatureType.import_items),
      QuickActionItem(
          title: "Trả lại hàng mua",
          imageAssets: AppResources.icItemUp,
          sortOrder: 2,
          type: EFeatureType.return_items),
      QuickActionItem(
          title: "Nhập kho",
          imageAssets: AppResources.icStorage,
          sortOrder: 3,
          type: EFeatureType.store_house),
      QuickActionItem(
          title: "Xuất kho",
          imageAssets: AppResources.icStorageUp,
          sortOrder: 4,
          type: EFeatureType.stock_issue),
      QuickActionItem(
          title: "Kiểm kê kho",
          imageAssets: AppResources.icStorageCheck,
          sortOrder: 5,
          type: EFeatureType.checking),
      QuickActionItem(
          title: "Hàng hoá",
          imageAssets: AppResources.icItem,
          sortOrder: 6,
          type: EFeatureType.items),
      QuickActionItem(
          title: "Khách hàng",
          imageAssets: AppResources.icCustomerGrey,
          sortOrder: 7,
          type: EFeatureType.customer),
      QuickActionItem(
          title: "Khuyến mãi",
          imageAssets: AppResources.icPromotion,
          sortOrder: 8,
          type: EFeatureType.promotion),
      QuickActionItem(
          title: "Quỹ tiền",
          imageAssets: AppResources.icMoneyFill2,
          sortOrder: 9,
          type: EFeatureType.balance),
      QuickActionItem(
          title: "Nhà cung cấp",
          imageAssets: AppResources.icDelivery,
          sortOrder: 10,
          type: EFeatureType.provider),
      QuickActionItem(
          title: "Đơn từ web",
          imageAssets: AppResources.icOrderOnline,
          sortOrder: 11,
          type: EFeatureType.order_online),
      QuickActionItem(
          title: "Đơn từ OCM",
          imageAssets: AppResources.icOrderOcm,
          sortOrder: 12,
          type: EFeatureType.order_ocm)
    ];
  }

  ///
  /// Khởi tạo nút chức năng mặc định
  ///
  List<QuickActionItem> createDefaultQuickActionForUser() {
    List<QuickActionItem> defaultQuickAction = createDefaultQuickAction();
    final defaultButton =
        defaultQuickAction.sublist(0, 3).map((e) => e.type.rawValue).join(";");
    return mappingQuickAction(defaultButton);
  }

  ///
  /// Mapping dữ liệu thiết lập nút chức năng của User
  ///
  /// [quickActionByUser] giá trị thiết lập các nút của user: 1;3;4;7
  ///
  List<QuickActionItem> mappingQuickAction(String quickActionByUser) {
    List<QuickActionItem> itemCustomizedList = [];

    final quickActionTypeArrs =
        quickActionByUser?.split(";")?.map((e) => int.tryParse(e))?.toList();

    List<QuickActionItem> defaultQuickAction = createDefaultQuickAction();
    quickActionTypeArrs?.forEach((itemCustomized) {
      final foundItem = defaultQuickAction?.firstWhere(
          (e) => itemCustomized == e.type.rawValue,
          orElse: () => null);

      if (foundItem != null) {
        itemCustomizedList.add(foundItem);
      }
    });

    return itemCustomizedList;
  }

  ///
  /// Tìm nút chức năng đã thiết lập của người dùng
  /// và remove nút chức năng đó đi ở DS mặc định
  ///
  /// [defaultQuickAction] DS các nút mặc định
  /// [quickActionByUser] giá trị thiết lập các nút của user: 1;3;4;7
  ///
  List<QuickActionItem> selectAndRemoveQuickActionExisted(
      List<QuickActionItem> defaultQuickAction, String quickActionByUser) {
    /// Nếu user đã thiết lập rồi
    final quickActionTypeArrs =
        quickActionByUser?.split(";")?.map((e) => int.tryParse(e))?.toList();

    /// Xoá những item là nút đã được người dùng customize đi
    List<QuickActionItem> itemCustomizedList = [];

    quickActionTypeArrs?.forEach((itemCustomized) {
      final foundItem = defaultQuickAction?.firstWhere(
          (e) => itemCustomized == e.type.rawValue,
          orElse: () => null);

      if (foundItem != null) {
        itemCustomizedList.add(foundItem);

        defaultQuickAction?.remove(foundItem);
      }
    });

    return itemCustomizedList;
  }
}
