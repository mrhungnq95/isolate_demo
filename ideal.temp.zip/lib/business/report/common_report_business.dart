import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/material.dart';

class CommonReportBusiness {
  CommonReportBusiness._internal();

  ///
  /// Xử lý so sánh dữ liệu giữa 2 kỳ báo cáo
  /// [reportN1] số liệu báo cáo hiện taij
  /// [reportN2] số liệu báo cáo cần so sánh
  ///
  static ReportCompareResult computeTwoReportData(
      double reportN1, double reportN2) {
    if (reportN1 == 0 && reportN2 == 0) {
      return ReportCompareResult(
          fluctuationsTitle: "0%",
          fluctuationsIcon: Icons.arrow_upward,
          fluctuationsColor: AppColor.green);
    } else if (reportN2 == 0) {
      return ReportCompareResult(
          fluctuationsTitle: "--",
          fluctuationsIcon: Icons.arrow_upward,
          fluctuationsColor: AppColor.green);
    } else {
      final growup = (reportN1 / reportN2) * 100 - 100;

      final color = growup >= 0 ? AppColor.green : Colors.red;
      final icon = growup >= 0 ? Icons.arrow_upward : Icons.arrow_downward;
      return ReportCompareResult(
          fluctuationsTitle:
              "${NumberFormatHelper.shared.formatPercent(growup)}%",
          fluctuationsIcon: icon,
          fluctuationsColor: color);
    }
  }
}
