import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/business/report/common_report_business.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/enums/enum_period.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/model/overview/abstract_overview_sheet_child_data_object.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/model/period_filter_object.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:MShopManager/model/overview/cash_receipt_status_day.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/model/overview/estimate_revenue_status_day.dart';
import 'package:MShopManager/model/overview/instock_today.dart';
import 'package:MShopManager/model/overview/invoice_today.dart';
import 'package:MShopManager/model/overview/report_daily_item.dart';
import 'package:MShopManager/enums/enum_report_daily.dart';
import 'package:MShopManager/enums/enum_report_item_code.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

class OverViewReportBusiness {
  ///
  /// Constant
  ///
  static const KEY_TOTAL_CASH_IN_DAY = "Total_Cash_In_Day";

  ///
  ///
  ///
  Map<String, Map<String, Map<String, ReportDailyItem>>> buildReportDailyData(
      List<ReportDailyItem> reportDailyItems) {
    var output = Map<String, Map<String, Map<String, ReportDailyItem>>>();

    for (int i = 0; i < reportDailyItems.length; i++) {
      final item = reportDailyItems[i];
      if (item.group <= 3) {
        if (output[item.group.toString()] == null) {
          ////
          // thêm mới
          var group = Map<String, Map<String, ReportDailyItem>>();
          var groupDetail = Map<String, ReportDailyItem>();
          // nếu là tổng tiền trong ngày
          if (item.group == EReportDaily.totalCashInDay.rawValue) {
            _addChildToParentGroup(item.group, KEY_TOTAL_CASH_IN_DAY,
                reportDailyItems, groupDetail);
            group[KEY_TOTAL_CASH_IN_DAY] = groupDetail;
          } else {
            // các nhóm khác
            final code = item.code; //EReportItemCode
            groupDetail[code.rawValue] = item;
            _addChildToParentGroup(
                item.group, code.rawValue, reportDailyItems, groupDetail);
            group[code.rawValue] = groupDetail;
            output[item.group.toString()] = group;
          }
          // thêm nhóm vừa tạo vào tệp kqua
          output[item.group.toString()] = group;
        } else {
          ////
          final group = output[item.group.toString()];
          final code =
              item.group == 3 ? KEY_TOTAL_CASH_IN_DAY : item.code.rawValue;
          // nếu không có nhóm của item đang duyệt thì thêm vào
          if (group[code] == null) {
            // thêm mới group con
            var groupDetail = Map<String, ReportDailyItem>();
            groupDetail[code] = item;
            _addChildToParentGroup(
                item.group, code, reportDailyItems, groupDetail);
            group[item.code.rawValue] = groupDetail;
            output[item.group.toString()] = group;
          }
        }
      }
    }
    return output;
  }

  ///
  /// Add những đối tượng dữ liệu vào từng Key tương ứng
  /// [group] sẽ có trong các nhóm: 0, 1, 2, 3, 12
  /// [reportDailyItems] DS Toàn bộ dữ liệu báo cáo (của từng key)
  /// [groupDetail] Map chứ các key cho từng section
  ///
  void _addChildToParentGroup(
      int group,
      String key,
      List<ReportDailyItem> reportDailyItems,
      Map<String, ReportDailyItem> groupDetail) {
    if (reportDailyItems != null) {
      for (int i = 0; i < reportDailyItems.length; i++) {
        final item = reportDailyItems[i];
        final code = item.code;
        if (code != null) {
          switch (group) {
            case 0:
              if (key == "Sale" && item.group == 4) {
                // bán hàng
                groupDetail[code.rawValue] = item;
              } else if (key == "ReceiveAmount" && item.group == 5) {
                // thu nợ
                groupDetail[code.rawValue] = item;
              } else if (key == "DepositAmount" && item.group == 6) {
                // khách đặt cọc
                groupDetail[code.rawValue] = item;
              } else if (key == "ReceiptOther" && item.group == 11) {
                // khác
                groupDetail[code.rawValue] = item;
              }
              break;
            case 1:
              //Doanh thu ước tính
              if (key == "InvoicePay" && item.group == 7) {
                groupDetail[code.rawValue] = item;
              } else if (key == "InvoiceProcess" && item.group == 8) {
                groupDetail[code.rawValue] = item;
              }
              break;
            case 2:
              if (key == "AtBranch" && item.group == 9) {
                groupDetail[code.rawValue] = item;
              } else if (key == "Delivery" && item.group == 10) {
                groupDetail[code.rawValue] = item;
              }
              break;
            case 3:
              if (group == 3 &&
                  key == KEY_TOTAL_CASH_IN_DAY &&
                  item.group == 3) {
                groupDetail[code.rawValue] = item;
              }
              break;
            case 12:
              if (group == 12 && key == "InStock" && item.group == 12) {
                groupDetail[code.rawValue] = item;
              }
              break;
            default:
              break;
          }
        }
      }
    }
  }

  ///
  /// Lấy dữ liệu tiền thu trong kỳ
  ///
  CashReceiptStatusDay getCashReceiptStatusDay(
      Map<String, Map<String, Map<String, ReportDailyItem>>> reportDailyData) {
    final result = CashReceiptStatusDay();
    final cashReceiptGroup = reportDailyData["3"];

    if (cashReceiptGroup != null) {
      final totalCashInDay = cashReceiptGroup[KEY_TOTAL_CASH_IN_DAY];

      if (totalCashInDay != null) {
        result.totalCardAmount = totalCashInDay["CardAmount"] != null
            ? totalCashInDay["CardAmount"]?.totalAmount
            : 0.0;
        result.totalVoucherAmount = totalCashInDay["VoucherAmount"] != null
            ? totalCashInDay["VoucherAmount"]?.totalAmount
            : 0.0;
        result.totalTransferAmount = totalCashInDay["TranferAmount"] != null
            ? totalCashInDay["TranferAmount"]?.totalAmount
            : 0.0;
        result.totalCashAmount = totalCashInDay["CashAmount"] != null
            ? totalCashInDay["CashAmount"]?.totalAmount
            : 0.0;

        result.previousPeriodTotalCardAmount =
            totalCashInDay["CardAmount"] != null
                ? totalCashInDay["CardAmount"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodTotalVoucherAmount =
            totalCashInDay["VoucherAmount"] != null
                ? totalCashInDay["VoucherAmount"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodTotalTransferAmount =
            totalCashInDay["TranferAmount"] != null
                ? totalCashInDay["TranferAmount"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodTotalCashAmount =
            totalCashInDay["CashAmount"] != null
                ? totalCashInDay["CashAmount"]?.previousPeriodTotalAmount
                : 0.0;
      }
    }

    final cashGroup = reportDailyData["0"];
    if (cashGroup != null) {
      final saleInDay = cashGroup["Sale"];
      result.saleTotalAmount =
          saleInDay["Sale"] != null ? saleInDay["Sale"]?.totalAmount : 0;
      result.saleCardAmount = saleInDay["CardAmount"] != null
          ? saleInDay["CardAmount"]?.totalAmount
          : 0;
      result.saleCashAmount = saleInDay["CashAmount"] != null
          ? saleInDay["CashAmount"]?.totalAmount
          : 0;
      result.saleVoucherAmount = saleInDay["VoucherAmount"] != null
          ? saleInDay["VoucherAmount"]?.totalAmount
          : 0;
      result.saleTransferAmount = saleInDay["TranferAmount"] != null
          ? saleInDay["TranferAmount"]?.totalAmount
          : 0;

      result.previousPeriodSaleTotalAmount = saleInDay["Sale"] != null
          ? saleInDay["Sale"]?.previousPeriodTotalAmount
          : 0.0;
      result.previousPeriodSaleCardAmount = saleInDay["CardAmount"] != null
          ? saleInDay["CardAmount"]?.previousPeriodTotalAmount
          : 0.0;
      result.previousPeriodSaleCashAmount = saleInDay["CashAmount"] != null
          ? saleInDay["CashAmount"]?.previousPeriodTotalAmount
          : 0.0;
      result.previousPeriodSaleVoucherAmount =
          saleInDay["VoucherAmount"] != null
              ? saleInDay["VoucherAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodSaleTransferAmount =
          saleInDay["TranferAmount"] != null
              ? saleInDay["TranferAmount"]?.previousPeriodTotalAmount
              : 0.0;

      final receiptInDay = cashGroup["ReceiveAmount"];
      result.receiptTotalAmount = receiptInDay["ReceiveAmount"] != null
          ? receiptInDay["ReceiveAmount"]?.totalAmount
          : 0.0;
      result.receiptCardAmount = receiptInDay["CardAmount"] != null
          ? receiptInDay["CardAmount"]?.totalAmount
          : 0.0;
      result.receiptCashAmount = receiptInDay["CashAmount"] != null
          ? receiptInDay["CashAmount"]?.totalAmount
          : 0.0;
      result.receiptTransferAmount = receiptInDay["TranferAmount"] != null
          ? receiptInDay["TranferAmount"]?.totalAmount
          : 0.0;

      result.previousPeriodReceiptTotalAmount =
          receiptInDay["ReceiveAmount"] != null
              ? receiptInDay["ReceiveAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodReceiptCardAmount =
          receiptInDay["CardAmount"] != null
              ? receiptInDay["CardAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodReceiptCashAmount =
          receiptInDay["CashAmount"] != null
              ? receiptInDay["CashAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodReceiptTransferAmount =
          receiptInDay["TranferAmount"] != null
              ? receiptInDay["TranferAmount"]?.previousPeriodTotalAmount
              : 0.0;

      final depositInDay = cashGroup["DepositAmount"];

      result.depositTotalAmount = depositInDay["DepositAmount"] != null
          ? depositInDay["DepositAmount"]?.totalAmount
          : 0.0;
      result.depositCashAmount = depositInDay["CashAmount"] != null
          ? depositInDay["CashAmount"]?.totalAmount
          : 0.0;
      result.depositCardAmount = depositInDay["CardAmount"] != null
          ? depositInDay["CardAmount"]?.totalAmount
          : 0.0;
      result.depositTransferAmount = depositInDay["TranferAmount"] != null
          ? depositInDay["TranferAmount"]?.totalAmount
          : 0.0;

      result.previousPeriodDepositTotalAmount =
          depositInDay["DepositAmount"] != null
              ? depositInDay["DepositAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodDepositCashAmount =
          depositInDay["CashAmount"] != null
              ? depositInDay["CashAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodDepositCardAmount =
          depositInDay["CardAmount"] != null
              ? depositInDay["CardAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodDepositTransferAmount =
          depositInDay["TranferAmount"] != null
              ? depositInDay["TranferAmount"]?.previousPeriodTotalAmount
              : 0.0;

      final otherInDay = cashGroup["ReceiptOther"];

      result.otherCashAmount = otherInDay["CashAmount"] != null
          ? otherInDay["CashAmount"]?.totalAmount
          : 0.0;
      result.otherTransferAmount = otherInDay["TranferAmount"] != null
          ? otherInDay["TranferAmount"]?.totalAmount
          : 0.0;
      result.totalOtherAmount = otherInDay["ReceiptOther"] != null
          ? otherInDay["ReceiptOther"]?.totalAmount
          : 0.0;

      result.previousPeriodOtherCashAmount = otherInDay["CashAmount"] != null
          ? otherInDay["CashAmount"]?.previousPeriodTotalAmount
          : 0.0;
      result.previousPeriodOtherTransferAmount =
          otherInDay["TranferAmount"] != null
              ? otherInDay["TranferAmount"]?.previousPeriodTotalAmount
              : 0.0;
      result.previousPeriodTotalOtherAmount = otherInDay["ReceiptOther"] != null
          ? otherInDay["ReceiptOther"]?.previousPeriodTotalAmount
          : 0.0;
    }

    result.receiptAmountInDay =
        (result.saleTotalAmount ?? 0) + (result.receiptTotalAmount ?? 0);
    result.receiptAmountInDay = (result.receiptAmountInDay ?? 0) +
        (result.depositTotalAmount ?? 0) +
        (result.totalOtherAmount ?? 0);

    result.previousPeriodReceiptAmountInDay =
        (result.previousPeriodSaleTotalAmount ?? 0) +
            (result.previousPeriodReceiptTotalAmount ?? 0);
    result.previousPeriodReceiptAmountInDay =
        (result.previousPeriodReceiptAmountInDay ?? 0) +
            (result.previousPeriodDepositTotalAmount ?? 0) +
            (result.previousPeriodTotalOtherAmount ?? 0);

    return result;
  }

  ///
  /// Lấy Doanh thu trong ngày
  ///
  EstimateRevenueStatusDay getRevenueInDay(
      Map<String, Map<String, Map<String, ReportDailyItem>>> reportDailyData) {
    final result = EstimateRevenueStatusDay();
    final estimateGroup = reportDailyData["1"];

    if (estimateGroup != null) {
      final invoicePay = estimateGroup["InvoicePay"];

      if (invoicePay != null) {
        // Hoá đơn đã thanh toán
        result.totalInvoicePaidAmount = invoicePay["InvoicePay"] != null
            ? invoicePay["InvoicePay"]?.totalAmount
            : 0.0;
        result.invoicePaidQuantity = invoicePay["InvoicePay"] != null
            ? invoicePay["InvoicePay"]?.quantity
            : 0.0;
        result.paidAmount = invoicePay["ReceiptAmount"] != null
            ? invoicePay["ReceiptAmount"]?.totalAmount
            : 0.0;

        // Hoá đơn khách nợ
        result.debtAmount = invoicePay["DebitAmount"] != null
            ? invoicePay["DebitAmount"]?.totalAmount
            : 0.0;
        result.debtQuantity = invoicePay["DebitAmount"] != null
            ? invoicePay["DebitAmount"]?.quantity
            : 0.0;

        // Thu hộ
        result.rentCollectorAmount = invoicePay["RentCollectorAmount"] != null
            ? invoicePay["RentCollectorAmount"]?.totalAmount
            : 0.0;
        result.rentCollectorQuantity = invoicePay["RentCollectorAmount"] != null
            ? invoicePay["RentCollectorAmount"]?.quantity
            : 0.0;

        // Dữ liệu kỳ báo cáo so sánh
        result.previousPeriodTotalInvoicePaidAmount =
            invoicePay["InvoicePay"] != null
                ? invoicePay["InvoicePay"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodTotalInvoicePaidQuantity =
            invoicePay["InvoicePay"] != null
                ? invoicePay["InvoicePay"]?.previousPeriodQuantity
                : 0.0;
        result.previousPeriodPaidAmount = invoicePay["ReceiptAmount"] != null
            ? invoicePay["ReceiptAmount"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodDebtAmount = invoicePay["DebitAmount"] != null
            ? invoicePay["DebitAmount"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodRentCollectorAmount =
            invoicePay["RentCollectorAmount"] != null
                ? invoicePay["RentCollectorAmount"]?.previousPeriodTotalAmount
                : 0.0;

        // Tính tổng hoá đơn đã thanh toán
        result.updateTotalInvoicePaidQuantity();
      }

      final invoiceProcess = estimateGroup["InvoiceProcess"];
      if (invoiceProcess != null) {
        // Hoá đơn chờ thanh toán
        result.totalInvoiceProcessingAmount =
            invoiceProcess["InvoiceProcess"] != null
                ? invoiceProcess["InvoiceProcess"]?.totalAmount
                : 0.0;
        result.totalInvoiceProcessingQuantity =
            invoiceProcess["InvoiceProcess"] != null
                ? invoiceProcess["InvoiceProcess"]?.quantity
                : 0.0;

        // Chờ thanh toán
        result.waitingPayAmount = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["UnpaidAmount"]?.totalAmount
            : 0.0;
        result.waitingPayQuantity = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["UnpaidAmount"]?.quantity
            : 0.0;

        // Chưa giao hàng
        result.pendingDeliveryAmount = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["NotDeliveryAmount"]?.totalAmount
            : 0.0;
        result.pendingDeliveryQuantity = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["NotDeliveryAmount"]?.quantity
            : 0.0;

        // Đang giao hàng
        result.deliveringAmount = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["DeliveryAmount"]?.totalAmount
            : 0.0;
        result.deliveringQuantity = invoiceProcess["UnpaidAmount"] != null
            ? invoiceProcess["DeliveryAmount"]?.quantity
            : 0.0;

        // Lấy số liệu báo cáo so với kỳ trước
        result.previousPeriodTotalInvoiceProcessingAmount =
            invoiceProcess["InvoiceProcess"] != null
                ? invoiceProcess["InvoiceProcess"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodTotalInvoiceProcessingQuantity =
            invoiceProcess["InvoiceProcess"] != null
                ? invoiceProcess["InvoiceProcess"]?.previousPeriodQuantity
                : 0.0;
        result.previousPeriodWaitingPayAmount =
            invoiceProcess["UnpaidAmount"] != null
                ? invoiceProcess["UnpaidAmount"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodPendingDeliveryAmount =
            invoiceProcess["UnpaidAmount"] != null
                ? invoiceProcess["NotDeliveryAmount"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodDeliveringAmount =
            invoiceProcess["UnpaidAmount"] != null
                ? invoiceProcess["DeliveryAmount"]?.previousPeriodTotalAmount
                : 0.0;
      }

      result.estimateRevenue = (result.totalInvoicePaidAmount ?? 0) +
          (result.totalInvoiceProcessingAmount ?? 0);
      result.previousPeriodEstimateRevenue =
          (result.previousPeriodTotalInvoicePaidAmount ?? 0) +
              (result.previousPeriodTotalInvoiceProcessingAmount ?? 0);
    }

    return result;
  }

  ///
  /// Lấy dữ liệu báo cáo trong ngày
  ///
  InvoiceToday getInvoiceStatusDay(
      Map<String, Map<String, Map<String, ReportDailyItem>>> reportDailyData) {
    final result = InvoiceToday();
    final invoiceGroup = reportDailyData["2"];
    if (invoiceGroup != null) {
      final atBranch = invoiceGroup["AtBranch"];
      if (atBranch != null) {
        result.totalInStoreAmount = atBranch["AtBranch"] != null
            ? atBranch["AtBranch"]?.totalAmount
            : 0.0;
        result.totalInStoreQuantity =
            atBranch["AtBranch"] != null ? atBranch["AtBranch"]?.quantity : 0.0;
        result.waitingPayAmount = atBranch["UnpaidAmount"] != null
            ? atBranch["UnpaidAmount"]?.totalAmount
            : 0.0;
        result.paidAmount = atBranch["PaidAmount"] != null
            ? atBranch["PaidAmount"]?.totalAmount
            : 0.0;
        // HD Huỷ
        result.cancelInStoreAmount = atBranch["CancelAmount"] != null
            ? atBranch["CancelAmount"]?.totalAmount
            : 0.0;
        result.cancelInStoreQuantity = atBranch["CancelAmount"] != null
            ? atBranch["CancelAmount"]?.quantity
            : 0.0;

        result.previousPeriodTotalInStoreAmount = atBranch["AtBranch"] != null
            ? atBranch["AtBranch"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodTotalInStoreQuantity = atBranch["AtBranch"] != null
            ? atBranch["AtBranch"]?.previousPeriodQuantity
            : 0.0;
        result.previousPeriodWaitingPayAmount = atBranch["UnpaidAmount"] != null
            ? atBranch["UnpaidAmount"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodPaidAmount = atBranch["PaidAmount"] != null
            ? atBranch["PaidAmount"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodCancelInStoreAmount =
            atBranch["CancelAmount"] != null
                ? atBranch["CancelAmount"]?.previousPeriodTotalAmount
                : 0.0;
      }

      final delivery = invoiceGroup["Delivery"];

      if (delivery != null) {
        result.totalDeliveryAmount = delivery["Delivery"] != null
            ? delivery["Delivery"]?.totalAmount
            : 0.0;
        result.totalDeliveryQuantity =
            delivery["Delivery"] != null ? delivery["Delivery"]?.quantity : 0.0;
        // Chưa giao hàng
        result.pendingDeliveryAmount = delivery["NotDelivery"] != null
            ? delivery["NotDelivery"]?.totalAmount
            : 0.0;
        result.pendingDeliveryQuantity = delivery["NotDelivery"] != null
            ? delivery["NotDelivery"]?.quantity
            : 0.0;
        // Đang giao hàng
        result.deliveringAmount = delivery["Delivery"] != null
            ? delivery["Delivery"]?.totalAmount
            : 0.0;
        result.deliveringQuantity =
            delivery["Delivery"] != null ? delivery["Delivery"]?.quantity : 0.0;
        // Chờ thu COD
        result.pendingReceiveCODAmount = delivery["ReceiveCOD"] != null
            ? delivery["ReceiveCOD"]?.totalAmount
            : 0.0;
        result.pendingReceiveCODQuantity = delivery["ReceiveCOD"] != null
            ? delivery["ReceiveCOD"]?.quantity
            : 0.0;
        // Hoàn thành
        result.deliveredAmount =
            delivery["Finish"] != null ? delivery["Finish"]?.totalAmount : 0.0;
        result.deliveredQuantity =
            delivery["Finish"] != null ? delivery["Finish"]?.quantity : 0.0;
        // Thất bại
        result.failedAmount =
            delivery["Fail"] != null ? delivery["Fail"]?.totalAmount : 0.0;
        result.failedQuantity =
            delivery["Fail"] != null ? delivery["Fail"]?.quantity : 0.0;
        // Chuyển hoàn
        result.reTransferAmount = delivery["Converting"] != null
            ? delivery["Converting"]?.totalAmount
            : 0.0;
        result.reTransferQuantity = delivery["Converting"] != null
            ? delivery["Converting"]?.quantity
            : 0.0;
        // Huỷ
        result.cancelDeliveryAmount =
            delivery["Cancel"] != null ? delivery["Cancel"]?.totalAmount : 0.0;
        result.cancelDeliveryQuantity =
            delivery["Cancel"] != null ? delivery["Cancel"]?.quantity : 0.0;
        result.totalInvoiceAmount = (result.totalInStoreAmount ?? 0) +
            (result.totalDeliveryAmount ?? 0);

        // Lấy số liệu báo cáo so với kỳ trước
        result.previousPeriodTotalDeliveryAmount = delivery["Delivery"] != null
            ? delivery["Delivery"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodTotalDeliveryQuantity =
            delivery["Delivery"] != null
                ? delivery["Delivery"]?.previousPeriodQuantity
                : 0.0;
        result.previousPeriodPendingDeliveryAmount =
            delivery["NotDelivery"] != null
                ? delivery["NotDelivery"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodDeliveringAmount = delivery["Delivery"] != null
            ? delivery["Delivery"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodPendingReceiveCODAmount =
            delivery["ReceiveCOD"] != null
                ? delivery["ReceiveCOD"]?.previousPeriodTotalAmount
                : 0.0;
        result.previousPeriodDeliveredAmount = delivery["Finish"] != null
            ? delivery["Finish"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodFailedAmount = delivery["Fail"] != null
            ? delivery["Fail"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodReTransferAmount = delivery["Converting"] != null
            ? delivery["Converting"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodCancelDeliveryAmount = delivery["Cancel"] != null
            ? delivery["Cancel"]?.previousPeriodTotalAmount
            : 0.0;
        result.previousPeriodTotalInvoiceAmount =
            (result.previousPeriodTotalInStoreAmount ?? 0) +
                (result.previousPeriodTotalDeliveryAmount ?? 0);
      }
    }
    return result;
  }

  ///
  /// Lấy danh sách thông tin khách hàng Dashboard
  ///
  CustomerToday getCustomerToday(List<ReportDailyItem> reportDailyItemList) {
    final result = CustomerToday();
    final customerReport = reportDailyItemList.firstWhere((element) =>
        element.group == 12 && element.code == EReportItemCode.customer);

    if (customerReport != null) {
      result.quantity = customerReport.quantity;
      result.previousPeriodQuantity = customerReport.previousPeriodQuantity;
    }

    return result;
  }

  ///
  /// Lấy thông tin tồn kho
  ///
  InstockToday getInstockToday(List<ReportDailyItem> reportDailyItemList) {
    final result = InstockToday();
    final inStockReport = reportDailyItemList.firstWhere((element) =>
        element.group == 12 && element.code == EReportItemCode.in_stock);

    if (inStockReport != null) {
      result.quantity = inStockReport.quantity;
      result.totalAmount = inStockReport.totalAmount;
      result.previousPeriodQuantity = inStockReport.previousPeriodQuantity;
      result.previousPeriodTotalAmount =
          inStockReport.previousPeriodTotalAmount;
    }

    return result;
  }

  //Lấy kỳ báo cáo
  List<PeriodFilterCategoryType> getPeriodFilterList() {
    List<PeriodFilterCategoryType> item = [
      PeriodFilterCategoryType(
          type: EDateFilterType.day,
          description: "Ngày",
          periodItemList: _getItemPeriodFilterByType(EDateFilterType.day)),
      PeriodFilterCategoryType(
          type: EDateFilterType.week,
          description: "Tuần",
          periodItemList: _getItemPeriodFilterByType(EDateFilterType.week)),
      PeriodFilterCategoryType(
          type: EDateFilterType.month,
          description: "Tháng",
          periodItemList: _getItemPeriodFilterByType(EDateFilterType.month)),
      PeriodFilterCategoryType(
          type: EDateFilterType.custom,
          description: "Tuỳ chỉnh",
          periodItemList: _getItemPeriodFilterByType(EDateFilterType.custom))
    ];
    return item;
  }

  ///
  /// Lấy các mốc filter của kỳ báo cáo
  ///
  List<ItemPeriodFilterObject> _getItemPeriodFilterByType(
      EDateFilterType type) {
    List<ItemPeriodFilterObject> output = [];

    switch (type) {
      case EDateFilterType.day:
        // Hôm nay
        final today = DateTimeHelper.getToday();

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.thisDay,
            title: ETimePeriod.today.getTitle(),
            description: DateTimeFormatHelper.formatDate2String(today.startDate,
                format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD),
            dateRange: today));

        // Hôm qua
        final yesterday = DateTimeHelper.getYesterday();
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.yesterday,
            title: ETimePeriod.yesterday.getTitle(),
            description: DateTimeFormatHelper.formatDate2String(
                yesterday.startDate,
                format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD),
            dateRange: yesterday));
        break;
      case EDateFilterType.week:
        // 7 ngày gần đây
        final lastSevenDay = DateTimeHelper.getLastSevenDay();
        final startLastSevenDay = DateTimeFormatHelper.formatDate2String(
            lastSevenDay.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        final endLastSevenDay = DateTimeFormatHelper.formatDate2String(
            lastSevenDay.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        // 28 Tháng 6 - 04 Tháng 7
        final lastSevenDayDesc = "$startLastSevenDay - $endLastSevenDay";
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastSevenDay,
            title: "7 ngày gần đây",
            description: lastSevenDayDesc,
            dateRange: lastSevenDay));

        // Tuần này 28 Tháng 6 - 04 Tháng 7
        final thisWeek = DateTimeHelper.getWeekRange(ofDate: DateTime.now());

        final startThisWeek = DateTimeFormatHelper.formatDate2String(
            thisWeek.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        final endThisWeek = DateTimeFormatHelper.formatDate2String(
            thisWeek.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        // 28 Tháng 6 - 04 Tháng 7
        final thisWeekDesc = "$startThisWeek - $endThisWeek";

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.thisWeek,
            title: ETimePeriod.thisWeek.getTitle(),
            description: thisWeekDesc,
            dateRange: thisWeek));
        break;
      case EDateFilterType.month:
        // 30 ngày gần đây
        final lastThirtyDay = DateTimeHelper.getLastThirtyDay();
        final startLastThirtyDay = DateTimeFormatHelper.formatDate2String(
            lastThirtyDay.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        final endLastThirtyDay = DateTimeFormatHelper.formatDate2String(
            lastThirtyDay.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        // 28 Tháng 6 - 04 Tháng 7
        final lastSevenDayDesc = "$startLastThirtyDay - $endLastThirtyDay";
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastThirtyDay,
            title: "30 ngày gần đây",
            description: lastSevenDayDesc,
            dateRange: lastThirtyDay));

        // Tháng này
        final thisMonth = DateTimeHelper.getMonthRange(ofDate: DateTime.now());

        final thisMonthDesc = DateTimeFormatHelper.formatDate2String(
            thisMonth.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM);

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.thisMonth,
            title: ETimePeriod.thisMonth.getTitle(),
            description: thisMonthDesc,
            dateRange: thisMonth));

        // Tháng trước
        final lastMonth =
            DateTimeHelper.getLastMonthRange(ofDate: DateTime.now());

        final lastMonthDesc = DateTimeFormatHelper.formatDate2String(
            lastMonth.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM);

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastMonth,
            title: ETimePeriod.lastMonth.getTitle(),
            description: lastMonthDesc,
            dateRange: lastMonth));
        break;
      case EDateFilterType.custom:
        // Từ ngày - ngày hiện tại
        // Hôm nay
        final thisMonth = DateTimeHelper.getMonthRange(ofDate: DateTime.now());
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.fromDateCustomize,
            title: "Từ ngày",
            isCustomizeDate: true,
            description: DateTimeFormatHelper.formatDate2String(
                thisMonth.startDate,
                format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD),
            dateRange: thisMonth));

        // Đến ngày - ngày cuối cùng của tháng hiện tại

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.toDateCustomize,
            title: "Đến ngày",
            isCustomizeDate: true,
            description: DateTimeFormatHelper.formatDate2String(
                thisMonth.endDate,
                format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD),
            dateRange: thisMonth));
        break;
    }
    return output;
  }

  ///
  /// Lấy các mốc filter của kỳ báo cáo trong quá khứ để đối chiếu
  ///
  List<ItemPeriodFilterObject> getPreviousItemPeriodFilterByType(
      {EDateFilterType periodFilter, DateRange dateRange}) {
    List<ItemPeriodFilterObject> output = [];
    switch (periodFilter) {
      case EDateFilterType.day:
        // Ngày trước đó
        final yesterday =
            DateTimeHelper.getYesterday(ofDate: dateRange.startDate);
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastDay,
            title: "Ngày trước đó",
            description: DateTimeFormatHelper.formatDate2String(
                yesterday.startDate,
                format: "dd 'tháng' MM"),
            dateRange: yesterday));

        // Tuỳ chỉnh
        final customize =
            DateTimeHelper.getYesterday(ofDate: dateRange.startDate);
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.toDateCustomize,
            title: "Tuỳ chỉnh",
            isCustomizeDate: true,
            description: "Chọn ngày",
            dateRange: null));
        break;
      case EDateFilterType.week:
        //Tuần trước đó
        final lastWeek =
            DateTimeHelper.getLastWeekRange(ofDate: dateRange.startDate);

        final startLastWeekDesc = DateTimeFormatHelper.formatDate2String(
            lastWeek.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        final endLastWeekDesc = DateTimeFormatHelper.formatDate2String(
            lastWeek.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        final lastWeekDesc = "$startLastWeekDesc - $endLastWeekDesc";

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastWeek,
            title: "Tuần trước đó",
            description: lastWeekDesc,
            dateRange: lastWeek));

        //Tuỳ chỉnh
        final cusLastWeek =
            DateTimeHelper.getLastWeekRange(ofDate: DateTime.now());
        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.toDateCustomize,
            title: "Tuỳ chỉnh",
            isCustomizeDate: true,
            description: "Chọn ngày",
            dateRange: cusLastWeek));
        break;
      case EDateFilterType.month:

        // 4 Tuần trước đó
        final lastfourWeek =
            DateTimeHelper.getFourLastWeekRange(ofDate: dateRange.startDate);

        final start4LastWeekDesc = DateTimeFormatHelper.formatDate2String(
            lastfourWeek.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        final end4LastWeekDesc = DateTimeFormatHelper.formatDate2String(
            lastfourWeek.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        final lastWeekDesc = "$start4LastWeekDesc - $end4LastWeekDesc";

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.fourLastWeek,
            title: "4 Tuần trước đó",
            description: lastWeekDesc,
            dateRange: lastfourWeek));

        // Tháng trước đó
        final lastMonth =
            DateTimeHelper.getLastMonthRange(ofDate: dateRange.startDate);

        final startLastMonthDesc = DateTimeFormatHelper.formatDate2String(
            lastMonth.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM);

        final lastMonthDesc = "$startLastMonthDesc";

        output.add(ItemPeriodFilterObject(
            type: EReportPeriodType.lastMonth,
            title: "Tháng trước đó",
            description: lastMonthDesc,
            dateRange: lastMonth));
        break;
      case EDateFilterType.custom:
        // Từ ngày
        output.add(ItemPeriodFilterObject(
            title: "Từ ngày",
            type: EReportPeriodType.fromDateCustomize,
            isCustomizeDate: true,
            description: "Chọn ngày",
            dateRange: null));
        // Đến ngày

        output.add(ItemPeriodFilterObject(
            title: "Đến ngày",
            type: EReportPeriodType.toDateCustomize,
            isCustomizeDate: true,
            description: "Chọn ngày",
            dateRange: null));
        break;
    }
    return output;
  }

  ///
  /// Thông tin Hoá đơn - Doanh thu ước tính
  ///
  List<ValuePropertyObject> buildEstimateRevenueDataSourceSummary(
      EstimateRevenueStatusDay estimateRevenueStatusDay) {
    List<ValuePropertyObject> result = [];

    result.add(ValuePropertyObject(
        title: "Hóa đơn thanh toán",
        amount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.totalInvoicePaidAmount)));

    result.add(ValuePropertyObject(
        title: "Hóa đơn chờ xử lý",
        amount: NumberFormatHelper.shared.formatMoney(
            estimateRevenueStatusDay.totalInvoiceProcessingAmount)));

    return result;
  }

  ///
  /// * Build dữ liệu hiển thị cho chi tiết cho mục: Doanh thu ước tính
  /// * Created by NQHung on 05/11/2020
  ///
  List<OverviewSheetChildDataObject> buildEstimateRevenueDataSource(
      EstimateRevenueStatusDay estimateRevenueStatusDay) {
    List<OverviewSheetChildDataObject> item = [];
    List<ValuePropertyObject> invoicePaidChild = [];
    List<ValuePropertyObject> pendingInvoiceChild = [];

    invoicePaidChild.add(ValuePropertyObject(
      title: "Đã thu tiền",
      amount: NumberFormatHelper.shared
          .formatMoney(estimateRevenueStatusDay.paidAmount),
      quantity: NumberFormatHelper.shared
          .formatQuantity(estimateRevenueStatusDay.invoicePaidQuantity),
    ));
    invoicePaidChild.add(ValuePropertyObject(
      title: "Khách nợ",
      amount: NumberFormatHelper.shared
          .formatMoney(estimateRevenueStatusDay.debtAmount),
      quantity: NumberFormatHelper.shared
          .formatQuantity(estimateRevenueStatusDay.debtQuantity),
    ));
    invoicePaidChild.add(ValuePropertyObject(
      title: "Thu hộ",
      amount: NumberFormatHelper.shared
          .formatMoney(estimateRevenueStatusDay.rentCollectorAmount),
      quantity: NumberFormatHelper.shared
          .formatQuantity(estimateRevenueStatusDay.rentCollectorQuantity),
    ));

    item.add(ExpandedChildObject(
        imageAssets: AppResources.icInvoiceFill,
        titleSection: "Hóa đơn thanh toán",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.totalInvoicePaidAmount),
        totalQuantity: NumberFormatHelper.shared
            .formatQuantity(estimateRevenueStatusDay.totalInvoicePaidQuantity),
        childList: invoicePaidChild));

    /// =================
    /// =================
    pendingInvoiceChild.add(ValuePropertyObject(
        title: "Chờ thanh toán",
        amount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.waitingPayAmount),
        quantity: NumberFormatHelper.shared
            .formatQuantity(estimateRevenueStatusDay.waitingPayQuantity)));
    pendingInvoiceChild.add(ValuePropertyObject(
        title: "Chờ giao hàng",
        amount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.pendingDeliveryAmount),
        quantity: NumberFormatHelper.shared
            .formatQuantity(estimateRevenueStatusDay.pendingDeliveryQuantity)));
    pendingInvoiceChild.add(ValuePropertyObject(
        title: "Đang giao hàng",
        amount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.deliveringAmount),
        quantity: NumberFormatHelper.shared
            .formatQuantity(estimateRevenueStatusDay.deliveringQuantity)));

    item.add(ExpandedChildObject(
        imageAssets: AppResources.icInvoiceFillPending,
        titleSection: "Chờ xử lý",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.totalInvoiceProcessingAmount),
        totalQuantity: NumberFormatHelper.shared.formatQuantity(
            estimateRevenueStatusDay.totalInvoiceProcessingQuantity),
        childList: pendingInvoiceChild));
    return item;
  }

  ///
  /// Build hình thức thanh toán Tổng
  ///
  List<ValuePropertyObject> buildCashReceiptDataSourceSummary(
      CashReceiptStatusDay cashReceiptStatusDay) {
    List<ValuePropertyObject> paymentTypeChild = [];

    paymentTypeChild.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalCashAmount)));
    paymentTypeChild.add(ValuePropertyObject(
        title: "Thẻ",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalCardAmount)));
    paymentTypeChild.add(ValuePropertyObject(
        title: "Vouhcer",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalVoucherAmount)));
    paymentTypeChild.add(ValuePropertyObject(
        title: "Chuyển khoản",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalTransferAmount)));

    return paymentTypeChild;
  }

  ///
  /// Doanh thu trong ngày
  ///
  List<ValuePropertyObject> buildCashReceiptOrderTypeDataSource(
      CashReceiptStatusDay cashReceiptStatusDay) {
    List<ValuePropertyObject> paymentTypeChild = [];

    paymentTypeChild.add(ValuePropertyObject(
        title: "Bán hàng",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleTotalAmount)));

    paymentTypeChild.add(ValuePropertyObject(
        title: "Đặt cọc",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.depositTotalAmount)));

    paymentTypeChild.add(ValuePropertyObject(
        title: "Thu nợ",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptTotalAmount)));

    paymentTypeChild.add(ValuePropertyObject(
        title: "Thu khác",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalOtherAmount)));

    return paymentTypeChild;
  }

  ///
  /// * Build dữ liệu hiển thị cho chi tiết cho mục: Tiền thu trong kì
  /// * Created by NQHung on 05/11/2020
  ///
  List<OverviewSheetChildDataObject> buildCashReceiptDataSource(
      CashReceiptStatusDay cashReceiptStatusDay) {
    List<OverviewSheetChildDataObject> item = [];

    /// TỔNG ===================================================================
    List<ValuePropertyObject> paymentTypeChildList =
        buildCashReceiptDataSourceSummary(cashReceiptStatusDay);
    item.add(GroupPaymentTypeObject(childList: paymentTypeChildList));

    /// BÁN HÀNG ===============================================================
    List<ValuePropertyObject> saleChildList = [];

    /// Tiền mặt
    saleChildList.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleCashAmount)));

    /// Thẻ
    saleChildList.add(ValuePropertyObject(
        title: "Thẻ",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleCardAmount)));

    /// Voucher
    saleChildList.add(ValuePropertyObject(
        title: "Voucher",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleVoucherAmount)));

    /// Chuyển khoản
    saleChildList.add(ValuePropertyObject(
        title: "Chuyển khoản",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleTransferAmount)));

    item.add(IncomingMoneyObject(
        imageAssets: AppResources.icSale,
        titleSection: "Bán hàng",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleTotalAmount),
        childList: saleChildList));

    /// THU NỢ/THU COD =========================================================
    List<ValuePropertyObject> collectDebtChildList = [];

    collectDebtChildList.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptCashAmount)));

    collectDebtChildList.add(ValuePropertyObject(
        title: "Thẻ",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptCardAmount)));

    collectDebtChildList.add(ValuePropertyObject(
        title: "Chuyển khoản",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptTransferAmount)));

    /// Tiền mặt
    /// Thẻ
    /// Chuyển khoản
    item.add(IncomingMoneyObject(
        imageAssets: AppResources.icCod,
        titleSection: "Thu nợ/thu COD",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptTotalAmount),
        childList: collectDebtChildList));

    /// KHÁCH ĐẶT CỌC ==========================================================
    List<ValuePropertyObject> depositChildList = [];

    /// Tiền mặt
    depositChildList.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.depositCashAmount)));

    /// Thẻ
    depositChildList.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.depositCardAmount)));

    /// Chuyển khoản
    depositChildList.add(ValuePropertyObject(
        title: "Chuyển khoản",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.depositTransferAmount)));

    item.add(IncomingMoneyObject(
        imageAssets: AppResources.icCashDollar,
        titleSection: "Khách đặt cọc",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.depositTotalAmount),
        childList: depositChildList));

    /// THU KHÁC ===============================================================
    List<ValuePropertyObject> otherChildList = [];

    /// Tiền mặt
    otherChildList.add(ValuePropertyObject(
        title: "Tiền mặt",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.otherCashAmount)));

    /// Chuyển khoản
    otherChildList.add(ValuePropertyObject(
        title: "Chuyển khoản",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.otherTransferAmount)));

    item.add(IncomingMoneyObject(
        imageAssets: AppResources.icComponentOther,
        titleSection: "Thu khác",
        totalAmount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.totalOtherAmount),
        childList: otherChildList));

    return item;
  }

  ///
  /// * Build dữ liệu hiển thị cho chi tiết cho mục: Đơn hàng
  /// * Created by NQHung on 05/11/2020
  ///
  List<OverviewSheetChildDataObject> buildOrderDataSource(
      InvoiceToday invoiceToday) {
    List<OverviewSheetChildDataObject> item = [];
    List<ValuePropertyObject> deliveryOrderPropertyList = [];

    item.add(OrderTypeObject(
        imageAssets: AppResources.icSale,
        titleSection: "Tại cửa hàng",
        totalAmount: invoiceToday.totalInStoreAmount
                ?.toStringFormat(EDoubleFormat.money) ??
            "0",
        childList: []));

    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Chờ giao hàng",
        amount: invoiceToday.pendingDeliveryQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Đang giao hàng",
        amount: invoiceToday.deliveringQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Hoàn thành",
        amount: invoiceToday.deliveredQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Chờ thu COD",
        amount: invoiceToday.pendingReceiveCODQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Thất bại",
        amount:
            invoiceToday.failedQuantity?.toStringFormat(EDoubleFormat.money) ??
                "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Đã chuyển hoàn",
        amount: invoiceToday.reTransferQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));
    deliveryOrderPropertyList.add(ValuePropertyObject(
        title: "Đã hủy",
        amount: invoiceToday.cancelDeliveryQuantity
                ?.toStringFormat(EDoubleFormat.money) ??
            "0"));

    item.add(OrderTypeObject(
        imageAssets: AppResources.icDelivery,
        titleSection: "Giao hàng",
        totalAmount: invoiceToday.totalDeliveryAmount
                ?.toStringFormat(EDoubleFormat.money) ??
            "0",
        childList: deliveryOrderPropertyList));
    return item;
  }

  ///
  ///
  ///
  OverviewHeaderObject buildOverviewHeader(
      bool isComparePreviousPeriod,
      CashReceiptStatusDay cashReceiptStatusDay,
      EstimateRevenueStatusDay estimateRevenueStatusDay,
      InvoiceToday invoiceToday) {
    List<OverviewHeaderMasterObject> headerMasterList = [];

    // Doanh thu trong ngày ====================================================
    List<ValuePropertyObject> revenueTodayList =
        buildCashReceiptOrderTypeDataSource(cashReceiptStatusDay);

    OverviewSheetHeaderDataObject itemRevenueTodayHeader =
        _itemRevenueTodayHeader(isComparePreviousPeriod, cashReceiptStatusDay);

    headerMasterList.add(OverviewHeaderMasterObject(
        imageAsset: AppResources.icRevenueToday,
        header: itemRevenueTodayHeader,
        childList: revenueTodayList));

    // Tiền thu trong kỳ =======================================================
    List<ValuePropertyObject> imcomingTodayList =
        buildCashReceiptDataSourceSummary(cashReceiptStatusDay);

    OverviewSheetHeaderDataObject itemCashReceiptHeader =
        _itemCashReceiptHeader(isComparePreviousPeriod, cashReceiptStatusDay);

    headerMasterList.add(OverviewHeaderMasterObject(
        imageAsset: AppResources.icCashReceiptToday,
        header: itemCashReceiptHeader,
        childList: imcomingTodayList));

    // Doanh thu ước tính ======================================================
    List<ValuePropertyObject> estimateTodayList =
        buildEstimateRevenueDataSourceSummary(estimateRevenueStatusDay);

    OverviewSheetHeaderDataObject itemEstimateHeader =
        _itemEstimateRevenueHeader(
            isComparePreviousPeriod, estimateRevenueStatusDay);

    headerMasterList.add(OverviewHeaderMasterObject(
        imageAsset: AppResources.icEstimateRevenue,
        header: itemEstimateHeader,
        childList: estimateTodayList));

    return OverviewHeaderObject(childList: headerMasterList);
  }

  ///
  /// Build thông tin header cho Bottom Sheet khi bấm vào các
  /// thông tin
  /// + Doanh thu ước tính
  /// + Tiền thu trong kỳ
  /// + Đơn hàng
  ///
  OverviewSheetHeaderDataObject itemHeaderSheetDataSource(
      bool isComparePreviousPeriod,
      EOverviewSheetType sheetType,
      CashReceiptStatusDay cashReceiptStatusDay,
      EstimateRevenueStatusDay estimateRevenueStatusDay,
      InvoiceToday invoiceToday) {
    OverviewSheetHeaderDataObject itemHeader;

    if (sheetType == EOverviewSheetType.estimateRevenue) {
      return _itemEstimateRevenueHeader(
          isComparePreviousPeriod, estimateRevenueStatusDay);
    } else if (sheetType == EOverviewSheetType.cashReceipt) {
      return _itemCashReceiptHeader(
          isComparePreviousPeriod, cashReceiptStatusDay);
    } else if (sheetType == EOverviewSheetType.order) {
      return _itemOrderHeader(isComparePreviousPeriod, invoiceToday);
    }

    return itemHeader;
  }

  ///
  /// Thông tin header của Doanh thu ước tính
  ///
  OverviewSheetHeaderDataObject _itemEstimateRevenueHeader(
      bool isComparePreviousPeriod,
      EstimateRevenueStatusDay estimateRevenueStatusDay) {
    ReportCompareResult diff = CommonReportBusiness.computeTwoReportData(
        estimateRevenueStatusDay.estimateRevenue ?? 0,
        estimateRevenueStatusDay.previousPeriodEstimateRevenue ?? 0);

    return OverviewSheetHeaderDataObject(
        title: "Doanh thu ước tính",
        amount: NumberFormatHelper.shared
            .formatMoney(estimateRevenueStatusDay.estimateRevenue),
        diff: isComparePreviousPeriod ? diff : null);
  }

  ///
  /// Thông tin header của Doanh thu trong ngày
  ///
  OverviewSheetHeaderDataObject _itemRevenueTodayHeader(
      bool isComparePreviousPeriod, CashReceiptStatusDay cashReceiptStatusDay) {
    ReportCompareResult diff = CommonReportBusiness.computeTwoReportData(
        cashReceiptStatusDay.receiptAmountInDay ?? 0,
        cashReceiptStatusDay.previousPeriodSaleTotalAmount ?? 0);

    return OverviewSheetHeaderDataObject(
        title: "Doanh thu trong ngày",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.receiptAmountInDay),
        diff: isComparePreviousPeriod ? diff : null);
  }

  ///
  /// Thông tin header của Tiền thu trong kỳ
  ///
  OverviewSheetHeaderDataObject _itemCashReceiptHeader(
      bool isComparePreviousPeriod, CashReceiptStatusDay cashReceiptStatusDay) {
    ReportCompareResult diff = CommonReportBusiness.computeTwoReportData(
        cashReceiptStatusDay.receiptAmountInDay ?? 0,
        cashReceiptStatusDay.previousPeriodSaleTotalAmount ?? 0);

    /// Tiền thu trong kỳ
    return OverviewSheetHeaderDataObject(
        title: "Tiền thu trong kỳ",
        amount: NumberFormatHelper.shared
            .formatMoney(cashReceiptStatusDay.saleTotalAmount),
        diff: isComparePreviousPeriod ? diff : null);
  }

  ///
  /// Thông tin header của Tiền thu trong kỳ
  ///
  OverviewSheetHeaderDataObject _itemOrderHeader(
      bool isComparePreviousPeriod, InvoiceToday invoiceToday) {
    ReportCompareResult diff = CommonReportBusiness.computeTwoReportData(
        invoiceToday.getTotalQuantityInvoice() ?? 0,
        invoiceToday.getPreviousPeriodTotalQuantityInvoice() ?? 0);

    /// Đơn hàng
    return OverviewSheetHeaderDataObject(
        totalAmount: NumberFormatHelper.shared
            .formatQuantity(invoiceToday.totalInvoiceAmount),
        title: "Đơn hàng",
        amount: NumberFormatHelper.shared
            .formatQuantity(invoiceToday.getTotalQuantityInvoice()),
        diff: isComparePreviousPeriod ? diff : null);
  }
}
