import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_report_view_type.dart';
import 'package:MShopManager/enums/enum_revenue_report_type.dart';
import 'package:MShopManager/features/report/revenue/provider/report_revenue_view_model.dart';
import 'package:MShopManager/model/chart_data_source.dart';
import 'package:MShopManager/model/overview/revenue_for_time_display_item.dart';
import 'package:MShopManager/model/revenue/abstract_revenue_data_object.dart';
import 'package:MShopManager/model/revenue/revenue_data_object.dart';
import 'package:MShopManager/model/revenue/revenue_inventory_item_proportion.dart';
import 'package:MShopManager/model/service/revenue_by_items_info.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';
import 'package:mp_chart/mp/core/entry/bar_entry.dart';
import 'package:mp_chart/mp/core/entry/entry.dart';
import 'package:mp_chart/mp/core/entry/pie_entry.dart';
import 'package:mp_chart/mp/core/value_formatter/default_value_formatter.dart';

class RevenueReportBusiness {
  ///
  ///  Xử lý dữ liệu Doanh thu hàng hoá bán chạy
  /// [data] Dữ liệu Doanh thu theo mặt hàng
  ///
  List<RevenueDataObjectAbstract> buildBestRevenueItemReport(
      bool isBuildHeader, RevenueByItemsInfo data) {
    List<RevenueDataObjectAbstract> output = [];

    final rateRevenueItemList = data.rateRevenueItemList;

    /// Tổng doanh thu của nhóm mặt hàng
    double totalItemAmount = rateRevenueItemList?.fold(
        0.0, (previousValue, element) => previousValue + element.totalAmount);

    final itemList = data.bestRevenueItemList
        ?.mapList<RevenueItemsObject>((e) => RevenueItemsObject(e));

    if (itemList.isNotEmpty) {
      if (isBuildHeader) {
        output.add(RevenueHeaderObject(totalItemAmount: totalItemAmount));
      }
      output.addAll(itemList);
    }

    return output;
  }

  ///
  ///  Xử lý dữ liệu Doanh thu tỷ trọng nhóm hàng hoá
  /// [data] Dữ liệu Doanh thu theo mặt hàng
  ///
  List<RevenueDataObjectAbstract> buildRevenueProportionReport(
      RevenueByItemsInfo data) {
    List<RevenueDataObjectAbstract> output = [];

    /// Danh sách nhóm mặt hàng theo tỷ trọng
    List<RevenueInventoryItemProportion> itemProportionList = [];

    /// Tổng doanh thu của nhóm mặt hàng
    double totalItemAmount = 0;

    final rateRevenueItemList = data.rateRevenueItemList;

    if (rateRevenueItemList != null && rateRevenueItemList.isNotEmpty) {
      // Tổng số: Tỷ trọng doanh thu nhóm hàng hoá
      totalItemAmount = rateRevenueItemList?.fold(
          0.0, (previousValue, element) => previousValue + element.totalAmount);

      for (int index = 0; index < rateRevenueItemList.length; index++) {
        final item = rateRevenueItemList[index];

        double percent = 0;

        if (totalItemAmount == 0) {
          percent = 1.0 / rateRevenueItemList.length * 100;
        } else {
          percent = item.totalAmount / totalItemAmount * 100;
        }
        final color = (index < AppColor.pieChartColor.length)
            ? AppColor.pieChartColor[index]
            : AppColor.pieChartOtherColor;

        final itemName =
            (item.inventoryItemName?.equalsIgnoreCase("#Other#") == true
                    ? "Khác"
                    : item.inventoryItemName) ??
                "";

        itemProportionList.add(RevenueInventoryItemProportion(
            color: color,
            inventoryItemID: item.inventoryItemId,
            inventoryItemName: itemName,
            amount: item.totalAmount,
            percent: percent));
      }
    }

    /// Chuẩn bị dữ liệu data source cho Biểu đồ
    final entryList = _prepareProportionDataChart(itemProportionList);

    if (itemProportionList.isNotEmpty) {
      output.add(RevenueItemsChartObject(entryList: entryList));
      output.addAll(itemProportionList);
    }

    return output;
  }

  ///
  /// Chuẩn bị dữ liệu data source cho Biểu đồ
  ///
  /// Created by nqhung on 09/11/2020
  List<PieEntry> _prepareProportionDataChart(
      List<RevenueInventoryItemProportion> itemProportionList) {
    List<PieEntry> entries = List();

    for (int i = 0; i < itemProportionList.length; i++) {
      entries.add(PieEntry(
          value: itemProportionList[i].percent,
          label: itemProportionList[i].inventoryItemName));
    }
    return entries;
  }

  ///
  /// Build item từng số liệu báo cáo theo thời gian
  /// [reportBy] Kiểu xem theo Thời gian
  /// [timeReportList] Dữ liệu báo cáo theo thời gian
  ///
  List<RevenueDataObjectAbstract> buildItemTimeRevenueDataForDisplay(
      ERevenueReportType reportBy,
      List<RevenueForTimeDisplayItem> timeReportList) {
    List<RevenueDataObjectAbstract> output = [];
    List<RevenuePropertyObject> propertyList = [];

    /// Tổng doanh thu
    double totalItemAmount = 0;

    for (int i = 0; i < timeReportList.length; i++) {
      final item = timeReportList[i];

      totalItemAmount += item.totalAmount;

      var timeName = "";

      if (reportBy == ERevenueReportType.byHour) {
        timeName = "${item.timeName} giờ";
      } else if (reportBy == ERevenueReportType.byDateOfWeek) {
        timeName = item.timeName?.equalsIgnoreCase("1") == true
            ? "Chủ nhật"
            : "Thứ ${item.timeName}";
      } else if (reportBy == ERevenueReportType.byWeek) {
        timeName = "${item.timeName} tuần";
      } else if (reportBy == ERevenueReportType.byMonth) {
        timeName = "Tháng ${item.timeName}";
      } else if (reportBy == ERevenueReportType.byYear) {
        timeName = "Năm ${item.timeName}";
      } else {
        timeName = item.timeName;
      }

      propertyList.add(RevenuePropertyObject(
          index: i.toDouble(), title: timeName, amount: item.totalAmount));
    }

    output.add(RevenueHeaderObject(totalItemAmount: totalItemAmount));
    output.add(RevenueTimeChartObject(
        lineEntry: _prepareLineChartData(propertyList),
        barDataSetList: _prepareBarChartData(propertyList)));
    output.addAll(propertyList);
    return output;
  }

  ///
  /// Tạo dữ liệu cho biểu đổ đường
  /// [displayList] dữ liệu cần vẽ lên biểu đồ
  ///
  LineChartEntry _prepareLineChartData(
      List<RevenuePropertyObject> displayList) {
    final List<Entry> entry = [];
    final List<String> label = [];
    for (int i = 0; i < displayList.length; i++) {
      final item = displayList[i];
      label.add(item.title);
      entry.add(Entry(x: i.toDouble(), y: item.amount));
    }
    return LineChartEntry(label: label, entry: entry);
  }

  ///
  /// Chuẩn bị dữ liệu cho chart
  ///
  List<BarDataSet> _prepareBarChartData(
      List<RevenuePropertyObject> displayList) {
    List<BarEntry> entryList = displayList.map((e) {
      return BarEntry(x: e.index, y: e.amount);
    }).toList();

    final data = BarDataSet(entryList, "Doanh thu theo thời gian");
    data.setDrawIcons(false);
    data.setHighLightColor(AppColor.indigoA200);
    data.setValueFormatter(DefaultValueFormatter(2));
    data.setColors1([AppColor.indigoA200]);
    data.setLabel("Doanh thu theo thời gian");

    List<BarDataSet> _barDataSet = [data];
    return _barDataSet;
  }

  ///
  /// Lấy kỳ báo cáo tương ứng
  /// với kiểu xem trong [_filterSetting.eRevenueReportType]
  /// [EReportViewType.viewByPeriodTime]
  ///
  List<EReportPeriodType> getReportPeriodListByView(
      EReportViewType eReportViewType, ERevenueReportType eRevenueReportType) {
    switch (eReportViewType) {
      case EReportViewType.viewByInventoryItem:
        return [
          EReportPeriodType.thisDay,
          EReportPeriodType.yesterday,
          EReportPeriodType.thisWeek,
          EReportPeriodType.lastWeek,
          EReportPeriodType.thisMonth,
          EReportPeriodType.lastMonth,
          EReportPeriodType.thisQuarter,
          EReportPeriodType.lastQuarter,
          EReportPeriodType.thisYear,
          EReportPeriodType.lastYear
        ];
      case EReportViewType.viewByPeriodTime:
        switch (eRevenueReportType) {
          case ERevenueReportType.byHour:
            return [
              EReportPeriodType.thisDay,
              EReportPeriodType.yesterday,
              EReportPeriodType.thisWeek,
              EReportPeriodType.lastWeek,
              EReportPeriodType.thisMonth,
              EReportPeriodType.lastMonth,
              EReportPeriodType.custom
            ];
          case ERevenueReportType.byDateOfWeek:
            return [
              EReportPeriodType.thisWeek,
              EReportPeriodType.lastWeek,
              EReportPeriodType.fourLastWeek,
              EReportPeriodType.custom
            ];
          case ERevenueReportType.byDay:
            return [
              EReportPeriodType.thisMonth,
              EReportPeriodType.lastMonth,
              EReportPeriodType.january,
              EReportPeriodType.february,
              EReportPeriodType.march,
              EReportPeriodType.april,
              EReportPeriodType.may,
              EReportPeriodType.june,
              EReportPeriodType.july,
              EReportPeriodType.august,
              EReportPeriodType.september,
              EReportPeriodType.october,
              EReportPeriodType.november,
              EReportPeriodType.december,
              EReportPeriodType.custom
            ];
          case ERevenueReportType.byWeek:
            return [EReportPeriodType.fourLastWeek, EReportPeriodType.custom];
          case ERevenueReportType.byMonth:
            return [
              EReportPeriodType.thisQuarter,
              EReportPeriodType.lastQuarter,
              EReportPeriodType.thisYear,
              EReportPeriodType.lastYear,
              EReportPeriodType.sixLastMonth,
              EReportPeriodType.custom
            ];
          case ERevenueReportType.byYear:
            return [
              EReportPeriodType.threeLastYear,
              EReportPeriodType.custom,
            ];
          default:
            return [];
        }
        break;
      default:
        return [];
    }
  }
}
