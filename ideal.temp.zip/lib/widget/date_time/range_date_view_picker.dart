import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';

const String MIN_DATETIME = '1945-01-01';
const String MAX_DATETIME = '2030-12-31';

class DateRangeViewPicker extends StatefulWidget {
  final String title;
  final DateTime fromDate;
  final DateTime toDate;
  final VoidCallback onClose;
  final Function(DateTime fromDate, DateTime toData) onConfirm;

  const DateRangeViewPicker(
      {Key key,
      this.title,
      @required this.fromDate,
      @required this.toDate,
      this.onClose,
      @required this.onConfirm})
      : super(key: key);

  @override
  _DateRangeViewPickerState createState() => _DateRangeViewPickerState();
}

class _DateRangeViewPickerState extends State<DateRangeViewPicker>
    with SingleTickerProviderStateMixin {
  PageController _pageController;
  TabController _tabController;

  DateTime fromDate;
  DateTime toDate;

  @override
  void initState() {
    _pageController = PageController(initialPage: 0, keepPage: true);
    _tabController = TabController(initialIndex: 0, length: 2, vsync: this);

    fromDate = widget.fromDate;
    toDate = widget.toDate;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Dialog(
        insetPadding: const EdgeInsets.all(kVerticalSpaceMedium),
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
              color: AppColor.white, borderRadius: BorderRadius.circular(13)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: DefaultTabController(
              initialIndex: 0,
              length: 4,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  kVerticalSpaceMediumBox,
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: kHorizontalSpaceMedium),
                    child: Text(
                      widget.title ?? "Chọn khoảng thời gian",
                      style: Theme.of(context).textTheme.subtitle2,
                    ),
                  ),
                  kVerticalSpaceMediumBox,
                  TabBar(
                    controller: _tabController,
                    onTap: (indexPage) {
                      _pageController.jumpToPage(indexPage);
                    },
                    labelColor: AppColor.primaryColor,
                    unselectedLabelColor: AppColor.brown,
                    labelStyle: Theme.of(context).textTheme.bodyText2,
                    indicatorColor: AppColor.primaryColor,
                    indicatorSize: TabBarIndicatorSize.tab,
                    tabs: [
                      Tab(text: "Từ ngày"),
                      Tab(text: "Đến ngày"),
                    ],
                  ),
                  Container(
                    height: 230,
                    child: PageView(
                      physics: NeverScrollableScrollPhysics(),
                      onPageChanged: (indexPage) {
                        _tabController.animateTo(indexPage);
                      },
                      controller: _pageController,
                      children: [
                        DateSelectView(
                          date: fromDate,
                          onChange: (date, selectedIndex) {
                            setState(() {
                              fromDate = date;
                            });
                          },
                        ),
                        DateSelectView(
                          date: toDate,
                          onChange: (date, selectedIndex) {
                            setState(() {
                              toDate = date;
                            });
                          },
                        )
                      ],
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      MSButton(
                        onPressed: () {
                          widget.onClose?.call();
                          Navigator.of(context).maybePop();
                        },
                        label: "ĐÓNG",
                        buttonColor: AppColor.white,
                        textColor: AppColor.primaryColor,
                      ),
                      kHorizontalSpaceMediumBox,
                      MSButton(
                        onPressed: () {
                          widget.onConfirm?.call(fromDate, toDate);
                          Navigator.of(context).maybePop();
                        },
                        label: "ĐỒNG Ý",
                        buttonColor: AppColor.white,
                        textColor: AppColor.primaryColor,
                      ),
                      kHorizontalSpaceMediumBox,
                    ],
                  ),
                  kVerticalSpaceMediumBox
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class TimeSelectView extends StatefulWidget {
  final DateTime date;
  final Function(DateTime dateTime, List<int> selectedIndex) onChange;
  const TimeSelectView({Key key, this.date, this.onChange}) : super(key: key);

  @override
  _TimeSelectViewState createState() => _TimeSelectViewState();
}

class _TimeSelectViewState extends State<TimeSelectView> {
  @override
  Widget build(BuildContext context) {
    return TimePickerWidget(
      initDateTime: widget.date,
      locale: DateTimePickerLocale.vi,
      dateFormat: DateTimeFormatConstant.HH_MM_24,
      onChange: widget.onChange,
      pickerTheme: DateTimePickerTheme(
        showTitle: false,
        backgroundColor: Colors.white,
        cancelTextStyle: TextStyle(color: Colors.white),
        confirmTextStyle: TextStyle(color: Colors.black),
        itemTextStyle: TextStyle(color: Colors.black),
        pickerHeight: 225.0,
        titleHeight: 0.0,
        itemHeight: 35.0,
      ),
    );
  }
}

class DateSelectView extends StatefulWidget {
  final DateTime date;
  final Function(DateTime dateTime, List<int> selectedIndex) onChange;
  const DateSelectView({Key key, this.date, this.onChange}) : super(key: key);

  @override
  DateSelectViewState createState() => DateSelectViewState();
}

class DateSelectViewState extends State<DateSelectView>
    with AutomaticKeepAliveClientMixin {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return DatePickerWidget(
      onMonthChangeStartWithFirstDate: true,
      locale: DateTimePickerLocale.vi,
      initialDateTime: widget.date,
      minDateTime: DateTime.parse(MIN_DATETIME),
      maxDateTime: DateTime.parse(MAX_DATETIME),
      dateFormat: DateTimeFormatConstant.DD_MMMM_YYYY,
      pickerTheme: DateTimePickerTheme(
        showTitle: false,
        backgroundColor: Colors.white,
        cancelTextStyle: TextStyle(color: Colors.white),
        confirmTextStyle: TextStyle(color: Colors.black),
        itemTextStyle: TextStyle(color: Colors.black),
        pickerHeight: 225.0,
        titleHeight: 0.0,
        itemHeight: 35.0,
      ),
      onChange: widget.onChange,
    );
  }

  @override
  bool get wantKeepAlive => true;
}
