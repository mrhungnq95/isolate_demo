import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/v2/ms_base_dialog_v2.dart';
import 'package:MShopManager/widget/date_time/range_date_view_picker.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';

class DateViewPicker extends StatefulWidget {
  final String title;
  final DateTime date;
  final VoidCallback onClose;
  final Function(DateTime date) onConfirm;

  const DateViewPicker(
      {Key key, this.title, this.date, this.onClose, this.onConfirm})
      : super(key: key);

  @override
  _DateViewPickerState createState() => _DateViewPickerState();
}

class _DateViewPickerState extends State<DateViewPicker> {
  DateTime date;

  @override
  void initState() {
    date = widget.date;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MSBaseDialogV2(
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            kVerticalSpaceMediumBox,
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: kHorizontalSpaceMedium),
              child: Text(
                widget.title ?? "Chọn ngày",
                style: Theme.of(context).textTheme.subtitle2,
              ),
            ),
            kVerticalSpaceMediumBox,
            Container(
              height: 230,
              child: DateSelectView(
                date: date,
                onChange: (value, selectedIndex) {
                  setState(() {
                    date = value;
                  });
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                MSButton(
                  onPressed: () {
                    widget.onClose?.call();
                    Navigator.of(context).maybePop();
                  },
                  label: "ĐÓNG",
                  buttonColor: AppColor.white,
                  textColor: AppColor.primaryColor,
                ),
                kHorizontalSpaceMediumBox,
                MSButton(
                  onPressed: () {
                    widget.onConfirm?.call(date);
                    Navigator.of(context).maybePop();
                  },
                  label: "ĐỒNG Ý",
                  buttonColor: AppColor.white,
                  textColor: AppColor.primaryColor,
                ),
                kHorizontalSpaceMediumBox,
              ],
            ),
            kVerticalSpaceMediumBox
          ],
        );
      },
    );
  }
}
