import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/model/pu_invoice/pu_invoice.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import 'inkwell_view.dart';

///
/// Item phiếu nhập, xuất kho
///
class StockImportExportItemView extends StatefulWidget {
  final PUInvoice puInvoice;
  final Function onTap;
  final List<Widget> listSwipeAction;

  const StockImportExportItemView({Key key, this.puInvoice, this.onTap, this.listSwipeAction}) : super(key: key);

  @override
  _StockImportExportItemViewState createState() => _StockImportExportItemViewState();
}

class _StockImportExportItemViewState extends State<StockImportExportItemView> {
  @override
  Widget build(BuildContext context) {
    return InkWellView(
      onPressed: widget.onTap,
      child: Slidable(
        actionPane: SlidableDrawerActionPane(),
        actionExtentRatio: 0.14,
        secondaryActions: widget.listSwipeAction,
        child: Container(
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge,
              vertical: kHorizontalSpaceSmall),
          child: Column(
            children: [
              Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.puInvoice.refNo ?? '',
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
                      kVerticalSpaceTinyBox,
                      Text(
                        DateTimeFormatHelper.formatDate2String(
                          widget.puInvoice.refDate,
                          format: DateTimeFormatConstant.DD_MM_YYYY_HH_MM_24,
                        ) ?? '',
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.grey600),
                      )
                    ],
                  ),
                  kHorizontalSpaceLargeBox,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          widget.puInvoice.totalAmount?.toStringFormat(EDoubleFormat.money) ?? '',
                          style: Theme.of(context).textTheme.bodyText1.copyWith(fontSize: 16),
                        ),
                        kVerticalSpaceTinyBox,
                        Text(
                          widget.puInvoice.vendorName ?? '',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: AppColor.grey600),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: kHorizontalSpaceMedium),
                    child: Icon(
                      Icons.keyboard_arrow_right,
                      color: AppColor.grey600,
                    ),
                  )
                ],
              ),
              kVerticalSpaceMediumBox,
              Divider(
                height: 1,
                thickness: 1,
                color: AppColor.grey400,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
