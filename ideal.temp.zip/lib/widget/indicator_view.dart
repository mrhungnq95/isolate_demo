import 'package:flutter/material.dart';

class IndicatorView extends StatelessWidget {
  final int currentIndex;
  final int length;
  final Color dotColorSelected;
  final Color dotColorUnSelected;

  const IndicatorView(
      {Key key,
      this.currentIndex,
      this.length,
      this.dotColorSelected,
      this.dotColorUnSelected})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.spaceAround, // set your alignment
      children: List.generate(
          length,
          (index) => _DotView(
              isSelected: index == currentIndex,
              dotColorUnSelected: dotColorUnSelected,
              dotColorSelected: dotColorSelected)),
    );
  }
}

class _DotView extends StatelessWidget {
  final bool isSelected;
  final Color dotColorSelected;
  final Color dotColorUnSelected;

  const _DotView(
      {Key key,
      this.isSelected,
      this.dotColorSelected,
      this.dotColorUnSelected})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      margin: const EdgeInsets.symmetric(horizontal: 3),
      height: 10,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isSelected ? dotColorSelected : dotColorUnSelected),
    );
  }
}
