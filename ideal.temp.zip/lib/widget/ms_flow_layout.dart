import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/material.dart';

class MSFlowLayout<T> extends StatelessWidget {
  final String title;
  final List<T> data;
  final String Function(T) onBindLabel;
  final bool Function(T) isSelected;
  final Function(T) onTap;

  const MSFlowLayout({
    Key key,
    this.title,
    @required this.data,
    @required this.onBindLabel,
    @required this.isSelected,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Visibility(
            visible: title != null,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title ?? "",
                    style: Theme.of(context)
                        .textTheme
                        .subtitle1
                        .copyWith(fontWeight: FontWeight.bold)),
                kVerticalSpaceMediumBox
              ],
            )),
        Wrap(
          spacing: kHorizontalSpaceMedium,
          runSpacing: kHorizontalSpaceMedium,
          children: <Widget>[]
            ..addAll(data.map<MSChipView>((item) => MSChipView(
                  text: onBindLabel?.call(item) ?? '',
                  isSelected: isSelected?.call(item) ?? false,
                  onTap: () => onTap?.call(item),
                ))),
        ),
      ],
    );
  }
}

class MSChipView extends StatelessWidget {
  final String text;
  final bool isSelected;
  final VoidCallback onTap;

  const MSChipView({Key key, this.text, this.isSelected, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Chip(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
              color: isSelected ? AppColor.primaryColor : AppColor.grey400),
        ),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        label: Text(
          text,
          style: Theme.of(context).textTheme.bodyText1.copyWith(
                color: isSelected ? AppColor.white : AppColor.grey600,
              ),
        ),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        backgroundColor: isSelected ? AppColor.primaryColor : AppColor.grey50,
      ),
      onTap: onTap,
    );
  }
}
