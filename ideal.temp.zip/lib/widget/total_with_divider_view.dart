import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/widget/total_style_border_value_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class TotalWithDividerView extends StatelessWidget with PreferredSizeWidget {

  final double height;
  final String title;
  final double totalItem;
  final double value;

  TotalWithDividerView({this.height = 60, this.title, this.totalItem, this.value});

  @override
  Size get preferredSize => Size.fromHeight(height ?? 60);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceOverSmall),
      decoration: BoxDecoration(
          color: AppColor.white,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10))),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(
                left: kHorizontalSpaceLarge,
                right: kHorizontalSpaceLarge,
                top: kVerticalSpaceMedium,
                bottom: kVerticalSpaceMedium),
            child: TotalStyleBorderValueView(
              title: title,
              totalItem: totalItem,
              value: value,
            ),
          ),
        ],
      ),
    );
  }
}