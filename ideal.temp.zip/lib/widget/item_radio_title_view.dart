import 'package:MShopManager/widget/many_option_view.dart';
import 'package:flutter/material.dart';

class ItemRadioTitle<T> extends StatelessWidget {
  final T groupValue;
  final T value;
  final ValueChanged<T> onChanged;
  final String title;

  const ItemRadioTitle(
      {Key key,
      @required this.title,
      @required this.groupValue,
      @required this.value,
      @required this.onChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RadioTitle<T>(
      value: value,
      groupValue: groupValue,
      title: Text(
        title,
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: onChanged,
    );
  }
}
