import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';

class SelectCategoryItemView extends StatelessWidget {
  final String title;
  final String value;
  final VoidCallback onPressed;
  final TextStyle valueStyle;
  final Widget trailingButton;

  const SelectCategoryItemView(
      {Key key,
      this.title,
      @required this.value,
      this.valueStyle,
      this.onPressed,
      this.trailingButton})
      : super(key: key);

  Widget _trailingButton() {
    if (trailingButton != null) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [kHorizontalSpaceSmallBox, trailingButton],
      );
    }
    return kSpaceShrinkBox;
  }

  Widget _title(BuildContext context) {
    if (title != null && title.isNotEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(fontWeight: FontWeight.bold)),
          kVerticalSpaceSmallBox,
        ],
      );
    } else {
      return kSpaceShrinkBox;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _title(context),
        kVerticalSpaceMediumBox,
        Material(
          clipBehavior: Clip.hardEdge,
          borderRadius: BorderRadius.circular(10),
          color: AppColor.backgroundTextField, //AppColor.grey50,
          child: InkWell(
            splashColor: AppColor.splashColor,
            onTap: onPressed,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
              height: 46,
              decoration: BoxDecoration(
                  border: Border.all(color: AppColor.grey300),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      value,
                      style:
                          valueStyle ?? Theme.of(context).textTheme.subtitle1,
                    ),
                  ),
                  Icon(
                    Icons.chevron_right,
                    color: AppColor.grey600,
                  ),
                  _trailingButton()
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}
