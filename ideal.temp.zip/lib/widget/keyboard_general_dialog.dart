import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class KeyboardGeneralDialog extends StatelessWidget {
  final EDoubleFormat type;
  final double maxValue;
  final double initialValue;
  final String titleDialog;
  final Function(double) callback;

  const KeyboardGeneralDialog({
    Key key,
    @required this.type,
    @required this.titleDialog,
    this.maxValue,
    this.initialValue = 0,
    this.callback,
  }) : super(key: key);

  /// lấy giá trị lớn nhất mặc định
  double getDefaultMaxValue(EDoubleFormat type) {
    switch (type) {
      case EDoubleFormat.money:
        return 99999999999999;
      case EDoubleFormat.quantity:
        return 10000000;
      case EDoubleFormat.percentage:
        return 100;
    }
    return 99999999999999;
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => _ViewModel(type, initialValue, callback, titleDialog,
          maxValue == null ? getDefaultMaxValue(type) : maxValue),
      child: AlertDialog(
        backgroundColor: Colors.transparent,
        contentPadding: EdgeInsets.zero,
        insetPadding: EdgeInsets.zero,
        content: _KeyboardGeneralDialog(),
      ),
    );
  }
}

class _KeyboardGeneralDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var viewModel = Provider.of<_ViewModel>(context);
    return SafeArea(
      child: Container(
        width: size.width * 0.8,
        padding: EdgeInsets.all(kVerticalSpaceLarge),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: AppColor.white,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              viewModel.titleDialog,
              style: Theme.of(context)
                  .textTheme
                  .subtitle2
                  .copyWith(fontWeight: FontWeight.w600),
            ),
            kVerticalSpaceLargeBox,
            _ButtonBorder(Row(
              children: [
                IconButton(
                  icon: Icon(
                    Icons.clear_rounded,
                    color: Colors.red,
                    size: 28,
                  ),
                  onPressed: () => viewModel.onClear(),
                ),
                Expanded(
                  child: Consumer<_ViewModel>(
                    builder: (BuildContext context, viewModel, Widget child) {
                      return Text(
                        viewModel.calc,
                        style: Theme.of(context).textTheme.subtitle1,
                        textAlign: TextAlign.end,
                      );
                    },
                  ),
                ),
                kHorizontalSpaceMediumBox,
              ],
            )),
            kVerticalSpaceLargeBox,
            Row(
              children: [
                _Button(
                  text: '7',
                  onPressed: () => viewModel.onInput('7'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '8',
                  onPressed: () => viewModel.onInput('8'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '9',
                  onPressed: () => viewModel.onInput('9'),
                ),
                kHorizontalSpaceLargeBox,
                _IconButton(
                  icon: Icon(
                    Icons.backspace_outlined,
                    color: Colors.red,
                    size: 24,
                  ),
                  onPressed: () => viewModel.onBackSpace(),
                  onLongPress: () => viewModel.onClear(),
                ),
              ],
            ),
            kVerticalSpaceLargeBox,
            Row(
              children: [
                _Button(
                  text: '4',
                  onPressed: () => viewModel.onInput('4'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '5',
                  onPressed: () => viewModel.onInput('5'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '6',
                  onPressed: () => viewModel.onInput('6'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '-',
                  onPressed: () => viewModel.onInput('-'),
                ),
              ],
            ),
            kVerticalSpaceLargeBox,
            Row(
              children: [
                _Button(
                  text: '1',
                  onPressed: () => viewModel.onInput('1'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '2',
                  onPressed: () => viewModel.onInput('2'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '3',
                  onPressed: () => viewModel.onInput('3'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: '+',
                  onPressed: () => viewModel.onInput('+'),
                ),
              ],
            ),
            kVerticalSpaceLargeBox,
            Row(
              children: [
                _Button(
                  text: '0',
                  onPressed: () => viewModel.onInput('0'),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: viewModel.keyZero,
                  onPressed: () => viewModel.onInput(viewModel.keyZero),
                ),
                kHorizontalSpaceLargeBox,
                _Button(
                  text: NumberFormatHelper.decimalSeparator,
                  onPressed: () =>
                      viewModel.onInput(NumberFormatHelper.decimalSeparator),
                ),
                kHorizontalSpaceLargeBox,
                Consumer<_ViewModel>(
                  builder: (context, vm, child) {
                    return _Button(
                      text: vm.keyDone,
                      onPressed: () => viewModel.onDone(),
                      backgroundColor: AppColor.primaryColor,
                      colorBorder: AppColor.primaryColor,
                      textColor: AppColor.white,
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  final Icon icon;
  final VoidCallback onPressed;
  final VoidCallback onLongPress;
  final Color backgroundColor;
  final Color colorBorder;

  const _IconButton({
    Key key,
    @required this.onPressed,
    @required this.icon,
    this.backgroundColor = AppColor.white,
    this.colorBorder = AppColor.borderColor,
    this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: AspectRatio(
        aspectRatio: 1,
        child: _ButtonBorder(
          FlatButton(
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: icon,
            onPressed: onPressed,
            onLongPress: onLongPress,
          ),
          backgroundColor: backgroundColor,
          colorBorder: colorBorder,
        ),
      ),
    );
  }
}

class _Button extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color backgroundColor;
  final Color colorBorder;
  final Color textColor;

  const _Button(
      {Key key,
      @required this.text,
      @required this.onPressed,
      this.backgroundColor = AppColor.white,
      this.colorBorder = AppColor.borderColor,
      this.textColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: AspectRatio(
        aspectRatio: 1,
        child: _ButtonBorder(
          FlatButton(
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10)),
            ),
            child: Text(
              text,
              maxLines: 1,
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(color: textColor, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            onPressed: onPressed,
          ),
          backgroundColor: backgroundColor,
          colorBorder: colorBorder,
        ),
      ),
    );
  }
}

class _ButtonBorder extends StatelessWidget {
  final Widget child;
  final Color backgroundColor;
  final Color colorBorder;

  const _ButtonBorder(this.child,
      {Key key,
      this.backgroundColor = Colors.transparent,
      this.colorBorder = AppColor.borderColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: backgroundColor,
        border: Border.all(color: colorBorder),
      ),
      child: child,
    );
  }
}

class _ViewModel with ChangeNotifier {
  final listCurrency = ['USD', 'EUR', 'GBP', 'AUD', 'SGD', 'CAD', 'CHF'];

  /// các phép tính có thể thực hiện dc
  final operation = '+-';

  /// key nhập nhanh hàng nghìn
  String keyZero = '000';

  /// dùng để handle text hiển thị của nút OK
  String keyDone = 'OK';

  /// tiêu đề của dialog
  String titleDialog = '';

  /// format bàn phím
  final EDoubleFormat type;

  /// Giá trị lớn nhất có thể nhập
  final double maxValue;

  /// dữ liệu hiển thị trên ô nhập số
  String calc = '0';

  /// callback khi ấn nút OK
  final Function(double) callback;

  /// cờ check xem có phải ấn lần đầu hay không?
  bool isFirstInput = true;

  _ViewModel(
      this.type, double value, this.callback, this.titleDialog, this.maxValue) {
    // if (value > maxValue) value = maxValue;
    calc = value.toStringFormat(type);
    keyZero = _getKeyZero();
  }

  void onInput(String input) {
    if (isFirstInput) {
      calc = '0';
      isFirstInput = false;
    }

    if (calc.isEmpty || calc == '0') {
      // Nếu nhập vào là dấu thập phân
      if (input == NumberFormatHelper.decimalSeparator) {
        if (type.getDecimalDigits() == 0) {
          return;
        }
        if (calc.characters.last == '.') {
          return;
        }
        calc = '0$input';
      } else if (input == '' || input == '+') {
        // Nhập vào là phép tính +/-
        calc = '0';
      } else if (input == keyZero) {
        // Nếu nhấn 000
        calc = '0';
      } else {
        // Nhập vào số
        if (convertToDouble(input) > maxValue) {
          return;
        } else {
          calc = input;
        }
      }
      notifyListeners();
    } else {
      var isNegative = false;
      var reFormat = calc;
      if (calc.characters.first == '-') {
        isNegative = true;
        reFormat = reFormat.substring(1);
      }

      // Nhập vào là dấu thập phân
      if (input == NumberFormatHelper.decimalSeparator) {
        if (type.getDecimalDigits() == 0) {
          return;
        }
        var calcLast = reFormat.characters.last;
        if (calcLast == '.') {
          return;
        }
        // Kiểm tra nếu trước dấu thập phân là phép tính +/- thì bỏ đi
        if (calcLast == '-' || calcLast == '+') {
          reFormat = reFormat.substring(0, reFormat.length - 1);
        }
        reFormat = formatAll(reFormat);
        // Thêm dấu thập phân sau khi đã định dạng lại cách hiển thị
        reFormat += input;
      } else if (input == '-' || input == '+') {
        var calcLast = reFormat.characters.last;
        // Kiểm tra nếu trước dấu thập phân là phép tính +/- thì bỏ đi
        if (calcLast == NumberFormatHelper.decimalSeparator) {
          reFormat = reFormat.substring(0, reFormat.length - 1);
        }
        // Không cho nhập các phép tính cạnh nhau
        if (operation.contains(calcLast)) {
          return;
        }
        reFormat = formatAll(reFormat);
        // Thêm dấu thập phân sau khi đã định dạng lại cách hiển thị
        reFormat += input;
      } else {
        if (compute(calc + input) > maxValue) {
          return;
        } else {
          reFormat = formatAll(reFormat + input);
        }
      }
      // Nếu là số âm
      if (isNegative) {
        reFormat = '-' + reFormat;
      }
      calc = reFormat;
      if (calc.contains(RegExp(r'[+-]'))) {
        keyDone = '=';
      } else {
        keyDone = 'OK';
      }
      notifyListeners();
    }
  }

  void onBackSpace() {
    if (calc == '0') {
      return;
    }
    if (calc.length <= 1) {
      calc = '0';
    } else {
      // Xoá một ký tự ở cuối đi
      var input = calc.substring(0, calc.length - 1);
      calc = formatValue(input);
    }
    if (calc.contains(RegExp(r'[+-]'))) {
      keyDone = '=';
    } else {
      keyDone = 'OK';
    }
    notifyListeners();
  }

  void onClear() {
    calc = '0';
    notifyListeners();
  }

  void onDone() {
    if (keyDone == '=') {
      var rs = compute(calc);
      calc = rs.toStringFormat(type);
      keyDone = 'OK';
      notifyListeners();
    } else {
      if (callback != null) callback(convertToDouble(calc));
    }
  }

  double compute(String input) {
    var rs = 0.0;
    var listDigits = input.split(RegExp(r'[\+\-]'));
    var listOperator = [];
    for (var char in input.characters) {
      if (char == '+' || char == '-') {
        listOperator.add(char);
      }
    }

    var index = 0;
    for (var value in listDigits) {
      if (value.isEmpty) {
        value = '0';
      }
      if (index > 0 && listOperator.isNotEmpty) {
        var operator = listOperator[index - 1];
        if (operator == '+') {
          rs += convertToDouble(value);
        } else if (operator == '-') {
          rs -= convertToDouble(value);
        }
      } else {
        rs = convertToDouble(value);
      }
      index++;
    }
    return rs;
  }

  /// format lại các chữ số ngăn cách bởi các ký tự +-*/
  String formatAll(String input) {
    var rs = '';
    var listDigits = input.split(RegExp(r'[\+\-]'));
    var listOperator = [];
    for (var char in input.characters) {
      if (char == '+' || char == '-') {
        listOperator.add(char);
      }
    }
    var index = 0;
    for (var value in listDigits) {
      if (index > 0 && listOperator.isNotEmpty) {
        rs += listOperator[index - 1];
      }
      rs += formatValue(value);
      index++;
    }
    return rs;
  }

  double convertToDouble(String input) {
    return double.parse(input
        .replaceAll(NumberFormatHelper.groupSeparator, '')
        .replaceAll(NumberFormatHelper.decimalSeparator, '.'));
  }

  /// Làm sạch dữ liệu trước khi đưa vào method định dạng lại số.
  /// Xóa hết bỏ các định dạng ngăn cách số hàng nghìn, đổi lại dấu thập phân từ "," => "."
  String formatValue(String input) {
    var rs = '';
    // B1: Xoá hết các dấu ngăn cách hàng nghìn đi rồi làm việc tiếp
    // B2: Lại đổi dấu thập phân từ "," => "." rồi lại làm việc tiếp
    var strValue = input
        .replaceAll(NumberFormatHelper.groupSeparator, '')
        .replaceAll(NumberFormatHelper.decimalSeparator, '.');
    // B3: Nếu chữ số sau số thập phân > số chữ số cho phép thì xoá bớt đi ^^
    var indexOfDecimal = strValue.indexOf('.');
    if (indexOfDecimal >= 0 &&
        (strValue.length - (indexOfDecimal + 1)) > type.getDecimalDigits()) {
      strValue =
          strValue.substring(0, indexOfDecimal + 1 + type.getDecimalDigits());
    }
    // B4: Biết chết liền
    if (strValue.contains('+') || strValue.contains('-')) {
      var tempBefore = '';
      var tempAfter = '';
      for (var value in strValue.characters) {
        if (!operation.contains(value)) {
          tempBefore += value;
        } else {
          if (tempBefore.isNotEmpty) {
            tempAfter = double.parse(tempBefore).toStringFormat(type);
          }
          rs += tempAfter + value;
          tempBefore = '';
          tempAfter = '';
        }
      }
      if (tempBefore.isNotEmpty) {
        if (!operation.contains(tempBefore)) {
          tempAfter = double.parse(tempBefore).toStringFormat(type);
          rs += tempAfter;
        } else {
          rs += tempBefore;
        }
      }
    } else {
      rs = double.parse(strValue).toStringFormat(type);
    }
    return rs;
  }

  String _getKeyZero() {
    switch (type) {
      case EDoubleFormat.money:
      case EDoubleFormat.percentage:
        return listCurrency.contains(NumberFormatHelper.currencySymbol)
            ? '00'
            : '000';
      default:
        return '000';
    }
  }
}
