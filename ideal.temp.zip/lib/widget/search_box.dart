import 'dart:async';

import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// Ô tìm kiếm
class SearchBox extends StatefulWidget {
  final double height;
  final String placeholder;
  final TextEditingController controller;
  final FocusNode nodeFocus;
  final ValueChanged<String> onSearch;
  final ValueChanged<String> onSubmitted;
  final Widget trailingView;
  final Color backgroundColor;
  final Color borderColor;
  final Function onTapTextField;
  final bool isEnable;
  final TextInputAction textInputAction;
  const SearchBox(
      {Key key,
      this.height = 40,
      this.placeholder,
      this.nodeFocus,
      this.controller,
      this.onSearch,
      this.onSubmitted,
      this.backgroundColor,
      this.borderColor,
      this.trailingView,
      this.onTapTextField,
      this.textInputAction,
      this.isEnable})
      : super(key: key);

  @override
  _SearchBoxState createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> {
  Timer _searchTimer;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: widget.height,
          padding: EdgeInsets.only(left: widget.height, right: 6),
          decoration: BoxDecoration(
              color: widget.backgroundColor == null
                  ? AppColor.grey100
                  : widget.backgroundColor,
              borderRadius: BorderRadius.all(Radius.circular(12)),
              border: Border.all(
                color: widget.borderColor == null
                    ? AppColor.grey300
                    : widget.borderColor,
                width: 1,
              )),
          child: Row(
            children: [
              Expanded(
                child: CupertinoTextField(
                  focusNode: widget.nodeFocus,
                  controller: widget.controller,
                  enabled: true, // widget.isEnable ?? true,
                  onTap: widget.onTapTextField,
                  onChanged: (value) {
                    _searchTimer?.cancel();
                    _searchTimer = Timer(const Duration(milliseconds: 300), () {
                      widget.onSearch?.call(value);
                    });
                  },
                  textInputAction:
                      widget.textInputAction ?? TextInputAction.search,
                  keyboardType: TextInputType.text,
                  onSubmitted: widget.onSubmitted,
                  maxLines: 1,
                  padding: EdgeInsets.zero,
                  clearButtonMode: OverlayVisibilityMode.editing,
                  style: Theme.of(context).textTheme.bodyText1,
                  placeholder: widget.placeholder,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(
                      width: 0,
                      color: Colors.transparent,
                    ),
                  ),
                ),
              ),
              widget.trailingView ?? kSpaceShrinkBox
            ],
          ),
        ),
        SizedBox(
          height: widget.height,
          width: widget.height,
          child: Icon(
            CupertinoIcons.search,
            size: 20,
            color: AppColor.grey600,
          ),
        ),
      ],
    );
  }
}
