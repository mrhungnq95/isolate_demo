import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class PullHeaderView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ClassicHeader(
      idleText: "",
      completeText: "",
      refreshingText: "",
      releaseText: "",
      failedText: "",
    );
  }
}

class PullFooterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ClassicFooter(
      idleText: "",
      loadingText: "",
      canLoadingText: "",
      noDataText: "",
      failedText: "",
      loadStyle: LoadStyle.ShowWhenLoading,
    );
  }
}
