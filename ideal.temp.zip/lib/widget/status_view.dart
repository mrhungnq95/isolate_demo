import 'package:MShopManager/app/app_color.dart';
import 'package:flutter/material.dart';

/// Trạng thái cơ bản
class StatusView extends StatelessWidget {
  final String text;
  final Color textColor;
  final Color backgroundColor;
  final Color borderColor;

  const StatusView(this.text,
      {Key key,
      this.backgroundColor = Colors.transparent,
      this.textColor = AppColor.primaryColor,
      this.borderColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
          color: backgroundColor,
          border: Border.all(color: borderColor ?? Colors.transparent),
          borderRadius: BorderRadius.all(Radius.circular(6))),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.caption.copyWith(color: textColor),
      ),
    );
  }
}
