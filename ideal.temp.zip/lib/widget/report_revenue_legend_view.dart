import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/report/chain_store/widget/chain_store_report_item_view.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

///
///
///
class ReportRevenueLegendView extends StatelessWidget {
  final VoidCallback onRevenuePressed;
  final VoidCallback onCostPressed;
  final VoidCallback onProfitPressed;

  const ReportRevenueLegendView(
      {Key key,
      this.onRevenuePressed,
      this.onCostPressed,
      this.onProfitPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ChainStoreReportItemView(
          amount: "200.020.155",
          inventoryItemName: "Doanh thu",
          dotColor: AppColor.indigoA200,
          onPressed: onRevenuePressed,
        ),
        ChainStoreReportItemView(
          amount: "45.796.203",
          inventoryItemName: "Chi phí",
          dotColor: AppColor.orange,
          onPressed: onCostPressed,
        ),
        ChainStoreReportItemView(
          amount: "154.223.952",
          inventoryItemName: "Lợi nhuận",
          dotColor: AppColor.cyan,
          onPressed: onProfitPressed,
        )
      ],
    );
  }
}

