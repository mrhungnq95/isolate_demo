//
// Created by nqhung on 06/11/2020.
//

import 'package:flutter/material.dart';

class IconCircleBackgroundView extends StatelessWidget {
  final String imageAssetName;

  const IconCircleBackgroundView({Key key, this.imageAssetName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 46,
      height: 46,
      alignment: Alignment.center,
      //decoration: BoxDecoration(
      //    shape: BoxShape.circle, color: AppColor.indigoA200.withOpacity(0.1)),
      child: Image.asset(
        imageAssetName,
        width: 46,
        height: 46,
        fit: BoxFit.fill,
      ),
    );
  }
}
