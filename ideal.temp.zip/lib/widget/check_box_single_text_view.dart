import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

/// Check box chỉ có title
class CheckBoxSingleTextView extends StatelessWidget {

  final String title;
  final Function onTap;
  final Color colorBackground;
  final TextStyle styleTitle;

  CheckBoxSingleTextView({@required this.title, this.colorBackground, this.styleTitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWellView(
          colorBackground: colorBackground ?? AppColor.grey350,
          onPressed: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: kHorizontalSpaceLarge,
                vertical: kVerticalSpaceOverSmall),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                    width: 22,
                    height: 28,
                    child: Checkbox(
                      value: false,
                      onChanged: (value) {},
                    )),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: kHorizontalSpaceMedium),
                  child: Text(
                    title,
                    style: styleTitle ?? Theme.of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        );
  }
}