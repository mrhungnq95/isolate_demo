import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ItemSwitchView extends StatefulWidget {
  final String title;
  final String description;
  final bool isSelected;
  final Color backgroundColor;
  final VoidCallback onTap;
  final ValueChanged<bool> onChanged;

  /// The amount of space by which to inset the child.
  final EdgeInsetsGeometry margin;

  const ItemSwitchView({
    Key key,
    @required this.title,
    @required this.isSelected,
    this.backgroundColor = AppColor.grey50,
    this.onTap,
    this.onChanged,
    this.description,
    this.margin,
  }) : super(key: key);

  @override
  _ItemSwitchViewState createState() => _ItemSwitchViewState();
}

class _ItemSwitchViewState extends State<ItemSwitchView> {
  bool isSelected;
  @override
  void initState() {
    super.initState();
    this.isSelected = widget.isSelected ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: widget.margin ?? EdgeInsets.zero,
      child: InkWellView(
          colorBackground: widget.backgroundColor,
          onPressed: () {
            widget.onTap?.call();
            setState(() {
              this.isSelected = !this.isSelected;
            });
          },
          borderRadius: 10,
          child: Container(
            padding: const EdgeInsets.symmetric(
                horizontal: kHorizontalSpaceLarge,
                vertical: kVerticalSpaceSmall),
            decoration: BoxDecoration(
                border: Border.all(color: AppColor.grey400),
                borderRadius: BorderRadius.circular(10)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        child: Text(
                      widget.title,
                      style: Theme.of(context).textTheme.bodyText2,
                    )),
                    kVerticalSpaceSmallBox,
                    CupertinoSwitch(
                        activeColor: AppColor.indigo900,
                        trackColor: AppColor.grey600,
                        value: isSelected,
                        onChanged: (value) {
                          widget.onChanged?.call(value);

                          setState(() {
                            this.isSelected = !this.isSelected;
                          });
                        })
                  ],
                ),
                Visibility(
                    visible: widget.description != null,
                    child: Text(widget.description ?? "",
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.textDisableColor),
                        maxLines: 3))
              ],
            ),
          )),
    );
  }
}
