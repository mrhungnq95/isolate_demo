import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

class TextWithIconButtonView extends StatelessWidget {
  final String title;
  final Color colorTitle;
  final Icon iconLeading;
  final Icon iconTrailing;
  final EdgeInsets space;
  final Function onTap;

  TextWithIconButtonView({
    @required this.title,
    this.space = const EdgeInsets.symmetric(horizontal: kHorizontalSpaceMedium),
    this.iconLeading,
    this.iconTrailing,
    this.colorTitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: space ??
          const EdgeInsets.symmetric(horizontal: kHorizontalSpaceMedium),
      child: InkWellView(
        colorBackground: Colors.transparent,
        borderRadius: 4,
        onPressed: onTap,
        child: Padding(
          padding: const EdgeInsets.all(kHorizontalSpaceTiny),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _iconLeadingView(iconLeading: iconLeading),
              kHorizontalSpaceSmallBox,
              Text(title,
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1
                      .copyWith(color: colorTitle ?? AppColor.primaryColor)),
              _iconTrailingView(iconTrailing: iconTrailing),
            ],
          ),
        ),
      ),
    );
  }
}

///
/// Icon bên phải
///
class _iconTrailingView extends StatelessWidget {
  const _iconTrailingView({
    Key key,
    @required this.iconTrailing,
  }) : super(key: key);

  final Icon iconTrailing;

  @override
  Widget build(BuildContext context) {
    if (iconTrailing != null) {
      return iconTrailing;
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
/// Icon bên trái
///
class _iconLeadingView extends StatelessWidget {
  const _iconLeadingView({
    Key key,
    @required this.iconLeading,
  }) : super(key: key);

  final Icon iconLeading;

  @override
  Widget build(BuildContext context) {
    if (iconLeading != null) {
      return iconLeading;
    } else {
      return kSpaceShrinkBox;
    }
  }
}
