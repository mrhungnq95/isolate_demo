import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

class TextButtonView extends StatelessWidget {
  final String title;
  final Function onTap;

  TextButtonView({@required this.title, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      onPressed: onTap,
      borderRadius: 4,
      child: Padding(
        padding: const EdgeInsets.all(kHorizontalSpaceSmall),
        child: Text(
          title,
          style: Theme.of(context)
              .textTheme
              .bodyText1
              .copyWith(color: AppColor.pink),
        ),
      ),
    );
  }
}
