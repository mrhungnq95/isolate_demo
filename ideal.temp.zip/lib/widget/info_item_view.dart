import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

class InfoItemView extends StatelessWidget {
  final String title;
  final String subTitle;
  final Icon iconLeading;
  final String imageAssetLeading;
  final Icon iconTrailing;
  final String imageAssetNameTrailing;
  final Color imageAssetColorTrailing;
  final TextStyle textStyleTitle;
  final TextStyle textStyleSubTitle;
  final bool isShowRequire;
  final double height;
  final EdgeInsets padding;

  final Function onTap;

  InfoItemView(
      {this.title = '',
      this.subTitle = '',
      this.iconLeading,
      this.imageAssetLeading,
      this.textStyleTitle,
      this.iconTrailing,
      this.imageAssetNameTrailing,
      this.imageAssetColorTrailing,
      this.textStyleSubTitle,
      this.isShowRequire = false,
      this.height,
      this.padding =
          const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ??
          const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: InkWellView(
        onPressed: onTap,
        borderRadius: 10,
        colorBackground: AppColor.grey200,
        child: Container(
          height: height,
          padding: const EdgeInsets.all(kHorizontalSpaceMedium),
          decoration: BoxDecoration(
            color: AppColor.grey50,
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              _iconLeadingView(
                iconLeading: iconLeading,
                imageAssetLeading: imageAssetLeading,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    RichText(
                        text: TextSpan(
                            children: [
                          TextSpan(
                              text: isShowRequire ? ' *' : '',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText2
                                  .copyWith(color: AppColor.pink))
                        ],
                            text: title,
                            style: textStyleTitle ??
                                Theme.of(context).textTheme.bodyText2)),
                    Visibility(
                      visible: subTitle.isNotEmpty,
                      child: Text(
                        subTitle,
                        style: textStyleSubTitle ??
                            Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(color: AppColor.grey700),
                      ),
                    )
                  ],
                ),
              ),
              _iconTrailingView(iconTrailing: iconTrailing, imageAssetNameTrailing: imageAssetNameTrailing, imageAssetColorTrailing: imageAssetColorTrailing)
            ],
          ),
        ),
      ),
    );
  }
}


/// 
/// Icon trailing view
/// 
class _iconTrailingView extends StatelessWidget {
  const _iconTrailingView({
    Key key,
    @required this.iconTrailing,
    @required this.imageAssetNameTrailing,
    @required this.imageAssetColorTrailing,
  }) : super(key: key);

  final Icon iconTrailing;
  final String imageAssetNameTrailing;
  final Color imageAssetColorTrailing;

  @override
  Widget build(BuildContext context) {
      if (iconTrailing != null) {
        return iconTrailing;
      } else if (imageAssetNameTrailing != null) {
        return Image.asset(
          imageAssetNameTrailing,
          color: imageAssetColorTrailing,
          fit: BoxFit.cover,
          width: 20,
          height: 20,
        );
      } else {
        return kSpaceShrinkBox;
      }
  }
}


///
/// Build icon bên trái
///
class _iconLeadingView extends StatelessWidget {
  final Icon iconLeading;
  final String imageAssetLeading;

  _iconLeadingView({this.iconLeading, this.imageAssetLeading});

  @override
  Widget build(BuildContext context) {
    if (iconLeading == null && imageAssetLeading == null) {
      return Container();
    } else {
      return Padding(
        padding: const EdgeInsets.only(
            left: kHorizontalSpaceSmall, right: kHorizontalSpaceMedium),
        child: iconLeading ??
            Image.asset(
              imageAssetLeading,
              fit: BoxFit.fitHeight,
              width: 48,
              height: 48,
            ),
      );
    }
  }
}
