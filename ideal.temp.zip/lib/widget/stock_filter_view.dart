import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/model/stock.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'ms_flow_layout.dart';

class StockFilterController {
  int threshold = 6;
  List<Stock> listAllStock = [];

  StockFilterController({this.listAllStock = const []});

  /// lấy danh sách chi nhánh dc chọn
  String getStockIDSelected() {
    return getListStockSelected().map((e) => e.stockID).join(',');
  }

  /// lấy danh sách chi nhánh dc chọn
  List<Stock> getListStockSelected() {
    return listAllStock.where((element) => element.isSelected).toList();
  }
}

/// View Filter chọn chi nhánh
class StockFilterView extends StatelessWidget {
  final StockFilterController controller;

  const StockFilterView({Key key, @required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => _ViewModel(controller),
      builder: (context, child) => _StockFilterView(),
    );
  }
}

class _StockFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppColor.white,
      child: Consumer<_ViewModel>(
        builder: (BuildContext context, viewModel, Widget child) => Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Kho',
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(fontWeight: FontWeight.bold),
            ),
            kVerticalSpaceLargeBox,
            Padding(
              padding: const EdgeInsets.only(left: kHorizontalSpaceLarge),
              child: MSFlowLayout<Stock>(
                data: viewModel.getListStockDisplay(),
                onBindLabel: (stock) => stock.stockName,
                isSelected: (stock) => stock.isSelected,
                onTap: (stock) => viewModel.toggleStock(stock),
              ),
            ),
            Visibility(
              child: Align(
                alignment: Alignment.center,
                child: TextButton(
                  child: Text(
                    viewModel.isViewMore
                        ? 'Ẩn bớt (${viewModel.hideStockCount()} kho)'
                        : 'Xem thêm (${viewModel.hideStockCount()} kho)',
                    style: Theme.of(context).textTheme.bodyText1.copyWith(
                          color: AppColor.primaryColor,
                        ),
                  ),
                  onPressed: () {
                    viewModel.toggleViewMore();
                  },
                ),
              ),
              maintainSize: false,
              maintainAnimation: true,
              maintainState: true,
              visible: viewModel.isShowViewMore(),
            ),
          ],
        ),
      ),
    );
  }
}

class _ViewModel with ChangeNotifier {
  final StockFilterController controller;

  _ViewModel(this.controller) {
    initData();
  }

  // Đang xem thêm hay ẩn bớt
  bool isViewMore = false;

  /// Khởi tạo dữ liệu
  void initData() async {
    notifyListeners();
  }

  /// Lấy danh sách kho sẽ hiển thị
  List<Stock> getListStockDisplay() {
    if (isViewMore) {
      return controller.listAllStock;
    }
    if (controller.listAllStock.length > controller.threshold) {
      return controller.listAllStock.sublist(0, controller.threshold);
    }
    return controller.listAllStock;
  }

  bool isShowViewMore() {
    return controller.listAllStock.length > controller.threshold;
  }

  int hideStockCount() =>
      controller.listAllStock.length - controller.threshold;

  int selectStockCount() {
    var count = 0;
    controller.listAllStock.forEach((element) {
      if (element.isSelected) count++;
    });
    return count;
  }

  void toggleViewMore() {
    isViewMore = !isViewMore;
    notifyListeners();
  }

  void toggleStock(Stock stock) {
    stock.isSelected = !stock.isSelected;
    notifyListeners();
  }
}
