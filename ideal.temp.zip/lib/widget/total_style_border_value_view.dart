import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

///
/// Build item total
///
class TotalStyleBorderValueView extends StatelessWidget {
  final String title;
  final double totalItem;
  final double value;
  final EDoubleFormat doubleFormat;
  final bool isBorderQuantityView;

  TotalStyleBorderValueView(
      {this.title,
      this.totalItem,
      this.value,
      this.doubleFormat = EDoubleFormat.quantity,
      this.isBorderQuantityView});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Text(
              title ?? '',
              style:
                  Theme.of(context).textTheme.bodyText1.copyWith(fontSize: 16),
            ),
            QuantityView(
              isBorderQuantityView: isBorderQuantityView ?? true,
              totalItem: totalItem,
            )
          ],
        ),
        Text(value?.toStringFormat(doubleFormat) ?? '',
            style: Theme.of(context).textTheme.subtitle2)
      ],
    );
  }
}

///
/// View quantity
///
class QuantityView extends StatelessWidget {
  final bool isBorderQuantityView;
  final double totalItem;

  QuantityView({this.isBorderQuantityView, this.totalItem});

  @override
  Widget build(BuildContext context) {
    if (isBorderQuantityView) {
      return TextValueBorderView(
        marginSpace: kHorizontalSpaceSmall,
        value: totalItem?.toStringFormat(EDoubleFormat.quantity) ?? '',
        textSize: 16,
      );
    } else {
      return Text(
        totalItem?.toStringFormat(EDoubleFormat.quantity) ?? '',
        style: Theme.of(context).textTheme.bodyText2,
      );
    }
  }
}
