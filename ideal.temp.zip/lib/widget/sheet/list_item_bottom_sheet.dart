import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/widget/item/item_view_selectable.dart';
import 'package:MShopManager/widget/msview/ms_circle_style_bottom_sheet_view.dart';
import 'package:flutter/material.dart';

class ListItemBottomSheetView<T> extends StatelessWidget {
  final String title;

  final bool Function(T item) isChecked;
  final String Function(T item) titleBuilder;

  final List<T> dataSourceList;

  const ListItemBottomSheetView(
      {Key key,
      @required this.title,
      @required this.dataSourceList,
      @required this.titleBuilder,
      @required this.isChecked})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.white,
      padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
      child: MSCircleStyleBottomSheetView(title: title, children: [
        kVerticalSpaceLargeBox,
        kVerticalSpaceMediumBox,
        Expanded(
            child: ListView.builder(
          padding: EdgeInsets.zero,
          itemBuilder: (context, index) {
            final item = dataSourceList[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
              child: ItemViewSelectable<T>(
                title: titleBuilder(item),
                isChecked: isChecked(item),
                onPressed: () async {
                  FocusScope.of(context).unfocus();

                  await Future.delayed(Duration(milliseconds: 500));

                  NavigationHelper.shared.pop(data: item);
                },
              ),
            );
          },
          itemCount: dataSourceList?.length ?? 0,
        ))
      ]),
    );
  }
}
