import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// view header phần detail tồn kho
class StockInventoryItemHeaderView extends StatelessWidget {
  final String label;
  final String value;

  const StockInventoryItemHeaderView({Key key, this.label, this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(label, style: Theme
              .of(context)
              .textTheme
              .bodyText1,), flex: 2,),
        Expanded(
          child: Text(value, style: Theme
              .of(context)
              .textTheme
              .bodyText1, textAlign: TextAlign.end,), flex: 3,),
      ],
    );
  }
}