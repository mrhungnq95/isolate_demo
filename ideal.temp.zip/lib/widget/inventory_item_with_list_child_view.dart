import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/model/inventory_item/inventory_item.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_cached_network_image.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import 'common/expanded_section_view.dart';
import 'msview/ms_circle_button.dart';

class InventoryItemWithListChildView extends StatefulWidget {
  final InventoryItem inventoryItem;

  /// Có cho phép show các theo thuộc tính của hàng hóa hay không?
  final bool isEnableExpandChild;

  /// Là item con
  final bool isChildItem;
  final List<Widget> listSwipeAction;
  final List<String> childList;
  final TextStyle titleStyle;

  final VoidCallback onPress;

  const InventoryItemWithListChildView(
      {Key key,
      @required this.inventoryItem,
      this.listSwipeAction,
      this.isEnableExpandChild = false,
      this.childList,
      this.titleStyle,
      this.isChildItem = false,
      @required this.onPress})
      : super(key: key);

  @override
  _InventoryItemWithListChildViewState createState() =>
      _InventoryItemWithListChildViewState();
}

class _InventoryItemWithListChildViewState
    extends State<InventoryItemWithListChildView> {
  bool isExpanded = false;
  bool isSelectMoreItem = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: widget.isChildItem
          ? EdgeInsets.zero
          : const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceOverSmall,
            ),
      margin: isSelectMoreItem
          ? const EdgeInsets.symmetric(vertical: kHorizontalSpaceOverSmall)
          : EdgeInsets.zero,
      child: InkWellView(
        borderRadius: 10,
        colorBackground: isSelectMoreItem
            ? AppColor.splashColor.withOpacity(0.1)
            : Colors.transparent,
        onLongPressed: () {
          // setState(() {
          //   isSelectMoreItem = !isSelectMoreItem;
          // });
        },
        onPressed: () {
          setState(() {
            isExpanded = !isExpanded;
          });
        },
        child: Slidable(
          actionPane: SlidableDrawerActionPane(),
          actionExtentRatio: 0.16,
          secondaryActions: widget.listSwipeAction,
          child: Container(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: kHorizontalSpaceOverSmall,
                    right: kHorizontalSpaceOverSmall,
                    top: kVerticalSpaceMedium,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      LeadingButtonView(
                        isChildItem: widget.isChildItem,
                        isEnableExpandChild: widget.isEnableExpandChild,
                        isExpanded: isExpanded,
                        onTap: () {
                          setState(() {
                            isExpanded = !isExpanded;
                          });
                        },
                      ),
                      MSCachedNetworkImage(
                        borderRadius: BorderRadius.circular(10),
                        height: 46,
                        width: 46,
                        imageUrl: UrlHelper.shared.getUrlInventoryItemImage(
                            pictureId: widget.inventoryItem.pictureID,
                            ext: widget.inventoryItem.ext ?? '.png',
                            pictureType: widget.inventoryItem.pictureType ?? 1,
                            width: 46,
                            height: 46),
                        // "https://bucket.nhanh.vn/store/2071/ps/20200615/49997184818_dcea40764a_k.jpg",
                        imageAssetDefault: Image.asset(
                          AppResources.imageDefault,
                          color: null,
                          width: 48,
                          height: 48,
                        ),
                      ),
                      kHorizontalSpaceMediumBox,
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.inventoryItem.inventoryItemName ?? '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: widget.titleStyle ??
                                  Theme.of(context)
                                      .textTheme
                                      .bodyText2
                                      .copyWith(
                                          color: AppColor.textSecondaryColor),
                            ),
                            Visibility(
                              visible: widget
                                      .inventoryItem?.skuCode?.isEmptyOrNull ==
                                  false,
                              child: Text(
                                widget.inventoryItem?.skuCode ?? '',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1
                                    .copyWith(
                                        fontSize: 16,
                                        color: AppColor.textSecondaryColor),
                              ),
                            ),
                            Text(
                              widget.inventoryItem?.unitPrice
                                  ?.toStringFormat(EDoubleFormat.money),
                              maxLines: 1,
                              style: Theme.of(context)
                                  .textTheme
                                  .subtitle1
                                  .copyWith(fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                      ),
                      TextValueBorderView(
                        value: widget.inventoryItem.quantity
                            .toStringFormat(EDoubleFormat.quantity),
                      ),
                    ],
                  ),
                ),
                kVerticalSpaceMediumBox,
                Visibility(
                  visible: !isSelectMoreItem,
                  child: Divider(
                    height: 1,
                    thickness: 1,
                    color: AppColor.grey400,
                  ),
                ),
                ListChildItemView(
                  childList: widget.childList,
                  isEnableExpandChild: widget.isEnableExpandChild,
                  isExpand: isExpanded,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Build View bên trái
class LeadingButtonView extends StatelessWidget {
  final bool isChildItem;
  final bool isEnableExpandChild;
  final bool isExpanded;
  final bool isSelectMoreItem;
  final Function onTap;

  LeadingButtonView(
      {@required this.isChildItem,
      @required this.isEnableExpandChild,
      @required this.isExpanded,
      this.isSelectMoreItem = false,
      @required this.onTap});

  @override
  Widget build(BuildContext context) {
    if (isSelectMoreItem) {
      return SizedBox(
          width: 22,
          height: 28,
          child: Checkbox(
            value: false,
            onChanged: (value) {},
          ));
    } else if (isChildItem) {
      return SizedBox(
        width: 30 + kHorizontalSpaceMedium, // + Thêm padding
        height: 30,
      );
    } else {
      return Visibility(
        visible: isEnableExpandChild,
        child: Padding(
          padding: const EdgeInsets.only(right: kHorizontalSpaceMedium),
          child: MSCircleButton(
              size: 30,
              borderSide: BorderSide(color: AppColor.grey300),
              color: Colors.white,
              icon: Icon(
                isExpanded ? Icons.remove : Icons.add,
                color: isExpanded ? AppColor.pink : AppColor.indigo900,
              ),
              onTap: onTap),
        ),
      );
    }
  }
}

///
/// Build ds các item con
///
class ListChildItemView extends StatelessWidget {
  /// Có cho phép show các theo thuộc tính của hàng hóa hay không?
  final bool isEnableExpandChild;
  final bool isExpand;
  final List<String> childList;

  ListChildItemView(
      {@required this.isEnableExpandChild,
      this.isExpand,
      @required this.childList});

  @override
  Widget build(BuildContext context) {
    if (isEnableExpandChild ?? false) {
      return ExpandedSection(
        expand: isExpand ?? false,
        child: _InventoryItemChildView(childList: childList),
      );
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
/// View hiển thị các item con
///
class _InventoryItemChildView extends StatelessWidget {
  final List<String> childList;

  const _InventoryItemChildView({@required this.childList});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: (context, index) {
        final childItem = childList[index];
        return InventoryItemWithListChildView(
          // propertyInventoryItem: childItem,
          isEnableExpandChild: false,
          isChildItem: true,
          onPress: () {}, inventoryItem: null,
        );
      },
      itemCount: childList.length,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
    );
  }
}
