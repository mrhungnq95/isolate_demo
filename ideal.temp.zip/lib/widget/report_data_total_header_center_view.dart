import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

class ReportDataTotalHeaderCenterView extends StatelessWidget {
  final String title;
  final double amount;

  const ReportDataTotalHeaderCenterView(
      {Key key, @required this.title, @required this.amount})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          title ?? "",
          style: Theme.of(context)
              .textTheme
              .bodyText1
              .copyWith(color: AppColor.textColor),
        ),
        Text(
          amount?.toStringFormat(EDoubleFormat.money) ?? "0",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(color: AppColor.textColor),
        )
      ],
    );
  }
}
