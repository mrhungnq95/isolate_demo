import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/quantity_border_style_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'circle_button_view.dart';
import 'keyboard_general_dialog.dart';

class ChangeQuantityView extends StatefulWidget {
  final Function(double value) changeQuantityAction;

  ChangeQuantityView({this.changeQuantityAction});

  @override
  _ChangeQuantityViewState createState() => _ChangeQuantityViewState();
}

class _ChangeQuantityViewState extends State<ChangeQuantityView> {
  double currentQuantity;

  _ChangeQuantityViewState({this.currentQuantity = 0});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        _LeadingButtonView(
          currentQuantity: currentQuantity,
          widget: widget,
          changeQuantityAction: (value) {
            if (currentQuantity > 0) {
              currentQuantity--;
              widget.changeQuantityAction(currentQuantity);
            }
          },
        ),
        _QuantityView(
          currentQuantity: currentQuantity,
          widget: widget,
          changeQuantityAction: (value) {
            currentQuantity = value;
            widget.changeQuantityAction(currentQuantity);
            Navigator.pop(context);
          },
        ),
        CircleButtonView(
          onTap: () {
            setState(() {
              currentQuantity++;
              widget.changeQuantityAction(currentQuantity);
            });
          },
          icon: Icon(
            Icons.add,
            color: AppColor.indigo700,
          ),
        )
      ],
    );
  }
}

///
/// Build button bên trái
///
class _LeadingButtonView extends StatelessWidget {
  const _LeadingButtonView({
    Key key,
    @required this.currentQuantity,
    @required this.widget,
    this.changeQuantityAction,
  }) : super(key: key);

  final double currentQuantity;
  final ChangeQuantityView widget;
  final Function(double) changeQuantityAction;

  @override
  Widget build(BuildContext context) {
      if (currentQuantity > 0) {
        return Padding(
          padding: const EdgeInsets.only(right: kHorizontalSpaceSmall),
          child: CircleButtonView(
            onTap: () {
              changeQuantityAction(currentQuantity);
            },
            icon: Icon(
              Icons.remove,
              color: AppColor.pink,
            ),
          ),
        );
      } else {
        return kSpaceShrinkBox;
      }
  }
}

///
/// View nhập SL
///
class _QuantityView extends StatelessWidget {
  const _QuantityView({
    Key key,
    @required this.currentQuantity,
    @required this.widget,
    this.changeQuantityAction,
  }) : super(key: key);

  final double currentQuantity;
  final ChangeQuantityView widget;
  final Function(double) changeQuantityAction;

  @override
  Widget build(BuildContext context) {
      if (currentQuantity > 0) {
        return Padding(
          padding: const EdgeInsets.only(right: kHorizontalSpaceSmall),
          child: QuantityBorderStyleView(
              quantity: currentQuantity,
              onPressed: () {
                showDialog(
                    context: context,
                    child: KeyboardGeneralDialog(
                      type: EDoubleFormat.quantity,
                      titleDialog: 'Nhập số lượng',
                      initialValue: currentQuantity,
                      callback: (value) {
                        changeQuantityAction(value);
                      },
                    ));
              }),
        );
      } else {
        return kSpaceShrinkBox;
      }
  }
}
