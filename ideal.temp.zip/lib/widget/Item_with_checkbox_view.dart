import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

///
/// Item phiếu nhập kho
///
class ItemWithCheckboxView extends StatelessWidget {
  
  final String titleLeft;
  final String titleRight;
  final String subTitleLeft;
  final String subTitleRight;
  final Function onTap;

  ItemWithCheckboxView(
      {this.titleLeft = '',
      this.titleRight = '',
      this.subTitleLeft = '',
      this.subTitleRight = '',
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: kHorizontalSpaceLarge, vertical: kVerticalSpaceSmall),
      child: InkWellView(
        borderRadius: 10,
        onPressed: onTap,
        child: Container(
          decoration: BoxDecoration(
              color: AppColor.grey200.withOpacity(0.8),
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge,
              vertical: kVerticalSpaceMedium),
          child: Row(
            children: [
              SizedBox(
                  width: 22,
                  height: 28,
                  child: Checkbox(
                    value: false,
                    onChanged: (value) {},
                  )),
              kHorizontalSpaceMediumBox,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    titleLeft,
                    style: Theme.of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(fontWeight: FontWeight.bold),
                  ),
                  kHorizontalSpaceMediumBox,
                  Visibility(
                    visible: subTitleLeft != null && subTitleLeft.isNotEmpty,
                    child: Text(subTitleLeft,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.grey600)),
                  )
                ],
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      titleRight,
                      style: Theme.of(context)
                          .textTheme
                          .bodyText2
                          .copyWith(color: AppColor.primaryColor),
                      textAlign: TextAlign.end,
                    ),
                    Visibility(
                      visible: subTitleRight != null && subTitleRight.isNotEmpty,
                      child: Text(subTitleRight,
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: AppColor.grey600)),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
