
import 'package:MShopManager/app/app_constant.dart';
import 'package:flutter/cupertino.dart';

class LoadMoreScrollController extends ScrollController {
  final int threshold;
  final VoidCallback onLoadMore;

  LoadMoreScrollController(this.onLoadMore, {this.threshold = AppConstant.LOAD_MORE_THRESHOLD}) {
    addListener(_onScroll);
  }

  void _onScroll() {
    if (isEndOfPage()) {
      onLoadMore?.call();
    }
  }

  /// đang đứng ở cuối cùng
  bool isEndOfPage() => position.extentAfter <= threshold;
}