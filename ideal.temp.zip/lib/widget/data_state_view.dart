import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class DataStateView extends StatelessWidget {
  final bool isAllowRetry;
  final VoidCallback onRetryPressed;

  const DataStateView(
      {Key key, @required this.onRetryPressed, this.isAllowRetry = true})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            AppResources.icEmptyChart,
            fit: BoxFit.fill,
            width: 80,
            height: 80,
          ),
          kVerticalSpaceLargeBox,
          Text("Không có dữ liệu"),
          kVerticalSpaceLargeBox,
          Visibility(
            visible: isAllowRetry,
            child: MSButton(
              minWidth: 150,
              onPressed: onRetryPressed,
              height: 40,
              label: "Thử lại",
              buttonColor: AppColor.white,
              buttonColorDisable: AppColor.white,
              iconData: Icons.sync,
              textColor: AppColor.indigo800,
              borderColor: AppColor.indigo800,
              iconColor: AppColor.indigo800,
            ),
          )
        ],
      ),
    );
  }
}
