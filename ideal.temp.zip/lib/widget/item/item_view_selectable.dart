import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class ItemViewSelectable<T> extends StatelessWidget {
  final String title;
  final bool isChecked;

  final VoidCallback onPressed;
  const ItemViewSelectable(
      {Key key, @required this.title, this.onPressed, this.isChecked = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      onPressed: onPressed,
      borderRadius: 10,
      colorBackground: isChecked ? AppColor.indigoA50 : AppColor.white,
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          border: Border.all(
              color: isChecked ? AppColor.deepPurple200 : AppColor.grey300),
          borderRadius: BorderRadius.circular(10),
        ),
        padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Text(title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodyText1),
            ),
            Visibility(
                visible: isChecked == true,
                child: Icon(
                  Icons.check,
                  color: AppColor.indigoA200,
                ))
          ],
        ),
      ),
    );
  }
}
