import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class ItemDescriptionViewSelectable extends StatelessWidget {
  final String title;
  final String description;
  final bool isChecked;

  final VoidCallback onPressed;
  const ItemDescriptionViewSelectable({
    Key key,
    @required this.title,
    @required this.description,
    this.onPressed,
    this.isChecked = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      onPressed: onPressed,
      borderRadius: 10,
      colorBackground: isChecked ? AppColor.indigoA50 : AppColor.white,
      child: Container(
        height: 72,
        decoration: BoxDecoration(
          border: Border.all(
              color: isChecked ? AppColor.deepPurple200 : AppColor.grey300),
          borderRadius: BorderRadius.circular(10),
        ),
        padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyText1),
                  Text(description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .caption
                          .copyWith(color: AppColor.grey600)),
                ],
              ),
            ),
            Visibility(
                visible: isChecked == true,
                child: Icon(
                  Icons.check,
                  color: AppColor.indigoA200,
                ))
          ],
        ),
      ),
    );
  }
}
