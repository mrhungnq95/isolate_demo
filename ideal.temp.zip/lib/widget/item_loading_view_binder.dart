import 'package:flutter/material.dart';

class LoadingObject { }

class ItemLoadingViewBinder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      child: Center(
        child: SizedBox(
          height: 36,
          width: 36,
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }

}