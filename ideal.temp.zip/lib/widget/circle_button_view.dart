import 'package:MShopManager/app/app_color.dart';
import 'package:flutter/cupertino.dart';
import 'inkwell_view.dart';

class CircleButtonView extends StatelessWidget {
  final Icon icon;
  final Function onTap;

  CircleButtonView({this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      borderRadius: 22,
      onPressed: onTap,
      child: Container(
        height: 44,
        width: 44,
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            borderRadius: BorderRadius.circular(22)),
        child: icon,
      ),
    );
  }
}
