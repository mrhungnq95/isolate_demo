import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class SelectCategoryItemRoundedView extends StatelessWidget {
  final String title;
  final String value;
  final VoidCallback onPressed;
  final TextStyle valueStyle;
  final bool isShowArrowRight;
  final bool isShowCheckBoxLeading;
  final bool isRequire;
  final Widget trailingView;
  final Widget bottomView;

  const SelectCategoryItemRoundedView(
      {Key key,
      this.title,
      this.value,
      this.valueStyle,
      this.onPressed,
      this.trailingView,
      this.isShowArrowRight = true,
      this.isShowCheckBoxLeading = false,
      this.bottomView,
      this.isRequire = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      borderRadius: 10,
      colorBackground: AppColor.backgroundTextField,
      onPressed: onPressed,
      child: Container(
        constraints: BoxConstraints(minHeight: 62),
        padding: const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _SpaceView(bottomView: bottomView),
            Row(
              children: [
                Visibility(
                  visible: isShowCheckBoxLeading,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(right: kHorizontalSpaceMedium),
                    child: SizedBox(
                        width: 22,
                        height: 28,
                        child: Checkbox(
                          value: false,
                          onChanged: (value) {},
                        )),
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _TitleView(
                          title: title, isRequire: isRequire, context: context),
                      _ValueView(value: value, valueStyle: valueStyle)
                    ],
                  ),
                ),
                _TrailingView(
                  trailingView: trailingView,
                ),
                Visibility(
                  visible: isShowArrowRight,
                  child: Icon(
                    Icons.chevron_right,
                    color: AppColor.grey600,
                  ),
                )
              ],
            ),
            _SpaceView(bottomView: bottomView),
            _BottomView(bottomView: bottomView),
            _SpaceView(bottomView: bottomView)
          ],
        ),
      ),
    );
  }
}

class _TitleView extends StatelessWidget {
  const _TitleView({
    Key key,
    @required this.title,
    @required this.isRequire,
    @required this.context,
  }) : super(key: key);

  final String title;
  final bool isRequire;
  final BuildContext context;

  @override
  Widget build(BuildContext context) {
    if (title != null && title.isNotEmpty) {
      return RichText(
          text: TextSpan(
              text: title,
              style:
                  Theme.of(context).textTheme.bodyText1.copyWith(fontSize: 13),
              children: [
            TextSpan(
                text: isRequire ? ' *' : '',
                style: TextStyle(color: AppColor.pink))
          ]));
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
/// Build view bên phải row
///
class _TrailingView extends StatelessWidget {
  const _TrailingView({
    Key key,
    @required this.trailingView,
  }) : super(key: key);

  final Widget trailingView;

  @override
  Widget build(BuildContext context) {
    if (trailingView != null) {
      return trailingView;
    }
    return kSpaceShrinkBox;
  }
}

///
/// View Space
///
class _SpaceView extends StatelessWidget {
  const _SpaceView({
    Key key,
    @required this.bottomView,
  }) : super(key: key);

  final Widget bottomView;

  @override
  Widget build(BuildContext context) {
    if (bottomView != null) {
      return kVerticalSpaceMediumBox;
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
/// Bottom View
///
class _BottomView extends StatelessWidget {
  const _BottomView({
    Key key,
    @required this.bottomView,
  }) : super(key: key);

  final Widget bottomView;

  @override
  Widget build(BuildContext context) {
    if (bottomView != null) {
      return bottomView;
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
///
///
class _ValueView extends StatelessWidget {
  const _ValueView({
    Key key,
    @required this.value,
    @required this.valueStyle,
  }) : super(key: key);

  final String value;
  final TextStyle valueStyle;

  @override
  Widget build(BuildContext context) {
//    if (value != null && value.isNotEmpty) {
    return Padding(
      padding: const EdgeInsets.only(top: kVerticalSpaceSmall),
      child: Text(
        value ?? '',
        maxLines: 2,
        style: valueStyle ?? Theme.of(context).textTheme.subtitle1,
      ),
    );
//    } else {
//      return kSpaceShrinkBox;
//    }
  }
}
