//
// Created by vô khuyết on 04/11/2020.
//
import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/material.dart';

class TextValueBorderView extends StatelessWidget {
  const TextValueBorderView(
      {@required this.value,
      this.textSize,
      this.textColor,
      this.backgroundColor,
      this.marginSpace});

  final String value;
  final double textSize;
  final Color textColor;
  final Color backgroundColor;
  final double marginSpace;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
          horizontal: marginSpace == null ? 0.0 : marginSpace),
      padding: const EdgeInsets.symmetric(
          horizontal: kVerticalSpaceMedium, vertical: 2),
      child: Text(value,
          style: Theme.of(context).textTheme.bodyText2.copyWith(
              color: textColor ?? AppColor.indigo900,
              fontSize: textSize)),
      decoration: BoxDecoration(
          color: backgroundColor ?? AppColor.indigoA200.withOpacity(0.2),
          borderRadius: BorderRadius.circular(10)),
    );
  }
}
