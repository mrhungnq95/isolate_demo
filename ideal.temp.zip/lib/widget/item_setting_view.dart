import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class ItemSettingView extends StatelessWidget {
  final String iconLeadingAsset;
  final Color iconColorLeading;
  final String title;
  final Color backgroundColor;
  final Widget widgetTrailing;
  final Function onTap;
  final EdgeInsets pading;

  const ItemSettingView(
      {Key key,
      @required this.iconLeadingAsset,
      @required this.title,
      this.iconColorLeading = Colors.grey,
      this.pading,
      this.backgroundColor,
      this.widgetTrailing,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: pading ?? EdgeInsets.zero,
      child: InkWellView(
        colorBackground: backgroundColor,
        onPressed: onTap,
        borderRadius: 10,
        child: Container(
          padding: const EdgeInsets.all(kHorizontalSpaceMedium),
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.grey400),
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            children: <Widget>[
              Image.asset(
                iconLeadingAsset,
                color: iconColorLeading,
                fit: BoxFit.fitWidth,
                width: 24,
                height: 24,
              ),
              kHorizontalSpaceLargeBox,
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.subtitle1,
                ),
              ),
              widgetTrailing ??
                  Icon(
                    Icons.keyboard_arrow_right,
                    color: AppColor.grey600,
                  )
            ],
          ),
        ),
      ),
    );
  }
}
