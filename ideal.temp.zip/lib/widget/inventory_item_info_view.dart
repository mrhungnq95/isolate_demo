import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_manage_item_type.dart';
import 'package:MShopManager/model/pu_invoice/pu_invoice_detail.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import 'text/text_value_border_view.dart';

class InventoryItemInfoView extends StatelessWidget {
  final String titleLeading;
  final String subTitleLeading;
  final String titleTrailing;
  final String subTitleTrailing;

  final PUInvoiceDetail puInvoiceDetail;

  final TextStyle txStyleTitleLeading;
  final TextStyle txStyleSubTitleLeading;
  final TextStyle txStyleTitleTrailing;
  final TextStyle txStylesubTitleTrailing;
  final bool isShowDivider;
  final EdgeInsets padding;

  final List<Widget> listSwipeAction;

  InventoryItemInfoView({
    this.puInvoiceDetail,
    this.titleLeading,
    this.subTitleLeading,
    this.titleTrailing,
    this.subTitleTrailing,
    this.txStyleTitleLeading,
    this.txStyleSubTitleLeading,
    this.txStyleTitleTrailing,
    this.txStylesubTitleTrailing,
    this.listSwipeAction,
    this.isShowDivider = true,
    this.padding = const EdgeInsets.symmetric(
      horizontal: kHorizontalSpaceLarge,
    ),
  });

  @override
  Widget build(BuildContext context) {
    return Slidable(
      actionPane: SlidableDrawerActionPane(),
      actionExtentRatio: 0.16,
      secondaryActions: listSwipeAction,
      child: Column(
        children: [
          Padding(
            padding: padding,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            titleLeading ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: txStyleTitleLeading ??
                                Theme.of(context).textTheme.bodyText1,
                          ),
                          Text(subTitleLeading ?? '',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: txStyleSubTitleLeading ??
                                  Theme.of(context)
                                      .textTheme
                                      .bodyText1
                                      .copyWith(
                                          color: AppColor.textSecondaryColor)),
                        ],
                      ),
                    ),
                    kHorizontalSpaceMediumBox,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(titleTrailing ?? '',
                            style: txStyleTitleTrailing ??
                                Theme.of(context).textTheme.bodyText1),
                        Text(subTitleTrailing ?? '',
                            style: txStylesubTitleTrailing ??
                                Theme.of(context).textTheme.bodyText1),
                      ],
                    )
                  ],
                ),

                /// Khuyến mãi + thuế
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildDiscountView(),
                    buildVATView(),
                  ],
                ),
                /// lô, serial/IMEI
                buildLotSerialView(),
              ],
            ),
          ),
          Visibility(
            visible: isShowDivider,
            child: Padding(
              padding: const EdgeInsets.only(top: kHorizontalSpaceMedium),
              child: Divider(
                height: 1,
                thickness: 1,
                color: AppColor.grey400,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLotSerialView() {
    if (puInvoiceDetail == null) return kSpaceShrinkBox;
    return Builder(
      builder: (context) {
        if (MISACommon.isEmpty(puInvoiceDetail.serials) &&
            MISACommon.isEmpty(puInvoiceDetail.lotNo)) {
          return kSpaceShrinkBox;
        }
        var value;
        if (puInvoiceDetail.manageType == EManageItemType.serial.value) {
          value = 'Serial/IMEI(${puInvoiceDetail.serials})';
        } else if (puInvoiceDetail.manageType == EManageItemType.lot.value) {
          value =
              '${puInvoiceDetail.lotNo} (${DateTimeFormatHelper.formatDate2String(puInvoiceDetail.expiryDate, format: DateTimeFormatConstant.DD_MM_YYYY)}))';
        } else {
          return kSpaceShrinkBox;
        }
        return Container(
          margin: EdgeInsets.only(top: kVerticalSpaceTiny),
          padding: const EdgeInsets.symmetric(
            horizontal: kVerticalSpaceSmall,
            vertical: 4,
          ),
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyText1.copyWith(
                color: AppColor.indigo900, fontWeight: FontWeight.w500),
          ),
          decoration: BoxDecoration(
            color: AppColor.indigoA200.withOpacity(0.2),
            borderRadius: BorderRadius.circular(6),
          ),
        );
      },
    );
  }

  /// build thông tin thuế
  Widget buildVATView() {
    if (puInvoiceDetail == null) return kSpaceShrinkBox;
    return Builder(
      builder: (context) {
        // Thuế
        final vatRateInfo = (puInvoiceDetail.vatRate > 0
            ? 'VAT ${puInvoiceDetail.vatRate.toStringFormat(EDoubleFormat.percentage)}% '
            : '');
        final vatInfo = vatRateInfo +
            (puInvoiceDetail.vatAmount > 0
                ? '(${puInvoiceDetail.vatAmount.toStringFormat(EDoubleFormat.money)})'
                : '');
        if (MISACommon.isEmpty(vatInfo)) {
          return kSpaceShrinkBox;
        }
        return Text(
          vatInfo,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(context).textTheme.bodyText1.copyWith(
                color: AppColor.orange,
              ),
        );
      },
    );
  }

  /// build View khuyến mại
  Widget buildDiscountView() {
    if (puInvoiceDetail == null) return kSpaceShrinkBox;
    return Builder(
      builder: (context) {
        // Khuyến mại
        double discountAmount = puInvoiceDetail.quantity *
            puInvoiceDetail.unitPrice *
            puInvoiceDetail.discountRate /
            100;
        final discountRateInfo = puInvoiceDetail.discountRate > 0
            ? '${puInvoiceDetail.discountRate.toStringFormat(EDoubleFormat.percentage)}% '
            : '';
        final discountInfo = discountRateInfo +
            (discountAmount > 0
                ? '(${discountAmount.toStringFormat(EDoubleFormat.money)})'
                : '');
        if (MISACommon.isEmpty(discountInfo)) {
          return kSpaceShrinkBox;
        }
        return Row(
          children: [
            SizedBox(
              width: discountInfo.isEmpty ? 0 : 10,
              child: Icon(
                CupertinoIcons.arrow_down,
                color: AppColor.orange,
                size: 14,
              ),
            ),
            kHorizontalSpaceTinyBox,
            Text(
              discountInfo,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyText1.copyWith(
                    color: AppColor.orange,
                  ),
            ),
          ],
        );
      },
    );
  }
}
