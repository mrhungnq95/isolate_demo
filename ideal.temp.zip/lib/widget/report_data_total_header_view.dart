import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

///
/// View hiển thị tổng hợp số liệu của báo cáo đang xem
/// với action Share
/// VD:
/// Doanh thu
/// 200.000.000
///
class ReportDataTotalHeaderView extends StatelessWidget {
  final double amount;
  final Widget extendedView;
  final VoidCallback onSharePressed;

  const ReportDataTotalHeaderView(
      {Key key, this.extendedView, this.amount, this.onSharePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Doanh thu",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: AppColor.textColor),
          ),
          Row(
            children: [
              Expanded(
                child: Text(
                  amount?.toStringFormat(EDoubleFormat.money) ?? "0",
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(color: AppColor.textColor, fontSize: 20),
                ),
              ),
              GestureDetector(
                onTap: onSharePressed,
                child: Image.asset(
                  AppResources.icShare,
                  width: 25,
                  height: 25,
                  color: AppColor.grey700,
                  fit: BoxFit.fill,
                ),
              )
            ],
          ),
          extendedView ?? kSpaceShrinkBox
        ],
      ),
    );
  }
}
