import 'package:freezed_annotation/freezed_annotation.dart';

part 'delete_status.freezed.dart';

///
/// [Description] Event handle
///
/// Created by TTLOI on 12/01/2021 (09:55).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
@Freezed()
abstract class DeleteStatus with _$DeleteStatus {
  const factory DeleteStatus.confirm(String title, String msg) = Confirm;

  const factory DeleteStatus.process(String title, String msg) = Process;

  const factory DeleteStatus.success(String title, String msg) = Success;

  const factory DeleteStatus.failed(String title, String msg) = Failed;

  const factory DeleteStatus.error(String title, String msg) = Error;
}
