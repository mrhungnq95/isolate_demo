// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'delete_status.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$DeleteStatusTearOff {
  const _$DeleteStatusTearOff();

// ignore: unused_element
  Confirm confirm(String title, String msg) {
    return Confirm(
      title,
      msg,
    );
  }

// ignore: unused_element
  Process process(String title, String msg) {
    return Process(
      title,
      msg,
    );
  }

// ignore: unused_element
  Success success(String title, String msg) {
    return Success(
      title,
      msg,
    );
  }

// ignore: unused_element
  Failed failed(String title, String msg) {
    return Failed(
      title,
      msg,
    );
  }

// ignore: unused_element
  Error error(String title, String msg) {
    return Error(
      title,
      msg,
    );
  }
}

/// @nodoc
// ignore: unused_element
const $DeleteStatus = _$DeleteStatusTearOff();

/// @nodoc
mixin _$DeleteStatus {
  String get title;
  String get msg;

  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  });

  $DeleteStatusCopyWith<DeleteStatus> get copyWith;
}

/// @nodoc
abstract class $DeleteStatusCopyWith<$Res> {
  factory $DeleteStatusCopyWith(
          DeleteStatus value, $Res Function(DeleteStatus) then) =
      _$DeleteStatusCopyWithImpl<$Res>;
  $Res call({String title, String msg});
}

/// @nodoc
class _$DeleteStatusCopyWithImpl<$Res> implements $DeleteStatusCopyWith<$Res> {
  _$DeleteStatusCopyWithImpl(this._value, this._then);

  final DeleteStatus _value;
  // ignore: unused_field
  final $Res Function(DeleteStatus) _then;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(_value.copyWith(
      title: title == freezed ? _value.title : title as String,
      msg: msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
abstract class $ConfirmCopyWith<$Res> implements $DeleteStatusCopyWith<$Res> {
  factory $ConfirmCopyWith(Confirm value, $Res Function(Confirm) then) =
      _$ConfirmCopyWithImpl<$Res>;
  @override
  $Res call({String title, String msg});
}

/// @nodoc
class _$ConfirmCopyWithImpl<$Res> extends _$DeleteStatusCopyWithImpl<$Res>
    implements $ConfirmCopyWith<$Res> {
  _$ConfirmCopyWithImpl(Confirm _value, $Res Function(Confirm) _then)
      : super(_value, (v) => _then(v as Confirm));

  @override
  Confirm get _value => super._value as Confirm;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(Confirm(
      title == freezed ? _value.title : title as String,
      msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
class _$Confirm implements Confirm {
  const _$Confirm(this.title, this.msg)
      : assert(title != null),
        assert(msg != null);

  @override
  final String title;
  @override
  final String msg;

  @override
  String toString() {
    return 'DeleteStatus.confirm(title: $title, msg: $msg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Confirm &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.msg, msg) ||
                const DeepCollectionEquality().equals(other.msg, msg)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(msg);

  @override
  $ConfirmCopyWith<Confirm> get copyWith =>
      _$ConfirmCopyWithImpl<Confirm>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return confirm(title, msg);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (confirm != null) {
      return confirm(title, msg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return confirm(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (confirm != null) {
      return confirm(this);
    }
    return orElse();
  }
}

abstract class Confirm implements DeleteStatus {
  const factory Confirm(String title, String msg) = _$Confirm;

  @override
  String get title;
  @override
  String get msg;
  @override
  $ConfirmCopyWith<Confirm> get copyWith;
}

/// @nodoc
abstract class $ProcessCopyWith<$Res> implements $DeleteStatusCopyWith<$Res> {
  factory $ProcessCopyWith(Process value, $Res Function(Process) then) =
      _$ProcessCopyWithImpl<$Res>;
  @override
  $Res call({String title, String msg});
}

/// @nodoc
class _$ProcessCopyWithImpl<$Res> extends _$DeleteStatusCopyWithImpl<$Res>
    implements $ProcessCopyWith<$Res> {
  _$ProcessCopyWithImpl(Process _value, $Res Function(Process) _then)
      : super(_value, (v) => _then(v as Process));

  @override
  Process get _value => super._value as Process;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(Process(
      title == freezed ? _value.title : title as String,
      msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
class _$Process implements Process {
  const _$Process(this.title, this.msg)
      : assert(title != null),
        assert(msg != null);

  @override
  final String title;
  @override
  final String msg;

  @override
  String toString() {
    return 'DeleteStatus.process(title: $title, msg: $msg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Process &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.msg, msg) ||
                const DeepCollectionEquality().equals(other.msg, msg)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(msg);

  @override
  $ProcessCopyWith<Process> get copyWith =>
      _$ProcessCopyWithImpl<Process>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return process(title, msg);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (process != null) {
      return process(title, msg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return process(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (process != null) {
      return process(this);
    }
    return orElse();
  }
}

abstract class Process implements DeleteStatus {
  const factory Process(String title, String msg) = _$Process;

  @override
  String get title;
  @override
  String get msg;
  @override
  $ProcessCopyWith<Process> get copyWith;
}

/// @nodoc
abstract class $SuccessCopyWith<$Res> implements $DeleteStatusCopyWith<$Res> {
  factory $SuccessCopyWith(Success value, $Res Function(Success) then) =
      _$SuccessCopyWithImpl<$Res>;
  @override
  $Res call({String title, String msg});
}

/// @nodoc
class _$SuccessCopyWithImpl<$Res> extends _$DeleteStatusCopyWithImpl<$Res>
    implements $SuccessCopyWith<$Res> {
  _$SuccessCopyWithImpl(Success _value, $Res Function(Success) _then)
      : super(_value, (v) => _then(v as Success));

  @override
  Success get _value => super._value as Success;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(Success(
      title == freezed ? _value.title : title as String,
      msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
class _$Success implements Success {
  const _$Success(this.title, this.msg)
      : assert(title != null),
        assert(msg != null);

  @override
  final String title;
  @override
  final String msg;

  @override
  String toString() {
    return 'DeleteStatus.success(title: $title, msg: $msg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Success &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.msg, msg) ||
                const DeepCollectionEquality().equals(other.msg, msg)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(msg);

  @override
  $SuccessCopyWith<Success> get copyWith =>
      _$SuccessCopyWithImpl<Success>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return success(title, msg);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (success != null) {
      return success(title, msg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return success(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (success != null) {
      return success(this);
    }
    return orElse();
  }
}

abstract class Success implements DeleteStatus {
  const factory Success(String title, String msg) = _$Success;

  @override
  String get title;
  @override
  String get msg;
  @override
  $SuccessCopyWith<Success> get copyWith;
}

/// @nodoc
abstract class $FailedCopyWith<$Res> implements $DeleteStatusCopyWith<$Res> {
  factory $FailedCopyWith(Failed value, $Res Function(Failed) then) =
      _$FailedCopyWithImpl<$Res>;
  @override
  $Res call({String title, String msg});
}

/// @nodoc
class _$FailedCopyWithImpl<$Res> extends _$DeleteStatusCopyWithImpl<$Res>
    implements $FailedCopyWith<$Res> {
  _$FailedCopyWithImpl(Failed _value, $Res Function(Failed) _then)
      : super(_value, (v) => _then(v as Failed));

  @override
  Failed get _value => super._value as Failed;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(Failed(
      title == freezed ? _value.title : title as String,
      msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
class _$Failed implements Failed {
  const _$Failed(this.title, this.msg)
      : assert(title != null),
        assert(msg != null);

  @override
  final String title;
  @override
  final String msg;

  @override
  String toString() {
    return 'DeleteStatus.failed(title: $title, msg: $msg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Failed &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.msg, msg) ||
                const DeepCollectionEquality().equals(other.msg, msg)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(msg);

  @override
  $FailedCopyWith<Failed> get copyWith =>
      _$FailedCopyWithImpl<Failed>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return failed(title, msg);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (failed != null) {
      return failed(title, msg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return failed(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (failed != null) {
      return failed(this);
    }
    return orElse();
  }
}

abstract class Failed implements DeleteStatus {
  const factory Failed(String title, String msg) = _$Failed;

  @override
  String get title;
  @override
  String get msg;
  @override
  $FailedCopyWith<Failed> get copyWith;
}

/// @nodoc
abstract class $ErrorCopyWith<$Res> implements $DeleteStatusCopyWith<$Res> {
  factory $ErrorCopyWith(Error value, $Res Function(Error) then) =
      _$ErrorCopyWithImpl<$Res>;
  @override
  $Res call({String title, String msg});
}

/// @nodoc
class _$ErrorCopyWithImpl<$Res> extends _$DeleteStatusCopyWithImpl<$Res>
    implements $ErrorCopyWith<$Res> {
  _$ErrorCopyWithImpl(Error _value, $Res Function(Error) _then)
      : super(_value, (v) => _then(v as Error));

  @override
  Error get _value => super._value as Error;

  @override
  $Res call({
    Object title = freezed,
    Object msg = freezed,
  }) {
    return _then(Error(
      title == freezed ? _value.title : title as String,
      msg == freezed ? _value.msg : msg as String,
    ));
  }
}

/// @nodoc
class _$Error implements Error {
  const _$Error(this.title, this.msg)
      : assert(title != null),
        assert(msg != null);

  @override
  final String title;
  @override
  final String msg;

  @override
  String toString() {
    return 'DeleteStatus.error(title: $title, msg: $msg)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is Error &&
            (identical(other.title, title) ||
                const DeepCollectionEquality().equals(other.title, title)) &&
            (identical(other.msg, msg) ||
                const DeepCollectionEquality().equals(other.msg, msg)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(title) ^
      const DeepCollectionEquality().hash(msg);

  @override
  $ErrorCopyWith<Error> get copyWith =>
      _$ErrorCopyWithImpl<Error>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result confirm(String title, String msg),
    @required Result process(String title, String msg),
    @required Result success(String title, String msg),
    @required Result failed(String title, String msg),
    @required Result error(String title, String msg),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return error(title, msg);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result confirm(String title, String msg),
    Result process(String title, String msg),
    Result success(String title, String msg),
    Result failed(String title, String msg),
    Result error(String title, String msg),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (error != null) {
      return error(title, msg);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result confirm(Confirm value),
    @required Result process(Process value),
    @required Result success(Success value),
    @required Result failed(Failed value),
    @required Result error(Error value),
  }) {
    assert(confirm != null);
    assert(process != null);
    assert(success != null);
    assert(failed != null);
    assert(error != null);
    return error(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result confirm(Confirm value),
    Result process(Process value),
    Result success(Success value),
    Result failed(Failed value),
    Result error(Error value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (error != null) {
      return error(this);
    }
    return orElse();
  }
}

abstract class Error implements DeleteStatus {
  const factory Error(String title, String msg) = _$Error;

  @override
  String get title;
  @override
  String get msg;
  @override
  $ErrorCopyWith<Error> get copyWith;
}
