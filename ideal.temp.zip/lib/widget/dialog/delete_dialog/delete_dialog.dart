import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';

import 'delete_status.dart';

///
/// [Description]  dialog chuyên dùng để xoá
///
/// Created by TTLOI on 19/01/2021 (08:41).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class DeleteDialog extends StatefulWidget {
  final String title;
  final String content;
  final Future<DeleteStatus> deleteFuture;

  const DeleteDialog({
    Key key,
    @required this.title,
    @required this.content,
    @required this.deleteFuture,
  }) : super(key: key);

  @override
  _DeleteDialogState createState() => _DeleteDialogState();
}

class _DeleteDialogState extends State<DeleteDialog> {
  DeleteStatus _deleteStatus;

  @override
  void initState() {
    _deleteStatus = DeleteStatus.confirm(widget.title, widget.content);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      elevation: 0,
      backgroundColor: Colors.transparent,
      contentPadding: EdgeInsets.zero,
      insetPadding: EdgeInsets.zero,
      titlePadding: EdgeInsets.zero,
      buttonPadding: EdgeInsets.zero,
      content: SafeArea(
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Container(
              width: ScreenUtils.width * 0.8,
              margin: EdgeInsets.only(top: 36),
              padding: EdgeInsets.only(top: 36),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 24,
                    offset: Offset(0, 12),
                    spreadRadius: 6,
                  ),
                ],
                color: AppColor.white,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Stack(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              right: 16,
                              left: 16,
                              bottom: 24,
                              top: _Title.titleHeight,
                            ),
                            child: _Content(_deleteStatus),
                          ),
                        ],
                      ),
                      _Title(
                        status: _deleteStatus,
                      ),
                    ],
                  ),
                  Divider(
                    thickness: 1,
                    height: 1,
                    color: AppColor.grey200,
                  ),
                  _Button(
                    _deleteStatus,
                    onExecutePressed: _execute,
                    onClosePressed: () {
                      NavigationHelper.shared.maybePop(
                        obj: _deleteStatus.maybeWhen(
                          orElse: () => false,
                          success: (title, msg) => true,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            _Icon(status: _deleteStatus),
          ],
        ),
      ),
    );
  }

  /// Thực hiện xoá
  void _execute() async {
    setState(() {
      _deleteStatus = DeleteStatus.process('Đang xoá..', '');
    });
    var result = await widget.deleteFuture;
    setState(() {
      _deleteStatus = result;
    });
    if (result.maybeWhen(
      orElse: () => false,
      success: (title, msg) => true,
      error: (title, msg) => true,
    )) {
      await Future.delayed(Duration(seconds: 1));
      await NavigationHelper.shared.maybePop(obj: true);
    }
  }
}

class _Button extends StatelessWidget {
  final DeleteStatus status;
  final VoidCallback onExecutePressed;
  final VoidCallback onClosePressed;

  const _Button(this.status,
      {Key key, this.onExecutePressed, this.onClosePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SizedBox(
        width: double.infinity,
        height: 64,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            status.maybeWhen(
              orElse: () => kSpaceShrinkBox,
              confirm: (_, __) => FlatButton(
                child: Text(
                  'Xóa',
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(color: AppColor.grey700),
                ),
                height: 40,
                onPressed: onExecutePressed,
              ),
            ),
            kHorizontalSpaceLargeBox,
            FlatButton(
              child: Text(
                'Đóng',
                style: Theme.of(context)
                    .textTheme
                    .bodyText2
                    .copyWith(color: AppColor.white),
              ),
              height: 40,
              color: AppColor.primaryColor,
              disabledColor: AppColor.grey700,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              onPressed: status.maybeWhen(
                orElse: () => onClosePressed,
                process: (_, __) => null,
              ),
            )
          ],
        ),
      ),
    );
  }
}

/// nội dung
class _Content extends StatelessWidget {
  final DeleteStatus status;

  _Content(this.status);

  @override
  Widget build(BuildContext context) {
    var msg = status.msg;
    if (MISACommon.isEmpty(status.msg)) {
      msg = '<font color="#ffffff">.</font>';
    }
    return HtmlWidget(
      '<div style="text-align:center; text-overflow: ellipsis;-webkit-line-clamp: 2; line-height: 1.4em; min-height: 2.8em;">$msg</div>',
      textStyle: Theme.of(context)
          .textTheme
          .bodyText1
          .copyWith(color: AppColor.grey700, fontSize: 16),
    );
  }
}

/// tiêu đề
class _Title extends StatefulWidget {
  static const titleHeight = 80.0;
  static const titleExpand = 148.0;

  final DeleteStatus status;

  const _Title({Key key, this.status}) : super(key: key);

  @override
  _TitleState createState() => _TitleState();
}

class _TitleState extends State<_Title> with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    var height = _Title.titleHeight;
    if (MISACommon.isEmpty(widget.status.msg)) {
      height = _Title.titleExpand;
    }
    return AnimatedSize(
      vsync: this,
      duration: Duration(milliseconds: 100),
      child: Container(
        color: AppColor.white,
        width: double.infinity,
        height: height,
        child: Center(
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
            child: Text(
              widget.status.title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headline2,
            ),
          ),
        ),
      ),
    );
  }
}

/// Icon
class _Icon extends StatelessWidget {
  final DeleteStatus status;

  const _Icon({Key key, this.status}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 72,
      height: 72,
      decoration: BoxDecoration(
        color: AppColor.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 6,
            offset: Offset(0, 3),
            spreadRadius: 1,
          ),
        ],
      ),
      child: Center(
        child: _buildIcon(status),
      ),
    );
  }

  /// build icon theo trạng thái
  /// [status] trạng thái
  Widget _buildIcon(DeleteStatus status) {
    return status.when(confirm: (title, msg) {
      return Image.asset(
        AppResources.icTrash,
        fit: BoxFit.fill,
        width: 32,
        height: 32,
      );
    }, process: (title, msg) {
      return SizedBox(
          width: 24, height: 24, child: CircularProgressIndicator());
    }, success: (title, msg) {
      return Icon(
        CupertinoIcons.checkmark_alt_circle_fill,
        color: AppColor.green,
        size: 32,
      );
    }, failed: (title, msg) {
      return Icon(
        Icons.close_rounded,
        color: Colors.red,
        size: 32,
      );
    }, error: (title, msg) {
      return Icon(
        Icons.close_rounded,
        color: Colors.red,
        size: 32,
      );
    });
  }
}
