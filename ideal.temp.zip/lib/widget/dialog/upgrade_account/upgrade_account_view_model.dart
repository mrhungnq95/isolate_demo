import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_license_view_type.dart';
import 'package:flutter/rendering.dart';

class UpgradeAccountViewModel extends MSBaseViewModel {
  final ELicenseViewType _licenseViewType;
  ELicenseViewType get licenseViewType => _licenseViewType;

  final String productPackageName;
  final int numberActiveBranch;
  final int numberBranchRegister;

  final double _progressValue;
  double get progressValue => _progressValue;

  final bool isShowUpgradeButton;
  final bool isShowInSignIn;

  UpgradeAccountViewModel(this._licenseViewType, this._progressValue,
      {this.isShowUpgradeButton = true,
      this.isShowInSignIn = false,
      this.productPackageName,
      this.numberActiveBranch,
      this.numberBranchRegister});

  String get title {
    switch (licenseViewType) {
      case ELicenseViewType.ocm_license:
        return "Thông báo";
      case ELicenseViewType.trail_license:
        return "";
      case ELicenseViewType.branch_out_of_quota_chain_store:
        return "Mua thêm cửa hàng";
      case ELicenseViewType.virtual_branch_trail_license:
        return "Nâng cấp tài khoản";
    }
    return "";
  }

  String get content {
    switch (licenseViewType) {
      case ELicenseViewType.ocm_license:
        return '''Thuê bao của Quý khách chỉ dùng nghiệp vụ <b>Bán hàng online 
        (OCM)</b> nên không sử dụng được ứng dụng này. 
        Vui lòng mua thêm nghiệp vụ <b>Bán hàng tại cửa hàng (Starter</b> 
        hoặc <b>Professional)</b>''';
      case ELicenseViewType.trail_license:

        /// Dùng dialog [LicenseView]
        return "";
      case ELicenseViewType.branch_out_of_quota_chain_store:
        return '''Bạn đang sử dụng chuỗi <b><font color="#FF8401">$numberActiveBranch</font></b> cửa hàng 
        nhưng thuê bao đã mua chỉ dùng cho <b><font color="#FF8401">$numberBranchRegister</font></b>
         cửa hàng. Vui lòng mua thêm thuê bao hoặc chọn các cửa hàng muốn giữ lại
          (ở trang quản lý cửa hàng).
        ''';
      case ELicenseViewType.virtual_branch_trail_license:
        return '''Bạn đang sử dụng thuê bao <b><font color="#FF8401">$productPackageName.</font>
        </b> Vui lòng mua thêm thuê bao <b><font color="#FF8401">Chain Store</font></b>
         để sử dụng <b><font color="#FF8401">Kho tổng</font></b>.</font>''';
    }
    return "";
  }

  bool isShowNegativeButton() {
    switch (licenseViewType) {
      case ELicenseViewType.branch_out_of_quota_chain_store:
      case ELicenseViewType.virtual_branch_trail_license:
        return isShowUpgradeButton;
      default:
        return true;
    }
  }

  String get positiveTextButton {
    switch (licenseViewType) {
      case ELicenseViewType.ocm_license:
        return 'Mua ngay';
      case ELicenseViewType.trail_license:

        /// Dùng dialog [LicenseView]
        return "";
      case ELicenseViewType.branch_out_of_quota_chain_store:
        return 'Nâng cấp';
      case ELicenseViewType.virtual_branch_trail_license:
        return 'Mua thêm';
    }
    return "";
  }

  String get negativeTextButton {
    switch (licenseViewType) {
      case ELicenseViewType.ocm_license:
        return 'Đóng';
      case ELicenseViewType.trail_license:

        /// Dùng dialog [LicenseView]
        return "";
      case ELicenseViewType.branch_out_of_quota_chain_store:
      case ELicenseViewType.virtual_branch_trail_license:
        return isShowInSignIn ? 'Đóng' : 'Bỏ qua';
    }
    return "";
  }

  ///
  /// Thực hiện Mua ngay/Nâng cấp/... trong từng ngữ cảnh
  ///
  void performPositivePressed() {
    switch (licenseViewType) {
      case ELicenseViewType.trail_license:

        /// Không xử lý gì, thông báo license đã có ở 1 view riêng
        break;
      case ELicenseViewType.ocm_license:
      case ELicenseViewType.branch_out_of_quota_chain_store:
      case ELicenseViewType.virtual_branch_trail_license:

        /// Launch Url
        /// https://%1$s.mshopkeeper.vn/payment
        ///
        /// https://%1$s.mshopkeeper.vn/payment
        /// => https://longnhishopacc.mshopkeeper.vn/payment
        ///
        final compayCode = commonDataRepository.getBranchCode();

        launchUrl("https://$compayCode.mshopkeeper.vn/payment");
        break;
    }
  }

  ///
  /// Thực hiện Bỏ qua, đóng trong từng ngữ cảnh
  ///
  void performNegativePressed() {
    ///
  }
}
