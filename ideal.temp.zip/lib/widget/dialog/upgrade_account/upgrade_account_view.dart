import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/v2/ms_base_dialog_v2.dart';
import 'package:MShopManager/enums/enum_license_view_type.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/dialog/upgrade_account/upgrade_account_view_model.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';

class UpgradeAccountView extends StatelessWidget {
  final ELicenseViewType licenseViewType;
  final int activeBranch;
  final int numberBranchRegister;
  final double progressValue;
  final bool isShowUpgradeButton;
  final bool isShowInSignIn;
  final String productPackageName;
  const UpgradeAccountView(
      {Key key,
      this.licenseViewType,
      this.activeBranch,
      this.numberBranchRegister,
      this.progressValue,
      this.isShowUpgradeButton,
      this.productPackageName,
      this.isShowInSignIn = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSBaseDialogV2(builder: (context) {
      return Padding(
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        child: ViewModelBuilder<UpgradeAccountViewModel>.nonReactive(
            builder: (context, model, child) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [_HeaderView(), _ContentView()],
              );
            },
            viewModelBuilder: () => UpgradeAccountViewModel(
                licenseViewType, progressValue,
                isShowUpgradeButton: isShowUpgradeButton,
                isShowInSignIn: isShowInSignIn,
                productPackageName: productPackageName,
                numberActiveBranch: activeBranch,
                numberBranchRegister: numberBranchRegister)),
      );
    });
  }
}

class _HeaderView extends ViewModelWidget<UpgradeAccountViewModel> {
  @override
  Widget build(BuildContext context, UpgradeAccountViewModel viewModel) {
    return Column(
      children: [
        Image.asset(
          AppResources.bgKey,
          width: 180,
          height: 180,
        ),
        kVerticalSpaceMediumBox,
        Text(
          viewModel.title,
          style: Theme.of(context).textTheme.bodyText1.copyWith(
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: AppColor.orange),
        ),
        kVerticalSpaceMediumBox,
        _ProgressBarView()
      ],
    );
  }
}

class _ContentView extends ViewModelWidget<UpgradeAccountViewModel> {
  @override
  Widget build(BuildContext context, UpgradeAccountViewModel viewModel) {
    return Column(
      children: [
        kVerticalSpaceLargeBox,
        Text(
          viewModel.content,
          style: Theme.of(context).textTheme.bodyText1,
        ),
        _renderNegativeButton(),
        kVerticalSpaceLargeBox,
        MSButton(
          minWidth: ScreenUtils.width * 0.5,
          buttonColor: AppColor.white,
          onPressed: () {
            viewModel.performNegativePressed();

            NavigationHelper.shared.pop();
          },
          textColor: AppColor.textSecondaryColor,
          label: viewModel.negativeTextButton,
        ),
      ],
    );
  }

  ///
  /// Lấy màu sắc của Positive Button theo kiểu view license
  /// [licenseViewType] kiểu license
  ///
  Color getColorButton(ELicenseViewType licenseViewType) {
    switch (licenseViewType) {
      case ELicenseViewType.ocm_license:
        return AppColor.indigo900;
      default:
        return AppColor.green;
    }
  }

  ///
  /// Lấy Icon của PositiveButton
  /// [licenseViewType] kiểu license
  ///
  IconData getIconPositiveButton(ELicenseViewType licenseViewType) {
    switch (licenseViewType) {
      case ELicenseViewType.virtual_branch_trail_license:
      case ELicenseViewType.branch_out_of_quota_chain_store:
        return Icons.check;
      default:
        return null;
    }
  }

  Widget _renderNegativeButton() {
    return Builder(
      builder: (BuildContext context) {
        final viewModel = context.watch<UpgradeAccountViewModel>();
        return Column(
          children: [
            kVerticalSpaceHugeBox,
            MSButton(
              buttonColor: getColorButton(viewModel.licenseViewType),
              minWidth: ScreenUtils.width * 0.5,
              onPressed: () {
                viewModel.performPositivePressed();

                NavigationHelper.shared.pop();
              },
              label: viewModel.positiveTextButton,
              iconData: getIconPositiveButton(viewModel.licenseViewType),
            ),
          ],
        );
      },
    );
  }
}

class _ProgressBarView extends ViewModelWidget<UpgradeAccountViewModel> {
  const _ProgressBarView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context, UpgradeAccountViewModel viewModel) {
    return Container(
      width: 100,
      child: LinearProgressIndicator(
        minHeight: 2,
        backgroundColor: AppColor.grey400,
        valueColor: AlwaysStoppedAnimation<Color>(
          Colors.orange,
        ),
        value: viewModel.progressValue ?? 0.5,
      ),
    );
  }
}
