import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/v2/ms_base_dialog_v2.dart';
import 'package:MShopManager/enums/enum_license_negative_button.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/custom_painter/header_license_custom_painter.dart';
import 'package:MShopManager/widget/dialog/license/license_view_model.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';

class LicenseView extends StatelessWidget {
  final LicenseInfo licenseInfo;
  final bool isAdmin;

  final Function onPositivePressed;
  final Function(ELicenseNegativeButton type) onNegativePressed;

  const LicenseView(
      {Key key,
      @required this.licenseInfo,
      @required this.isAdmin,
      this.onNegativePressed,
      this.onPositivePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSBaseDialogV2(builder: (context) {
      return ViewModelBuilder<LicenseViewModel>.nonReactive(
          builder: (context, model, child) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _HeaderLicenseView(),
                _ContentLicenseView(
                    onPositivePressed: onPositivePressed,
                    onNegativePressed: onNegativePressed)
              ],
            );
          },
          onModelReady: (model) {
            model.initLicenseData();
          },
          viewModelBuilder: () => LicenseViewModel(isAdmin, licenseInfo));
    });
  }
}

class _HeaderLicenseView extends ViewModelWidget<LicenseViewModel> {
  @override
  Widget build(BuildContext context, LicenseViewModel viewModel) {
    return Stack(
      children: [
        CustomPaint(
          size: Size(double.infinity, 190),
          painter: HeaderLicenseCustomPainter(),
        ),
        Positioned(
            top: 20,
            right: 0,
            bottom: 0,
            left: 0,
            child: Text(viewModel.title,
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .bodyText1
                    .copyWith(color: AppColor.white))),
        Positioned(
          bottom: 40,
          right: 0,
          left: 0,
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColor.white,
                border:
                    Border.all(width: 3, color: AppColor.licenseBackground)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  viewModel.remainDay?.toString(),
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontSize: 40, color: AppColor.orange),
                ),
                Text("ngày",
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1
                        .copyWith(color: AppColor.orange))
              ],
            ),
          ),
        ),
        Positioned(
            bottom: 10,
            right: 0,
            left: 0,
            child: Text("Điều gì sẽ xảy ra nếu tài khoản bạn quá hạn",
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyText1))
      ],
    );
  }
}

class _ContentLicenseView extends ViewModelWidget<LicenseViewModel> {
  final Function onPositivePressed;
  final Function(ELicenseNegativeButton type) onNegativePressed;
  const _ContentLicenseView(
      {Key key, this.onPositivePressed, this.onNegativePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context, LicenseViewModel viewModel) {
    return Padding(
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Column(
        children: [
          _NoteItemView(
            day: viewModel.overDay,
            description: "Hệ thống sẽ không cho phép đăng nhập vào phần mềm",
          ),
          kVerticalSpaceMediumBox,
          _NoteItemView(
            day: 30,
            description:
                "Hệ thống sẽ xóa hoàn toàn dữ liệu của quý khách khỏi trung tâm dữ liệu của MISA.",
          ),
          _renderPositiveButtonView(onPositivePressed),
          _renderNegativeButtonView(onNegativePressed)
        ],
      ),
    );
  }

  Widget _renderPositiveButtonView(Function onPositivePressed) {
    return Builder(builder: (context) {
      final model = context.watch<LicenseViewModel>();
      if (model.isVisiblePositiveButton) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            kVerticalSpaceLargeBox,
            MSButton(
              buttonColor: AppColor.green,
              onPressed: () {
                model.onPositivePressed();

                onPositivePressed?.call();
              },
              label: model.titlePositiveButton ?? "",
              minWidth: ScreenUtils.width * 0.5,
            )
          ],
        );
      }
      return kSpaceShrinkBox;
    });
  }

  Widget _renderNegativeButtonView(
      Function(ELicenseNegativeButton type) onNegativePressed) {
    return Builder(builder: (context) {
      final model = context.watch<LicenseViewModel>();
      if (model.isVisiblePositiveButton) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            kVerticalSpaceMediumBox,
            MSButton(
              buttonColor: AppColor.white,
              onPressed: () {
                final model = context.read<LicenseViewModel>();

                final licenseNegativeButtonType =
                    model.getLicenseNegativeButtonType();

                onNegativePressed?.call(licenseNegativeButtonType);
              },
              textColor: AppColor.indigo900,
              label: model.titleNegativeButton ?? "",
              minWidth: ScreenUtils.width * 0.5,
            )
          ],
        );
      }
      return kSpaceShrinkBox;
    });
  }
}

class _NoteItemView extends StatelessWidget {
  final int day;
  final String description;

  const _NoteItemView({Key key, this.day, this.description}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
        constraints: BoxConstraints(minHeight: 90),
        child: Container(
          padding: const EdgeInsets.all(kVerticalSpaceSmall),
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.borderColor),
              borderRadius: BorderRadius.circular(8)),
          child: Row(
            children: [
              Column(
                children: [
                  Text("Quá hạn", style: Theme.of(context).textTheme.bodyText1),
                  Text("$day",
                      style: Theme.of(context)
                          .textTheme
                          .headline1
                          .copyWith(fontWeight: FontWeight.bold)),
                  Text("ngày", style: Theme.of(context).textTheme.bodyText1)
                ],
              ),
              kHorizontalSpaceSmallBox,
              VerticalDivider(
                thickness: 1,
                color: AppColor.grey200,
                width: 1,
                indent: 10,
                endIndent: 10,
              ),
              kHorizontalSpaceSmallBox,
              Expanded(
                  child: Text(
                description,
                style: Theme.of(context)
                    .textTheme
                    .bodyText1
                    .copyWith(color: AppColor.textSecondaryColor),
              ))
            ],
          ),
        ));
  }
}
