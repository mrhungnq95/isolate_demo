import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_license_negative_button.dart';
import 'package:MShopManager/enums/enum_package_license.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:MShopManager/service/storage/local_storage.dart';

class LicenseViewModel extends MSBaseViewModel {
  /// object thông tin license
  LicenseInfo _licenseInfo;
  bool isAdmin = false;

  /// Số ngày còn lại
  int _remainDay;
  int get remainDay => _remainDay;

  /// Số ngày quá hạn
  int _overDay = 1;
  int get overDay => _overDay;

  /// Tiêu đề: Số ngày dùng thử còn lại / Thuê bao của bạn đã quá hạn
  String _title;
  String get title => _title;

  /// Cờ hiển thị view Quá hạn 7 ngày
  bool _isVisibleOutOfDate7Day = true;
  bool get isVisibleOutOfDate7Day => _isVisibleOutOfDate7Day;

  bool _isVisiblePositiveButton = true;
  bool get isVisiblePositiveButton => _isVisiblePositiveButton;

  bool _isVisibleNegativeButton = true;
  bool get isVisibleNegativeButton => _isVisibleNegativeButton;

  String _titlePositiveButton;
  String get titlePositiveButton => _titlePositiveButton;

  String _titleNegativeButton;
  String get titleNegativeButton => _titleNegativeButton;

  int _statusLicense = 0;
  int get statusLicense => _statusLicense;

  LicenseViewModel(this.isAdmin, this._licenseInfo);

  ///
  /// Khởi tạo dữ liệu license
  ///
  void initLicenseData() {
    ELicenseType licenseType =
        ELicenseTypeExt.valueOf(_licenseInfo.productPackCode);

    _statusLicense = _licenseInfo.status;

    if (licenseType == ELicenseType.LicensePackageTrial) {
      _overDay = 1;

      _isVisiblePositiveButton = isAdmin;

      if (_statusLicense == 0) {
        /// MÀU CAM
        ///
        _title = "Số ngày dùng thử còn lại";
        _remainDay = _licenseInfo.remain;

        _titlePositiveButton = "Mua ngay".toUpperCase();
        _titleNegativeButton = "Bỏ qua".toUpperCase();
      } else {
        /// MÀU ĐỎ
        ///
        _title = "Thuê bao của bạn đã quá hạn";
        _remainDay = _licenseInfo.overDue;

        if (_licenseInfo.overDue >= 1) {
          _isVisibleOutOfDate7Day = false;
        } else {
          _isVisibleOutOfDate7Day = true;
        }

        _titlePositiveButton = "Mua ngay".toUpperCase();
        _titleNegativeButton = "Đăng xuất".toUpperCase();
      }
    } else {
      if (_licenseInfo.status == 0) {
        /// MÀU CAM
        ///
        _title = "Số ngày sử dùng còn lại";
        _remainDay = _licenseInfo.remain;

        if (_licenseInfo.remain >= 1 && _licenseInfo.remain <= 30) {
          _overDay = 1;
        } else {
          _overDay = 7;
        }

        _titlePositiveButton = "Đăng ký gia hạn".toUpperCase();
        _titleNegativeButton = "Đóng".toUpperCase();
      } else {
        /// MÀU ĐỎ
        ///
        _title = "Thuê bao của bạn đã quá hạn";
        _remainDay = _licenseInfo.overDue;

        _isVisiblePositiveButton = false;

        if (_licenseInfo.overDue >= 1) {
          if (isAdmin) {
            _isVisiblePositiveButton = isAdmin;

            _titlePositiveButton = "Đăng ký gia hạn".toUpperCase();
            _titleNegativeButton = "Đăng xuất".toUpperCase();
          }
          _isVisibleOutOfDate7Day = false;
        }
      }
    }

    /// Nếu domain .com => ẩn Mua ngay
    ///
    notifyListeners();
  }

  ///
  /// Action khi bấm vào các nút:
  /// Đăng ký gia hạn
  /// Mua ngay
  ///
  void onPositivePressed() {
    ELicenseType licenseType =
        ELicenseTypeExt.valueOf(_licenseInfo.productPackCode);
    if (licenseType == ELicenseType.LicensePackageTrial) {
      ///
      /// https://%s/bao-gia
      /// => https://mshopkeeper.vn/bao-gia
      ///

      var subDomain = commonDataRepository.getSubDomain();
      subDomain = subDomain.replaceFirst(".", "");
      launchUrl("https://$subDomain/bao-gia");
    } else {
      ///
      /// https://%1$s.mshopkeeper.vn/payment
      /// => https://longnhishopacc.mshopkeeper.vn/payment
      ///
      final compayCode = commonDataRepository.getBranchCode();

      launchUrl("https://$compayCode.mshopkeeper.vn/payment");
    }
  }

  ///
  /// Lấy kiểu của negative button
  ///
  ELicenseNegativeButton getLicenseNegativeButtonType() {
    ELicenseType licenseType =
        ELicenseTypeExt.valueOf(_licenseInfo.productPackCode);

    _statusLicense = _licenseInfo.status;

    if (licenseType == ELicenseType.LicensePackageTrial) {
      if (_statusLicense == 0) {
        /// Bỏ qua
        return ELicenseNegativeButton.skip;
      } else {
        /// Đăng xuất
        return ELicenseNegativeButton.signout;
      }
    } else {
      if (_statusLicense == 0) {
        /// Đóng
        return ELicenseNegativeButton.close;
      } else {
        /// Đăng xuất
        return ELicenseNegativeButton.signout;
      }
    }
  }

  ///
  /// Actionn khi bấm vào nút
  /// Đăng xuất
  ///
  void onSignOutPressed() {}

  ///
  /// Action khi bấm vào các nút:
  /// Đóng
  ///
  void onClosePressed() {}

  ///
  /// Action khi bấm vào các nút:
  /// Bỏ qua
  ///
  void onSkipPressed() {}
}
