import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dashed_rect_view.dart';


/// 
/// View border
/// 
class DashedBorderWithBottomActionView extends StatelessWidget {
  final bool isShowBottomActionView;
  final bool isShowEmptyView; // Hiển thị thông báo khi view empty
  final List<Widget> listBottomAction;
  final String titleEmpty;
  final String subTitleEmpty;
  final Widget child;

  DashedBorderWithBottomActionView(
      {this.isShowBottomActionView = true,
      @required this.isShowEmptyView,
      @required this.child,
      this.titleEmpty,
      this.subTitleEmpty,
      this.listBottomAction});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Positioned.fill(
          child: _ContentView(child: child),
        ),
        _BottomActionView(isShowBottomActionView: isShowBottomActionView)
      ],
    );
  }
}

/// 
/// 
/// 
class _ContentView extends StatelessWidget {
  final Widget child;

  _ContentView({this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: DashedRectView(
        color: AppColor.grey600.withOpacity(0.5),
        strokeWidth: 2.0,
        gap: 3.0,
        child: Container(
          color: AppColor.grey200,
          child: child,
        ),
      ),
    );
  }
}

///
/// Build bottom Action view
class _BottomActionView extends StatelessWidget {
  final bool isShowEmptyView; // Hiển thị thông báo khi view empty
  final bool isShowBottomActionView;

  _BottomActionView({this.isShowEmptyView, this.isShowBottomActionView});

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
        child: Align(
      alignment: !isShowEmptyView ? Alignment.bottomCenter : Alignment.center,
      child: Visibility(visible: isShowBottomActionView, child: _BottomView()),
    ));
  }
}


/// 
/// Hiển thị text khi không có dữ liệu
/// 
class _BottomView extends StatelessWidget {
  final bool isShowEmptyView; // Hiển thị thông báo khi view empty
  final String titleEmpty;
  final String subTitleEmpty;
  final List<Widget> listBottomAction;

  _BottomView(
      {this.isShowEmptyView,
      this.titleEmpty,
      this.subTitleEmpty,
      this.listBottomAction});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Visibility(
          visible: isShowEmptyView,
          child: Text(
            titleEmpty,
            style: Theme.of(context)
                .textTheme
                .bodyText2
                .copyWith(fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
        Visibility(
          visible: isShowEmptyView,
          child: Text(
            subTitleEmpty,
            style: Theme.of(context)
                .textTheme
                .bodyText1
                .copyWith(color: Colors.grey),
          ),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: listBottomAction,
        ),
        kVerticalSpaceMediumBox
      ],
    );
  }
}
