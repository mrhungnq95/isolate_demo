import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class CheckboxTitle extends StatefulWidget {
  final Widget title;
  final bool isChecked;
  final ValueChanged<bool> onChanged;

  const CheckboxTitle(
      {Key key,
      this.isChecked = false,
      @required this.onChanged,
      @required this.title})
      : super(key: key);

  @override
  _CheckboxTitleState createState() => _CheckboxTitleState();
}

class _CheckboxTitleState extends State<CheckboxTitle> {
  bool isChecked;

  @override
  void initState() {
    super.initState();
    isChecked = widget.isChecked;
  }

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      colorBackground: Colors.transparent,
      borderRadius: 4,
      onPressed: () {
        setState(() {
          isChecked = !isChecked;
        });
        widget.onChanged(isChecked);
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Checkbox(
            value: isChecked,
            activeColor: AppColor.primaryColor,
            onChanged: (value) {
              setState(() {
                isChecked = !isChecked;
              });
              widget.onChanged(value);
            },
          ),
          Expanded(
            child: widget.title,
          ),
        ],
      ),
    );
  }
}
