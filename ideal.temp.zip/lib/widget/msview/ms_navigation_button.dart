import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MSNavigationButton extends StatelessWidget {
  final VoidCallback onTap;
  final IconData iconData;
  final Color iconColor;
  final Color buttonColor;
  final String imageAsset;
  final Color imageAssetColor;
  final int numberNotification;
  final double elevation;
  final double size;
  const MSNavigationButton(
      {Key key,
      this.onTap,
      this.iconData,
      this.iconColor,
      this.buttonColor,
      this.numberNotification = 0,
      this.elevation = 0,
      this.imageAsset,
      this.imageAssetColor,
      this.size = 36})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          alignment: Alignment.center,
          width: isVisibleDot() ? 45 : 40,
          height: 40,
          child: MSCircleButton(
              size: size,
              elevation: elevation,
              imageAsset: imageAsset,
              imageAssetColor: imageAssetColor,
              icon: imageAsset == null
                  ? Icon(
                      iconData,
                      size: 28,
                      color: iconColor ?? AppColor.black,
                    )
                  : null,
              color: buttonColor ?? AppColor.grey600,
              onTap: onTap),
        ),
        _redDotView(context)
      ],
    );
  }

  bool isVisibleDot() {
    return numberNotification > 0;
  }

  Positioned _redDotView(BuildContext context) {
    return Positioned(
      right: 0,
      top: 2,
      child: Visibility(
        visible: isVisibleDot(),
        child: Container(
          width: 20,
          alignment: Alignment.center,
          height: 20,
          decoration: BoxDecoration(
            color: AppColor.primaryColor,
            shape: BoxShape.circle,
          ),
          child: Text(
            "$numberNotification",
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: AppColor.white),
          ),
        ),
      ),
    );
  }
}
