//
// Created by nqhung on 30/10/2020.
//

import 'package:flutter/material.dart';

class ExpandedView extends StatelessWidget {
  final Widget child;

  final double _width;
  final double _height;

  ExpandedView.both({Key key, this.child})
      : _width = double.infinity,
        _height = double.infinity,
        super(key: key);

  ExpandedView.horizontal({Key key, this.child})
      : _width = double.infinity,
        _height = null,
        super(key: key);

  ExpandedView.vertical({Key key, this.child})
      : _width = null,
        _height = double.infinity,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(width: _width, height: _height, child: child);
  }
}
