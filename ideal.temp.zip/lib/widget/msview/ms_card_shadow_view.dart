import 'package:flutter/material.dart';

class MSCardShadowView extends StatelessWidget {
  const MSCardShadowView(
      {Key key,
      this.width,
      this.height,
      this.margin,
      this.padding,
      this.color = Colors.white,
      this.borderRadius,
      this.alignment = Alignment.center,
      @required this.child})
      : super(key: key);

  final Color color;
  final double width;
  final double height;
  final Widget child;
  final Alignment alignment;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final BorderRadiusGeometry borderRadius;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return ConstrainedBox(
            constraints: BoxConstraints(
                maxWidth: width != null ? width : double.infinity,
                maxHeight: height != null ? height : double.infinity),
            child: Container(
              padding: padding != null ? padding : EdgeInsets.zero,
              alignment: alignment,
              decoration: BoxDecoration(
                color: color,
                borderRadius: borderRadius != null
                    ? borderRadius
                    : BorderRadius.all(Radius.circular(10)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 7,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: child,
            ),
          );
        },
      ),
    );
  }
}
