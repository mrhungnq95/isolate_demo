import 'package:flutter/material.dart';
import '../../app/app_color.dart';

class MSCircleButton extends StatelessWidget {
  const MSCircleButton(
      {Key key,
      @required this.size,
      this.color = AppColor.primaryColor,
      this.borderSide,
      this.elevation = 0,
      this.padding = EdgeInsets.zero,
      this.imageAsset,
      this.imageAssetColor,
      this.icon,
      this.isIconFullSizeParent = false,
      @required this.onTap})
      : super(key: key);

  final double elevation;
  final EdgeInsets padding;
  final BorderSide borderSide;
  final Color color;
  final double size;
  final Icon icon;
  final String imageAsset;
  final Color imageAssetColor;
  final bool isIconFullSizeParent;    // Icon bằng size với button
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: elevation,
      clipBehavior: Clip.hardEdge,
      shape: borderSide != null
          ? CircleBorder(side: borderSide)
          : CircleBorder(side: BorderSide(color: Colors.transparent, width: 0)),
      color: color,
      child: InkWell(
        splashColor: AppColor.splashColor,
        highlightColor: AppColor.splashColor,
        child: Container(
            padding: padding,
            width: size,
            height: size,
            child: icon ??
                Image.asset(
                  imageAsset,
                  color: imageAssetColor,
                  width: isIconFullSizeParent ? size : 25,
                  height: isIconFullSizeParent ? size : 25,
                )),
        onTap: onTap,
      ),
    );
  }
}
