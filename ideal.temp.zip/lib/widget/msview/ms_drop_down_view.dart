import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/model/drop_down_item_object.dart';
import 'package:flutter/material.dart';

class MSDropDownView<T> extends StatefulWidget {
  final DropDownItemObject<T> itemOption;
  final List<DropDownItemObject<T>> optionList;
  final ValueChanged<DropDownItemObject<T>> onValueChanged;
  final Color titleColor;
  final Color dropDownIconColor;
  const MSDropDownView(
      {Key key,
      @required this.itemOption,
      @required this.optionList,
      this.titleColor = AppColor.textColor,
      this.dropDownIconColor = AppColor.black,
      this.onValueChanged})
      : super(key: key);

  @override
  _DropDownViewState<T> createState() => _DropDownViewState<T>();
}

class _DropDownViewState<T> extends State<MSDropDownView<T>> {
  DropDownItemObject<T> _itemOption;
  List<DropDownItemObject<T>> _optionList;

  @override
  void initState() {
    super.initState();

    _itemOption = widget.itemOption;
    _optionList = widget.optionList;
  }

  @override
  Widget build(BuildContext context) {
    return DropdownButton<DropDownItemObject<T>>(
      value: _itemOption,
      icon: Icon(
        Icons.keyboard_arrow_down,
        color: widget.dropDownIconColor ?? AppColor.black,
      ),
      iconSize: 20,
      elevation: 16,
      style: Theme.of(context)
          .textTheme
          .bodyText1
          .copyWith(color: widget.titleColor ?? AppColor.textColor),
      onChanged: (DropDownItemObject<T> newValue) {
        setState(() {
          _itemOption = newValue;
        });

        widget.onValueChanged(newValue);
      },
      isDense: true,
      underline: const SizedBox.shrink(),
      items: _optionList.map<DropdownMenuItem<DropDownItemObject<T>>>(
          (DropDownItemObject<T> value) {
        return DropdownMenuItem<DropDownItemObject<T>>(
          value: value,
          child: Text(value.title),
        );
      }).toList(),
    );
  }
}
