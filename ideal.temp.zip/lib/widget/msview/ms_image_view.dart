import 'package:MShopManager/widget/msview/ms_cached_network_image.dart';
import 'package:flutter/material.dart';

enum ImageViewType { asset, network }

class MSImageView extends StatelessWidget {
  final double width;

  final double height;
  final BorderRadiusGeometry borderRadius;

  /// The aspect ratio to attempt to use.
  ///
  /// The aspect ratio is expressed as a ratio of width to height. For example,
  /// a 16:9 width:height aspect ratio would have a value of 16.0/9.0.
  final double aspectRatio;

  final String imageUrl;
  final String imageAssetsPath;
  final ImageViewType type;

  const MSImageView({
    Key key,
    @required this.type,
    this.width,
    this.height,
    this.borderRadius,
    this.aspectRatio,
    this.imageUrl,
    this.imageAssetsPath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (type == ImageViewType.network) {
      return MSCachedNetworkImage(
        width: width,
        height: height,
        imageUrl: imageUrl,
        aspectRatio: aspectRatio,
        borderRadius: borderRadius,
      );
    } else {
      final imageView = Container(
        height: height,
        width: width,
        decoration: BoxDecoration(
          borderRadius: borderRadius != null ? borderRadius : BorderRadius.zero,
          image: DecorationImage(
            image: AssetImage(imageAssetsPath),
            fit: BoxFit.cover,
          ),
        ),
      );

      if (aspectRatio != null) {
        return AspectRatio(
          aspectRatio: aspectRatio,
          child: imageView,
        );
      } else {
        return imageView;
      }
    }
  }
}
