import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/material.dart';
import '../../app/app_color.dart';
import '../../utils/extension/color_ext.dart';

enum MSButtonStyle { facebookSignIn, googleSignIn, appleSignIn, rectangle }

class MSButton extends RaisedButton {
  const MSButton(
      {@required this.onPressed,
      @required this.label,
      this.buttonStyle = MSButtonStyle.rectangle,
      this.minWidth,
      this.height = 48,
      this.isContentCenter = true,
      this.imageAsset,
      this.imageAssetSize = 24,
      this.imageAssetColor,
      this.iconData,
      this.iconColor = AppColor.white,
      this.buttonColor = AppColor.primaryColor,
      this.buttonColorDisable = AppColor.grey600,
      this.textSize = 14,
      this.borderColor = Colors.transparent,
      this.borderRadius,
      this.borderWidth = 0.0,
      this.elevation = 0.0,
      this.mainAxisSize = MainAxisSize.min,
      this.isRemovePadding = false,
      this.textColor = Colors.white});

  final minWidth;
  final height;
  final bool isRemovePadding;
  final double elevation;
  final bool isContentCenter;
  final String imageAsset;
  final IconData iconData;
  final double imageAssetSize;
  final Color imageAssetColor;
  final Color iconColor;
  final Color buttonColor;
  final Color buttonColorDisable;
  final Color textColor;
  final double textSize;
  final VoidCallback onPressed;
  final String label;
  final Color borderColor;
  final double borderWidth;
  final MSButtonStyle buttonStyle;
  final BorderRadiusGeometry borderRadius;
  final MainAxisSize mainAxisSize;

  Widget buildIconButton(BuildContext context) {
    return Row(
      mainAxisSize: mainAxisSize,
      mainAxisAlignment:
          isContentCenter ? MainAxisAlignment.center : MainAxisAlignment.start,
      children: [
        iconData != null
            ? Icon(
                iconData,
                size: 24,
                color: iconColor,
              )
            : Image.asset(
                imageAsset,
                fit: BoxFit.fill,
                width: imageAssetSize,
                height: imageAssetSize,
                color: imageAssetColor,
              ),
        kHorizontalSpaceSmallBox,
        Text(
          label,
          style: Theme.of(context)
              .textTheme
              .button
              .copyWith(color: textColor, fontSize: textSize),
        )
      ],
    );
  }

  Widget buildButton(BuildContext context) {
    return Text(
      label,
      style: Theme.of(context)
          .textTheme
          .button
          .copyWith(color: textColor, fontSize: textSize),
    );
  }

  ButtonThemeData getButtonThemeData(BuildContext context) {
    switch (buttonStyle) {
      case MSButtonStyle.facebookSignIn:
      case MSButtonStyle.googleSignIn:
      case MSButtonStyle.appleSignIn:
        return Theme.of(context).buttonTheme.copyWith(
            minWidth: minWidth,
            height: height,
            buttonColor: buttonStyle.getColorButton(),
            shape: RoundedRectangleBorder(
              side: BorderSide(color: borderColor, width: borderWidth),
              borderRadius: BorderRadius.circular(22),
            ));
      default:
        return Theme.of(context).buttonTheme.copyWith(
            minWidth: minWidth,
            height: height,
            buttonColor: buttonColor,
            shape: RoundedRectangleBorder(
              side: BorderSide(color: borderColor, width: borderWidth),
              borderRadius: borderRadius != null
                  ? borderRadius
                  : BorderRadius.circular(12),
            ));
    }
  }

  bool hasIconButton() {
    return imageAsset != null || iconData != null;
  }

  @override
  Widget build(BuildContext context) {
    var child =
        hasIconButton() ? buildIconButton(context) : buildButton(context);

    RaisedButton supperButton = RaisedButton(
      onPressed: onPressed,
      elevation: elevation,
      disabledColor: buttonColorDisable,
      padding: EdgeInsets.symmetric(
          horizontal: isRemovePadding ? 0 : kHorizontalSpaceSmall),
      highlightElevation: 0.0,
      child: child,
    );

    //minWidth: minWidth, height: height, buttonColor: buttonColor
    return Theme(
      data: Theme.of(context).copyWith(
        buttonTheme: getButtonThemeData(context),
      ),
      child: supperButton,
    );
  }
}

extension AppButtonThemeData on MSButtonStyle {
  Color getColorButton() {
    switch (this) {
      case MSButtonStyle.facebookSignIn:
        return "#4267b2".toColor();
      case MSButtonStyle.googleSignIn:
        return "#FFFFFF".toColor();
      case MSButtonStyle.appleSignIn:
        return "#000000".toColor();
      default:
        return AppColor.grey600;
    }
  }
}
