import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_navigation_button.dart';
import 'package:flutter/material.dart';

class MSEShopSliverAppBar extends StatelessWidget {
  final IconData iconLeading;
  final VoidCallback onLeadingTap;
  final VoidCallback onTrailingTap;
  final double toolbarHeight;
  final double expandedHeight;
  final double collapsedHeight;
  final Color iconLeadingColor;
  final Color iconTrailingColor;
  final Color backgroundColor;

  final String title;
  final Widget customTitle;
  final Widget bottom;

  final Widget leadingButton;
  final List<Widget> actions;
  final bool automaticallyImplyTrailing;
  final bool automaticallyImplyLeading;
  final bool
      isEmptyTrailingViewWhenEmptyButton; // Xóa khoảng trắng bên phải khi không có button
  final Widget flexibleSpace;

  final double elevation;
  final bool pinned;
  final bool snap;
  final bool floating;
  final bool stretch;

  const MSEShopSliverAppBar(
      {Key key,
      @required this.title,
      this.customTitle,
      this.toolbarHeight,
      this.expandedHeight,
      this.collapsedHeight,
      this.iconLeading = Icons.arrow_back_ios_rounded,
      this.backgroundColor = AppColor.white,
      this.iconLeadingColor = AppColor.white,
      this.iconTrailingColor = AppColor.white,
      this.onLeadingTap,
      this.pinned = true,
      this.bottom,
      this.snap = false,
      this.floating = false,
      this.stretch = false,
      this.onTrailingTap,
      this.automaticallyImplyLeading = false,
      this.automaticallyImplyTrailing = false,
      this.isEmptyTrailingViewWhenEmptyButton = false,
      this.leadingButton,
      this.flexibleSpace,
      this.elevation = 1,
      this.actions})
      : assert(title != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      toolbarHeight: toolbarHeight ?? kToolbarHeight,
      expandedHeight: expandedHeight,
      collapsedHeight: collapsedHeight,
      titleSpacing: 0,
      elevation: elevation,
      stretch: stretch,
      bottom: bottom ??
          PreferredSize(
              child: kSpaceShrinkBox, preferredSize: Size.fromHeight(0)),
      backgroundColor: backgroundColor,
      pinned: pinned,
      snap: snap,
      flexibleSpace: flexibleSpace,
      floating: floating,
      title: Container(
        //padding: const EdgeInsets.only(right: kHorizontalSpaceMedium),
        height: toolbarHeight ?? kToolbarHeight,
        child: Row(
          children: [
            Expanded(
                flex: automaticallyImplyLeading == true ? 0 : 1,
                child: _buildLeadingButton()),
            customTitle ??
                Text(title,
                    textAlign: automaticallyImplyLeading == true
                        ? TextAlign.left
                        : TextAlign.center,
                    style: Theme.of(context)
                        .textTheme
                        .subtitle2
                        .copyWith(fontWeight: FontWeight.bold)),
            Expanded(child: _buildTrailingButton())
          ],
        ),
      ),
      automaticallyImplyLeading: false,
    );
  }

  Widget _buildLeadingButton() {
    if (leadingButton != null) {
      return leadingButton;
    } else {
      if (automaticallyImplyLeading) {
        return SizedBox(
          width: kHorizontalSpaceLarge,
        );
      } else {
        return MSNavigationButton(
            iconData: iconLeading,
            iconColor: iconLeadingColor,
            buttonColor: Colors.transparent, //AppColor.white.withOpacity(0.3),
            onTap: onLeadingTap);
      }
    }
  }

  ///
  /// Ds button bên phải
  ///
  Widget _buildTrailingButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: _contentTrailingButton(),
    );
  }

  List<Widget> _contentTrailingButton() {
    if (actions != null && actions.isNotEmpty) {
      return actions;
    } else {
      if (automaticallyImplyTrailing) {
        return [
          SizedBox(
            width: isEmptyTrailingViewWhenEmptyButton ? 0 : 40,
          )
        ];
      } else {
        return [
          MSCircleButton(
              elevation: 5,
              color: null,
              size: 40,
              imageAsset: AppResources.icFilter,
              imageAssetColor: null,
              onTap: onTrailingTap)
        ];
      }
    }
  }
}
