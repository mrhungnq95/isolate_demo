import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_navigation_button.dart';
import 'package:flutter/material.dart';

class MSEShopAppBar extends StatelessWidget with PreferredSizeWidget {
  final IconData iconLeading;
  final VoidCallback onLeadingTap;
  final VoidCallback onTrailingTap;
  final double toolbarHeight;
  final double expandedHeight;
  final Color backgroundColor;

  final String title;
  final Widget customTitle;
  final Widget bottom;
  final double elevation;

  final Widget leadingButton;
  final List<Widget> actions;
  final bool isCenterTitle;
  final bool automaticallyImplyTrailing;
  final bool automaticallyImplyLeading;

  static const double heightToolbarValue = 55;

  const MSEShopAppBar(
      {Key key,
      @required this.title,
      this.customTitle,
      this.elevation = 4.0, //Default
      this.toolbarHeight = heightToolbarValue,
      this.expandedHeight,
      this.iconLeading = Icons.arrow_back_ios_rounded,
      this.backgroundColor = AppColor.white,
      this.onLeadingTap,
      this.bottom,
      this.onTrailingTap,
      this.automaticallyImplyLeading = false,
      this.automaticallyImplyTrailing = false,
      this.leadingButton,
      this.actions,
      this.isCenterTitle = false})
      : assert(title != null),
        super(key: key);

  Widget _buildLeadingButton() {
    if (leadingButton != null) {
      return leadingButton;
    } else {
      if (automaticallyImplyLeading) {
        return SizedBox(
          width: 40,
        );
      } else {
        return MSNavigationButton(
            iconData: iconLeading,
            buttonColor: Colors.transparent, //AppColor.white.withOpacity(0.3),
            onTap: onLeadingTap);
      }
    }
  }

  ///
  /// Ds button bên phải
  ///
  Widget _buildTrailingButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: _contentTrailingButton(),
    );
  }

  List<Widget> _contentTrailingButton() {
    if (actions != null && actions.isNotEmpty) {
      return actions;
    } else {
      if (automaticallyImplyTrailing) {
        return [
          SizedBox(
            width: 40,
          )
        ];
      } else {
        return [
          MSCircleButton(
              elevation: 5,
              color: null,
              size: 40,
              imageAsset: AppResources.icFilter,
              imageAssetColor: null,
              onTap: onTrailingTap)
        ];
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: elevation,
      toolbarHeight: toolbarHeight,
      titleSpacing: 0,
      bottom: bottom ??
          PreferredSize(
              child: kSpaceShrinkBox, preferredSize: Size.fromHeight(0)),
      backgroundColor: backgroundColor,
      title: Container(
        padding: const EdgeInsets.only(right: kHorizontalSpaceLarge),
        height: heightToolbarValue,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
                flex: isCenterTitle == true ? 1 : 0,
                child: _buildLeadingButton()),
            Flexible(
              child: customTitle ??
                  Text(title,
                      textAlign: isCenterTitle == true
                          ? TextAlign.center
                          : TextAlign.left,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .subtitle2
                          .copyWith(fontWeight: FontWeight.bold)),
            ),
            Expanded(child: _buildTrailingButton())
          ],
        ),
      ),
      automaticallyImplyLeading: false,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(toolbarHeight);
}
