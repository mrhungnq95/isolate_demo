import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import '../../app/app_color.dart';
import '../../app/app_spacing.dart';
import 'ms_circle_button.dart';

class MSEditText extends StatefulWidget {
  MSEditText(
      {Key key,
      @required this.controller,
      @required this.focusNode,
      this.hintText = "",
      this.title,
      this.titleTextStyle,
      this.height,
      this.isPassword = false,
      this.isRequire = false,
      this.isShowObscureTextModeButton = true,
      this.readOnly = false,
      this.isValidated = true,
      this.isTitleInsideBackground = false,
      this.textAlign = TextAlign.start,
      this.suffixIcon,
      this.prefixIconAsset,
      this.prefixIcon,
      this.prefixIconColor,
      this.borderColor = Colors.transparent,
      this.backgroundColor = AppColor.backgroundTextField,
      this.suffixIconColor = Colors.black,
      this.maxLines = 1,
      this.minLines = 1,
      this.autofocus = false,
      this.isShowClearTextButton = false,
      this.keyboardType,
      this.textInputAction,
      this.textCapitalization = TextCapitalization.none,
      this.onChanged,
      this.onEditingComplete,
      this.onSubmitted,
      this.onSuffixIconTapped,
      this.onPrefixIconTapped})
      : super(key: key);

  final TextEditingController controller;
  final FocusNode focusNode;
  final double height;
  final String title;
  final TextStyle titleTextStyle;
  final String hintText;
  final isTitleInsideBackground;
  final bool isPassword;
  final bool isRequire;
  final bool isShowClearTextButton;
  final bool isShowObscureTextModeButton;
  final IconData prefixIcon;
  final String prefixIconAsset;
  final IconData suffixIcon;
  final Color prefixIconColor;
  final Color suffixIconColor;
  final Color borderColor;
  final Color backgroundColor;
  final int maxLines;
  final int minLines;
  final bool autofocus;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final TextAlign textAlign;
  final TextCapitalization textCapitalization;
  final bool readOnly;
  final bool isValidated;
  final ValueChanged<String> onChanged;
  final VoidCallback onEditingComplete;
  final ValueChanged<String> onSubmitted;
  final VoidCallback onSuffixIconTapped;
  final VoidCallback onPrefixIconTapped;

  @override
  _MSEditTextState createState() => _MSEditTextState();
}

class _MSEditTextState extends State<MSEditText> {
  static const double heightDef = 48;
  static const double heightForTitleInsideBackgroundDef = 20;
  static const double sizeIconDef = 40;
  static const double sizeIconForTitleInsideBackgroundDef = 20;

  bool isShowHint = true;
  bool isShowingPassword = false;
  bool isEditTextFocused = false;

  @override
  void initState() {
    super.initState();

    isEditTextFocused = widget.focusNode.hasFocus;
    isShowingPassword = !widget.isPassword;

    widget.focusNode.addListener(() {
      if (mounted) {
        setState(() {
          isEditTextFocused = widget.focusNode.hasFocus;
        });
      }
    });
  }

  IconData getSuffixIconButton() {
    if (isPasswordSuffixIconButton()) {
      return isShowingPassword ? Icons.visibility_off : Icons.visibility;
    } else if (widget.isShowClearTextButton) {
      return Icons.cancel;
    }

    return Icons.cancel;
  }

  bool isPasswordSuffixIconButton() {
    return widget.isPassword && widget.isShowObscureTextModeButton;
  }

  bool isClearTextSuffixIconButton() {
    return widget.isShowClearTextButton;
  }

  bool isShowSuffixIconButton() {
    return (widget.isPassword && widget.isShowObscureTextModeButton) ||
        (widget.isShowClearTextButton &&
            isShowHint == false &&
            widget.focusNode.hasFocus);
  }

  bool isObscureText() {
    return isShowingPassword == false &&
        widget.isPassword &&
        widget.isShowObscureTextModeButton;
  }

  bool isMultiline() {
    return widget.maxLines > 1;
  }

  Widget _prefixButton() {
    if (widget.prefixIcon != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          splashColor: AppColor.primaryColor.withOpacity(0.5),
          onTap: widget.onPrefixIconTapped,
          child: Icon(
            widget.prefixIcon,
            size: 20,
            color: AppColor.black,
          ),
        ),
      );
    } else if (widget.prefixIconAsset != null) {
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: Image.asset(
          widget.prefixIconAsset,
          fit: BoxFit.fill,
          width: 25,
          height: 25,
          color: widget.prefixIconColor,
        ),
      );
    } else {
      return SizedBox.shrink();
    }
  }

  Widget _suffixButton() {
    if (isShowSuffixIconButton()) {
      return MSCircleButton(
          size: widget.isTitleInsideBackground
              ? sizeIconForTitleInsideBackgroundDef
              : sizeIconDef,
          icon: Icon(
            getSuffixIconButton(),
            size: 20,
            color: widget.suffixIconColor,
          ),
          color: Colors.transparent,
          onTap: () {
            if (widget.onSuffixIconTapped != null) {
              widget.onSuffixIconTapped();
            }
            setState(() {
              if (isPasswordSuffixIconButton()) {
                isShowingPassword = !isShowingPassword;
              } else if (widget.isShowClearTextButton) {
                widget.controller.clear();
                isShowHint = true;

                if (widget.onChanged != null) {
                  widget.onChanged("");
                }
              }
            });
          });
    } else {
      if (widget.suffixIcon != null) {
        return MSCircleButton(
            size: widget.isTitleInsideBackground
                ? sizeIconForTitleInsideBackgroundDef
                : sizeIconDef,
            icon: Icon(
              widget.suffixIcon,
              size: 25,
              color: widget.suffixIconColor,
            ),
            color: Colors.transparent,
            onTap: widget.onSuffixIconTapped);
      }
      return kSpaceShrinkBox;
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  double _getHeight() {
    if (isMultiline()) {
      return null;
    } else {
      if (widget.isTitleInsideBackground) {
        return heightForTitleInsideBackgroundDef;
      } else {
        return widget.height ?? heightDef;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    isShowHint = widget.controller.text.isEmpty == true;

    var prefixWidget = _prefixButton();

    var suffixWidget = _suffixButton();

    var content = Container(
      height: _getHeight(),
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceMedium),
      decoration: widget.isTitleInsideBackground == true
          ? BoxDecoration(
              border: Border.all(
                  color: widget.isValidated ? Colors.transparent : Colors.red),
              //color: Color(0xFFF5F5F5),
              borderRadius: BorderRadius.circular(12))
          : BoxDecoration(),
      child: _contentEditText(context, prefixWidget, suffixWidget),
    );

    return GestureDetector(
        onTap: () {
          widget.focusNode.requestFocus();
        },
        child: _buildContent(content: content));
  }

  Widget _contentEditText(
      BuildContext context, Widget prefixWidget, Widget suffixWidget) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        prefixWidget,
        Expanded(
          child: Container(
            margin: EdgeInsets.only(
                left: widget.prefixIcon != null ? kHorizontalSpaceLarge : 0,
                right: widget.suffixIcon != null ? kHorizontalSpaceLarge : 0),
            child: TextField(
                decoration: InputDecoration(
                  fillColor: Colors.transparent,
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                  hintText: widget.hintText,
                  filled: true,
                ),
                restorationId: 'editable',
                readOnly: widget.readOnly,
                controller: widget.controller,
                focusNode: widget.focusNode,
                cursorColor: AppColor.indigo900,
                style: Theme.of(context).textTheme.bodyText1,
                onSubmitted: (value) {
                  print("onSubmitted: $value");

                  if (widget.onSubmitted != null) {
                    widget.onSubmitted(value);
                  }
                },
                onEditingComplete: () {
                  print("onEditingComplete:");
                  if (widget.onEditingComplete != null) {
                    widget.onEditingComplete();
                  }
                },
                onChanged: (value) {
                  print("MSEditableText: $value");

                  if (mounted) {
                    setState(() {
                      isShowHint = value == null || value.isEmpty;
                    });
                  }

                  if (widget.onChanged != null) {
                    widget.onChanged(value);
                  }
                },
                expands: widget.minLines == null && widget.maxLines == null
                    ? true
                    : false,
                minLines: widget.minLines,
                maxLines: widget.maxLines,
                autofocus: widget.autofocus,
                obscureText: isObscureText(),
                keyboardType: isMultiline()
                    ? TextInputType.multiline
                    : widget.keyboardType,
                textInputAction: widget.textInputAction,
                textAlign: widget.textAlign,
                textCapitalization: widget.textCapitalization),
          ),
        ),
        suffixWidget
      ],
    );
  }

  Widget _titleView() {
    if (widget.title != null) {
      return Container(
          height: 20,
          padding: const EdgeInsets.only(
            left: kHorizontalSpaceMedium,
            right: kHorizontalSpaceMedium,
          ),
          child: RichText(
              text: TextSpan(
                  text: widget.title,
                  style: widget.titleTextStyle != null
                      ? widget.titleTextStyle
                      : Theme.of(context).textTheme.caption,
                  children: [
                TextSpan(
                    text: widget.isRequire ? ' *' : '',
                    style: TextStyle(color: AppColor.pink))
              ])));
    }
    return SizedBox.shrink();
  }

  Widget _editText({@required Widget content}) {
    return isMultiline()
        ? LayoutBuilder(builder: (context, constraint) {
            return ConstrainedBox(
                constraints: BoxConstraints(minHeight: heightDef),
                child: content);
          })
        : content;
  }

  Widget _buildContent({@required Widget content}) {
    final verticalPadding =
        widget.isTitleInsideBackground ? kVerticalSpaceMedium : 0.0;
    return Container(
      padding: EdgeInsets.symmetric(vertical: verticalPadding),
      decoration: widget.isTitleInsideBackground
          ? BoxDecoration(
              border: Border.all(
                  color: widget.isValidated ? widget.borderColor : Colors.red),
              color: widget.backgroundColor,
              borderRadius: BorderRadius.circular(12))
          : BoxDecoration(
              border: Border.all(
                color: widget.borderColor,
              ),
              color: widget.backgroundColor,
              borderRadius: BorderRadius.circular(12)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [_titleView(), _editText(content: content)],
      ),
    );
  }
}