//
// Created by nqhung on 09/11/2020.
//

import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MSSegmentView extends StatefulWidget {

  final List<String> values;
  final position;
  final ValueChanged onValueChanged;
  final Color backgroundColor;
  final Color backgroundColorItemSelected;
  final Color textColorSelectedItem;
  final Color textColorUnSelectedItem;
  final double heightView;


  MSSegmentView(
      {Key key,
      @required this.values,
      @required this.onValueChanged,
      this.position, this.backgroundColor, this.textColorSelectedItem, this.textColorUnSelectedItem, this.backgroundColorItemSelected, this.heightView})
      : super(key: key);

  @override
  _MSSegmentViewState createState() => _MSSegmentViewState();
}

class _MSSegmentViewState extends State<MSSegmentView> {
  int positionSelected = 0;
  double width;
  double widthItem;

  @override
  void initState() {
    super.initState();
    positionSelected = widget.position;
    width = ScreenUtils.width;
  }

  @override
  Widget build(BuildContext context) {
    widthItem = ScreenUtils.width / widget.values.length;
    return Container(
      width: width,
      height: widget.heightView ?? width * .13,
      child: Stack(
        children: [
          Container(
            width: width,
            height: widget.heightView ?? width * .13,
            decoration: BoxDecoration(
                border: Border.all(color: AppColor.grey300),
                color: widget.backgroundColor ?? AppColor.white,
                borderRadius: BorderRadius.circular(10)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                widget.values.length,
                (index) => Expanded(
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        positionSelected = index;
                      });
                      widget.onValueChanged(index);
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: widthItem,
                      height: widget.heightView ?? width * .13,
                      //padding: EdgeInsets.symmetric(horizontal: width * .1),
                      child: Text(
                        widget.values[index],
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.bodyText1.copyWith(
                            fontWeight: FontWeight.bold,
                            color: widget.textColorUnSelectedItem ?? AppColor.textDisableColor),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          _selectedView()
        ],
      ),
    );
  }

  Widget _selectedView() {
    return AnimatedAlign(
      alignment:
          positionSelected == 0 ? Alignment.centerLeft : Alignment.centerRight,
      duration: Duration(milliseconds: 350),
      curve: Curves.ease,
      child: Container(
        alignment: Alignment.center,
        width: widthItem,
        height: widget.heightView ?? width * .13,
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            color: widget.backgroundColorItemSelected ?? AppColor.indigo900,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
            borderRadius: BorderRadius.circular(10)),
        child: Text(
          widget.values[positionSelected],
          style: TextStyle(fontWeight: FontWeight.bold, color: widget.textColorSelectedItem ?? AppColor.white),
        ),
      ),
    );
  }
}
