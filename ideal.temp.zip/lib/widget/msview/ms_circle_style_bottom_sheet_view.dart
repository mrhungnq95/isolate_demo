import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'ms_circle_button.dart';

///
/// Header chung cho bottom Sheet
///
class MSCircleStyleBottomSheetView extends StatelessWidget {
  final String title;
  final double height;
  final EdgeInsets padding;
  final List<Widget> children;

  MSCircleStyleBottomSheetView(
      {this.title, this.height, this.padding, @required this.children});

  @override
  Widget build(BuildContext context) {
    children.insert(0, _headerView(context: context, title: title));

    return Container(
      padding: padding ??
          EdgeInsets.only(
            left: kHorizontalSpaceLarge,
            right: kHorizontalSpaceLarge,
          ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(12), topRight: Radius.circular(12)),
        color: AppColor.white,
      ),
      height: this.height != null ? this.height : null,
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }

  ///
  /// Build title cho bottom sheet
  ///
  Widget _headerView({BuildContext context, String title}) {
    return Padding(
      padding: (padding != null && padding == EdgeInsets.zero)
          ? EdgeInsets.only(
              left: kHorizontalSpaceLarge,
              right: kHorizontalSpaceLarge,
              top: kHorizontalSpaceMedium)
          : EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2,
          ),
          MSCircleButton(
              elevation: 10,
              color: AppColor.white,
              size: 40,
              icon: Icon(
                Icons.clear,
                color: Colors.red,
              ),
              imageAssetColor: AppColor.indigo900,
              onTap: () {
                Navigator.of(context).pop();
              }),
        ],
      ),
    );
  }
}
