import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';

class MSCircleNetworkNetworkImage extends StatelessWidget {
  final String imageUrl;
  final double width;
  final double height;

  const MSCircleNetworkNetworkImage(
      {Key key,
      @required this.width,
      @required this.height,
      @required this.imageUrl})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        image: DecorationImage(
          fit: BoxFit.cover,
          image: CachedNetworkImageProvider(imageUrl),
        ),
      ),
    );
  }
}
