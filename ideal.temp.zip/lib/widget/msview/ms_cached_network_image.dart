import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class MSCachedNetworkImage extends StatelessWidget {
  const MSCachedNetworkImage(
      {Key key,
      @required this.imageUrl,
      this.aspectRatio,
      this.height,
      this.width,
      this.borderRadius,
      this.imageAssetDefault})
      : super(key: key);

  final String imageUrl;
  final double height;
  final double width;
  final Image imageAssetDefault;
  final BorderRadiusGeometry borderRadius;

  /// The aspect ratio to attempt to use.
  ///
  /// The aspect ratio is expressed as a ratio of width to height. For example,
  /// a 16:9 width:height aspect ratio would have a value of 16.0/9.0.
  final double aspectRatio;

  @override
  Widget build(BuildContext context) {
    Widget _content(ImageProvider<dynamic> imageProvider) {
      return Container(
        height: height,
        width: width,
        decoration: BoxDecoration(
          borderRadius: borderRadius != null ? borderRadius : BorderRadius.zero,
          image: DecorationImage(
            image: imageProvider,
            fit: BoxFit.cover,
          ),
        ),
      );
    }

    return CachedNetworkImage(
      imageUrl: imageUrl,
      imageBuilder: (context, imageProvider) => aspectRatio != null
          ? AspectRatio(
              aspectRatio: aspectRatio,
              child: _content(imageProvider),
            )
          : _content(imageProvider),
      progressIndicatorBuilder: (context, url, downloadProgress) => Container(
        width: 50,
        height: 50,
        color: Colors.transparent,
        alignment: Alignment.center,
        child: CircularProgressIndicator(value: downloadProgress.progress),
      ),
      errorWidget: (context, url, error) =>
          imageAssetDefault ?? Icon(Icons.error),
    );
  }
}
