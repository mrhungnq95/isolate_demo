import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'ms_navigation_button.dart';

class MSCupertinoNavigationBar extends StatelessWidget
    with ObstructingPreferredSizeWidget {
  final String title;
  final Color titleTextColor;
  final Color backgroundColor;
  final Color iconLeadingColor;
  final Color iconTrailingColor;
  final Border border;
  final IconData iconLeadingButton;
  final IconData iconTrailingButton;
  final VoidCallback onLeadingTap;
  final VoidCallback onTrailingTap;
  final numberNotifyLeadingButton;
  final numberNotifyTrailingButton;

  static const borderDefault = Border(
    bottom: BorderSide(
      color: Color(0x4D000000),
      width: 0.0, // One physical pixel.
      style: BorderStyle.solid,
    ),
  );

  const MSCupertinoNavigationBar(
      {Key key,
      this.title = "",
      this.border,
      this.iconLeadingButton = Icons.chevron_left,
      this.iconTrailingButton,
      this.iconLeadingColor = AppColor.black,
      this.iconTrailingColor = AppColor.white,
      this.titleTextColor = AppColor.white,
      this.backgroundColor = AppColor.primaryColor,
      this.numberNotifyLeadingButton = 0,
      this.numberNotifyTrailingButton = 0,
      this.onTrailingTap,
      this.onLeadingTap})
      : super(key: key);

  Widget _buildLeadingButton() {
    if (iconLeadingButton != null) {
      // return MSNavigationButton(
      //     iconData: iconLeadingButton,
      //     buttonColor: Colors.transparent, //AppColor.white.withOpacity(0.3),
      //     onTap: onLeadingTap);

      return MSNavigationButton(
          iconData: iconLeadingButton,
          iconColor: iconLeadingColor,
          numberNotification: numberNotifyLeadingButton,
          buttonColor: Colors.transparent, //AppColor.white.withOpacity(0.3),
          onTap: onLeadingTap);
    }
    return kSpaceShrinkBox;
  }

  Widget _buildTrailingButton() {
    if (iconTrailingButton != null) {
      return MSNavigationButton(
          iconData: iconTrailingButton,
          iconColor: iconTrailingColor,
          numberNotification: numberNotifyTrailingButton,
          buttonColor: Colors.transparent, //AppColor.white.withOpacity(0.3),
          onTap: onTrailingTap);
    }
    return kSpaceShrinkBox;
  }

  @override
  Widget build(BuildContext context) {
    return CupertinoNavigationBar(
      padding: EdgeInsetsDirectional.only(
          start: kHorizontalSpaceSmall, end: kHorizontalSpaceSmall),
      backgroundColor: backgroundColor,
      leading: _buildLeadingButton(),
      border: border ?? borderDefault,
      trailing: _buildTrailingButton(),
      middle: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .subtitle2
            .copyWith(fontWeight: FontWeight.bold, color: titleTextColor),
      ),
    );
  }

  @override
  Size get preferredSize {
    return const Size.fromHeight(kMinInteractiveDimensionCupertino);
  }

  @override
  bool shouldFullyObstruct(BuildContext context) {
    final Color backgroundColor =
        CupertinoDynamicColor.resolve(this.backgroundColor, context) ??
            CupertinoTheme.of(context).barBackgroundColor;
    return backgroundColor.alpha == 0xFF;
  }
}
