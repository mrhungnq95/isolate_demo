import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:MShopManager/widget/total_style_border_value_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

/// 
/// Chọn, thêm hàng hóa vào danh sách
/// Dùng cho các màn hình thêm phiếu nhập kho, xuất kho, trả lại hàng mua
/// 
class ImportInventoryItemView extends StatelessWidget {

  final Widget contentView;

  ImportInventoryItemView({@required this.contentView});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppColor.grey50,
          border: Border.all(color: AppColor.grey300),
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        children: [
          kVerticalSpaceMediumBox,
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
            child: SearchBox(
              onTapTextField: () {
                Navigator.pushNamed(context, AppRouterName.choose_inventory_item_page.value());
              },
              isEnable: false,
              placeholder: 'Nhập tên hàng hóa, mã SKU...',
              trailingView: Row(
                children: [
                  InkWellView(
                    borderRadius: 6,
                    onPressed: () {
                      Navigator.pushNamed(
                          context, AppRouterName.add_inventory_item.value());
                    },
                    child: Icon(
                      Icons.add,
                      size: 25,
                      color: AppColor.primaryColor,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(kHorizontalSpaceOverSmall),
                    child: InkWellView(
                      borderRadius: 6,
                      onPressed: () {},
                      child: Image.asset(
                        AppResources.icBarcode,
                        width: 25,
                        height: 25,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          kVerticalSpaceMediumBox,
          Expanded(child: contentView),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
            decoration: BoxDecoration(
                color: AppColor.grey400,
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10))),
            height: 44,
            child: TotalStyleBorderValueView(
              isBorderQuantityView: false,
              title: 'Tổng: ',
              totalItem: 2,
              value: 470000,
            ),
          )
        ],
      ),
    );
  }
}
