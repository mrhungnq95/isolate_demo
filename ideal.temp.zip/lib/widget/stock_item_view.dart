import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/features/report/checking/widget/item_checking_info_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class StockItemView extends StatelessWidget {
  final String title;
  final String subTitle;
  final Function onTap;
  final EdgeInsetsGeometry padding;
  StockItemView({this.title, this.subTitle, this.onTap, this.padding});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ??
          const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: ItemChekingInfoView(
        title: title,
        value: subTitle,
        iconRight: Icon(
          Icons.keyboard_arrow_right,
          color: AppColor.grey600,
        ),
        onTap: onTap,
      ),
    );
  }
}
