library scroll_bottom_navigation_bar;

export 'package:MShopManager/widget/bottomnav/scroll_bars_common/scroll_bars_controller.dart'
    show Snap;

export 'src/scroll_bottom_navigation_bar.dart';
export 'src/scroll_bottom_navigation_bar_controller.dart';
