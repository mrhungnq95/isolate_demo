import 'package:flutter/material.dart';

class FloatingNavbarItem {
  final String title;
  final IconData icon;
  final String assetImage;
  final Widget customWidget;

  FloatingNavbarItem({
    this.icon,
    this.assetImage,
    this.title,
    this.customWidget,
  });
}
