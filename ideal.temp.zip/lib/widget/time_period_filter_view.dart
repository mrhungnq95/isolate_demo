import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:flutter/material.dart';

import 'many_option_view.dart';

/// Bộ lọc thời gian
class TimePeriodFilter extends StatelessWidget {
  final DateRange dateRange;
  final EReportPeriodType groupValue;
  final List<EReportPeriodType> items;
  final Function(EReportPeriodType period, DateRange dateRange) onChanged;
  final String customTitle;

  const TimePeriodFilter(
      {Key key,
      @required this.dateRange,
      @required this.groupValue,
      @required this.items,
      @required this.onChanged,
        this.customTitle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ManyOptionView<EReportPeriodType>(
      title: 'Thời gian',
      groupValue: groupValue,
      itemCount: items.length,
      valueBuilder: (index) => items[index],
      titleBuilder: (value) {
        return Text(
          buildTitle(timePeriod: value, timePeriodSelected: groupValue),
          style: Theme.of(context).textTheme.bodyText1,
        );
      },
      onChanged: (value) {
        if (value == EReportPeriodType.custom) {
          var fromDate = DateTime.now();
          var toDate = DateTime.now();
          // nếu trước đấy dang chọn custom thì vẫn giữ nguyên dateRange
          // không thi lấy ngày hiện tại
          if (groupValue == EReportPeriodType.custom) {
            fromDate = dateRange.startDate;
            toDate = dateRange.endDate;
          }
          showDateRangePickerDialog(
            context: context,
            fromDate: fromDate,
            toDate: toDate,
            onConfirm: (fromDate, toDate) {
              onChanged?.call(
                value,
                DateRange(
                  startDate: DateTimeHelper.getStartOfDate(fromDate),
                  endDate: DateTimeHelper.getEndOfDate(toDate),
                ),
              );
            },
          );
        } else {
          onChanged?.call(
            value,
            DateTimeHelper.getDateRangeByPeriod(DateTime.now(), value),
          );
        }
      },
    );
  }

  ///
  /// Build tiêu đề case trường hợp mode là custom
  /// VNLONG - 05/12/2021
  ///
  String buildTitle({EReportPeriodType timePeriod, EReportPeriodType timePeriodSelected}) {
    if (timePeriodSelected == EReportPeriodType.custom && timePeriod == EReportPeriodType.custom && customTitle != null) {
      return customTitle;
    } else {
      return timePeriod.title;
    }
  }
}
