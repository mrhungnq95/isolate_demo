import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/material.dart';

class HeaderChartView extends StatelessWidget {
  final String title;
  final String amount;
  final Color titleColor;
  final Color valueColor;
  final Color iconColor;
  final bool isCompare;
  final IconData fluctuationsIcon;
  final Color fluctuationsColor;
  final String fluctuationsTitle;
  final VoidCallback onSharePressed;

  const HeaderChartView({
    Key key,
    this.title,
    this.amount,
    this.titleColor = AppColor.white,
    this.valueColor = AppColor.white,
    this.iconColor = AppColor.white,
    this.isCompare,
    this.fluctuationsTitle,
    this.fluctuationsIcon,
    this.fluctuationsColor,
    @required this.onSharePressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style:
              Theme.of(context).textTheme.caption.copyWith(color: titleColor),
        ),
        Row(
          children: [
            Expanded(
              child: Text(
                amount,
                style: Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(color: valueColor, fontSize: 20),
              ),
            ),
            GestureDetector(
              onTap: onSharePressed,
              child: Image.asset(
                AppResources.icShare,
                width: 25,
                height: 25,
                color: iconColor,
                fit: BoxFit.fill,
              ),
            )
          ],
        ),
        Visibility(
          visible: isCompare,
          child: Row(
            children: [
              Icon(
                fluctuationsIcon ?? Icons.arrow_upward,
                color: fluctuationsColor ?? Colors.green,
                size: 15,
              ),
              Text(
                fluctuationsTitle ?? "--",
                style: Theme.of(context)
                    .textTheme
                    .caption
                    .copyWith(color: fluctuationsColor ?? Colors.green),
              )
            ],
          ),
        ),
      ],
    );
  }
}
