import 'package:MShopManager/app/app_color.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class InkWellView extends StatelessWidget {

  final Widget child;
  final double borderRadius;
  final Color colorBackground;
  final Function onPressed;
  final Function onLongPressed;


  InkWellView({this.child, this.borderRadius, this.colorBackground, this.onPressed, this.onLongPressed});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: colorBackground,
      borderRadius: BorderRadius.circular(borderRadius ?? 0),
      child: InkWell(
        borderRadius: BorderRadius.circular(borderRadius ?? 0),
        onTap: onPressed,
        onLongPress: onLongPressed,
        splashColor: AppColor.splashColor,
        highlightColor: AppColor.splashColor,
        child: child,
      ),
    );
  }
}
