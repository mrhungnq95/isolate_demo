import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

///
/// Item phiếu nhập kho
///
class RadioItemView<T> extends StatelessWidget {
  final String title;
  final String subTitle;
  final T groupValue;
  final T value;
  final Function(T value) onTap;

  RadioItemView(
      {this.title,
      this.subTitle = '',
      this.onTap,
      @required this.groupValue,
      @required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: kVerticalSpaceSmall),
      child: InkWellView(
        borderRadius: 10,
        onPressed: () => onTap(value),
        child: Container(
          decoration: BoxDecoration(
              color: AppColor.grey50,
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge,
              vertical: kVerticalSpaceMedium),
          child: Row(
            children: [
              Container(
                margin: const EdgeInsets.only(right: kHorizontalSpaceMedium),
                width: 22,
                height: 22,
                child: Radio<T>(
                  onChanged: (value) => onTap(value),
                  value: value,
                  groupValue: groupValue,
                  activeColor: AppColor.primaryColor,
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context)
                          .textTheme
                          .subtitle1
                          .copyWith(fontWeight: FontWeight.bold),
                    ),
                    Visibility(
                      visible: subTitle.isNotEmpty,
                      child: Text(subTitle,
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: AppColor.textSecondaryColor)),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
