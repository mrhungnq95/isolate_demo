import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:MShopManager/widget/checkbox_title_view.dart';
import 'package:MShopManager/widget/many_option_view.dart';
import 'package:MShopManager/widget/two_option_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

import 'common/expanded_section_view.dart';
import 'ms_flow_layout.dart';


class BranchFilterController {
  bool isSingleMode = false;
  BranchFilterMode mode = BranchFilterMode.ALL;
  List<Branch> listAllBranch = [];

  BranchFilterController(
      {this.isSingleMode = false, this.listAllBranch = const []});

  /// lấy danh sách chi nhánh dc chọn
  String getBranchIDSelected() {
    return getListBranchSelected().map((e) => e.branchId).join(';');
  }

  /// lấy danh sách chi nhánh dc chọn
  List<Branch> getListBranchSelected() {
    if (mode == BranchFilterMode.ALL && !isSingleMode) {
      return listAllBranch;
    } else {
      return listAllBranch.where((element) => element.isSelected).toList();
    }
  }

  ///
  /// Đánh dấu Branch được chọn theo [branchIds] DS BranchID,
  /// ngăn cách nhau bởi dấu ,
  ///
  void markBranchSelected(String branchIds) {
    if (branchIds == null || branchIds.isEmpty) {
      return null;
    }
    print(branchIds);
    listAllBranch?.forEach((element) {
      element.isSelected = false;
      if (branchIds.toLowerCase()?.contains(element.branchId?.toLowerCase()) ==
          true) {
        element.isSelected = true;
      }
    });
  }

  ///
  /// Kiểm tra xem có cửa hàng được chọn không?
  ///
  bool hasBranchSelected() {
    final branchSelectedList = getListBranchSelected();
    if (branchSelectedList != null && branchSelectedList.isNotEmpty) {
      return true;
    }
    return false;
  }
}

/// View Filter chọn chi nhánh
class BranchFilterView extends StatelessWidget {
  final BranchFilterController controller;
  final VoidCallback onChanged;

  const BranchFilterView({Key key, @required this.controller, this.onChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => _ViewModel(controller, this.onChanged),
      builder: (context, child) => _BranchFilterView(controller),
    );
  }
}

class _BranchFilterView extends StatelessWidget {
  final BranchFilterController controller;

  _BranchFilterView(this.controller);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.white,
      child: Consumer<_ViewModel>(
        builder: (BuildContext context, viewModel, Widget child) => Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            buildTitle(),
            _SpaceView(),
            Padding(
                padding: const EdgeInsets.only(
                    left: kHorizontalSpaceLarge, right: kHorizontalSpaceMedium),
                child: _ListBranchView(controller)),
          ],
        ),
      ),
    );
  }

  /// build title của chi nhánh
  Widget buildTitle() {
    return Builder(
      builder: (context) {
        _ViewModel viewModel = Provider.of(context);
        if (viewModel.controller.isSingleMode) {
          return Text(
            'Cửa hàng',
            style: Theme.of(context)
                .textTheme
                .subtitle1
                .copyWith(fontWeight: FontWeight.bold),
          );
        }
        return TwoOptionView(
          option1Value: BranchFilterMode.ALL,
          option2Value: BranchFilterMode.CUSTOM,
          groupValue: viewModel.controller.mode,
          onChanged: (value) {
            _handleRadioValueChange(viewModel, value);
          },
          title: 'Cửa hàng',
          option1: Text(
            'Tất cả',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          option2: Text(
            'Nhóm cửa hàng',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          ratio: 0.5,
        );
      },
    );
  }

  void _handleRadioValueChange(_ViewModel viewModel, BranchFilterMode value) {
    viewModel.toggleMode(value);
  }
}

class _SpaceView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<_ViewModel>(context);
    if (model.isShowListBranch()) {
      return kVerticalSpaceMediumBox;
    } else {
      return kSpaceShrinkBox;
    }
  }
}

///
/// Danh sách các option chọn branch
///
class _ListBranchView extends ViewModelWidget<_ViewModel> {
  final BranchFilterController controller;

  _ListBranchView(this.controller);

  @override
  Widget build(BuildContext context, _ViewModel viewModel) {
    if (controller.isSingleMode) {
      return ManyOptionView<Branch>(
        title: '',
        groupValue: controller?.getListBranchSelected()?.first ??
            controller.listAllBranch?.first,
        itemCount: controller.listAllBranch?.length ?? 0,
        valueBuilder: (index) => controller.listAllBranch[index],
        titleBuilder: (value) => Text(
          value.branchName ?? '',
          style: Theme.of(context).textTheme.bodyText1,
        ),
        onChanged: (branch) {
          viewModel.toggleBranch(branch: branch);
        },
      );
    } else {
      return ExpandedSection(
        expand: viewModel.isShowListBranch(),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: kVerticalSpaceMedium),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: AppColor.grey50,
              border: Border.all(width: 1.0, color: AppColor.grey300)),
          child: ListView.builder(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              final branch = controller.listAllBranch[index];
              return Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: kHorizontalSpaceMedium),
                child: CheckboxTitle(
                  title: Text(
                    branch.branchName,
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                  isChecked: branch.isSelected,
                  onChanged: (value) {
                    viewModel.toggleBranch(branch: branch, isNeedNotifyChange: false);
                  },
                ),
              );
            },
            itemCount: controller.listAllBranch?.length ?? 0,
          ),
        ),
      );
    }
  }
}

enum BranchFilterMode { ALL, CUSTOM }

extension BranchFilterModeExt on BranchFilterMode {
  int get rawValue {
    switch (this) {
      case BranchFilterMode.ALL:
        return 0;
      case BranchFilterMode.CUSTOM:
        return 1;
      default:
        return 0;
    }
  }

  static BranchFilterMode valueOf(int value) {
    switch (value) {
      case 0:
        return BranchFilterMode.ALL;
      case 1:
        return BranchFilterMode.CUSTOM;
      default:
        return BranchFilterMode.ALL;
    }
  }
}

class _ViewModel with ChangeNotifier {
  final BranchFilterController controller;
  final VoidCallback onChanged;

  _ViewModel(this.controller, this.onChanged) {
    initData();
  }

  /// Khởi tạo dữ liệu
  void initData() async {
    if (this.controller.listAllBranch.isEmpty) {
      this.controller.listAllBranch = await MISACommon.getAllBranchesOfUser();
    }
    notifyListeners();
  }

  List<Branch> getListBranchDisplay() {
    return controller.listAllBranch;
  }

  void toggleMode(BranchFilterMode mode) {
    this.controller.mode = mode;
    onChanged?.call();
    notifyListeners();
  }

  /// Chọn chi nhánh
  void toggleBranch({Branch branch, bool isNeedNotifyChange = true}) {
    if (controller.isSingleMode) {
      controller.listAllBranch.forEach((element) {
        element.isSelected = false;
      });
      branch.isSelected = true;
    } else {
      // muốn bỏ chọn thì cứ thoải mái nhưng muốn chọn chi nhánh thì phải chơi theo luật của MISA eShop.
      if (branch.isSelected) {
        branch.isSelected = false;
        onChanged?.call();
        notifyListeners();
        return;
      }
      // chưa chọn gì thì cho chọn một cái.
      if (!controller.listAllBranch.any((element) => element.isSelected)) {
        branch.isSelected = true;
        onChanged?.call();
      } else {
        // đã chọn rồi thì kiểm tra xem có quyền không.
        if (MISACommon.isAllowViewReportAllChain()) {
          branch.isSelected = true;
          onChanged?.call();
        } else {
          // todo:
        }
      }
    }

    if (isNeedNotifyChange) {
      notifyListeners();
    }
  }

  ///
  /// Hiển thị ds branch
  ///
  bool isShowListBranch() {
    return controller.isSingleMode ||
        controller.mode == BranchFilterMode.CUSTOM;
  }
}
