import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ManyOptionView<T> extends StatelessWidget {
  final String title;

  final T groupValue;
  final int itemCount;
  final T Function(int index) valueBuilder;
  final Widget Function(T value) titleBuilder;
  final ValueChanged<T> onChanged;

  const ManyOptionView({
    Key key,
    @required this.title,
    @required this.groupValue,
    @required this.itemCount,
    @required this.valueBuilder,
    @required this.titleBuilder,
    @required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var children = <Widget>[
      Visibility(
        visible: title.isNotEmpty,
        child: Column(
          children: [
            Text(
              title,
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(fontWeight: FontWeight.bold),
            ),
            kVerticalSpaceSmallBox,
          ],
        ),
      ),
    ];

    for (int i = 0; i < itemCount; i++) {
      var value = valueBuilder(i);
      children.add(RadioTitle<T>(
        value: value,
        groupValue: groupValue,
        title: titleBuilder(value),
        onChanged: onChanged,
      ));
    }
    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: children);
  }
}

class RadioTitle<T> extends StatelessWidget {
  final T groupValue;
  final T value;
  final ValueChanged<T> onChanged;
  final Widget title;

  const RadioTitle(
      {Key key,
      @required this.groupValue,
      @required this.value,
      @required this.onChanged,
      @required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(6),
        splashColor: AppColor.splashColor,
        highlightColor: Colors.transparent,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Radio<T>(
              value: value,
              groupValue: groupValue,
              activeColor: AppColor.primaryColor,
              onChanged: onChanged,
            ),
            Expanded(
              child: title,
            ),
          ],
        ),
        onTap: () => onChanged(value),
      ),
    );
  }
}
