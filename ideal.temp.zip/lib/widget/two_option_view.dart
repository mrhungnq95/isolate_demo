import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'many_option_view.dart';

class TwoOptionView<T> extends StatelessWidget {
  final T option1Value;
  final T option2Value;
  final T groupValue;
  final ValueChanged<T> onChanged;

  final String title;
  final Widget option1;
  final Widget option2;

  final double ratio;

  const TwoOptionView(
      {Key key,
      @required this.option1Value,
      @required this.option2Value,
      @required this.groupValue,
      @required this.onChanged,
      @required this.title,
      @required this.option1,
      @required this.option2,
      this.ratio = 1})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    int flex1 = 1;
    int flex2 = flex1 ~/ ratio;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          title,
          style: Theme.of(context)
              .textTheme
              .subtitle1
              .copyWith(fontWeight: FontWeight.bold),
        ),
        kVerticalSpaceSmallBox,
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(
              flex: flex1,
              child: RadioTitle<T>(
                value: option1Value,
                groupValue: groupValue,
                title: option1,
                onChanged: onChanged,
              ),
            ),
            Expanded(
              flex: flex2,
              child: RadioTitle<T>(
                value: option2Value,
                groupValue: groupValue,
                title: option2,
                onChanged: onChanged,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
