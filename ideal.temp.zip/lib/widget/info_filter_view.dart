//
// Created by  on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:flutter/material.dart';

class InfoFilterView extends StatelessWidget {
  final bool isShowCompareInfo;
  final String title;
  final Color titleColor;
  final Color compareTitleColor;
  final String compareTitle;
  final String description;
  final double horizontalPadding;
  final VoidCallback onFilterPressed;

  const InfoFilterView({
    Key key,
    this.title,
    this.titleColor = AppColor.textColor,
    this.compareTitleColor = AppColor.textCaptionColor,
    this.compareTitle,
    this.description,
    this.onFilterPressed,
    this.isShowCompareInfo = false,
    this.horizontalPadding = kHorizontalSpaceLarge,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          MSCircleButton(
              elevation: 0,
              color: AppColor.white.withOpacity(0.1),
              size: 40,
              imageAsset: AppResources.icCalendarPurple,
              imageAssetColor: AppColor.white,
              onTap: onFilterPressed),
          kHorizontalSpaceMediumBox,
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(title ?? "",
                          maxLines: 2,
                          overflow: TextOverflow.fade,
                          style: Theme.of(context).textTheme.bodyText2.copyWith(
                                color: titleColor,
                              )),
                    ),
                  ],
                ),
                _CompareTextView(
                    isShowCompareInfo: isShowCompareInfo,
                    compareTitle: compareTitle,
                    compareTitleColor: compareTitleColor),
                _renderDescription(),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _renderDescription() {
    return Builder(builder: (c) {
      if (description != null) {
        return Text(description ?? "",
            style:
                Theme.of(c).textTheme.caption.copyWith(color: AppColor.white));
      }
      return kSpaceShrinkBox;
    });
  }
}

///
/// Compare text
///
class _CompareTextView extends StatelessWidget {
  final bool isShowCompareInfo;
  final String compareTitle;
  final Color compareTitleColor;

  _CompareTextView(
      {this.isShowCompareInfo,
      this.compareTitle,
      this.compareTitleColor = AppColor.textCaptionColor});

  @override
  Widget build(BuildContext context) {
    if (isShowCompareInfo) {
      return Text(
        compareTitle ?? "",
        style: Theme.of(context)
            .textTheme
            .bodyText1
            .copyWith(color: compareTitleColor),
      );
    } else {
      return kSpaceShrinkBox;
    }
  }
}
