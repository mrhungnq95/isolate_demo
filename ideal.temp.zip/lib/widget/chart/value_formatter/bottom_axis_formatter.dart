import 'package:mp_chart/mp/core/axis/axis_base.dart';
import 'package:mp_chart/mp/core/axis/x_axis.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

enum EBottomAxisValueVisble { one, two, three, five }

extension EBottomAxisValueVisbleExt on EBottomAxisValueVisble {
  int get rawValue {
    switch (this) {
      case EBottomAxisValueVisble.one:
        return 1;
      case EBottomAxisValueVisble.two:
        return 2;
      case EBottomAxisValueVisble.three:
        return 3;
      case EBottomAxisValueVisble.five:
        return 5;
      default:
        return 1;
    }
  }
}

class BottomAxisValueFormater extends ValueFormatter {
  List<String> label;
  EBottomAxisValueVisble type;
  BottomAxisValueFormater({this.label, this.type = EBottomAxisValueVisble.two});

  @override
  String getFormattedValue1(double value) {
    int position = value.toInt();
    //print(position);
    //String label = label[month % label.length];

    return label[position] ?? "";
    //print("$position -- ${label[position]}");
    //return "";
  }

  int get digits => 1;
}
