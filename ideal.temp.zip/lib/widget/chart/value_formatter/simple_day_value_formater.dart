import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:mp_chart/mp/core/axis/axis_base.dart';
import 'package:mp_chart/mp/core/axis/x_axis.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

class SimpleDayValueFormater extends ValueFormatter {
  @override
  String getFormattedValue1(double value) {
    //return _format.format(value) + _suffix;
    return NumberFormatHelper.shared.formatMoney((value / 1000000));
  }

  @override
  String getAxisLabel(double value, AxisBase axis) {
    if (axis is XAxis) {
      return value.toString();
    }
    return NumberFormatHelper.shared.formatMoney((value / 1000000));
  }
}
