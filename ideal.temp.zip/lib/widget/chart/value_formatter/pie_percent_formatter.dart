import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:mp_chart/mp/core/entry/pie_entry.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

class PiePercentFormatter extends ValueFormatter {
  bool _percentSignSeparated;

  PercentFormatter() {
    _percentSignSeparated = true;
  }

  @override
  String getFormattedValue1(double value) {
    return NumberFormatHelper.shared.formatPercent(value) +
        (_percentSignSeparated == true ? " %" : "%");
  }

  @override
  String getPieLabel(double value, PieEntry pieEntry) {
    return getFormattedValue1(value);
  }
}
