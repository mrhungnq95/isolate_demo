import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:mp_chart/mp/core/axis/axis_base.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

class SimpleMilionValueFormater extends ValueFormatter {
  final double oneMillionDong = 1000000;

  @override
  String getFormattedValue1(double value) {
    //return _format.format(value) + _suffix;
    return NumberFormatHelper.shared.formatMoney((value / oneMillionDong));
  }

  @override
  String getAxisLabel(double value, AxisBase axis) {
    // if (axis is XAxis) {
    //   return _format.format(value);
    // } else if (value > 0) {
    //   return _format.format(value) + _suffix;
    // } else {
    //   return _format.format(value);
    // }
    return NumberFormatHelper.shared.formatMoney((value / oneMillionDong));
  }
}
