import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/chart/marker/my_bar_marker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:mp_chart/mp/chart/bar_chart.dart';
import 'package:mp_chart/mp/controller/bar_chart_controller.dart';
import 'package:mp_chart/mp/core/axis/axis_base.dart';
import 'package:mp_chart/mp/core/axis/x_axis.dart';
import 'package:mp_chart/mp/core/data/bar_data.dart';
import 'package:mp_chart/mp/core/data_interfaces/i_bar_data_set.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';
import 'package:mp_chart/mp/core/description.dart';
import 'package:mp_chart/mp/core/enums/legend_form.dart';
import 'package:mp_chart/mp/core/enums/legend_orientation.dart';
import 'package:mp_chart/mp/core/enums/legend_vertical_alignment.dart';
import 'package:mp_chart/mp/core/enums/x_axis_position.dart';
import 'package:mp_chart/mp/core/enums/y_axis_label_position.dart';
import 'package:mp_chart/mp/core/utils/color_utils.dart';
import 'package:mp_chart/mp/core/value_formatter/default_axis_value_formatter.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

class BarChartView extends StatefulWidget {
  final Color progressColor;
  final String axisBottomTitle;
  final Color axistTitleColor;
  final String axisLeftTitle;
  final Color axisLeftGridColor;
  final Color textColorAxisLeft;
  final double barWidth;

  final bool drawBottomAxisLabels;
  final bool useMarker;
  final ValueFormatter leftAxistValueFormatter;
  final ValueFormatter bottomAxistValueFormatter;
  final ValueFormatter markerValueFormatter;

  final double leftOffsetViewPort;
  final double rightOffsetViewPort;
  final double topOffsetViewPort;
  final double bottomOffsetViewPort;

  final List<BarDataSet> barDataSet;

  const BarChartView(
      {Key key,
      @required this.barDataSet,
      @required this.axisBottomTitle,
      @required this.axistTitleColor,
      @required this.axisLeftTitle,
      this.progressColor = AppColor.indigo900,
      this.axisLeftGridColor = AppColor.borderAxisLeftColor,
      this.textColorAxisLeft = AppColor.grey700,
      this.barWidth = 0.2,
      this.drawBottomAxisLabels = true,
      this.useMarker = true,
      this.leftOffsetViewPort = 0,
      this.rightOffsetViewPort = 0,
      this.topOffsetViewPort = 0,
      this.bottomOffsetViewPort = 0,
      this.leftAxistValueFormatter,
      this.bottomAxistValueFormatter,
      this.markerValueFormatter})
      : super(key: key);

  @override
  _BarChartViewState createState() => _BarChartViewState();
}

class _BarChartViewState extends State<BarChartView> {
  BarChartController _barController;
  bool _isWaitingDrawChart = true;

  @override
  void initState() {
    _initController();
    _initBarData();

    super.initState();

    SchedulerBinding.instance.addPostFrameCallback((Duration _) {
      Future.delayed(Duration(milliseconds: 1000), () {
        if (mounted) {
          setState(() {
            _isWaitingDrawChart = false;
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(0),
      child: Column(
        children: [
          Row(
            children: [
              Visibility(
                visible: !_isWaitingDrawChart,
                child: Text(
                  widget.axisLeftTitle,
                  style: Theme.of(context).textTheme.caption.copyWith(
                      color: widget.axistTitleColor,
                      fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
          Container(
              height: 200,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(
                  top: kVerticalSpaceSmall, bottom: kVerticalSpaceMedium),
              child: _isWaitingDrawChart
                  ? CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        widget.progressColor,
                      ),
                    )
                  : BarChart(_barController)),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Visibility(
                visible: !_isWaitingDrawChart,
                child: Text(
                  widget.axisBottomTitle,
                  style: Theme.of(context).textTheme.caption.copyWith(
                      color: widget.axistTitleColor,
                      fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _initBarData() async {
    _initData();
    setState(() {});
  }

  void _initController() {
    var desc = Description()..enabled = false;
    _barController = BarChartController(
        axisLeftSettingFunction: (axisLeft, controller) {
          axisLeft
            ..drawAxisLine = false
            ..drawLimitLineBehindData = true
            ..enableGridDashedLine(5, 5, 0)
            ..setLabelCount2(8, false)
            //..setValueFormatter(MyValueFormatter("\$"))
            ..position = YAxisLabelPosition.OUTSIDE_CHART
            ..spacePercentTop = 15
            ..gridColor = widget.axisLeftGridColor
            ..textColor = widget.textColorAxisLeft
            ..axisValueFormatter =
                widget.leftAxistValueFormatter ?? DefaultAxisValueFormatter(2)
            ..setAxisMinimum(0);
        },
        axisRightSettingFunction: (axisRight, controller) {
          axisRight
            ..drawGridLines = false
            ..setLabelCount2(8, false)
            //..setValueFormatter(MyValueFormatter("\$"))
            ..spacePercentTop = 15
            ..setAxisMinimum(0)
            ..enabled = false;
        },
        legendSettingFunction: (legend, controller) {
          legend
            ..verticalAlignment = LegendVerticalAlignment.BOTTOM
            ..orientation = LegendOrientation.HORIZONTAL
            ..drawInside = false
            ..shape = LegendForm.SQUARE
            ..formSize = 20
            ..textSize = 11
            ..textColor = ColorUtils.RED
            ..xEntrySpace = 4;
          legend.enabled = false;
        },
        xAxisSettingFunction: (xAxis, controller) {
          xAxis
            ..position = XAxisPosition.BOTTOM
            ..drawGridLines = false
            ..setGranularity(1.0)
            ..drawLabels = widget.drawBottomAxisLabels
            ..setLabelCount1(12)
            ..setValueFormatter(widget.bottomAxistValueFormatter);
        },
        customViewPortEnabled: false,
        drawBarShadow: false,
        drawValueAboveBar: false,
        drawGridBackground: false,
        dragXEnabled: false,
        dragYEnabled: false,
        scaleXEnabled: false,
        scaleYEnabled: false,
        pinchZoomEnabled: false,
        maxVisibleCount: 60,
        drawMarkers: widget.useMarker,
        marker: widget.useMarker
            ? MyBarMarker(
                formatter: widget.markerValueFormatter,
                backColor: AppColor.indigoA200,
                textColor: AppColor.white)
            : null,
        description: desc);

    _barController.setViewPortOffsets(
        widget.leftOffsetViewPort,
        widget.topOffsetViewPort,
        widget.rightOffsetViewPort,
        widget.bottomOffsetViewPort);
  }

  void _initData() {
    // List<BarEntry> values = List();

    // for (int i = start.toInt(); i < start + count; i++) {
    //   double val = (random.nextDouble() * (range + 1));

    //   values.add(BarEntry(x: i.toDouble(), y: val));
    // }

    _barController.data = BarData(widget.barDataSet ?? List<IBarDataSet>());
    _barController.data
      ..setDrawValues(false)
      ..setValueTextSize(10)
      ..barWidth = widget.barWidth;
  }
}
