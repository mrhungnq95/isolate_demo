import 'dart:math';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/chart/marker/circle_dot_marker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:mp_chart/mp/chart/combined_chart.dart';
import 'package:mp_chart/mp/controller/combined_chart_controller.dart';
import 'package:mp_chart/mp/core/data/bar_data.dart';
import 'package:mp_chart/mp/core/data/combined_data.dart';
import 'package:mp_chart/mp/core/data/line_data.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';
import 'package:mp_chart/mp/core/data_set/line_data_set.dart';
import 'package:mp_chart/mp/core/description.dart';
import 'package:mp_chart/mp/core/entry/bar_entry.dart';
import 'package:mp_chart/mp/core/entry/entry.dart';
import 'package:mp_chart/mp/core/enums/axis_dependency.dart';
import 'package:mp_chart/mp/core/enums/legend_horizontal_alignment.dart';
import 'package:mp_chart/mp/core/enums/legend_orientation.dart';
import 'package:mp_chart/mp/core/enums/legend_vertical_alignment.dart';
import 'package:mp_chart/mp/core/enums/mode.dart';
import 'package:mp_chart/mp/core/enums/x_axis_position.dart';
import 'package:mp_chart/mp/core/enums/y_axis_label_position.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';
import 'package:mp_chart/mp/painter/combined_chart_painter.dart';

class CombineBarAndLineChartView extends StatefulWidget {
  final Color progressColor;
  final String axisBottomTitle;
  final Color axistTitleColor;
  final String axisLeftTitle;
  final Color axisLeftGridColor;
  final Color textColorAxisLeft;
  final Color circleColor;
  final Color strokeCircleColor;

  const CombineBarAndLineChartView(
      {Key key,
      this.progressColor = AppColor.indigo900,
      this.axisLeftGridColor = AppColor.borderAxisLeftColor,
      this.textColorAxisLeft = AppColor.grey700,
      @required this.axisBottomTitle,
      @required this.axistTitleColor,
      @required this.axisLeftTitle,
      this.circleColor = AppColor.white,
      this.strokeCircleColor = AppColor.indigo900})
      : super(key: key);

  @override
  _CombineBarAndLineChartViewState createState() =>
      _CombineBarAndLineChartViewState();
}

final List<String> months = List()
  ..add("Jan")
  ..add("Feb")
  ..add("Mar")
  ..add("Apr")
  ..add("May")
  ..add("Jun")
  ..add("Jul");

class A extends ValueFormatter {
  @override
  String getFormattedValue1(double value) {
    return months[value.toInt() % months.length];
  }
}

class _CombineBarAndLineChartViewState
    extends State<CombineBarAndLineChartView> {
  CombinedChartController controller;
  int _count = 7;
  var random = Random(1);
  bool isWaitingDrawChart = true;
  @override
  void initState() {
    _initController();
    _initCombinedData();
    super.initState();

    SchedulerBinding.instance.addPostFrameCallback((Duration _) {
      Future.delayed(Duration(milliseconds: 1000), () {
        if (mounted) {
          setState(() {
            isWaitingDrawChart = false;
          });
        }
      });
    });
  }

  void _initController() {
    //var desc = Description()..enabled = false;
    controller = CombinedChartController(
        axisLeftSettingFunction: (axisLeft, controller) {
          axisLeft
            //..setAxisMinimum(0)
            ..drawAxisLine = false
            ..drawLimitLineBehindData = true
            ..enableGridDashedLine(5, 5, 0)
            ..setLabelCount2(8, false)
            //..setValueFormatter(MyValueFormatter("\$"))
            ..position = YAxisLabelPosition.OUTSIDE_CHART
            ..spacePercentTop = 15
            ..drawGridLines = (true)
            ..gridColor = widget.axisLeftGridColor
            ..drawZeroLine = true;
        },
        axisRightSettingFunction: (axisRight, controller) {
          axisRight
            ..drawGridLines = (false)
            //..setAxisMinimum(0)
            ..drawZeroLine = true
            ..enabled = false;
          ;
        },
        legendSettingFunction: (legend, controller) {
          legend
            ..wordWrapEnabled = (true)
            ..verticalAlignment = (LegendVerticalAlignment.BOTTOM)
            ..horizontalAlignment = (LegendHorizontalAlignment.CENTER)
            ..orientation = (LegendOrientation.HORIZONTAL)
            ..drawInside = (false)
            ..enabled = false;
        },
        xAxisSettingFunction: (xAxis, controller) {
          xAxis
            ..position = (XAxisPosition.BOTTOM)
            ..spaceMin = 0.5
            ..spaceMax = 0.5
            ..drawAxisLine = false
            ..drawGridLines = false
            ..gridColor = Colors.transparent
            ..setValueFormatter(A());
        },
        customViewPortEnabled: true,
        drawGridBackground: false,
        backgroundColor: Colors.transparent,
        drawBarShadow: false,
        highlightFullBarEnabled: false,
        dragXEnabled: false,
        dragYEnabled: false,
        scaleXEnabled: false,
        scaleYEnabled: false,
        pinchZoomEnabled: false,
        maxVisibleCount: 31,
        drawMarkers: true,
        marker: CircleDotMarker(
            backColor: widget.circleColor,
            strokeColor: widget.strokeCircleColor),
        //description: desc,
        drawOrder: List()..add(DrawOrder.BAR)..add(DrawOrder.LINE));
  }

  void _initCombinedData() {
    controller.data = CombinedData();
    controller.data
      ..setData1(generateLineData())
      ..setData2(generateBarData());
  }

  LineData generateLineData() {
    LineData d = LineData();

    List<Entry> entries = List();

    for (int index = 0; index < _count; index++) {
      entries.add(Entry(x: index + 0.0, y: getRandom(15, 5)));
    }

    LineDataSet set = LineDataSet(entries, "Line DataSet");
    set.setColor1(AppColor.cyan);
    set.setLineWidth(2.5);
    set.setCircleColor(Colors.transparent);
    set.setCircleRadius(3);
    set.setFillColor(Color(0xFF2B3173));
    set.setMode(Mode.CUBIC_BEZIER);
    set.setDrawValues(false);

    set.setAxisDependency(AxisDependency.LEFT);
    set.setDrawCircleHole(true);

    set.setHighLightColor(widget.axisLeftGridColor);
    set.setDrawHorizontalHighlightIndicator(false);
    set.setDrawVerticalHighlightIndicator(true);

    set.setHighlightLineWidth(1);
    set.enableDashedHighlightLine(5, 5, 0);

    d.addDataSet(set);
    d.setDrawValues(false);

    return d;
  }

  BarData generateBarData() {
    List<BarEntry> entries2 = List();

    for (int index = 0; index < _count; index++) {
      // stacked
      entries2.add(BarEntry.fromListYVals(
          x: index + 0.0,
          vals: List<double>()..add(getRandom(50, 1))..add(getRandom(50, 1))));
    }

    BarDataSet set2 = BarDataSet(entries2, "");
    set2.setStackLabels(List<String>()..add("Stack 1")..add("Stack 2"));
    set2.setColors1(
        List<Color>()..add(AppColor.orange)..add(AppColor.indigoA200));
    set2.setValueTextColor(Color.fromARGB(255, 61, 165, 255));
    set2.setValueTextSize(10);
    set2.setAxisDependency(AxisDependency.LEFT);

    double groupSpace = 0.06;
    double barSpace = 0.02; // x2 dataset
    double barWidth = 0.4; // x2 dataset
    // (0.45 + 0.02) * 2 + 0.06 = 1.00 -> interval per "group"

    BarData d = BarData(List()..add(set2));
    d.barWidth = (barWidth);
    d.setDrawValues(false);
    d.setHighlightEnabled(false);

    // make this BarData object grouped
    //d.groupBars(0, groupSpace, barSpace); // start at x = 0

    return d;
  }

  double getRandom(double range, double start) {
    return (random.nextDouble() * range) + start;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kVerticalSpaceSmall),
      child: Column(
        children: [
          Row(
            children: [
              Visibility(
                visible: !isWaitingDrawChart,
                child: Text(
                  widget.axisLeftTitle,
                  style: Theme.of(context)
                      .textTheme
                      .caption
                      .copyWith(color: widget.axistTitleColor),
                ),
              ),
            ],
          ),
          Container(
              height: 200,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(
                  left: kVerticalSpaceMedium,
                  top: kVerticalSpaceSmall,
                  bottom: kVerticalSpaceMedium),
              child: isWaitingDrawChart
                  ? CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        widget.progressColor,
                      ),
                    )
                  : CombinedChart(controller)),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Visibility(
                visible: !isWaitingDrawChart,
                child: Text(
                  widget.axisBottomTitle,
                  style: Theme.of(context)
                      .textTheme
                      .caption
                      .copyWith(color: widget.axistTitleColor),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
