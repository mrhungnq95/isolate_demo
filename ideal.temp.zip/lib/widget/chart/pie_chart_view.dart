//
// Created by nqhung on 07/11/2020.
//

import 'dart:math';

import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/widget/chart/value_formatter/pie_percent_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/widgets.dart';
import 'package:mp_chart/mp/chart/pie_chart.dart';
import 'package:mp_chart/mp/controller/pie_chart_controller.dart';
import 'package:mp_chart/mp/core/animator.dart';
import 'package:mp_chart/mp/core/data/pie_data.dart';
import 'package:mp_chart/mp/core/data_set/pie_data_set.dart';
import 'package:mp_chart/mp/core/description.dart';
import 'package:mp_chart/mp/core/entry/pie_entry.dart';
import 'package:mp_chart/mp/core/enums/legend_horizontal_alignment.dart';
import 'package:mp_chart/mp/core/enums/legend_orientation.dart';
import 'package:mp_chart/mp/core/enums/legend_vertical_alignment.dart';
import 'package:mp_chart/mp/core/enums/value_position.dart';
import 'package:mp_chart/mp/core/render/pie_chart_renderer.dart';
import 'package:mp_chart/mp/core/utils/color_utils.dart';
import 'package:mp_chart/mp/core/value_formatter/percent_formatter.dart';

class PieChartView extends StatefulWidget {
  final Color loadingColor;
  final List<Color> entryColorList;
  final List<PieEntry> entryList;

  const PieChartView(
      {@required this.entryList, this.loadingColor, this.entryColorList});

  @override
  _PieChartViewState createState() => _PieChartViewState();
}

class _PieChartViewState extends State<PieChartView> {
  bool isWaitingDrawChart = true;

  int _count = 4;
  double _range = 100.0;

  PiePercentFormatter _formatter = PiePercentFormatter();
  PieChartController controller;

  @override
  void initState() {
    _initController();
    _initPieData(_count, _range);
    super.initState();

    SchedulerBinding.instance.addPostFrameCallback((Duration _) {
      Future.delayed(Duration(milliseconds: 1000), () {
        if (mounted) {
          setState(() {
            isWaitingDrawChart = false;
          });
        }
      });
    });
  }

  void _initController() {
    var desc = Description()..enabled = false;
    controller = PieChartController(
        legendSettingFunction: (legend, controller) {
          legend
            ..verticalAlignment = (LegendVerticalAlignment.TOP)
            ..horizontalAlignment = (LegendHorizontalAlignment.RIGHT)
            ..orientation = (LegendOrientation.VERTICAL)
            ..drawInside = (false)
            ..enabled = (false);
        },
        rendererSettingFunction: (renderer) {
          (renderer as PieChartRenderer)
            ..setHoleColor(AppColor.white)
            ..setTransparentCircleColor(AppColor.white)
            ..setTransparentCircleAlpha(60);
        },
        rotateEnabled: false,
        holeRadiusPercent: 40,
        drawEntryLabels: false,
        extraLeftOffset: 10,
        extraTopOffset: 0,
        extraRightOffset: 10,
        extraBottomOffset: 0,
        usePercentValues: true,
        transparentCircleRadiusPercent: 61,
        highLightPerTapEnabled: false,
        description: desc);
  }

  void _initPieData(int count, double range) async {
    PieDataSet dataSet = PieDataSet(widget.entryList, "Values");
    dataSet.setSliceSpace(0);
    dataSet.setSelectionShift(5);

    // add a lot of colors
    List<Color> colors = List();
    if (widget.entryColorList != null) {
      colors.addAll(widget.entryColorList);
    } else {
      for (Color c in ColorUtils.COLORFUL_COLORS) {
        colors.add(c);
      }
    }

    colors.add(ColorUtils.HOLO_BLUE);
    dataSet.setColors1(colors);

    // dataSet.setValueLinePart1OffsetPercentage(80.0);
    // dataSet.setValueLinePart1Length(0.5);
    // dataSet.setValueLinePart2Length(0.5);

    dataSet.setYValuePosition(ValuePosition.INSIDE_SLICE);

    controller.data = PieData(dataSet)
      ..setValueFormatter(_formatter)
      ..setValueTextSize(14)
      ..setValueTextColor(ColorUtils.WHITE);

    setState(() {});
  }

  Widget _initPieChart() {
    var pieChart = PieChart(controller);
    controller.animator
      ..reset()
      ..animateY2(1400, Easing.EaseInOutQuad);
    return pieChart;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 300,
        alignment: Alignment.center,
        padding: const EdgeInsets.only(
            left: kVerticalSpaceSmall,
            top: kVerticalSpaceSmall,
            bottom: kVerticalSpaceSmall),
        child: isWaitingDrawChart
            ? CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                  widget.loadingColor ?? Colors.white,
                ),
              )
            : _initPieChart());
  }
}
