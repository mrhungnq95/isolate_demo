//
// Created by nqhung on 04/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/widget/chart/marker/circle_dot_marker.dart';
import 'package:flutter/material.dart';
import 'package:mp_chart/mp/chart/line_chart.dart';
import 'package:mp_chart/mp/controller/line_chart_controller.dart';
import 'package:mp_chart/mp/core/adapter_android_mp.dart';
import 'package:mp_chart/mp/core/data/line_data.dart';
import 'package:mp_chart/mp/core/data_interfaces/i_line_data_set.dart';
import 'package:mp_chart/mp/core/data_set/line_data_set.dart';
import 'package:mp_chart/mp/core/description.dart';
import 'package:mp_chart/mp/core/entry/entry.dart';
import 'package:mp_chart/mp/core/enums/x_axis_position.dart';
import 'package:mp_chart/mp/core/value_formatter/value_formatter.dart';

enum EChartState { loading, done, noData }

class LineChartView extends StatefulWidget {
  ///
  /// Trạng thái của chart
  ///
  final EChartState state;

  ///
  /// Chiều cao của chart
  ///
  final double height;

  ///
  /// Màu của marker hình tròn
  ///
  final Color circleColor;

  ///
  /// Viền màu của marker hình tròn
  ///
  final Color strokeCircleColor;

  ///
  /// Màu của Ox bên dưới
  ///
  final Color axistTitleColor;

  ///
  /// Màu của đường biểu đồ
  ///
  final Color lineColor;

  ///
  /// Màu của label Oy bên trái
  ///
  final Color textColorAxisLeft;

  ///
  /// Màu của label Ox bên dưới
  ///
  final Color textColorAxis;

  ////
  /// Customize view không có dữ liệu
  ///
  final Widget customNoDataView;

  ///
  /// Title không có dữ liệu
  ///
  final String noDataTitle;

  ///
  /// Màu của label không có dữ liệu
  ///
  final Color noDataTitleColor;

  ///
  /// Màu của Progress bar
  ///
  final Color progressColor;

  ////
  /// Màu khi chọn vào 1 line
  ///
  final Color highLightColor;

  ///
  /// Màu đường grid của Oy bên trái
  ///
  final Color axisLeftGridColor;

  ///
  /// Title của Oy bên trái
  ///
  final String axisLeftTitle;

  ///
  /// Title của Ox bên dưới
  ///
  final String axisBottomTitle;

  ///
  /// Dữ liệu biểu đồ
  ///
  final List<Entry> values;

  final ValueFormatter leftAxistValueFormatter;
  final ValueFormatter bottomAxistValueFormatter;

  final double leftOffsetViewPort;
  final double rightOffsetViewPort;
  final double topOffsetViewPort;
  final double bottomOffsetViewPort;

  const LineChartView({
    Key key,
    @required this.axistTitleColor,
    @required this.progressColor,
    @required this.lineColor,
    @required this.axisLeftGridColor,
    @required this.highLightColor,
    @required this.axisLeftTitle,
    @required this.axisBottomTitle,
    @required this.textColorAxisLeft,
    @required this.textColorAxis,
    @required this.values,
    this.height = 280,
    this.circleColor = AppColor.indigoA200,
    this.strokeCircleColor = AppColor.indigoA200,
    this.state = EChartState.noData,
    this.customNoDataView,
    this.noDataTitle = "Không có dữ liệu",
    this.noDataTitleColor = AppColor.indigoA200,
    this.leftAxistValueFormatter,
    this.bottomAxistValueFormatter,
    this.leftOffsetViewPort = 0.0,
    this.rightOffsetViewPort = 0.0,
    this.topOffsetViewPort = 0.0,
    this.bottomOffsetViewPort = 0.0,
  }) : super(key: key);

  @override
  _LineChartViewState createState() => _LineChartViewState();
}

class _LineChartViewState extends State<LineChartView> {
  LineChartController controller;

  @override
  void initState() {
    super.initState();

    //if (widget.state == ChartState.done) {
    _initController();

    _initLineData();
    //}
  }

  Widget _initLineChart() {
    if (controller == null) {
      return kSpaceShrinkBox;
    }
    final lineChart = LineChart(controller);

    controller.backgroundColor = Colors.transparent;
    controller.animator
      ..reset()
      ..animateX1(2000);
    return lineChart;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height,
      child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Row(
              children: [
                Visibility(
                  visible: widget.state == EChartState.done,
                  child: Text(
                    widget.axisLeftTitle,
                    style: Theme.of(context).textTheme.caption.copyWith(
                        color: widget.axistTitleColor,
                        fontStyle: FontStyle.italic),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(
                      top: kVerticalSpaceSmall, bottom: kVerticalSpaceMedium),
                  child: _ContentChartView(
                    progressColor: widget.progressColor,
                    chartState: widget.state,
                    noDataTitle: widget.noDataTitle,
                    noDataTitleColor: widget.noDataTitleColor,
                    customDataView: widget.customNoDataView,
                    chartView: _initLineChart(),
                  )),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Visibility(
                  visible: widget.state == EChartState.done,
                  child: Text(
                    widget.axisBottomTitle,
                    style: Theme.of(context).textTheme.caption.copyWith(
                        color: widget.axistTitleColor,
                        fontStyle: FontStyle.italic),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _initController() {
    var desc = Description()..enabled = false;
    controller = LineChartController(
        axisLeftSettingFunction: (axisLeft, controller) {
          axisLeft
            ..drawAxisLine = false
            ..drawLimitLineBehindData = false
            ..enableGridDashedLine(5, 5, 0)
            ..gridColor = widget.axisLeftGridColor
            ..axisValueFormatter = widget.leftAxistValueFormatter
            ..textColor = widget.textColorAxisLeft;
        },
        axisRightSettingFunction: (axisRight, controller) {
          axisRight..enabled = (false);
        },
        legendSettingFunction: (legend, controller) {
          legend.enabled = false;
        },
        xAxisSettingFunction: (xAxis, controller) {
          xAxis
            ..spaceMin = 0.25
            ..position = XAxisPosition.BOTTOM
            ..textColor = widget.textColorAxis
            ..drawAxisLine = false
            ..enableAxisLineDashedLine(5, 5, 0)
            ..axisValueFormatter = widget.bottomAxistValueFormatter
            ..gridColor = Colors.transparent;
        },
        customViewPortEnabled: false,
        drawGridBackground: false,
        backgroundColor: Colors.transparent,
        dragXEnabled: false,
        dragYEnabled: false,
        scaleXEnabled: false,
        scaleYEnabled: false,
        drawMarkers: true,
        marker: CircleDotMarker(
            backColor: widget.circleColor,
            strokeColor: widget.strokeCircleColor),
        pinchZoomEnabled: false,
        description: desc);

    controller.setViewPortOffsets(
        widget.leftOffsetViewPort,
        widget.topOffsetViewPort,
        widget.rightOffsetViewPort,
        widget.bottomOffsetViewPort);
  }

  void _initLineData() async {
    LineDataSet set1;

    // create a dataset and give it a type
    set1 = LineDataSet(widget.values, "DataSet1");

    set1.setDrawIcons(false);

    // draw dashed line
    //set1.enableDashedLine(10, 5, 0);

    // black lines and points
    set1.setColor1(widget.lineColor);
    //set1.setCircleColor(ColorUtils.BLACK);
    set1.setHighLightColor(widget.highLightColor);
    set1.setDrawHorizontalHighlightIndicator(false);
    set1.setDrawVerticalHighlightIndicator(true);
    set1.setHighlightLineWidth(1);

    // line thickness and point size
    set1.setLineWidth(2);
    set1.setCircleRadius(3);
    set1.setDrawCircles(false);
    // draw points as solid circles
    set1.setDrawCircleHole(true);
    set1.setCircleColor(widget.circleColor);

    // Customize legend entry
    set1.setFormLineWidth(1);
    set1.setFormLineDashEffect(DashPathEffect(5, 5, 0));
    set1.setFormSize(15);

    // Text size of values
    set1.setValueTextSize(9);
    set1.setValueTextColor(Colors.transparent);
    // Draw selection line as dashed
    set1.enableDashedHighlightLine(5, 3, 0);

    // set the filled area
    //set1.setDrawFilled(true);
    //set1.setFillFormatter(A(lineChart.painter));

    // set color of filled area
    //set1.setGradientColor(ColorUtils.BLUE, ColorUtils.RED);

    List<ILineDataSet> dataSets = List();
    dataSets.add(set1); // add the data sets

    // create a data object with the data sets
    controller.data = LineData.fromList(dataSets);
    controller.setViewPortOffsets(15, 0, 10, 0);
    setState(() {});
  }
}

class _ContentChartView extends StatelessWidget {
  final Color progressColor;
  final EChartState chartState;
  final String noDataTitle;
  final Color noDataTitleColor;
  final Widget chartView;
  final Widget customDataView;

  const _ContentChartView(
      {Key key,
      this.progressColor = Colors.white,
      @required this.chartState,
      @required this.chartView,
      this.customDataView,
      this.noDataTitle,
      this.noDataTitleColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (chartState == EChartState.loading) {
      return CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(
          progressColor,
        ),
      );
    }

    if (chartState == EChartState.noData) {
      return customDataView ??
          Text(
            noDataTitle,
            style: Theme.of(context)
                .textTheme
                .bodyText1
                .copyWith(color: noDataTitleColor),
          );
    }

    return chartView;
  }
}
