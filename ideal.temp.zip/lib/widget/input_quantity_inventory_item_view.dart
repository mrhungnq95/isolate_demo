import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/quantity_border_style_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';
import 'keyboard_general_dialog.dart';

class InputQuantityInventoryItemView extends StatefulWidget {
  final String title;
  final String subTitleFirst;
  final String subTitleSecond;
  final EdgeInsets padding;
  final double borderRadius;
  double quantity;

  InputQuantityInventoryItemView(
      {this.title,
      this.subTitleFirst,
      this.subTitleSecond,
      this.quantity,
      this.padding, this.borderRadius});

  @override
  _InputQuantityInventoryItemViewState createState() =>
      _InputQuantityInventoryItemViewState();
}

class _InputQuantityInventoryItemViewState
    extends State<InputQuantityInventoryItemView> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: InkWellView(
        borderRadius: widget.borderRadius ?? 0,
        onPressed: () {},
        child: Container(
          padding: widget.padding ?? const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge, vertical: kVerticalSpaceSmall),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                  width: 22,
                  height: 28,
                  child: Checkbox(
                    value: false,
                    onChanged: (value) {},
                  )),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: kHorizontalSpaceMedium),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.title,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2
                            .copyWith(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        widget.subTitleFirst,
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                      Text(
                        widget.subTitleSecond,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.grey700),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 58,
                alignment: Alignment.centerRight,
                child: QuantityBorderStyleView(
                    quantity: 100,
                    onPressed: () {
                      showDialog(
                          context: context,
                          child: KeyboardGeneralDialog(
                            type: EDoubleFormat.quantity,
                            titleDialog: 'Nhập số lượng',
                            initialValue: widget.quantity,
                            callback: (value) {
                              setState(() {
                                this.widget.quantity = value;
                                Navigator.pop(context);
                              });
                            },
                          ));
                    }),
              )
            ],
          ),
        ),
      ),
    );
  }
}
