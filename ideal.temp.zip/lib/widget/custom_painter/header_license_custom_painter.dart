import 'package:MShopManager/app/app_expose.dart';
import 'package:flutter/rendering.dart';

class HeaderLicenseCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint_0 = Paint()
      ..color = AppColor.licenseBackground
      ..style = PaintingStyle.fill
      ..strokeWidth = 1;

    Path path_0 = Path();
    path_0.moveTo(0, 0);
    path_0.lineTo(0, size.height * 0.3);
    path_0.lineTo(size.width * 0.5, size.height * 0.6);
    path_0.lineTo(size.width, size.height * 0.3);
    path_0.lineTo(size.width, 0);
    path_0.lineTo(0, 0);
    path_0.close();

    canvas.drawPath(path_0, paint_0);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
