import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';

/// Tổng tiền
class TotalView extends StatelessWidget {
  final String totalLabel;
  final bool isBoldLabel;
  final double totalQuantity;
  final double totalAmount;

  final Color totalLabelColor;
  final Color totalQuantityColor;
  final Color totalAmountColor;

  const TotalView({
    Key key,
    this.totalLabel = 'Tổng',
    this.isBoldLabel = true,
    this.totalQuantity,
    this.totalAmount,
    this.totalLabelColor = AppColor.textColor,
    this.totalQuantityColor = AppColor.textColor,
    this.totalAmountColor = AppColor.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          totalLabel,
          style: isBoldLabel
              ? Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(color: totalLabelColor)
              : Theme.of(context)
                  .textTheme
                  .bodyText2
                  .copyWith(color: totalLabelColor),
        ),
        kHorizontalSpaceMediumBox,
        Visibility(
          visible: totalQuantity != null,
          child: TextValueBorderView(
            value: totalQuantity?.toStringFormat(EDoubleFormat.quantity) ?? '0',
            textSize: 16,
            textColor: totalQuantityColor,
          ),
        ),
        Expanded(
            child: Text(
          totalAmount?.toStringFormat(EDoubleFormat.money) ?? '0',
          style: Theme.of(context)
              .textTheme
              .subtitle1
              .copyWith(fontWeight: FontWeight.bold, color: totalAmountColor),
          textAlign: TextAlign.end,
        )),
      ],
    );
  }
}
