import 'package:MShopManager/model/unit/unit.dart';

/// Tham số truyền vào
class SelectUnitArguments {
  Unit unitSelected;

  // danh sách các đơn vị tính sẽ bị loại bỏ trong danh sách
  List<Unit> listExclude = [];
  bool isMultiSelect = false;

  SelectUnitArguments({this.unitSelected, this.listExclude = const <Unit>[], this.isMultiSelect = false});
}
