import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/model/unit/unit.dart';
import 'package:flutter/material.dart';

class ItemUnitView extends StatefulWidget {
  const ItemUnitView({this.unit, this.isCheck = false, this.onTap});
  final Unit unit;
  final bool isCheck;
  final Function(Unit) onTap;

  @override
  ItemUnitViewState createState() => ItemUnitViewState();
}

class ItemUnitViewState extends State<ItemUnitView> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Material(
        color: AppColor.grey50,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: AppColor.grey400)
        ),
        child: InkWell(
          splashColor: AppColor.splashColor,
          highlightColor: AppColor.splashColor,
          borderRadius: BorderRadius.circular(10),
          onTap: () {
            setState(() {
              widget.unit.isSelected = !widget.unit.isSelected;
              widget.onTap?.call(widget.unit);
            });
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16),
            height: 44,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.unit?.unitName ?? '',
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1
                        .copyWith(color: AppColor.black, fontWeight: FontWeight.bold),
                  ),
                ),
                widget.isCheck
                    ? Icon(
                  Icons.check_rounded,
                  color: AppColor.indigo700,
                )
                    : SizedBox.shrink()
              ],
            ),
          ),
        ),
      ),
    );
  }
}