import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/model/unit/unit.dart';
import 'package:MShopManager/widget/two_option_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'item_unit_view.dart';
import 'select_unit_arguments.dart';


class UnitFilterController {
  UnitFilterMode mode = UnitFilterMode.ALL;
  final unitAll = Unit()
    ..unitID = AppConstant.UUID_EMPTY
    ..unitName = "Tất cả";

  /// DS đơn vị tính sẽ bị loại bỏ
  List<Unit> listExclude = [];

  Unit unitSelected;

  UnitFilterController({this.listExclude = const []});
}

/// view chọn đơn vị tính
class UnitFilterView extends StatefulWidget {
  final UnitFilterController controller;

  const UnitFilterView({Key key, this.controller}) : super(key: key);

  @override
  _UnitFilterViewState createState() => _UnitFilterViewState();
}

class _UnitFilterViewState extends State<UnitFilterView> {

  /// sự kiện thay đổi
  void _handleRadioValueChange(UnitFilterMode value) {
    if (value == UnitFilterMode.CUSTOM) {
      // nếu chưa chọn đơn vị tính thì mở luôn
      if(widget.controller.unitSelected == null) {
        _openSelectUnitPage(widget.controller.unitSelected);
        return;
      }
    }
    // chuyển mode
    setState(() {
      widget.controller.mode = value;
    });
  }

  /// cập nhật đơn vị tính dc chọn
  void _updateUnitSelected(Object value) {
    setState(() {
      // nếu không chọn DVT thì vẫn là mode cũ
      if (value is Unit) {
        widget.controller.mode = UnitFilterMode.CUSTOM;
        widget.controller.unitSelected = value;
      }
    });
  }

  /// mở màn hình chọn đơn vị tính
  void _openSelectUnitPage(Unit value) {
    var unitArguments = SelectUnitArguments(
            unitSelected: value,
            listExclude: widget.controller.listExclude);
    Navigator.of(context)
        .pushNamed(AppRouterName.select_unit.value(), arguments: unitArguments)
        .then(_updateUnitSelected);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          TwoOptionView(
            option1Value: UnitFilterMode.ALL,
            option2Value: UnitFilterMode.CUSTOM,
            groupValue: widget.controller.mode,
            onChanged: _handleRadioValueChange,
            title: 'Đơn vị tính',
            option1: Text(
              'Tất cả đơn vị tính',
              style: Theme.of(context).textTheme.bodyText1,
            ),
            option2: Text(
              'Khác',
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
          Visibility(
            visible: widget.controller.mode == UnitFilterMode.CUSTOM,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
              child: ItemUnitView(
                unit: widget.controller.unitSelected,
                isCheck: widget.controller.unitSelected?.isSelected == true,
                onTap: _openSelectUnitPage,
              ),
            ),
          )
        ],
      ),
    );
  }
}

enum UnitFilterMode { ALL, CUSTOM }
