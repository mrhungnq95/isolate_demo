import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_cached_network_image.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';

class InventoryItemView extends StatelessWidget {
  final String propertyInventoryItem;
  final VoidCallback onPress;
  const InventoryItemView(
      {Key key, this.propertyInventoryItem = 'AKZ-001', @required this.onPress})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: kVerticalSpaceSmall),
      child: InkWellView(
        onPressed: onPress,
        child: Container(
          padding: const EdgeInsets.only(
              left: kVerticalSpaceLarge,
              right: kVerticalSpaceLarge,
              top: kVerticalSpaceTiny,
              bottom: kVerticalSpaceTiny),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MSCachedNetworkImage(
                  borderRadius: BorderRadius.circular(10),
                  height: 46,
                  width: 46,
                  imageUrl:
                      "https://bucket.nhanh.vn/store/2071/ps/20200615/49997184818_dcea40764a_k.jpg"),
              kHorizontalSpaceMediumBox,
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Áo khoác kaki Zara",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyText1.copyWith(
                          fontSize: 16, color: AppColor.textSecondaryColor),
                    ),
                    Text(
                      propertyInventoryItem,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyText1.copyWith(
                          fontSize: 16, color: AppColor.textSecondaryColor),
                    ),
                    Text(
                      "8.602.000",
                      maxLines: 1,
                      style: Theme.of(context)
                          .textTheme
                          .subtitle1
                          .copyWith(fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
              TextValueBorderView(
                value: "100",
              ),
              Icon(
                Icons.keyboard_arrow_right,
                size: 25,
                color: AppColor.grey600,
              )
            ],
          ),
        ),
      ),
    );
  }
}
