import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

class QuantityBorderStyleView extends StatelessWidget {
  final double quantity;
  final double width;
  final Color colorBackground;
  final Function onPressed;

  const QuantityBorderStyleView({
    Key key,
    @required this.quantity,
    this.colorBackground,
    this.width,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      borderRadius: 10,
      colorBackground: colorBackground,
      onPressed: onPressed,
      child: Container(
        width: width,
        constraints: BoxConstraints(minWidth: 50),
        padding: const EdgeInsets.symmetric(
            horizontal: kHorizontalSpaceSmall, vertical: kVerticalSpaceSmall),
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            borderRadius: BorderRadius.circular(10)),
        child: Text(
          quantity?.toStringFormat(EDoubleFormat.quantity),
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyText1,
          maxLines: 1,
        ),
      ),
    );
  }
}
