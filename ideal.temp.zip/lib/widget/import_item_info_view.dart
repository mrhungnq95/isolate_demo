
import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/features/other/stock_issue/page/document_info_sheet_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

///
/// View thông tin phiếu
///
class ImportItemInfoView extends StatelessWidget {

  final String refNoItem;

  ImportItemInfoView({this.refNoItem});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: InkWellView(
        onPressed: () {
          showModalBottomSheet(
              elevation: 10,
              context: context,
              backgroundColor: Colors.transparent,
              isScrollControlled: true,
              builder: (c) => DocumentInfoSheetView());
        },
        borderRadius: 10,
        colorBackground: AppColor.grey50,
        child: Container(
          padding: const EdgeInsets.all(kHorizontalSpaceMedium),
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    RichText(
                        text: TextSpan(
                            children: [
                          TextSpan(
                              text: '   ' + '08/08/2020 16:30',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1
                                  .copyWith(fontSize: 16))
                        ],
                            text: refNoItem,
                            style: Theme.of(context).textTheme.bodyText2)),
                  ],
                ),
              ),
              Icon(
                Icons.keyboard_arrow_right,
                color: AppColor.grey600,
              )
            ],
          ),
        ),
      ),
    );
  }
}