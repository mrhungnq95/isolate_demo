import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class ItemCategoryView extends StatelessWidget {
  final Function(int position) onPressed;
  final int position;
  final String iconPath;
  final String title;
  
  const ItemCategoryView({
    Key key,
    this.position,
    this.iconPath,
    this.title,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      colorBackground: AppColor.grey50,
      borderRadius: 12,
      onPressed: () => onPressed(position),
      child: Container(
        padding: EdgeInsets.all(kVerticalSpaceMedium),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            border: Border.all(
              color: AppColor.grey400,
              width: 1,
            )),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(iconPath, width: 55, height: 55, fit: BoxFit.fill),
            SizedBox(
              height: 5,
            ),
            Text(
              title,
              maxLines: 1,
              textAlign: TextAlign.start,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.subtitle1,
            )
          ],
        ),
      ),
    );
  }
}
