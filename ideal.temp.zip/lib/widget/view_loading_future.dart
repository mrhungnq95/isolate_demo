import 'package:flutter/material.dart';

class ViewLoadingHolder<T> extends StatelessWidget {
  final Future<T> future;
  final Widget Function(T data) builder;

  const ViewLoadingHolder(
      {Key key, @required this.future, @required this.builder})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: this.future,
      builder: (BuildContext context, AsyncSnapshot<T> snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return Container(
            width: double.infinity,
            height: double.infinity,
            child: this.builder(snapshot.data),
          );
        } else {
          return ViewLoading();
        }
      },
    );
  }
}

class ViewError extends StatelessWidget {
  final Widget error;

  const ViewError(
    this.error, {
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: error,
      ),
    );
  }
}

class ViewLoading extends StatelessWidget {
  const ViewLoading({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: SizedBox(
          height: 36,
          width: 36,
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }
}
