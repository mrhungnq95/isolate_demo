import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// View Detail phần tồn kho
class StockInventoryItemView extends StatelessWidget {
 final String label;
 final String refNo;
 final double totalAmount;
 final double totalQuantity;

  const StockInventoryItemView({Key key, this.label, this.refNo, this.totalAmount, this.totalQuantity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Container(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context)
                    .textTheme
                    .bodyText1,
              ),
              Visibility(
                visible: refNo?.isNotEmpty == true,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: kVerticalSpaceSmall),
                  child: Text(
                    refNo,
                    style: Theme.of(context)
                        .textTheme
                        .caption
                        .copyWith(color: AppColor.textSecondaryColor),
                  ),
                ),
              ),
              Text(
                totalAmount?.toStringFormat(EDoubleFormat.money) ?? '0',
                style: Theme.of(context)
                    .textTheme
                    .subtitle1
                    .copyWith(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          kHorizontalSpaceMediumBox,
          Spacer(),
          kHorizontalSpaceMediumBox,
          TextValueBorderView(
            value: totalQuantity?.toStringFormat(EDoubleFormat.quantity) ?? '0',
            textSize: 16,
          ),
        ],
      ),
    );
  }
}
