import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';

///
/// View hiển thị tổng và value
///
class TotalItemButtonView extends StatelessWidget {

  final String titleString;
  final String valueString;
  final Function onTap;

  TotalItemButtonView({this.titleString, this.valueString, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      onPressed: onTap,
        borderRadius: 10,
          child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: AppColor.primaryColor,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge,
            ),
            child: Row(
              children: [
                Text(
                  titleString,
                  style: Theme.of(context)
                      .textTheme
                      .subtitle1
                      .copyWith(color: AppColor.white),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: kHorizontalSpaceMedium),
                  child: VerticalDivider(
                    thickness: 1,
                    color: AppColor.grey300.withOpacity(0.1),
                  ),
                ),
                Expanded(
                  child: Text(
                    valueString,
                    style: Theme.of(context)
                        .textTheme
                        .subtitle1
                        .copyWith(color: AppColor.white),
                    textAlign: TextAlign.end,
                  ),
                ),
              ],
            )),
      ),
    );
  }
}
