import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'inkwell_view.dart';

class TimeView extends StatelessWidget {
  final String title;
  final Function onTap;

  TimeView({this.title, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      borderRadius: 4,
      onPressed: onTap,
      child: Container(
        padding: const EdgeInsets.all(kVerticalSpaceTiny),
        child: Row(
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.bodyText1,
            ),
            Icon(
              Icons.keyboard_arrow_down,
              size: 22,
              color: AppColor.grey600,
            )
          ],
        ),
      ),
    );
  }
}