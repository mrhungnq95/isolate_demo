import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'inkwell_view.dart';
import 'input_quantity_view.dart';

class ChooseInventoryItemView extends StatefulWidget {
  final String title;
  final String subTitleFirst;
  final String subTitleSecond;
  final bool isShowCheckbox;
  final Function onTap;
  double quantity;

  ChooseInventoryItemView(
      {this.title,
      this.subTitleFirst,
      this.subTitleSecond,
      this.quantity = 0,
      this.isShowCheckbox = true,
      this.onTap});

  @override
  _ChooseInventoryItemViewState createState() =>
      _ChooseInventoryItemViewState();
}

class _ChooseInventoryItemViewState extends State<ChooseInventoryItemView> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: kHorizontalSpaceOverSmall, vertical: kVerticalSpaceTiny),
      child: InkWellView(
        borderRadius: 10,
        onPressed: widget.onTap,
        child: Container(
            decoration: BoxDecoration(
                color: widget.quantity > 0
                    ? AppColor.indigoA200.withOpacity(0.1)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(
                vertical: kVerticalSpaceSmall),
            child: Stack(
              children: [
                SizedBox(
                  width: ScreenUtils.width * 0.75,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Visibility(
                        visible: widget.isShowCheckbox,
                        child: SizedBox(
                            width: 22,
                            height: 28,
                            child: Checkbox(
                              value: false,
                              onChanged: (value) {},
                            )),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: kHorizontalSpaceOverSmall),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.title,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText2
                                    .copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                              Text(
                                widget.subTitleFirst,
                                style: Theme.of(context).textTheme.bodyText1,
                              ),
                              Text(
                                widget.subTitleSecond,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1
                                    .copyWith(color: AppColor.textSecondaryColor),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned.fill(
                  right: kHorizontalSpaceOverSmall,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ChangeQuantityView(changeQuantityAction: (value) {
                        setState(() {
                          widget.quantity = value;
                        });
                      })
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }
}
