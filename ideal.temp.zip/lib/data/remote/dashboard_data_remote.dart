import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/overview/revenue_for_time_display_item.dart';
import 'package:MShopManager/model/business_status/business_status_info.dart';
import 'package:MShopManager/model/service/get_detail_invoice_response.dart';
import 'package:MShopManager/model/service/get_list_debt_response.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/request/get_business_status_param.dart';
import 'package:MShopManager/model/service/request/get_debt_report_param.dart';
import 'package:MShopManager/model/service/request/revenue_for_inventory_item_param.dart';
import 'package:MShopManager/model/service/request/revenue_setting_dashboard_param.dart';
import 'package:MShopManager/model/service/revenue_by_items_info.dart';
import 'package:MShopManager/service/api/impl/dashboard_api_client.dart';

abstract class DashboardDataRemote {
  ///
  /// Lấy báo cáo Tổng quát
  /// [param] object [DrawDashboarForMobileParam] lưu thông tin request
  ///
  Future<ApiResult<List<RevenueForTimeDisplayItem>>> getRevenueReportByTime(
      RevenueSettingDashboardParam param);

  ///
  /// Get chi tiết hóa đơn
  /// VNLONG 31/12/2020
  ///
  Future<ApiResult<GetDetailInvoiceResponse>> getDetailInvoice(String refId);

  ///
  /// Lấy báo cáo doanh thu theo mặt hàng
  /// [param] object [RevenueForInventoryItemParam] lưu thông tin request
  ///
  Future<ApiResult<RevenueByItemsInfo>> getRevenueReportByInventory(
      RevenueForInventoryItemParam param);

  ///
  /// Lấy danh sách công nợ khách hàng
  /// [param]: Tham số lấy báo cáo
  ///
  Future<ApiResult<GetListDebtResponse>> getDebtReport(
      GetDebtReportParam param);

  ///
  /// Lấy báo cáo tình hình kinh doanh
  /// [param]: Tham số lấy báo cáo
  ///
  Future<ApiResult<List<BusinessStatusInfo>>> getBusinessStatus(
      GetBusinessStatusParam param);
}

class DashboardDataRemoteImpl extends MSBaseRepository
    implements DashboardDataRemote {
  final DashboardAPIClient dashboardAPIClient;

  DashboardDataRemoteImpl({this.dashboardAPIClient});

  @override
  Future<ApiResult<List<RevenueForTimeDisplayItem>>> getRevenueReportByTime(
      RevenueSettingDashboardParam param) async {
    final response = await dashboardAPIClient.getChartDashboardReport(param);

    final output = MSOutputService<RevenueForTimeDisplayItem>.fromJson(
        response, (data) => RevenueForTimeDisplayItem.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<List<RevenueForTimeDisplayItem>>.success(
          data: output.data);
    } else {
      return ApiResult<List<RevenueForTimeDisplayItem>>.failure(
          errorData: null, error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<GetDetailInvoiceResponse>> getDetailInvoice(
      String refId) async {
    try {
      final response = await dashboardAPIClient.getDetailInvoice(refId);

      final output = MSOutputService<GetDetailInvoiceResponse>.fromJson(
          response, (data) => GetDetailInvoiceResponse.fromMap(data));
      if (output != null && output.hasData()) {
        return ApiResult.success(data: output?.first());
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<RevenueByItemsInfo>> getRevenueReportByInventory(
      RevenueForInventoryItemParam param) async {
    return await dashboardAPIClient
        .getRevenueReportByInventory(param)
        .then((response) {
      final output = MSOutputService<RevenueByItemsInfo>.fromJson(
          response, (data) => RevenueByItemsInfo.fromMap(data));

      if (output != null && output.hasData()) {
        return ApiResult<RevenueByItemsInfo>.success(data: output.first());
      } else {
        return ApiResult<RevenueByItemsInfo>.failure(
            errorData: null, error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<GetListDebtResponse>> getDebtReport(
      GetDebtReportParam param) async {
    return await dashboardAPIClient.getDebtReport(param).then((response) {
      final output = MSOutputService<GetListDebtResponse>.fromJson(
          response, (data) => GetListDebtResponse.fromMap(data));

      if (output != null && output.hasData()) {
        return ApiResult<GetListDebtResponse>.success(data: output.first());
      } else {
        return ApiResult<GetListDebtResponse>.failure(
            errorData: null, error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<List<BusinessStatusInfo>>> getBusinessStatus(
      GetBusinessStatusParam param) async {
    return await dashboardAPIClient.getBusinessStatus(param).then((response) {
      final output = MSOutputService<List<BusinessStatusInfo>>.fromJson(
          response, (data) => GetListDebtResponse.fromMap(data));

      if (output != null && output.hasData()) {
        return ApiResult<List<BusinessStatusInfo>>.success(
            data: output.data ?? []);
      } else {
        return ApiResult<List<BusinessStatusInfo>>.failure(
            errorData: null, error: NetworkExceptions.unexpectedError());
      }
    });
  }
}
