import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/enums/enum_edit_mode.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/unit/unit.dart';
import 'package:MShopManager/service/api/impl/unit_api_client.dart';

abstract class UnitDataRemote {
  ///
  /// Lấy danh sách đơn vị tính của hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 13/01/2021
  ///
  Future<ApiResult<List<Unit>>> getListUnit(
      EditMode editMode);
}

class UnitDataRemoteImp implements UnitDataRemote {
  UnitAPIClient apiClient;

  UnitDataRemoteImp({this.apiClient});

  @override
  Future<ApiResult<List<Unit>>> getListUnit(EditMode editMode) async {
    try {
      final response = await apiClient.getListUnit(editMode);
      final output = MSOutputService<Unit>.fromJson(response, (data) => Unit.fromMap(data));
    
      if (output != null && output.hasData()) {
        return ApiResult<List<Unit>>.success(data: output.data);
      } else {
        return ApiResult<List<Unit>>.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult<List<Unit>>.failure(
          error: NetworkExceptions.getDioException(e));
    }
  }
}
