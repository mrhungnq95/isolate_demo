import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/service/api/impl/dboption_api_client.dart';

abstract class DBOptionDataRemote {
  ///
  /// Lấy DBOption theo [branchId]
  ///
  Future<ApiResult<List<DBOption>>> getDBOptionByBranchID(String branchId);
}



class DBOptionDataRemoteImpl implements DBOptionDataRemote {
  DBOptionAPIClient apiClient;

  DBOptionDataRemoteImpl({
    this.apiClient,
  });

  @override
  Future<ApiResult<List<DBOption>>> getDBOptionByBranchID(
      String branchId) async {
    try {
      final response = await apiClient.getDBOptionByBranchID(branchId);

      final output = MSOutputService<DBOption>.fromJson(
          response, (data) => DBOption.fromMap(data));

      if (output != null && output.hasData()) {
        return ApiResult<List<DBOption>>.success(data: output.data);
      } else {
        return ApiResult<List<DBOption>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult<List<DBOption>>.failure(
          error: NetworkExceptions.getDioException(e));
    }
  }
}
