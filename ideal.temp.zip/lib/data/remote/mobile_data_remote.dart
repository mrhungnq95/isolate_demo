import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/base/sumary_data_info.dart';
import 'package:MShopManager/model/invoice/group_invoice.dart';
import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/model/overview/report_daily_item.dart';
import 'package:MShopManager/model/role_permission.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/model/service/get_detail_invoice_response.dart';
import 'package:MShopManager/model/service/get_list_invoice_param.dart';
import 'package:MShopManager/model/service/get_list_invoice_response.dart';
import 'package:MShopManager/model/service/get_notification_config_param.dart';
import 'package:MShopManager/model/service/get_notification_config_response.dart';
import 'package:MShopManager/model/service/get_notification_param.dart';
import 'package:MShopManager/model/service/get_roles_permission_param.dart';
import 'package:MShopManager/model/service/get_roles_permission_response.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/ms_base_service_output_normal.dart';
import 'package:MShopManager/model/service/request/draw_dashboar_for_mobile_param.dart';
import 'package:MShopManager/model/service/request/get_customer_dashboard_param.dart';
import 'package:MShopManager/model/service/request/validate_serial_imei_param.dart';
import 'package:MShopManager/model/service/set_notification_readed_param.dart';
import 'package:MShopManager/model/service/request/get_customer_paging_param.dart';
import 'package:MShopManager/model/service/request/list_order_for_customer_param.dart';
import 'package:MShopManager/model/service/update_notification_config_param.dart';
import 'package:MShopManager/model/service/validate_serial_emei_error.dart';
import 'package:MShopManager/model/summary_data.dart';
import 'package:MShopManager/service/api/impl/mobile_api_client.dart';

abstract class MobileDataRemote {
  ///
  /// Lấy Role Permission
  /// [param] obj GetRolesPermissionParam
  ///
  Future<ApiResult<GetRolesPermissionResponse>> fetchRolesPermission(
      GetRolesPermissionParam param);

  ///
  /// Lấy báo cáo Tổng quát
  /// [param] object [DrawDashboarForMobileParam] lưu thông tin request
  ///
  Future<ApiResult<List<ReportDailyItem>>> fetchDrawDashboardReport(
      DrawDashboarForMobileParam param);

  ///
  /// Lấy DS KH Tổng quan
  /// [param] object [GetCustomerDashboardParam] lưu thông tin request
  ///
  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerListDashboard(
      GetCustomerDashboardParam param);

  ///
  /// Lấy DS KH Tổng quan
  /// [param] object [GetCustomerDashboardParam] lưu thông tin request
  ///
  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerListPaging(
      GetCustomerPagingParam param);

  ///
  /// Lấy chi tiết của KH
  /// [customerId] id của Khách hàng
  ///
  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerDetailById(
      String customerId);

  ///
  /// Lấy ds thông báo
  /// [param] obj ListNofiticationParam
  ///
  Future<ApiResult<List<NotificationItem>>> getListNotification(
      ListNofiticationParam param);

  ///
  /// lấy thiết lập thông báo của thiết bị
  /// [param] obj ListNofiticationParam
  ///
  Future<ApiResult<GetNotificationConfigResponse>> getNotificationConfig(
      GetNotificationConfigParam param);

  ///
  /// Cập nhật các thông tin thông báo
  /// [param] obj ListNofiticationParam
  ///
  Future<ApiResult<MSOutputService>> updateNotificationConfig(
      UpdateNotificationConfigParam param);

  ///
  /// Kiểm tra SerialIMEI của hàng hóa có thoả mãn hay không?
  /// [param] ds hàng hoá cần validate
  ///
  Future<ApiResult<MSOutputService<ValidateSerialIMEIError>>> validateSerialIMEI(ValidateSerialIMEIParam param);


  ///
  /// Cập nhật trạng thái đã đọc cho item thông báo
  /// VNLONG - 30/12/2020
  ///
  Future<ApiResult<MSOutputServiceNormal>> setNotificationReaded(
      SetNotificationReadedParam param);

  ///
  /// Lấy danh sách hóa đơn
  ///
  Future<ApiResult<GetListInvoiceResponse>> getListInvoice(
      GetListInvoiceParam param);

  /// Lấy hoá đơn theo Khách hàng
  /// [param] object [GetOrderForCustomerParam]  thông tin param cho request
  ///
  Future<ApiResult<MSOutputService<SAInvoice>>> fetchSaleHistoryMobilePaging(
      GetOrderForCustomerParam param);
}

class MobileDataRemoteImpl implements MobileDataRemote {
  MobileAPIClient apiClient;

  MobileDataRemoteImpl({
    this.apiClient,
  });

  @override
  Future<ApiResult<GetRolesPermissionResponse>> fetchRolesPermission(
      GetRolesPermissionParam param) async {
    final response = await apiClient.getRolesPermission(param);

    final output = MSOutputService<RolePermission>.fromJson(
        response, (data) => RolePermission.fromMap(data));
    if (output != null) {
      return ApiResult<GetRolesPermissionResponse>.success(
          data: GetRolesPermissionResponse(output.data));
    } else {
      return ApiResult<GetRolesPermissionResponse>.failure(
          error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<List<ReportDailyItem>>> fetchDrawDashboardReport(
      DrawDashboarForMobileParam param) async {
    final response = await apiClient.getDrawDashboardReport(param);

    final output = MSOutputService<ReportDailyItem>.fromJson(
        response, (data) => ReportDailyItem.fromMap(data));
    if (output != null) {
      return ApiResult<List<ReportDailyItem>>.success(data: output.data);
    } else {
      return ApiResult<List<ReportDailyItem>>.failure(
          error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerListDashboard(
      GetCustomerDashboardParam param) {
    return apiClient.getCustomerListDashboard(param).then((response) {
      final output = MSOutputService<Customer>.fromJson(
          response, (data) => Customer.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<Customer>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<Customer>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<List<NotificationItem>>> getListNotification(
      ListNofiticationParam param) async {
    try {
      final response = await apiClient.getListNotification(param);

      final output = MSOutputService<NotificationItem>.fromJson(
          response, (data) => NotificationItem.fromMap(data));
      if (output != null && output.hasData()) {
        return ApiResult.success(data: output.data);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<GetNotificationConfigResponse>> getNotificationConfig(
      GetNotificationConfigParam param) async {
    try {
      final response = await apiClient.getNotificationConfig(param);

      final output = MSOutputService<GetNotificationConfigResponse>.fromJson(
          response, (data) => GetNotificationConfigResponse.fromMap(data));
      if (output != null && output.hasData()) {
        return ApiResult.success(data: output?.data?.first);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<MSOutputService>> updateNotificationConfig(
      UpdateNotificationConfigParam param) async {
    try {
      final response = await apiClient.updateNotification(param);

      final output = MSOutputService<GetNotificationConfigResponse>.fromJson(
          response, (data) => GetNotificationConfigResponse.fromMap(data));
      if (output != null && output.hasData()) {
        return ApiResult.success(data: output);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<MSOutputService<ValidateSerialIMEIError>>> validateSerialIMEI(ValidateSerialIMEIParam param) async {
    try {
      final response = await apiClient.validateSerialIMEI(param);

      final output = MSOutputService<ValidateSerialIMEIError>.fromJson(
          response, (data) => ValidateSerialIMEIError.fromMap(data));
      if (output != null && output.hasData()) {
        return ApiResult.success(data: output);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<MSOutputServiceNormal>> setNotificationReaded(
      SetNotificationReadedParam param) async {
    try {
      final response = await apiClient.setNotificationReaded(param);

      final output = MSOutputServiceNormal.fromMap(response);
      if (output != null) {
        return ApiResult.success(data: output);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<ApiResult<GetListInvoiceResponse>> getListInvoice(
      GetListInvoiceParam param) async {
    try {
      final response = await apiClient.getListInvoice(param);

      final output = MSOutputService<GroupInvoice>.fromJson(
          response, (data) => GroupInvoice.fromMap(data));
      GetListInvoiceResponse result = GetListInvoiceResponse(
          listGroupInvoice: output.data ?? [], summaryData: SummaryNormalData.fromMap(output.summaryData));

      if (output != null) {
        return ApiResult.success(data: result);
      } else {
        return ApiResult.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult.failure(error: NetworkExceptions.getDioException(e));
    }
  }

  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerListPaging(
      GetCustomerPagingParam param) {
    return apiClient.getCustomerListPaging(param).then((response) {
      final output = MSOutputService<Customer>.fromJson(
          response, (data) => Customer.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<Customer>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<Customer>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<MSOutputService<Customer>>> fetchCustomerDetailById(
      String customerId) {
    return apiClient.fetchCustomerDetailById(customerId).then((response) {
      final output = MSOutputService<Customer>.fromJson(
          response, (data) => Customer.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<Customer>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<Customer>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<MSOutputService<SAInvoice>>> fetchSaleHistoryMobilePaging(
      GetOrderForCustomerParam param) {
    return apiClient.fetchSaleHistoryMobilePaging(param).then((response) {
      final output = MSOutputService<SAInvoice>.fromJson(
          response, (data) => SAInvoice.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<SAInvoice>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<SAInvoice>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }
}
