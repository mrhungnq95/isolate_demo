import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/response/add_customer_response.dart';
import 'package:MShopManager/model/service/response/customer_category_response.dart';
import 'package:MShopManager/service/api/impl/be_api_client.dart';

abstract class BeDataRemote {
  ///
  /// Thêm khách hàng
  /// [customer] obj KH muốn thêm
  ///
  Future<ApiResult<MSOutputService<AddCustomerResponseData>>> addCustomer(
      Customer customer);

  ///
  /// Lấy nhóm khách hàng
  /// [keySearch] nội dung cần searhc
  /// [pageIndex] vị trí của page đang lấy dữ liệu
  /// [pageSize] tổng số page cần lấy
  ///
  Future<ApiResult<MSOutputService<CustomerCategoryReponse>>>
      fetchListCustomerCategory(
    String keySearch,
    int pageIndex,
    int pageSize,
  );

  ///
  /// Sửa khách hàng
  /// [customer] obj KH cần sửa
  ///
  Future<ApiResult<MSOutputService<bool>>> editCustomer(Customer customer);

  ///
  /// Xoá khách hàng
  /// [customerId] id của KH
  ///
  Future<ApiResult<MSOutputService<bool>>> deleteCustomer(String customerId);
}

class BeDataRemoteImpl extends BeDataRemote {
  BeAPIClient beAPIClient;

  BeDataRemoteImpl({
    this.beAPIClient,
  });

  @override
  Future<ApiResult<MSOutputService<AddCustomerResponseData>>> addCustomer(
      Customer customer) {
    return beAPIClient.addCustomer(customer).then((response) {
      final output = MSOutputService<AddCustomerResponse>.fromJson(
          response, (data) => AddCustomerResponse.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<AddCustomerResponseData>>.success(
            data: output.first()?.data);
      } else {
        return ApiResult<MSOutputService<AddCustomerResponseData>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<MSOutputService<bool>>> deleteCustomer(String customerId) {
    return beAPIClient.deleteCustomer(customerId).then((response) {
      final output = MSOutputService<bool>.fromJson(response, null);
      if (output != null) {
        return ApiResult<MSOutputService<bool>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<bool>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<MSOutputService<bool>>> editCustomer(Customer customer) {
    return beAPIClient.editCustomer(customer).then((response) {
      final output = MSOutputService<bool>.fromJson(response, null);
      if (output != null) {
        return ApiResult<MSOutputService<bool>>.success(data: output);
      } else {
        return ApiResult<MSOutputService<bool>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }

  @override
  Future<ApiResult<MSOutputService<CustomerCategoryReponse>>>
      fetchListCustomerCategory(String keySearch, int pageIndex, int pageSize) {
    return beAPIClient
        .fetchListCustomerCategory(keySearch, pageIndex, pageSize)
        .then((response) {
      final output = MSOutputService<CustomerCategoryReponse>.fromJson(
          response, (data) => CustomerCategoryReponse.fromMap(data));
      if (output != null) {
        return ApiResult<MSOutputService<CustomerCategoryReponse>>.success(
            data: output);
      } else {
        return ApiResult<MSOutputService<CustomerCategoryReponse>>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    });
  }
}
