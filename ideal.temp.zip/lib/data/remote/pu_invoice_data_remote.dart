import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/pu_invoice/pu_invoice.dart';
import 'package:MShopManager/model/pu_invoice/pu_invoice_detail.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/ms_base_service_output_master_data.dart';
import 'package:MShopManager/model/service/pu_invoice_arisen_response.dart';
import 'package:MShopManager/model/service/request/check_item_receipt_note_arisen_param.dart';
import 'package:MShopManager/model/service/request/delete_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/delete_vendor_param.dart';
import 'package:MShopManager/model/service/request/get_detail_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/get_list_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/get_list_vendor_param.dart';
import 'package:MShopManager/model/service/request/get_new_ref_no_param.dart';
import 'package:MShopManager/model/service/request/save_item_receipt_note_param.dart';
import 'package:MShopManager/model/vendor.dart';
import 'package:MShopManager/model/vendor_category.dart';
import 'package:MShopManager/service/api/impl/pu_invoice_api_client.dart';

abstract class PUInvoiceDataRemote {
  ///
  /// Lấy danh sách nhà cung cấp
  /// [param] obj GetRolesPermissionParam
  ///
  Future<ApiResult<List<Vendor>>> getListVendor(GetListVendorParam param);

  ///
  /// Lưu nhà cung cấp
  /// [param] NCC
  ///
  Future<ApiResult<MSOutputService>> saveVendor(Vendor param);

  ///
  /// xoá nhà cung cấp
  /// [param] danh sách NCC cần xoá
  ///
  Future<ApiResult<MSOutputService>> deleteVendors(DeleteVendorParam param);

  ///
  /// Lấy danh sách nhóm nhà cung cấp
  ///
  Future<ApiResult<List<VendorCategory>>> getListVendorCategory();

  ///
  /// Thêm nhóm nhà cung cấp
  /// [param] obj nhóm nhà cung cấp
  ///
  Future<ApiResult<MSOutputServiceMasterData<VendorCategory>>> addVendorCategory(VendorCategory param);

  // region ---------------------- API Nhập hàng ------------------------------
  ///
  /// Lấy số phiếu nhập hàng mới nhất
  /// [param] param
  ///
  Future<ApiResult<MSOutputService<String>>> getNewRefNoByRefType(GetNewRefNoParam param);

  ///
  /// Lấy chi tiết phiếu nhập hàng
  /// [param] param
  ///
  Future<ApiResult<MSOutputService<PUInvoice>>> getDetailItemReceiptNote(GetDetailItemReceiptNoteParam param);

  ///
  /// Lấy danh sách phiếu nhập hàng
  /// [param] param
  ///
  Future<ApiResult<MSOutputService<PUInvoice>>> getListItemReceiptNote(GetListItemReceiptNoteParam param);

  ///
  /// Lưu phiếu nhập hàng
  /// [param] param
  ///
  Future<ApiResult<MSOutputService>> saveItemReceiptNote(SaveItemReceiptNoteParam param);

  ///
  /// Kiểm tra chứng từ đã phát sinh hay chưa
  /// [param] param
  ///
  Future<ApiResult<MSOutputService<PUInvoiceArisenResponse>>> checkItemReceiptNoteIsArisen(CheckItemReceiptNoteIsArisenParam param);

  ///
  /// Xoá phiếu nhập hàng
  /// [param] param
  ///
  Future<ApiResult<MSOutputService>> deleteItemReceiptNote(DeleteItemReceiptNoteParam param);

// endregion
}

class PUInvoiceDataRemoteImpl implements PUInvoiceDataRemote {
  PUInvoiceAPIClient apiClient;

  PUInvoiceDataRemoteImpl(this.apiClient);

  @override
  Future<ApiResult<List<Vendor>>> getListVendor(GetListVendorParam param) async {
    final response = await apiClient.getListVendor(param);
    final output = MSOutputService<Vendor>.fromJson(response, (data) => Vendor.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<List<Vendor>>.success(data: output.data);
    } else {
      return ApiResult<List<Vendor>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService>> saveVendor(Vendor param) async {
    final response = await apiClient.saveVendor(param);
    final output = MSOutputService<Vendor>.fromJson(response, (data) => data);
    if (output != null && output.primaryKeyValue != null && output.primaryKeyValue.isNotEmpty) {
      return ApiResult<MSOutputService>.success(data: output);
    } else {
      return ApiResult<MSOutputService>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService>> deleteVendors(DeleteVendorParam param) async {
    final response = await apiClient.deleteVendors(param);
    final output = MSOutputService.fromJson(response, (data) => data);
    if (output != null) {
      return ApiResult<MSOutputService>.success(data: output);
    } else {
      return ApiResult<MSOutputService>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<List<VendorCategory>>> getListVendorCategory() async {
    final response = await apiClient.getListVendorCategory();
    final output = MSOutputService<VendorCategory>.fromJson(response, (data) => VendorCategory.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<List<VendorCategory>>.success(data: output.data);
    } else {
      return ApiResult<List<VendorCategory>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputServiceMasterData<VendorCategory>>> addVendorCategory(VendorCategory param) async {
    final response = await apiClient.addVendorCategory(param);
    final output = MSOutputServiceMasterData<VendorCategory>.fromJson(response, (data) => VendorCategory.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<MSOutputServiceMasterData<VendorCategory>>.success(data: output);
    } else {
      return ApiResult<MSOutputServiceMasterData<VendorCategory>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService>> deleteItemReceiptNote(DeleteItemReceiptNoteParam param) async {
    final response = await apiClient.deleteItemReceiptNote(param);
    final output = MSOutputService.fromJson(response, (data) => data);
    if (output != null) {
      return ApiResult<MSOutputService>.success(data: output);
    } else {
      return ApiResult<MSOutputService>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService<PUInvoice>>> getListItemReceiptNote(GetListItemReceiptNoteParam param) async {
    final response = await apiClient.getListItemReceiptNote(param);
    final output = MSOutputService<PUInvoice>.fromJson(response, (data) => PUInvoice.fromMap(data));
    if (output != null) {
      return ApiResult<MSOutputService<PUInvoice>>.success(data: output);
    } else {
      return ApiResult<MSOutputService<PUInvoice>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService<String>>> getNewRefNoByRefType(GetNewRefNoParam param) async {
    final response = await apiClient.getNewRefNoByRefType(param);
    final output = MSOutputService<String>.fromJson(response, (data) => data);
    if (output != null) {
      return ApiResult<MSOutputService<String>>.success(data: output);
    } else {
      return ApiResult<MSOutputService<String>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService>> saveItemReceiptNote(SaveItemReceiptNoteParam param) async {
    final response = await apiClient.saveItemReceiptNote(param);
    final output = MSOutputService.fromJson(response, (data) => data);
    if (output != null) {
      return ApiResult<MSOutputService>.success(data: output);
    } else {
      return ApiResult<MSOutputService>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService<PUInvoice>>> getDetailItemReceiptNote(GetDetailItemReceiptNoteParam param) async {
    final response = await apiClient.getDetailItemReceiptNote(param);
    final output = MSOutputService<PUInvoice>.fromJson(response, (data) => PUInvoice.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<MSOutputService<PUInvoice>>.success(data: output);
    } else {
      return ApiResult<MSOutputService<PUInvoice>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

  @override
  Future<ApiResult<MSOutputService<PUInvoiceArisenResponse>>> checkItemReceiptNoteIsArisen(CheckItemReceiptNoteIsArisenParam param) async {
    final response = await apiClient.checkItemReceiptNoteIsArisen(param);
    final output = MSOutputService<PUInvoiceArisenResponse>.fromJson(response, (data) => PUInvoiceArisenResponse.fromMap(data));
    if (output != null && output.hasData()) {
      return ApiResult<MSOutputService<PUInvoiceArisenResponse>>.success(data: output);
    } else {
      return ApiResult<MSOutputService<PUInvoiceArisenResponse>>.failure(error: NetworkExceptions.unexpectedError());
    }
  }

}
