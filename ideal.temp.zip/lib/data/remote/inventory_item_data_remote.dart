import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/inventory_item/inventory_item.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_param.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_response.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/service/api/impl/inventory_item_api_client.dart';

abstract class InventoryItemDataRemote {
  ///
  /// Lấy danh sách hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 13/01/2021
  ///
  Future<ApiResult<GetListInventoryItemResponse>> getListInventroyItem(
      GetListInventoryItemParam param);
}

class InventoryItemDataRemoteImp implements InventoryItemDataRemote {
  InventoryItemAPIClient apiClient;

  InventoryItemDataRemoteImp({this.apiClient});

  @override
  Future<ApiResult<GetListInventoryItemResponse>> getListInventroyItem(GetListInventoryItemParam param) async {
    try {
      final response = await apiClient.getListInventoryItem(param);
      final output = MSOutputService<InventoryItem>.fromJson(response, (data) => InventoryItem.fromMap(data));
    
      if (output != null && output.hasData()) {
        final data = GetListInventoryItemResponse(listInventoryItem: output.data, total: output.total);
        return ApiResult<GetListInventoryItemResponse>.success(data: data);
      } else {
        return ApiResult<GetListInventoryItemResponse>.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult<GetListInventoryItemResponse>.failure(
          error: NetworkExceptions.getDioException(e));
    }
  }
}
