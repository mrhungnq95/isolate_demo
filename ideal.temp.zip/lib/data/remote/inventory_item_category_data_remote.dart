import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/inventory_item/inventory_item_category.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_category_param.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/service/api/impl/inventory_item_category_api_client.dart';

/// 
/// API Nhóm hàng hóa
/// 
abstract class InventoryItemCategoryDataRemote {
  ///
  /// Lấy danh sách Category hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 18/01/2021
  ///
  Future<ApiResult<List<InventoryItemCategory>>> getListInventroyItemCategory(
      GetListInventoryItemCategoryParam param);
}

class InventoryItemCategoryDataRemoteImp implements InventoryItemCategoryDataRemote {
  InventoryItemCategoryAPIClient apiClient;

  InventoryItemCategoryDataRemoteImp({this.apiClient});

  @override
  Future<ApiResult<List<InventoryItemCategory>>> getListInventroyItemCategory(GetListInventoryItemCategoryParam param) async {
    try {
      final response = await apiClient.getListInventoryItemCategory(param);
      final output = MSOutputService<InventoryItemCategory>.fromJson(response, (data) => InventoryItemCategory.fromMap(data));
    
      if (output != null && output.hasData()) {
        return ApiResult<List<InventoryItemCategory>>.success(data: output.data);
      } else {
        return ApiResult<List<InventoryItemCategory>>.failure(error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      return ApiResult<List<InventoryItemCategory>>.failure(
          error: NetworkExceptions.getDioException(e));
    }
  }
}
