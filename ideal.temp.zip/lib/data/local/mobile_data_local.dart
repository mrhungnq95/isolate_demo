abstract class MobileDataLocal {}

class MobileDataLocalImpl implements MobileDataLocal {}
