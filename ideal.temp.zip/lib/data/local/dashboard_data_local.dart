abstract class DashboardDataLocal {}

class DashboardDataLocalImpl implements DashboardDataLocal {}
