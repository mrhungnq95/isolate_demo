import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';
import 'package:MShopManager/service/storage/local_storage.dart';

abstract class FilterSettingDataLocal {
  T getFilterSettings<T>(EFilterViewModelKey filterKey);
  void saveFilterSettings(EFilterViewModelKey filterKey, dynamic data);

  ///
  /// Lấy cache Tổng quan
  ///
  OverViewFilterSettings getOverViewFilterSettings();

  ///
  /// Cất cache Tổng quan xuống cache
  ///
  void saveOverViewFilterSettings(OverViewFilterSettings data);
}

class FilterSettingDataLocalImpl implements FilterSettingDataLocal {
  final LocalStorage _localStorage;

  FilterSettingDataLocalImpl(this._localStorage);

  @override
  T getFilterSettings<T>(EFilterViewModelKey filterKey) {
    switch (filterKey) {
      case EFilterViewModelKey.overview:
        return _localStorage.getOverViewFilterSettings();
      case EFilterViewModelKey.revenue:
        return _localStorage.getRevenueFilterSettings();
      case EFilterViewModelKey.inventoryItem:
        return _localStorage.getListInventoryItemFilterSetting();
      case EFilterViewModelKey.listInvoice:
        return _localStorage.getListInvoiceFilterSetting();
      case EFilterViewModelKey.customer:
        return _localStorage.getCustomerListFilterSettings();
      case EFilterViewModelKey.customer_transaction_history:
        return _localStorage.getCustomerTransactionHistoryFilterSettings();
      case EFilterViewModelKey.listVendor:
        return _localStorage.getListVendorFilterSettings();
      case EFilterViewModelKey.listItemNoteReceipt:
        return _localStorage.getItemReceiptNoteFilterSettings();
      case EFilterViewModelKey.debtCustomer:
        return _localStorage.getListDebtCustomerFilterSetting();
      case EFilterViewModelKey.overview_chain:
        return _localStorage.getOverViewChainFilterSettings();
        break;
    }
    return null;
  }

  @override
  void saveFilterSettings(EFilterViewModelKey filterKey, dynamic data) {
    switch (filterKey) {
      case EFilterViewModelKey.overview:
        _localStorage.saveOverViewFilterSettings(data);
        break;
      case EFilterViewModelKey.revenue:
        _localStorage.saveRevenueFilterSettings(data);
        break;
      case EFilterViewModelKey.listVendor:
        _localStorage.saveListVendorFilterSettings(data);
        break;
      case EFilterViewModelKey.listItemNoteReceipt:
        _localStorage.saveItemReceiptNoteFilterSettings(data);
        break;
      case EFilterViewModelKey.inventoryItem:
        _localStorage.saveListInventoryItemFilterSetting(data);
        break;
      case EFilterViewModelKey.customer:
        _localStorage.saveCustomerListFilterSettings(data);
        break;
      case EFilterViewModelKey.customer_transaction_history:
        _localStorage.saveCustomerTransactionHistoryFilterSettings(data);
        break;
      case EFilterViewModelKey.listInvoice:
        _localStorage.saveListInvoiceFilterSetting(data);
        break;
      case EFilterViewModelKey.debtCustomer:
        _localStorage.saveListDebtCustomerFilterSetting(data);
        break;
      case EFilterViewModelKey.overview_chain:
        _localStorage.saveOverViewChainFilterSettings(data);
        break;
    }
  }

  @override
  OverViewFilterSettings getOverViewFilterSettings() {
    return _localStorage.getOverViewFilterSettings();
  }

  @override
  void saveOverViewFilterSettings(OverViewFilterSettings data) {
    return _localStorage.saveOverViewFilterSettings(data);
  }
}
