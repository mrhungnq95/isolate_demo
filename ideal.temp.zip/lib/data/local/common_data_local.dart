import 'dart:convert';

import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/model/location_client.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/utils/file_utils.dart';

abstract class CommonDataLocal {
  ///
  /// Lấy company code
  ///
  String getBranchCode();

  ///
  /// Lấy đuôi tên miền của nhà hàng
  /// VD: longnhishopacc.mshopkepper.vn => mshopkepper.vn
  ///
  String getSubDomain();

  ///
  /// Load dữ liệu tỉnh thành phố, quận huyện
  ///
  Future<List<LocationClient>> loadLocationVN();

  ///
  /// Lấy DS DBOption
  ///
  List<DBOption> getDBOptionList();

  ///
  /// Lưu DS thông tin Phường xã
  /// [wardList] DS object thông tin phường xã cần lưu
  ///
  void saveWardLocationList(List<LocationClient> wardList);

  ///
  /// Lưu DS thông tin object: Thành phố - Quần huyện
  ///
  void saveDistrictMergeList(List<LocationClientMerge> districtList);

  ///
  /// Lấy DS thông tin Phường xã
  ///
  List<LocationClient> getWardLocationList();

  ///
  /// Lấy DS thông tin Tỉnh, Thành phố - Quận, huyện
  ///
  List<LocationClientMerge> getDistrictMergeList();

  ///
  /// Lưu lối tắt các chức năng người dùng đã chọn
  ///
  void saveQuickActionItemListByUser(String actionList);

  ///
  /// Lấy DS lối tắt các chức năng người dùng đã chọn
  ///
  Future<String> getQuickActionItemListByUser();
}

class CommonDataLocalImpl implements CommonDataLocal {
  final LocalStorage _localStorage;

  CommonDataLocalImpl(this._localStorage);

  @override
  List<DBOption> getDBOptionList() {
    return _localStorage.getDBOptionList();
  }

  @override
  Future<List<LocationClient>> loadLocationVN() async {
    /// Tạm thời dùng static, sau sẽ inject qua constructor
    final result = FileUtils.readFile("vn_location").then<List<LocationClient>>(
        (value) => jsonDecode(value)
            ?.map<LocationClient>((x) => LocationClient.fromMap(x))
            ?.toList());

    return Future.value(result);
  }

  @override
  void saveDistrictMergeList(List<LocationClientMerge> districtList) {
    return _localStorage.saveDistrictMergeList(districtList);
  }

  @override
  void saveWardLocationList(List<LocationClient> wardList) {
    return _localStorage.saveWardLocationList(wardList);
  }

  @override
  List<LocationClientMerge> getDistrictMergeList() {
    return _localStorage.getDistrictMergeList();
  }

  @override
  List<LocationClient> getWardLocationList() {
    return _localStorage.getWardLocationList();
  }

  @override
  Future<String> getQuickActionItemListByUser() {
    return Future.value(_localStorage.getQuickActionItemListByUser());
  }

  @override
  void saveQuickActionItemListByUser(String actionList) {
    return _localStorage.saveQuickActionItemListByUser(actionList);
  }

  @override
  String getBranchCode() {
    return _localStorage.getBranchCode();
  }

  @override
  String getSubDomain() {
    return _localStorage.getSubDomain();
  }
}
