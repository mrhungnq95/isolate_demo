import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/data/local/common_data_local.dart';
import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/model/location_client.dart';

abstract class CommonDataRepository {
  ///
  /// Lấy company code
  ///
  String getBranchCode();

  ///
  /// Lấy đuôi tên miền của nhà hàng
  /// VD: longnhishopacc.mshopkepper.vn => mshopkepper.vn
  ///
  String getSubDomain();

  ///
  /// Lấy DS DBOption
  ///
  List<DBOption> getDBOptionList();

  ///
  /// Lấy DS các tỉnh thành, khu vực của VN
  ///
  Future<MSBaseResult<List<LocationClient>>> loadLocationVNList();

  ///
  /// Lưu DS thông tin Phường xã
  /// [wardList] DS object thông tin phường xã cần lưu
  ///
  void saveWardLocationList(List<LocationClient> wardList);

  ///
  /// Lưu DS thông tin object: Thành phố - Quần huyện
  ///
  void saveDistrictMergeList(List<LocationClientMerge> districtList);

  ///
  /// Lấy DS thông tin Phường xã
  ///
  List<LocationClient> getWardLocationList();

  ///
  /// Lấy DS thông tin Tỉnh, Thành phố - Quận, huyện
  ///
  List<LocationClientMerge> getDistrictMergeList();

  ///
  /// Lưu lối tắt các chức năng người dùng đã chọn
  ///
  void saveQuickActionItemListByUser(String actionList);

  ///
  /// Lấy DS lối tắt các chức năng người dùng đã chọn
  ///
  Future<String> getQuickActionItemListByUser();
}

class CommonDataRepositoryImpl extends MSBaseRepository
    implements CommonDataRepository {
  final CommonDataLocal _commonDataLocal;

  CommonDataRepositoryImpl(this._commonDataLocal);

  @override
  List<DBOption> getDBOptionList() {
    return _commonDataLocal.getDBOptionList();
  }

  @override
  Future<MSBaseResult<List<LocationClient>>> loadLocationVNList() {
    return _commonDataLocal
        .loadLocationVN()
        .then(
            (value) => MSBaseResult<List<LocationClient>>.success(data: value))
        .catchError((e) {
      print(e);
      return MSBaseResult<List<LocationClient>>.commonError(error: e);
    });
  }

  @override
  void saveDistrictMergeList(List<LocationClientMerge> districtList) {
    return _commonDataLocal.saveDistrictMergeList(districtList);
  }

  @override
  void saveWardLocationList(List<LocationClient> wardList) {
    return _commonDataLocal.saveWardLocationList(wardList);
  }

  @override
  List<LocationClientMerge> getDistrictMergeList() {
    return _commonDataLocal.getDistrictMergeList();
  }

  @override
  List<LocationClient> getWardLocationList() {
    return _commonDataLocal.getWardLocationList();
  }

  @override
  Future<String> getQuickActionItemListByUser() {
    return _commonDataLocal.getQuickActionItemListByUser();
  }

  @override
  void saveQuickActionItemListByUser(String actionList) {
    _commonDataLocal.saveQuickActionItemListByUser(actionList);
  }

  @override
  String getBranchCode() {
    return _commonDataLocal.getBranchCode();
  }

  @override
  String getSubDomain() {
    return _commonDataLocal.getSubDomain();
  }
}
