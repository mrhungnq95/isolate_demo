import 'dart:io';

import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/error_result.dart';
import 'package:MShopManager/model/service/login_error_response.dart';
import 'package:MShopManager/model/service/login_response.dart';
import 'package:MShopManager/service/api/impl/authenticate_api_client.dart';
import 'package:dio/dio.dart';

abstract class AuthRepository {
  ///
  ///  Đăng nhập hệ thống
  /// [companyCode] mã cửa hàng
  /// [userName]  user name
  /// [password]  password
  ///
  Future<ApiResult<LoginResponse>> login(
      String companyCode, String userName, String password);
}

class AuthRepositoryImpl extends MSBaseRepository implements AuthRepository {
  AuthenticateAPIClient authClient;

  AuthRepositoryImpl({
    this.authClient,
  });

  @override
  Future<ApiResult<LoginResponse>> login(
      String companyCode, String userName, String password) async {
    try {
      final response = await authClient.login(companyCode, userName, password);

      final loginResponse = LoginResponse.fromMap(response);
      if (loginResponse != null) {
        return ApiResult<LoginResponse>.success(data: loginResponse);
      } else {
        return ApiResult<LoginResponse>.failure(
            error: NetworkExceptions.unexpectedError());
      }
    } catch (e) {
      if (e is DioError) {
        final response = e.response;
        if (response?.statusCode == HttpStatus.badRequest) {
          LoginErrorResponse loginErrorResponse;
          if (response?.data is Map<String, dynamic>) {
            loginErrorResponse = LoginErrorResponse.fromMap(response?.data);
          } else {
            loginErrorResponse = LoginErrorResponse(
                error: "Invalid_CompanyCode", errorDescription: response?.data);
          }

          return ApiResult<LoginResponse>.failure(
              errorData: ErrorData(
                  statusCode: response?.statusCode, data: loginErrorResponse),
              error: NetworkExceptions.getDioException(e));
        }
      }
      return ApiResult<LoginResponse>.failure(
          error: NetworkExceptions.getDioException(e));
    }
  }
}
