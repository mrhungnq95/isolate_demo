import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/inventory_item_category_data_remote.dart';
import 'package:MShopManager/model/inventory_item/inventory_item_category.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_category_param.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_response.dart';
import 'package:flutter/material.dart';

abstract class InventoryItemCategoryRepository {
  ///
  /// Lấy danh sách Category hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 13/01/2021
  ///
  Future<MSBaseResult<List<InventoryItemCategory>>> getListInventoryItemCategory(
      GetListInventoryItemCategoryParam param);
}

class InventoryItemCategoryRepositoryImp extends MSBaseRepository
    implements InventoryItemCategoryRepository {
  final InventoryItemCategoryDataRemote inventoryItemDataRemote;

  InventoryItemCategoryRepositoryImp({@required this.inventoryItemDataRemote});

  @override
  Future<MSBaseResult<List<InventoryItemCategory>>> getListInventoryItemCategory(
      GetListInventoryItemCategoryParam param) async {
    return await inventoryItemDataRemote.getListInventroyItemCategory(param).then((value) {
      return value.when<MSBaseResult<List<InventoryItemCategory>>>(
          success: (dataResponse) {
        return MSBaseResult<List<InventoryItemCategory>>.success(
            data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<List<InventoryItemCategory>>.commonError(
            error: null);
      });
    }).catchError((e) {
      return MSBaseResult<GetListInventoryItemResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
