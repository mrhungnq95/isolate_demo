import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/dboption_data_remote.dart';
import 'package:MShopManager/model/dboption.dart';

abstract class DBOptionRepository {
  ///
  /// Lấy DBOption theo [branchId]
  ///
  Future<MSBaseResult<List<DBOption>>> getDBOptionByBranchID(String branchId);
}

class DBOptionRepositoryImpl extends MSBaseRepository
    implements DBOptionRepository {
  DBOptionDataRemote dbOptionDataRemote;

  DBOptionRepositoryImpl({
    this.dbOptionDataRemote,
  });

  @override
  Future<MSBaseResult<List<DBOption>>> getDBOptionByBranchID(
      String branchId) async {
    return await dbOptionDataRemote
        .getDBOptionByBranchID(branchId)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<List<DBOption>>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<DBOption>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<List<DBOption>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
