import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/unit_data_remote.dart';
import 'package:MShopManager/enums/enum_edit_mode.dart';
import 'package:MShopManager/model/unit/unit.dart';
import 'package:flutter/material.dart';

abstract class UnitRepository {
  ///
  /// Lấy danh sách đơn vị tính hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 13/01/2021
  ///
  Future<MSBaseResult<List<Unit>>> getListUnit(
      EditMode editMode);
}

class UnitRepositoryImp extends MSBaseRepository
    implements UnitRepository {
  final UnitDataRemote unitDataRemote;

  UnitRepositoryImp({@required this.unitDataRemote});

  @override
  Future<MSBaseResult<List<Unit>>> getListUnit(
      EditMode editMode) async {
    return await unitDataRemote.getListUnit(editMode).then((value) {
      return value.when<MSBaseResult<List<Unit>>>(
          success: (dataResponse) {
        return MSBaseResult<List<Unit>>.success(
            data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<List<Unit>>.commonError(
            error: null);
      });
    }).catchError((e) {
      return MSBaseResult<List<Unit>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
