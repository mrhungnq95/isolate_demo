import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/pu_invoice_data_remote.dart';
import 'package:MShopManager/model/pu_invoice/pu_invoice.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/ms_base_service_output_master_data.dart';
import 'package:MShopManager/model/service/pu_invoice_arisen_response.dart';
import 'package:MShopManager/model/service/request/check_item_receipt_note_arisen_param.dart';
import 'package:MShopManager/model/service/request/delete_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/delete_vendor_param.dart';
import 'package:MShopManager/model/service/request/get_detail_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/get_list_item_receipt_note_param.dart';
import 'package:MShopManager/model/service/request/get_list_vendor_param.dart';
import 'package:MShopManager/model/service/request/get_new_ref_no_param.dart';
import 'package:MShopManager/model/service/request/save_item_receipt_note_param.dart';
import 'package:MShopManager/model/vendor.dart';
import 'package:MShopManager/model/vendor_category.dart';

abstract class PUInvoiceRepository {
  ///
  /// Lấy danh sách nhà cung cấp
  /// [param] obj GetRolesPermissionParam
  ///
  Future<MSBaseResult<List<Vendor>>> getListVendor(GetListVendorParam param);
  
  ///
  /// Lưu nhà cung cấp
  /// [param] NCC
  ///
  Future<MSBaseResult<MSOutputService>> saveVendor(Vendor param);

  ///
  /// xoá nhà cung cấp
  /// [param] danh sách NCC cần xoá
  ///
  Future<MSBaseResult<MSOutputService>> deleteVendors(DeleteVendorParam param);

  ///
  /// Lấy danh sách nhóm nhà cung cấp
  ///
  Future<MSBaseResult<List<VendorCategory>>> getListVendorCategory();

  ///
  /// Thêm nhóm nhà cung cấp
  /// [param] obj nhóm nhà cung cấp
  ///
  Future<MSBaseResult<MSOutputServiceMasterData<VendorCategory>>> addVendorCategory(VendorCategory param);


  // region ---------------------- API Nhập hàng ------------------------------
  ///
  /// Lấy số phiếu nhập hàng mới nhất
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService<String>>> getNewRefNoByRefType(GetNewRefNoParam param);


  ///
  /// Lấy chi tiết phiếu nhập hàng
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService<PUInvoice>>> getDetailItemReceiptNote(GetDetailItemReceiptNoteParam param);


  ///
  /// Lấy danh sách phiếu nhập hàng
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService<PUInvoice>>> getListItemReceiptNote(GetListItemReceiptNoteParam param);

  ///
  /// Lưu phiếu nhập hàng
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService>> saveItemReceiptNote(SaveItemReceiptNoteParam param);

  ///
  /// Xoá phiếu nhập hàng
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService>> deleteItemReceiptNote(DeleteItemReceiptNoteParam param);

  ///
  /// Kiểm tra chứng từ đã phát sinh hay chưa
  /// [param] param
  ///
  Future<MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>> checkItemReceiptNoteIsArisen(CheckItemReceiptNoteIsArisenParam param);

// endregion
}

class PUInvoiceRepositoryImpl extends MSBaseRepository implements PUInvoiceRepository {
  final PUInvoiceDataRemote remote;

  PUInvoiceRepositoryImpl(this.remote);

  @override
  Future<MSBaseResult<List<Vendor>>> getListVendor(GetListVendorParam param) async {
    return await remote
        .getListVendor(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<List<Vendor>>>(success: (dataResponse) {
        return MSBaseResult<List<Vendor>>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<Vendor>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<List<Vendor>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService>> saveVendor(Vendor param) async {
    return await remote
        .saveVendor(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService>> deleteVendors(DeleteVendorParam param) async {
    return await remote
        .deleteVendors(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<List<VendorCategory>>> getListVendorCategory() async {
    return await remote
        .getListVendorCategory()
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<List<VendorCategory>>>(success: (dataResponse) {
        return MSBaseResult<List<VendorCategory>>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<VendorCategory>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<List<VendorCategory>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputServiceMasterData<VendorCategory>>> addVendorCategory(VendorCategory param) async {
    return await remote
        .addVendorCategory(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputServiceMasterData<VendorCategory>>>(success: (dataResponse) {
        return MSBaseResult<MSOutputServiceMasterData<VendorCategory>>.success(data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputServiceMasterData<VendorCategory>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputServiceMasterData<VendorCategory>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService>> deleteItemReceiptNote(DeleteItemReceiptNoteParam param) async {
    return await remote
        .deleteItemReceiptNote(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<PUInvoice>>> getListItemReceiptNote(GetListItemReceiptNoteParam param) async {
    return await remote
        .getListItemReceiptNote(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService<PUInvoice>>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService<PUInvoice>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<PUInvoice>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService<PUInvoice>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<String>>> getNewRefNoByRefType(GetNewRefNoParam param) async {
    return await remote
        .getNewRefNoByRefType(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService<String>>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService<String>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<String>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService<String>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService>> saveItemReceiptNote(SaveItemReceiptNoteParam param) async {
    return await remote
        .saveItemReceiptNote(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<PUInvoice>>> getDetailItemReceiptNote(GetDetailItemReceiptNoteParam param) {
    return remote
        .getDetailItemReceiptNote(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService<PUInvoice>>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService<PUInvoice>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<PUInvoice>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService<PUInvoice>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>> checkItemReceiptNoteIsArisen(CheckItemReceiptNoteIsArisenParam param) async {
    return await remote
        .checkItemReceiptNoteIsArisen(param)
        .then((dataResponse) {
      return dataResponse.when<MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>>(success: (dataResponse) {
        return MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>.apiError(error: error);
      });
    }).catchError((e) {
      print(e);
      return MSBaseResult<MSOutputService<PUInvoiceArisenResponse>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

}
