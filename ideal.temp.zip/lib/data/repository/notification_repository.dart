import 'package:MShopManager/base/service/api_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/model/service/get_notification_param.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/service/api/impl/notification_api_client.dart';

abstract class NotificationRepository {

}

class NotificationRepositoryImpl extends NotificationRepository {
  // NotificationAPIClient apiClient;

  // NotificationRepositoryImpl({
  //   this.apiClient,
  // });


}
