import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/inventory_item_data_remote.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_param.dart';
import 'package:MShopManager/model/service/get_list_inventory_items_response.dart';
import 'package:flutter/material.dart';

abstract class InventoryItemRepository {
  ///
  /// Lấy danh sách hàng hóa
  /// [param] Tham số truyền vào service
  /// VNLONG - 13/01/2021
  ///
  Future<MSBaseResult<GetListInventoryItemResponse>> getListInventoryItem(
      GetListInventoryItemParam param);
}

class InventoryItemRepositoryImp extends MSBaseRepository
    implements InventoryItemRepository {
  final InventoryItemDataRemote inventoryItemDataRemote;

  InventoryItemRepositoryImp({@required this.inventoryItemDataRemote});

  @override
  Future<MSBaseResult<GetListInventoryItemResponse>> getListInventoryItem(
      GetListInventoryItemParam param) async {
    return await inventoryItemDataRemote.getListInventroyItem(param).then((value) {
      return value.when<MSBaseResult<GetListInventoryItemResponse>>(
          success: (dataResponse) {
        return MSBaseResult<GetListInventoryItemResponse>.success(
            data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<GetListInventoryItemResponse>.commonError(
            error: null);
      });
    }).catchError((e) {
      return MSBaseResult<GetListInventoryItemResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
