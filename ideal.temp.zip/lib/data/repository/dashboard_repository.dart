import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/dashboard_data_remote.dart';
import 'package:MShopManager/model/business_status/business_status_info.dart';
import 'package:MShopManager/model/overview/revenue_for_time_display_item.dart';
import 'package:MShopManager/model/service/get_detail_invoice_response.dart';
import 'package:MShopManager/model/service/get_list_debt_response.dart';
import 'package:MShopManager/model/service/request/get_business_status_param.dart';
import 'package:MShopManager/model/service/request/get_debt_report_param.dart';
import 'package:MShopManager/model/service/request/revenue_for_inventory_item_param.dart';
import 'package:MShopManager/model/service/request/revenue_setting_dashboard_param.dart';
import 'package:flutter/foundation.dart';
import 'package:MShopManager/model/service/revenue_by_items_info.dart';

abstract class DashboardRepository {
  ///
  /// Lấy báo cáo Tổng quát
  /// [param] object [DrawDashboarForMobileParam] lưu thông tin request
  ///
  Future<MSBaseResult<List<RevenueForTimeDisplayItem>>>
      fetchRevenueReportByTime(RevenueSettingDashboardParam param);

  ///
  /// Lấy báo cáo Doanh thu theo mặt hàng
  /// [param] object [RevenueForInventoryItemParam] lưu thông tin request
  ///
  Future<MSBaseResult<RevenueByItemsInfo>> fetchRevenueReportByInventory(
      RevenueForInventoryItemParam param);

  //
  /// Lấy chi tiết hóa đơn
  ///
  Future<MSBaseResult<GetDetailInvoiceResponse>> getDetailInvoice(
      {String refId});

  ///
  /// Lấy danh sách công nợ khách hàng
  /// [param]: Tham số truyền vào
  ///
  Future<MSBaseResult<GetListDebtResponse>> getListDebt(
      {GetDebtReportParam param});

  /// 
  /// Lấy thông tin tình hình kinh doanh
  /// [param]: Tham số lấy báo cáo
  /// 
  Future<MSBaseResult<List<BusinessStatusInfo>>> getBusinessStatus(
      {GetBusinessStatusParam param});
}

class DashboardRepositoryImpl extends MSBaseRepository
    implements DashboardRepository {
  final DashboardDataRemote dashboardDataRemote;

  DashboardRepositoryImpl({@required this.dashboardDataRemote});

  @override
  Future<MSBaseResult<List<RevenueForTimeDisplayItem>>>
      fetchRevenueReportByTime(RevenueSettingDashboardParam param) async {
    /// Sau dùng cache báo cáo sẽ case trạng thái mạng ở đây để dùng
    /// Data remote hoặc Data local (nếu cần)
    return await dashboardDataRemote
        .getRevenueReportByTime(param)
        .then((value) {
      return value.when<MSBaseResult<List<RevenueForTimeDisplayItem>>>(
          success: (dataResponse) {
        return MSBaseResult<List<RevenueForTimeDisplayItem>>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<RevenueForTimeDisplayItem>>.commonError(
            error: null);
      });
    }).catchError((e) {
      return MSBaseResult<List<RevenueForTimeDisplayItem>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<GetDetailInvoiceResponse>> getDetailInvoice(
      {String refId}) async {
    return await dashboardDataRemote
        .getDetailInvoice(refId)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<GetDetailInvoiceResponse>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<GetDetailInvoiceResponse>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<GetDetailInvoiceResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<RevenueByItemsInfo>> fetchRevenueReportByInventory(
      RevenueForInventoryItemParam param) async {
    /// Sau dùng cache báo cáo sẽ case trạng thái mạng ở đây để dùng
    /// Data remote hoặc Data local (nếu cần)
    return await dashboardDataRemote
        .getRevenueReportByInventory(param)
        .then((value) {
      return value.when<MSBaseResult<RevenueByItemsInfo>>(
          success: (dataResponse) {
        return MSBaseResult<RevenueByItemsInfo>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<RevenueByItemsInfo>.commonError(error: null);
      });
    }).catchError((e) {
      return MSBaseResult<RevenueByItemsInfo>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<GetListDebtResponse>> getListDebt(
      {GetDebtReportParam param}) async {
    return await dashboardDataRemote.getDebtReport(param).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<GetListDebtResponse>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<GetListDebtResponse>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<GetListDebtResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<List<BusinessStatusInfo>>> getBusinessStatus({GetBusinessStatusParam param}) async {
    return await dashboardDataRemote.getBusinessStatus(param).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<List<BusinessStatusInfo>>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<BusinessStatusInfo>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<List<BusinessStatusInfo>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
