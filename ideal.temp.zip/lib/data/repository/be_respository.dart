import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/data/remote/be_data_remote.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/model/base/customer_category_base.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/response/add_customer_response.dart';

abstract class BeRepository {
  ///
  /// Thêm khách hàng
  /// [customer] obj KH muốn thêm
  ///
  Future<MSBaseResult<MSOutputService<AddCustomerResponseData>>> addCustomer(
      Customer customer);

  ///
  /// Lấy nhóm khách hàng
  /// [keySearch] nội dung cần searhc
  /// [pageIndex] vị trí của page đang lấy dữ liệu
  /// [pageSize] tổng số page cần lấy
  ///
  Future<MSBaseResult<List<CustomerCategory>>> fetchListCustomerCategory(
    String keySearch,
    int pageIndex,
    int pageSize,
  );

  ///
  /// Sửa khách hàng
  /// [customer] obj KH cần sửa
  ///
  Future<MSBaseResult<MSOutputService<bool>>> editCustomer(Customer customer);

  ///
  /// Xoá khách hàng
  /// [customerId] id của KH
  ///
  Future<MSBaseResult<MSOutputService<bool>>> deleteCustomer(String customerId);
}

class BeRepositoryImpl extends BeRepository {
  BeDataRemote beDataRemote;
  BeRepositoryImpl({
    this.beDataRemote,
  });

  @override
  Future<MSBaseResult<MSOutputService<AddCustomerResponseData>>> addCustomer(
      Customer customer) {
    return beDataRemote.addCustomer(customer).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        if (dataResponse?.hasData() == true) {
          return MSBaseResult<MSOutputService<AddCustomerResponseData>>.success(
              data: dataResponse);
        } else {
          return MSBaseResult<
                  MSOutputService<AddCustomerResponseData>>.apiError(
              error: NetworkExceptions.unexpectedError());
        }
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<AddCustomerResponseData>>.apiError(
            error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<AddCustomerResponseData>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<bool>>> deleteCustomer(
      String customerId) {
    return beDataRemote.deleteCustomer(customerId).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<MSOutputService<bool>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<bool>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<bool>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<bool>>> editCustomer(Customer customer) {
    return beDataRemote.editCustomer(customer).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<MSOutputService<bool>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<bool>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<bool>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<List<CustomerCategory>>> fetchListCustomerCategory(
      String keySearch, int pageIndex, int pageSize) {
    return beDataRemote
        .fetchListCustomerCategory(keySearch, pageIndex, pageSize)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        if (dataResponse?.hasData() == true) {
          return MSBaseResult<List<CustomerCategory>>.success(
              data: dataResponse.first().data?.data);
        } else {
          return MSBaseResult<List<CustomerCategory>>.apiError(
              error: NetworkExceptions.unexpectedError());
        }
      }, failure: (errorData, error) {
        return MSBaseResult<List<CustomerCategory>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<List<CustomerCategory>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
