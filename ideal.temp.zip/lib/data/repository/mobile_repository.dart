import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/base/repository/ms_base_result.dart';
import 'package:MShopManager/base/service/network_exceptions.dart';
import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/model/service/get_list_invoice_param.dart';
import 'package:MShopManager/model/service/get_list_invoice_response.dart';
import 'package:MShopManager/model/service/get_notification_param.dart';
import 'package:MShopManager/model/service/get_notification_config_param.dart';
import 'package:MShopManager/model/service/get_notification_config_response.dart';
import 'package:MShopManager/data/local/mobile_data_local.dart';
import 'package:MShopManager/data/remote/mobile_data_remote.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/model/overview/report_daily_item.dart';
import 'package:MShopManager/model/service/get_roles_permission_param.dart';
import 'package:MShopManager/model/service/get_roles_permission_response.dart';
import 'package:MShopManager/model/service/ms_base_service_output.dart';
import 'package:MShopManager/model/service/request/validate_serial_imei_param.dart';
import 'package:MShopManager/model/service/request/list_order_for_customer_param.dart';
import 'package:MShopManager/model/service/set_notification_readed_param.dart';
import 'package:MShopManager/model/service/request/get_customer_paging_param.dart';
import 'package:MShopManager/model/service/update_notification_config_param.dart';
import 'package:MShopManager/model/service/request/draw_dashboar_for_mobile_param.dart';
import 'package:MShopManager/model/service/request/get_customer_dashboard_param.dart';
import 'package:MShopManager/model/service/validate_serial_emei_error.dart';

abstract class MobileRepository {
  ///
  /// Lấy Role Permission
  /// [param] obj GetRolesPermissionParam
  ///
  Future<MSBaseResult<GetRolesPermissionResponse>> getRolesPermission(
      GetRolesPermissionParam param);

  ///
  /// Lấy ds thông báo
  /// [param] obj ListNofiticationParam
  ///
  Future<MSBaseResult<List<NotificationItem>>> getListNotification(
      ListNofiticationParam param);

  ///
  /// lấy thiết lập thông báo của thiết bị
  /// [param] obj GetNotificationConfigParam
  ///
  Future<MSBaseResult<GetNotificationConfigResponse>> getNotificationConfig(
      GetNotificationConfigParam param);

  ///
  /// Cập nhật các thông tin thông báo
  /// [param] obj ListNofiticationParam
  ///
  Future<MSBaseResult<MSOutputService>> updateNotificationConfig(
      UpdateNotificationConfigParam param);

  ///
  /// Lưu trạng thái đã đọc cho item thông báo
  /// VNLONG - 30/12/2020
  ///
  Future<MSBaseResult<bool>> setNotificationReaded(
      SetNotificationReadedParam param);

  ///
  /// Lấy danh sách hóa đơn
  /// VNLONG - 31/12/2020
  ///
  Future<MSBaseResult<GetListInvoiceResponse>> getListInvoice(
      GetListInvoiceParam param);

  ///
  /// Lấy báo cáo Tổng quát
  /// [param] object [DrawDashboarForMobileParam] lưu thông tin request
  ///
  Future<MSBaseResult<List<ReportDailyItem>>> getDrawDashboardReport(
      DrawDashboarForMobileParam param);

  ///
  /// Lấy DS KH Tổng quan
  /// [param] object [GetCustomerDashboardParam] lưu thông tin request
  ///
  Future<MSBaseResult<MSOutputService<Customer>>> getCustomerListDashboard(
      GetCustomerDashboardParam param);


  ///
  /// Kiểm tra SerialIMEI của hàng hóa có thoả mãn hay không?
  /// [param] ds hàng hoá cần validate
  ///
  Future<MSBaseResult<MSOutputService<ValidateSerialIMEIError>>> validateSerialIMEI(ValidateSerialIMEIParam param);


  ///
  /// Lấy DS KH Tổng quan
  /// [param] object [GetCustomerPagingParam] lưu thông tin request
  ///
  Future<MSBaseResult<MSOutputService<Customer>>> getCustomerListPaging(
      GetCustomerPagingParam param);

  ///
  /// Lấy chi tiết của KH
  /// [customerId] id của Khách hàng
  ///
  Future<MSBaseResult<Customer>> getCustomerDetailById(String customerId);

  /// Lấy hoá đơn theo Khách hàng
  /// [param] object [GetOrderForCustomerParam]  thông tin param cho request
  ///
  Future<MSBaseResult<MSOutputService<SAInvoice>>> fetchSaleHistoryMobilePaging(
      GetOrderForCustomerParam param);
}

class MobileRepositoryImpl extends MSBaseRepository
    implements MobileRepository {
  final MobileDataRemote mobileDataRemote;
  final MobileDataLocal mobileDataLocal;

  MobileRepositoryImpl({
    this.mobileDataRemote,
    this.mobileDataLocal,
  });

  @override
  Future<MSBaseResult<List<ReportDailyItem>>> getDrawDashboardReport(
      DrawDashboarForMobileParam param) async {
    try {
      /// Sau dùng cache báo cáo sẽ case trạng thái mạng ở đây để dùng
      /// Data remote hoặc Data local (nếu cần)

      return await mobileDataRemote
          .fetchDrawDashboardReport(param)
          .then((dataResponse) {
        return dataResponse.when<MSBaseResult<List<ReportDailyItem>>>(
            success: (dataResponse) {
          return MSBaseResult<List<ReportDailyItem>>.success(
              data: dataResponse ?? []);
        }, failure: (errorData, error) {
          return MSBaseResult<List<ReportDailyItem>>.apiError(error: error);
        });
      }).catchError((e) {
        return MSBaseResult<List<ReportDailyItem>>.apiError(
            error: NetworkExceptions.getDioException(e));
      });

      // final fetchData = await mobileDataRemote.getDrawDashboardReport(param);
      // return fetchData.map(success: (dataResponse) {
      //   return MSBaseResult.success(data: dataResponse?.data ?? []);
      // }, failure: (e) {
      //   return MSBaseResult.apiError(
      //       error: NetworkExceptions.unexpectedError());
      // });
    } catch (e) {
      return MSBaseResult.apiError(error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<MSBaseResult<GetRolesPermissionResponse>> getRolesPermission(
      GetRolesPermissionParam param) async {
    try {
      final dataResponse = await mobileDataRemote.fetchRolesPermission(param);
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<GetRolesPermissionResponse>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<GetRolesPermissionResponse>.apiError(error: error);
      });
    } catch (e) {
      return MSBaseResult<GetRolesPermissionResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<MSBaseResult<List<NotificationItem>>> getListNotification(
      ListNofiticationParam param) async {
    try {
      final response = await mobileDataRemote.getListNotification(param);

      return response.when(success: (dataResponse) {
        return MSBaseResult<List<NotificationItem>>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<List<NotificationItem>>.apiError(error: error);
      });
    } catch (e) {
      return MSBaseResult<List<NotificationItem>>.apiError(
          error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<MSBaseResult<GetNotificationConfigResponse>> getNotificationConfig(
      GetNotificationConfigParam param) async {
    try {
      final response = await mobileDataRemote.getNotificationConfig(param);

      return response.when(success: (dataResponse) {
        return MSBaseResult<GetNotificationConfigResponse>.success(
            data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<GetNotificationConfigResponse>.apiError(
            error: error);
      });
    } catch (e) {
      return MSBaseResult<GetNotificationConfigResponse>.apiError(
          error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<MSBaseResult<MSOutputService>> updateNotificationConfig(
      UpdateNotificationConfigParam param) async {
    try {
      final response = await mobileDataRemote.updateNotificationConfig(param);

      return response.when(success: (response) {
        return MSBaseResult<MSOutputService>.success(data: response ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService>.apiError(error: error);
      });
    } catch (e) {
      return MSBaseResult<MSOutputService>.apiError(
          error: NetworkExceptions.getDioException(e));
    }
  }

  @override
  Future<MSBaseResult<MSOutputService<Customer>>> getCustomerListDashboard(
      GetCustomerDashboardParam param) async {
    return await mobileDataRemote
        .fetchCustomerListDashboard(param)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<MSOutputService<Customer>>.success(
            data: dataResponse ?? []);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<Customer>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<Customer>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<ValidateSerialIMEIError>>> validateSerialIMEI(ValidateSerialIMEIParam param) async {
    return await mobileDataRemote
        .validateSerialIMEI(param)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<MSOutputService<ValidateSerialIMEIError>>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<ValidateSerialIMEIError>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<ValidateSerialIMEIError>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<bool>> setNotificationReaded(
      SetNotificationReadedParam param) async {
    return await mobileDataRemote
        .setNotificationReaded(param)
        .then((dataResponse) {
      return dataResponse.when(success: (result) {
        return MSBaseResult<bool>.success(data: result.success ?? false);
      }, failure: (errorData, error) {
        return MSBaseResult<bool>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<Customer>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  Future<MSBaseResult<MSOutputService<Customer>>> getCustomerListPaging(
      GetCustomerPagingParam param) {
    return mobileDataRemote.fetchCustomerListPaging(param).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<MSOutputService<Customer>>.success(
            data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<Customer>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<Customer>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<GetListInvoiceResponse>> getListInvoice(
      GetListInvoiceParam param) async {
    return await mobileDataRemote.getListInvoice(param).then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<GetListInvoiceResponse>.success(data: dataResponse);
      }, failure: (errorData, error) {
        return MSBaseResult<GetListInvoiceResponse>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<Customer>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  Future<MSBaseResult<Customer>> getCustomerDetailById(String customerId) {
    return mobileDataRemote
        .fetchCustomerDetailById(customerId)
        .then((dataResponse) {
      return dataResponse.when(success: (dataResponse) {
        return MSBaseResult<Customer>.success(data: dataResponse?.first());
      }, failure: (errorData, error) {
        return MSBaseResult<Customer>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<Customer>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }

  @override
  Future<MSBaseResult<MSOutputService<SAInvoice>>> fetchSaleHistoryMobilePaging(
      GetOrderForCustomerParam param) {
    return mobileDataRemote
        .fetchSaleHistoryMobilePaging(param)
        .then((dataResponse) {
      return dataResponse.when(success: (data) {
        return MSBaseResult<MSOutputService<SAInvoice>>.success(data: data);
      }, failure: (errorData, error) {
        return MSBaseResult<MSOutputService<SAInvoice>>.apiError(error: error);
      });
    }).catchError((e) {
      return MSBaseResult<MSOutputService<SAInvoice>>.apiError(
          error: NetworkExceptions.getDioException(e));
    });
  }
}
