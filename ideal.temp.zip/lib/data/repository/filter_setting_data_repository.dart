import 'package:MShopManager/base/repository/ms_base_repository.dart';
import 'package:MShopManager/data/local/filter_setting_data_local.dart';
import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';

abstract class FilterSettingRepository {
  OverViewFilterSettings getOverViewFilterSettings();
  void saveOverViewFilterSettings(OverViewFilterSettings data);

  T getFilterSettings<T>(EFilterViewModelKey filterKey);
  void saveFilterSettings(EFilterViewModelKey filterKey, dynamic data);
}

class FilterSettingRepositoryImpl extends MSBaseRepository
    implements FilterSettingRepository {
  final FilterSettingDataLocal _filterSettingDataLocal;

  FilterSettingRepositoryImpl(this._filterSettingDataLocal);

  @override
  OverViewFilterSettings getOverViewFilterSettings() {
    return _filterSettingDataLocal.getOverViewFilterSettings();
  }

  @override
  void saveOverViewFilterSettings(OverViewFilterSettings data) {
    return _filterSettingDataLocal.saveOverViewFilterSettings(data);
  }

  @override
  T getFilterSettings<T>(EFilterViewModelKey filterKey) {
    return _filterSettingDataLocal.getFilterSettings(filterKey);
  }

  @override
  void saveFilterSettings(EFilterViewModelKey filterKey, dynamic data) {
    return _filterSettingDataLocal.saveFilterSettings(filterKey, data);
  }
}
