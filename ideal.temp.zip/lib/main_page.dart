//
// Created by nqhung on 06/11/2020.
//

import 'dart:async';

import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/widget/msview/ms_cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'package:rxdart/subjects.dart';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_nested_navigation.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/ms_tab_nested_navigation.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/bottomnav/floating_navbar.dart';
import 'package:MShopManager/widget/bottomnav/floating_navbar_item.dart';
import 'package:MShopManager/widget/msview/ms_circle_network_image.dart';

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class ScrollDataObs {
  double offset;
  ScrollPosition scrollPosition;

  ScrollDataObs({
    this.offset,
    this.scrollPosition,
  });
}

class MainPageViewModel extends MSBaseViewModel {
  int _currentIndex = 0;
  int get currentIndex => _currentIndex;

  BehaviorSubject<ScrollDataObs> scrollSubject =
      BehaviorSubject<ScrollDataObs>();

  StreamSubscription<ScrollDataObs> _scrollSubscription;

  bool isVisible = true;

  MainPageViewModel() {
    _scrollSubscription = scrollSubject.listen((scrollDataObs) {
      if (scrollDataObs.scrollPosition.userScrollDirection ==
          ScrollDirection.reverse) {
        if (isVisible) {
          isVisible = false;
          notifyListeners();
        }
      }
      if (scrollDataObs.scrollPosition.userScrollDirection ==
          ScrollDirection.forward) {
        if (!isVisible) {
          isVisible = true;
          notifyListeners();
        }
      }
    });
  }

  set currentIndex(int value) {
    _currentIndex = value;
    notifyListeners();
  }

  ///
  /// Đường dẫn url của avatar
  ///
  String getAvatarUrl() {
    final avatarId = UserCredential.currentSession.loginResponse?.avatar;
    return UrlHelper.shared.getUrlAvatar(
      avatarId: avatarId,
    );
  }

  @override
  void dispose() {
    _scrollSubscription?.cancel();
    scrollSubject?.close();
    super.dispose();
  }
}

class _MainPageState extends State<MainPage> {
  PageController _pageController =
      PageController(initialPage: 0, keepPage: true);

  _BottomNavigationBarController _bottomNavigationBarController =
      _BottomNavigationBarController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _pageController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => MainPageViewModel(),
      builder: (context, child) => _body(context),
    );
  }

  Widget _body(BuildContext contextRoot) {
    print("================ Scaffold RootPage ================");
    return Builder(builder: (context) {
      return Scaffold(
        backgroundColor: Colors.transparent,
        extendBody: true,
        //extendBodyBehindAppBar: true,
        body: PageView(
          controller: _pageController,
          scrollDirection: Axis.horizontal,
          physics: NeverScrollableScrollPhysics(),
          onPageChanged: (int index) {
            //context.read<MainPageViewModel>().currentIndex = index;
          },
          children: [
            TabNestedNavigation(tabItemType: ETabItemType.overview),
            TabNestedNavigation(tabItemType: ETabItemType.invoice),
            TabNestedNavigation(tabItemType: ETabItemType.report),
            TabNestedNavigation(tabItemType: ETabItemType.notification),
            TabNestedNavigation(tabItemType: ETabItemType.profile),
          ],
        ),
        bottomNavigationBar: _BottomNavigationBarContainer((context, index) {
          return _AppBottomNavigationView(_pageController);
        }, _bottomNavigationBarController),
      );
    });
  }
}

class _AppBottomNavigationView extends StatelessWidget {
  final PageController _pageController;

  _AppBottomNavigationView(this._pageController);

  final double gap = 10;
  final padding = EdgeInsets.symmetric(horizontal: 18, vertical: 5);

  @override
  Widget build(BuildContext context) {
    MainPageViewModel model = context.watch<MainPageViewModel>();

    return AnimatedContainer(
      width: ScreenUtils.width * 0.8,
      alignment: Alignment.center,
      duration: Duration(milliseconds: 300),
      height: model.isVisible ? 80.0 : 0.0,
      child: Wrap(
        children: [
          FloatingNavbar(
            width: ScreenUtils.width * 0.8,
            selectedItemColor: AppColor.indigo900,
            unselectedItemColor: AppColor.grey600,
            backgroundColor: AppColor.white,
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  blurRadius: 7,
                  offset: Offset(0, 3))
            ],
            borderRadius: 30,
            onTap: (int index) {
              context.read<MainPageViewModel>().currentIndex = index;
              _pageController.jumpToPage(index);
            },
            currentIndex: model.currentIndex,
            items: [
              FloatingNavbarItem(
                assetImage: AppResources.icNavOverview,
              ),
              FloatingNavbarItem(assetImage: AppResources.icNavInvoice),
              FloatingNavbarItem(assetImage: AppResources.icNavReport),
              FloatingNavbarItem(assetImage: AppResources.icNotification),
              FloatingNavbarItem(
                  customWidget: _circleAvatarView(model.getAvatarUrl())),
            ],
          )
        ],
      ),
    );
  }

  Widget _circleAvatarView(String avatarUrl) {
    return CircleAvatar(
      radius: 15,
      backgroundColor: AppColor.brown,
      child: MSCachedNetworkImage(
        imageUrl: avatarUrl,
        width: 30,
        height: 30,
        borderRadius: BorderRadius.circular(15),
        imageAssetDefault: Image.asset(
          AppResources.icAvatarPlaceHolder,
          width: 30,
          height: 30,
          fit: BoxFit.fill,
        ),
      ),
    );
  }

  Widget _circleNavigationItemMenuItem(
      {@required int currentIndex, @required VoidCallback onPressed}) {
    return Container(
      decoration: BoxDecoration(boxShadow: [
        BoxShadow(
            color: Colors.grey.withOpacity(0.15),
            spreadRadius: 0,
            blurRadius: 6,
            offset: Offset(0, 3))
      ], shape: BoxShape.circle),
      child: ClipOval(
        child: Stack(
          children: [
            Material(
              color: AppColor.primaryColor,
              child: InkWell(
                onTap: () {
                  print("_circleNavigationItemMenuItem");
                  onPressed();
                },
                child: Container(
                  width: 44,
                  height: 44,
                ),
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      color: AppColor.black.withOpacity(0.2),
                      blurRadius: 1,
                      offset: Offset(0, 1)),
                  BoxShadow(
                      color: Color(0xFFFF4B4B).withOpacity(0.16),
                      blurRadius: 12,
                      offset: Offset(0, 6))
                ],
                shape: BoxShape.circle,
              ),
              child: _iconMenuItem(
                  imageName: AppResources.icNavOverview,
                  color: currentIndex == 2 ? AppColor.white : Colors.white),
            )
          ],
        ),
      ),
    );
  }

  Widget _iconMenuItem({String imageName, Color color}) {
    return Container(
      alignment: Alignment.center,
      child: Image.asset(
        imageName,
        color: color,
        isAntiAlias: true,
        fit: BoxFit.fill,
        width: 28,
        height: 28,
      ),
    );
  }
}

class _BottomNavigationBarContainer extends StatefulWidget {
  final IndexedWidgetBuilder builder;
  final _BottomNavigationBarController controller;

  _BottomNavigationBarContainer(this.builder, this.controller);

  @override
  _BottomNavigationBarContainerState createState() =>
      _BottomNavigationBarContainerState();
}

class _BottomNavigationBarContainerState
    extends State<_BottomNavigationBarContainer> {
  @override
  void initState() {
    super.initState();

    widget.controller.addListener(_onIndexChanged);
  }

  @override
  void didUpdateWidget(_BottomNavigationBarContainer oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_onIndexChanged);
      widget.controller.addListener(_onIndexChanged);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onIndexChanged);
    super.dispose();
  }

  _onIndexChanged() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return widget.builder(context, widget.controller.index);
  }
}

class _BottomNavigationBarController extends Listenable {
  int _currentIndex = 0;

  _BottomNavigationBarController({int initialIndex = 0})
      : _currentIndex = initialIndex;

  setIndex(int index) {
    if (index == _currentIndex) return;
    _currentIndex = index;
    _notification();
  }

  get index {
    return _currentIndex;
  }

  List<VoidCallback> listeners = [];

  @override
  void addListener(listener) {
    listeners.add(listener);
  }

  @override
  void removeListener(listener) {
    listeners.remove(listener);
  }

  _notification() {
    listeners.map((listener) {
      listener();
    });
  }
}
