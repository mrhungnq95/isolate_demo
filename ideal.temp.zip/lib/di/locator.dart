//
// Created by nqhung on 30/10/2020.
//
import 'package:MShopManager/app/app_page_manager.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/business/report/overview_report_business.dart';
import 'package:MShopManager/business/report/revenue_report_business.dart';
import 'package:MShopManager/data/local/common_data_local.dart';
import 'package:MShopManager/data/local/filter_setting_data_local.dart';
import 'package:MShopManager/data/local/mobile_data_local.dart';
import 'package:MShopManager/data/remote/be_data_remote.dart';
import 'package:MShopManager/data/remote/dashboard_data_remote.dart';
import 'package:MShopManager/data/remote/inventory_item_category_data_remote.dart';
import 'package:MShopManager/data/remote/inventory_item_data_remote.dart';
import 'package:MShopManager/data/remote/mobile_data_remote.dart';
import 'package:MShopManager/data/remote/pu_invoice_data_remote.dart';
import 'package:MShopManager/data/remote/unit_data_remote.dart';
import 'package:MShopManager/data/repository/be_respository.dart';
import 'package:MShopManager/data/repository/common_data_repository.dart';
import 'package:MShopManager/data/repository/dashboard_repository.dart';
import 'package:MShopManager/data/repository/filter_setting_data_repository.dart';
import 'package:MShopManager/data/repository/inventory_item_category_repository.dart';
import 'package:MShopManager/data/repository/inventory_item_repository.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/data/repository/pu_invoice_repository.dart';
import 'package:MShopManager/data/repository/unit_repository.dart';
import 'package:MShopManager/features/customer/provider/add_customer_view_model.dart';
import 'package:MShopManager/features/customer/provider/customer_category_view_model.dart';
import 'package:MShopManager/features/customer/provider/customer_detail_view_model.dart';
import 'package:MShopManager/features/customer/provider/customer_filter_view_model.dart';
import 'package:MShopManager/features/customer/provider/customer_list_view_model.dart';
import 'package:MShopManager/features/customer/provider/select_customer_address_view_model.dart';
import 'package:MShopManager/features/overview/provider/overview_chain_view_model.dart';
import 'package:MShopManager/features/overview/provider/overview_filter_view_model.dart';
import 'package:MShopManager/features/overview/provider/overview_view_model.dart';
import 'package:MShopManager/features/inventory_item/add_inventory_item/provider/add_inventory_item_view_model.dart';
import 'package:MShopManager/features/inventory_item/category_inventory_item/provider/category_inventory_item_view_model.dart';
import 'package:MShopManager/features/inventory_item/declaration_inventory_item/provider/delcaration_inventory_item_view_model.dart';
import 'package:MShopManager/features/inventory_item/list_inventory_item/provider/inventory_item_filter_view_model.dart';
import 'package:MShopManager/features/inventory_item/list_inventory_item/provider/inventory_item_view_model.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_detail_view_model.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_filter_view_model.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_view_model.dart';
import 'package:MShopManager/features/invoice/provider/list_invoice_filter_view_model.dart';
import 'package:MShopManager/features/invoice/provider/list_invoice_view_model.dart';
import 'package:MShopManager/features/notification/provider/notification_setting_view_model.dart';
import 'package:MShopManager/features/notification/provider/notification_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/provider/add_import_inventory_item_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/provider/add_import_item_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/provider/choose_employee_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/detail/detail_import_item_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/filter/import_inventory_item_filter_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/list/import_inventory_item_view_model.dart';
import 'package:MShopManager/features/other/import_inventory_item/provider/payment_method_view_model.dart';
import 'package:MShopManager/features/other/language_setting/provider/language_setting_view_model.dart';
import 'package:MShopManager/features/other/other_view_model.dart';
import 'package:MShopManager/features/other/provider/add/add_provider_view_model.dart';
import 'package:MShopManager/features/other/provider/category/add/add_category_provider_view_model.dart';
import 'package:MShopManager/features/other/provider/category/list/choose_category_provider_view_model.dart';
import 'package:MShopManager/features/other/provider/detail/provider_detail_view_model.dart';
import 'package:MShopManager/features/other/provider/filter/provider_filter_view_model.dart';
import 'package:MShopManager/features/other/provider/choose/choose_provider_view_model.dart';
import 'package:MShopManager/features/other/provider/list/provider_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/add_return_inventory_item_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/add_return_item_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/choose_import_item_return_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/choose_inventory_item_return_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/detail_return_inventory_item_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/payment_info_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/return_inventory_item_filter_view_model.dart';
import 'package:MShopManager/features/other/return_inventory_item/provider/return_inventory_item_view_model.dart';
import 'package:MShopManager/features/other/sercurity_setting/provider/sercurity_setting_view_model.dart';
import 'package:MShopManager/features/other/setting/provider/setting_page_view_model.dart';
import 'package:MShopManager/features/other/stock_issue/stock_issue_expose.dart'
    as vnlong;
import 'package:MShopManager/features/other/storehouse_receipt/provider/add_storehouse_receipt_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/choose_branch_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/choose_item_sheet_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/choose_transfer_document_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/choose_type_storehouse_receipt_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/detail_inventory_item_storehouse_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/detail_storehouse_receipt_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/storehouse_receipt_filter_view_model.dart';
import 'package:MShopManager/features/other/storehouse_receipt/provider/storehouse_receipt_view_model.dart';
import 'package:MShopManager/features/recoverypassword/presentation/provider/recovery_password_view_model.dart';
import 'package:MShopManager/features/report/best_seller/provider/best_seller_filter_view_model.dart';
import 'package:MShopManager/features/report/best_seller/provider/best_seller_view_model.dart';
import 'package:MShopManager/features/report/business_situation/provider/business_situation_filter_view_model.dart';
import 'package:MShopManager/features/report/business_situation/provider/business_situation_view_model.dart';
import 'package:MShopManager/features/report/chain_store/provider/chain_store_detail_view_model.dart';
import 'package:MShopManager/features/report/chain_store/provider/chain_store_view_model.dart';
import 'package:MShopManager/features/report/checking/provider/add_checking_view_model.dart';
import 'package:MShopManager/features/report/checking/provider/checking_filter_view_model.dart';
import 'package:MShopManager/features/report/checking/provider/checking_view_model.dart';
import 'package:MShopManager/features/report/checking/provider/choose_batch_view_model.dart';
import 'package:MShopManager/features/report/checking/provider/choose_inventory_item_quantity_view_model.dart';
import 'package:MShopManager/features/report/choose_inventory_item/provider/choose_inventory_item_view_model.dart';
import 'package:MShopManager/features/report/debt_customer/provider/debt_customer_filter_view_model.dart';
import 'package:MShopManager/features/report/debt_customer/provider/debt_customer_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/detail/provider/report_inventories_by_exp_detail_page_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/filter/provider/report_inventories_by_exp_filter_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/provider/report_inventories_by_exp_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/provider/inventories_in_lot_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/provider/report_inventories_by_lot_filter_view_model.dart';
import 'package:MShopManager/features/report/report_inventories_by_lot/provider/report_inventories_by_lot_view_model.dart';
import 'package:MShopManager/features/report/report_menu_view_model.dart';
import 'package:MShopManager/features/report/revenue/provider/report_revenue_detail_view_model.dart';
import 'package:MShopManager/features/report/revenue/provider/report_revenue_filter_view_model.dart';
import 'package:MShopManager/features/report/revenue/provider/report_revenue_view_model.dart';
import 'package:MShopManager/features/report/revenueandexpenditure/provider/revenue_and_expenditure_detail_view_model.dart';
import 'package:MShopManager/features/report/revenueandexpenditure/provider/revenue_and_expenditure_view_model.dart';
import 'package:MShopManager/features/signin/provider/signin_view_model.dart';
import 'package:MShopManager/features/transaction_history/provider/customer_transaction_history_filter_view_model.dart';
import 'package:MShopManager/features/transaction_history/provider/customer_transaction_history_view_model.dart';
import 'package:MShopManager/features/transaction_history/provider/detail_invoice_view_model.dart';
import 'package:MShopManager/service/api/be_api.dart';
import 'package:MShopManager/service/api/dashboard_api.dart';
import 'package:MShopManager/service/api/impl/be_api_client.dart';
import 'package:MShopManager/service/api/impl/dashboard_api_client.dart';
import 'package:MShopManager/service/api/impl/inventory_item_api_client.dart';
import 'package:MShopManager/service/api/impl/inventory_item_category_api_client.dart';
import 'package:MShopManager/service/api/impl/mobile_api_client.dart';
import 'package:MShopManager/service/api/impl/pu_invoice_api_client.dart';
import 'package:MShopManager/service/api/impl/unit_api_client.dart';
import 'package:MShopManager/service/api/inventory_item_api.dart';
import 'package:MShopManager/service/api/inventory_item_category_api.dart';
import 'package:MShopManager/service/api/mobile_api.dart';
import 'package:MShopManager/service/api/pu_invoice_api.dart';
import 'package:MShopManager/service/api/unit_api.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/utils/network_info.dart';
import 'package:MShopManager/widget/unit/selectunit/provider/select_unit_view_model.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:get_it/get_it.dart';

Future<void> setupDependencies() async {
  final _locator = LocatorService.shared.locator;

  /// App
  _locator.registerFactory<PageManager>(() => PageManager());
  //_locator.registerFactory(() => LocalStorage.shared);
  _locator.registerLazySingleton(() => DataConnectionChecker());
  _locator.registerLazySingleton<NetworkInfo>(
      () => NetworkInfoImpl(_locator.get()));

  /// API

  /// ======== InventoryItem
  _locator.registerLazySingleton<InventoryItemAPI>(() => InventoryItemAPI());
  _locator.registerLazySingleton<InventoryItemAPIClient>(
      () => InventoryItemAPIClientImp(_locator.get()));

  /// ======== InventoryItem Category
  _locator.registerLazySingleton<InventoryItemCategoryAPI>(
      () => InventoryItemCategoryAPI());
  _locator.registerLazySingleton<InventoryItemCategoryAPIClient>(
      () => InventoryItemCategoryAPIClientImp(_locator.get()));

  /// ======== Unit
  _locator.registerLazySingleton<UnitAPI>(() => UnitAPI());
  _locator.registerLazySingleton<UnitAPIClient>(
      () => UnitAPIClientImp(_locator.get()));

  /// ======== Mobile
  _locator.registerLazySingleton<MobileAPI>(() => MobileAPI());
  _locator.registerLazySingleton<MobileAPIClient>(
      () => MobileAPIClientImpl(_locator.get()));

  /// ======== Dashboard
  _locator.registerLazySingleton<DashboardAPI>(() => DashboardAPI());
  _locator.registerLazySingleton<DashboardAPIClient>(
      () => DashboardAPIClientImpl(_locator.get()));

  /// ======== PUInvoice
  _locator.registerLazySingleton<PUInvoiceAPI>(() => PUInvoiceAPI());
  _locator.registerLazySingleton<PUInvoiceAPIClient>(
      () => PUInvoiceAPIClientImpl(_locator.get()));

  /// ======== BE
  _locator.registerLazySingleton<BeAPI>(() => BeAPI());
  _locator.registerLazySingleton<BeAPIClient>(
      () => BeAPIClientImpl(_locator.get()));

  /// Repository
  /// ======== Common
  _locator.registerLazySingleton<CommonDataLocal>(
      () => CommonDataLocalImpl(LocalStorage.shared));
  _locator.registerLazySingleton<CommonDataRepository>(
      () => CommonDataRepositoryImpl(_locator.get()));

  _locator.registerLazySingleton<FilterSettingDataLocal>(
      () => FilterSettingDataLocalImpl(LocalStorage.shared));
  _locator.registerLazySingleton<FilterSettingRepository>(
      () => FilterSettingRepositoryImpl(_locator.get()));

  /// ======== Mobile
  _locator.registerLazySingleton<MobileDataRemote>(
      () => MobileDataRemoteImpl(apiClient: _locator.get()));
  _locator.registerLazySingleton<MobileDataLocal>(() => MobileDataLocalImpl());
  _locator.registerLazySingleton<MobileRepository>(() => MobileRepositoryImpl(
      mobileDataRemote: _locator.get(), mobileDataLocal: _locator.get()));

  /// ======== Dashboard
  _locator.registerLazySingleton<DashboardDataRemote>(
      () => DashboardDataRemoteImpl(dashboardAPIClient: _locator.get()));
  _locator.registerLazySingleton<DashboardRepository>(
      () => DashboardRepositoryImpl(dashboardDataRemote: _locator.get()));

  /// ======== PUInvoice
  _locator.registerLazySingleton<PUInvoiceDataRemote>(
      () => PUInvoiceDataRemoteImpl(_locator.get()));
  _locator.registerLazySingleton<PUInvoiceRepository>(
      () => PUInvoiceRepositoryImpl(_locator.get()));

  /// ======== InventoryItem
  _locator.registerLazySingleton<InventoryItemRepository>(() =>
      InventoryItemRepositoryImp(inventoryItemDataRemote: _locator.get()));
  _locator.registerLazySingleton<InventoryItemDataRemote>(
      () => InventoryItemDataRemoteImp(apiClient: _locator.get()));

  /// ======== InventoryItem Category
  _locator.registerLazySingleton<InventoryItemCategoryRepository>(() =>
      InventoryItemCategoryRepositoryImp(
          inventoryItemDataRemote: _locator.get()));
  _locator.registerLazySingleton<InventoryItemCategoryDataRemote>(
      () => InventoryItemCategoryDataRemoteImp(apiClient: _locator.get()));

  /// ======== Unit
  _locator.registerLazySingleton<UnitRepository>(
      () => UnitRepositoryImp(unitDataRemote: _locator.get()));
  _locator.registerLazySingleton<UnitDataRemote>(
      () => UnitDataRemoteImp(apiClient: _locator.get()));

  /// ======== BE
  _locator.registerLazySingleton<BeDataRemote>(
      () => BeDataRemoteImpl(beAPIClient: _locator.get()));
  _locator.registerLazySingleton<BeRepository>(
      () => BeRepositoryImpl(beDataRemote: _locator.get()));

  // Business ==================================================================
  _locator.registerLazySingleton<OverViewReportBusiness>(
      () => OverViewReportBusiness());

  _locator.registerLazySingleton<RevenueReportBusiness>(
      () => RevenueReportBusiness());

  _locator
      .registerLazySingleton<QuickActionBusiness>(() => QuickActionBusiness());

  // VIEWMODEL =================================================================
  _locator.registerFactory(() => SignInViewModel());
  _locator.registerFactory(() => RecoveryPasswordViewModel());
  _locator.registerFactory(() => OverviewViewModel(_locator.get()));
  _locator.registerFactory(() => OverviewChainViewModel());
  _locator.registerFactory(() => OverviewFilterViewModel(_locator.get()));
  _locator.registerFactory(() => ReportRevenueViewModel(_locator.get()));
  _locator.registerFactory(() => ReportRevenueFilterViewModel());
  _locator.registerFactory(() => BusinessSituationViewModel());
  _locator.registerFactory(() => BusinessSituationFilterViewModel());
  _locator.registerFactory(() => ListInvoiceViewModel());
  _locator.registerFactory(() => RevenueAndExpenditureViewModel());
  _locator.registerFactory(() => RevenueAndExpenditureDetailViewModel());
  _locator.registerFactory(() => CheckingViewModel());
  _locator.registerFactory(() => ChooseBatchViewModel());
  _locator.registerFactory(() => InventoryItemViewModel());
  _locator.registerFactory(() => InventoryItemFilterViewModel());
  _locator.registerFactory(() => AddCheckingViewModel());
  _locator.registerFactory(() => CheckingFilterViewModel());
  _locator.registerFactory(() => AddInventoryItemViewModel());
  _locator.registerFactory(() => CategoryInventoryItemViewModel());
  _locator.registerFactory(() => DeclarationInventoryItemViewModel());
  _locator.registerFactory(() => SelectUnitViewModel());
  _locator.registerFactory(() => ReportInventoriesByExpFilterViewModel());
  _locator.registerFactory(() => ReportInventoriesByExpViewModel());
  _locator.registerFactory(() => InventoryItemInStoreViewModel());
  _locator.registerFactory(() => InventoryItemInStoreFilterViewModel());
  _locator.registerFactory(() => InventoryItemInStoreDetailViewModel());
  _locator.registerFactory(() => ChainStoreViewModel());
  _locator.registerFactory(() => ReportInventoriesByExpDetailPageViewModel());
  _locator.registerFactory(() => SettingPageViewModel());
  _locator.registerFactory(() => DebtCustomerViewModel());
  _locator.registerFactory(() => DebtCustomerFilterViewModel());
  _locator.registerFactory(() => StorehouseReceiptViewModel());
  _locator.registerFactory(() => StorehouseReceiptFilterViewModel());
  _locator.registerFactory(() => ChooseTypeStorehouseReceiptViewModel());
  _locator.registerFactory(() => ChooseBranchViewModel());
  _locator.registerFactory(() => ChooseTransferDocumentViewModel());
  _locator.registerFactory(() => AddStorehouseReceiptViewModel());
  _locator.registerFactory(() => ChooseItemViewModel());
  _locator.registerFactory(() => DetailInventoryItemStorehouseViewModel());
  _locator.registerFactory(() => DetailStorehouseReceiptViewModel());
  _locator.registerFactory(() => vnlong.StockIssueViewModel());
  _locator.registerFactory(() => vnlong.StockIssueFilterViewModel());
  _locator.registerFactory(() => vnlong.AddStockIssueViewModel());
  _locator.registerFactory(() => vnlong.ChooseStockIssueTypeViewModel());
  _locator.registerFactory(() => vnlong.ChooseImportItemViewModel());
  _locator.registerFactory(() => vnlong.DetailStockIssueViewModel());
  _locator.registerFactory(() => vnlong.ChooseImportItemFilterViewModel());
  _locator.registerFactory(() => vnlong.ChooseImporterFilterViewModel());
  _locator.registerFactory(() => vnlong.ChooseImporterViewModel());
  _locator.registerFactory(() => vnlong.DocumentInfoViewModel());
  _locator.registerFactory(() => vnlong.ChooseItemStockIssueViewModel());
  _locator.registerFactory(() => ProviderViewModel(_locator.get()));
  _locator.registerFactory(() => ProviderFilterViewModel());
  _locator.registerFactory(() => ProviderDetailViewModel(_locator.get()));
  _locator
      .registerFactory(() => ChooseCategoryProviderViewModel(_locator.get()));
  _locator.registerFactory(() => AddCategoryProviderViewModel(_locator.get()));
  _locator.registerFactory(() => AddProviderViewModel(_locator.get()));
  _locator.registerFactory(() => ReportRevenueDetailViewModel(_locator.get()));
  _locator.registerFactory(() => NotificationViewModel());
  _locator.registerFactory(() => CustomerListViewModel(_locator.get()));
  _locator.registerFactory(() => CustomerFilterViewModel());
  _locator.registerFactory(
      () => CustomerDetailViewModel(_locator.get(), _locator.get()));
  _locator.registerFactory(() => AddCustomerViewModel(_locator.get()));
  _locator.registerFactory(
      () => CustomerTransactionHistoryViewModel(_locator.get()));
  _locator.registerFactory(() => CustomerTransactionHistoryFilterViewModel());
  _locator.registerFactory(() => OtherViewModel());
  _locator.registerFactory(() => SercuritySettingViewModel());
  _locator.registerFactory(() => NotificationSettingViewModel());
  _locator.registerFactory(() => ReportInventoriesByLotViewModel());
  _locator.registerFactory(() => ReportInventoriesByLotFilterViewModel());
  _locator.registerFactory(() => InventoriesInLotViewModel());
  _locator.registerFactory(() => ReturnInventoryItemViewModel());
  _locator.registerFactory(() => ReturnInventoryItemFilterViewModel());
  _locator.registerFactory(() => AddReturnItemViewModel());
  _locator.registerFactory(() => PaymentInfoViewModel());
  _locator.registerFactory(() => SelectCustomerAddressViewModel());
  _locator.registerFactory(() => BestSellerViewModel());
  _locator.registerFactory(() => BestSellerFilterViewModel());
  _locator.registerFactory(() => LanguageSettingViewModel());
  _locator.registerFactory(() => ChooseProviderViewModel(_locator.get()));
  _locator.registerFactory(() => ChooseInventoryItemReturnViewModel());
  _locator.registerFactory(() => ChooseImportItemReturnViewModel());
  _locator.registerFactory(() => ImportInventoryItemViewModel(_locator.get()));
  _locator.registerFactory(() => ImportInventoryItemFilterViewModel());
  _locator.registerFactory(() => AddImportItemViewModel());
  _locator.registerFactory(() => PaymentMethodViewModel());
  _locator.registerFactory(() => ChooseEmployeeViewModel());
  _locator.registerFactory(() => AddImportInventoryItemViewModel());
  _locator.registerFactory(() => ListInvoiceFilterViewModel());
  _locator.registerFactory(() => ReportMenuViewModel());
  _locator.registerFactory(() => ChainStoreDetailViewModel());
  _locator.registerFactory(() => ChooseInventoryItemViewModel());
  _locator.registerFactory(() => ChooseInventoryItemQuantityViewModel());
  _locator.registerFactory(() => DetailImportItemViewModel(_locator.get()));
  _locator.registerFactory(() => DetailReturnInventoryItemViewModel());
  _locator.registerFactory(() => AddReturnInventoryItemViewModel());
  _locator.registerFactory(() => DetailInvoiceViewModel());
  _locator.registerFactory(() => CustomerCategoryViewModel(_locator.get()));
  // VIEWMODEL =================================================================

  print("LocatorService setupDependencies");
}

class LocatorService {
  static GetIt _locator;
  static LocatorService _instance;
  static LocatorService get shared => _getInstance();
  GetIt get locator => _locator;

  LocatorService._internal() {
    print("LocatorService init!");
  }

  void _init() {
    _locator = GetIt.instance;
  }

  static LocatorService _getInstance() {
    if (_instance == null) {
      _instance = LocatorService._internal();
    }
    if (_locator == null) {
      _instance._init();
    }
    return _instance;
  }

  T get<T>() {
    return _locator<T>();
  }

  Future<T> getAsync<T>() async {
    return await _locator.getAsync<T>();
  }

  void clear() {
    _locator.reset(dispose: true);
  }
}
