import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/app_page_manager.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/app/routes/app_router.dart';
import 'package:MShopManager/app/app_theme.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/widget/pull_to_refresh/pull_indicator_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class AppViewModel extends MSBaseViewModel {
  //Authorize

  //Localize
  Locale _locale = Locale("vi", "VN");
  Locale get locale => _locale;

  //ThemeDark/ThemeLight
  ThemeMode _themeMode = ThemeMode.light;
  ThemeMode get themeMode => _themeMode;

  //Cart

  // void funcTest() async {
  //   print("funcTest ${Isolate.current.debugName}");
  //   String jsonData = await FileUtils.readFile("data");
  //   await compute(parseDataCompute, jsonData);
  // }

}

// void parseDataCompute(String jsonData) async {
//   print("parseDataCompute: ${Isolate.current.debugName}");
//   Map<String, dynamic> json = jsonDecode(jsonData);
//   var msOutputService =
//       MSOutputService<RevenueByItemsInfo>.fromJson(json, (jsonItem) {
//     return RevenueByItemsInfo.fromJson(jsonItem);
//   });

//   print(msOutputService);
// }

class MyApp extends StatelessWidget {
  final navigatorKey = NavigationHelper.shared.navigatorKey;
  //LocatorService.shared.get<NavigationHelper>().navigatorKey;

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(
            value: LocatorService.shared.get<PageManager>()),
        ChangeNotifierProvider(
          create: (context) => AppViewModel(),
        )
      ],
      builder: (context, child) {
        return RefreshConfiguration(
            headerBuilder: () =>
                PullHeaderView(), // Configure the default header indicator. If you have the same header indicator for each page, you need to set this
            footerBuilder: () => PullFooterView(),
            child: MaterialApp(
              navigatorKey: navigatorKey,
              onGenerateRoute: AppRouterHandler.handleRouterNavigate,
              initialRoute: AppRouterName.root.value(),
              title: 'Quản lý',
              theme: AppTheme.shared.getLightTheme(),
              navigatorObservers: [AppNavigatorObserver()],
              builder: (BuildContext context, Widget child) {
                /// make sure that loading can be displayed in front of all other widgets
                return FlutterEasyLoading(child: child);
              },
              //home: MainNavigatorPage(),
            ));
      },
    );

    // return ViewModelBuilder<AppViewModel>.reactive(
    //     builder: (context, model, child) => MaterialApp(
    //           navigatorKey: locator<NavigationHelper>().navigatorKey,
    //           onGenerateRoute: AppRouterHandler.handleRouterNavigate,
    //           initialRoute: AppRouterName.root.value(),
    //           title: 'Membership',
    //           theme: ThemeManager.shared.getLightTheme(),
    //         ),
    //     onModelReady: (vm) {
    //       print("$vm");
    //     },
    //     viewModelBuilder: () => AppViewModel());
  }
}

class AppNavigatorObserver extends NavigatorObserver {
  @override
  void didPush(Route route, Route previousRoute) {
    // TODO: implement didPush
    super.didPush(route, previousRoute);

    print("[Base] ${route.settings} didPush");
  }

  @override
  void didPop(Route route, Route previousRoute) {
    // TODO: implement didPop
    super.didPop(route, previousRoute);

    print("[Base] ${route.settings} didPop");
  }

  @override
  void didRemove(Route route, Route previousRoute) {
    // TODO: implement didRemove
    super.didRemove(route, previousRoute);

    print("[Base] ${route.settings} didRemove");
  }

  @override
  void didReplace({Route<dynamic> newRoute, Route<dynamic> oldRoute}) {
    // TODO: implement didReplace
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);

    print("[Base] ${oldRoute.settings} didReplace with ${newRoute.settings}");
  }
}
