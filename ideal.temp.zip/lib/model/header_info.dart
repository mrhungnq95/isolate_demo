///
/// [Description] Header
///
/// Created by TTLOI on 15/01/2021 (16:39).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class HeaderInfo {
 String title;
 String value;

 HeaderInfo(this.title, this.value);
}