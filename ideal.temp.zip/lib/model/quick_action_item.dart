import 'dart:convert';

import 'package:MShopManager/enums/enum_feature_type.dart';

class QuickActionItem {
  String title;
  String imageAssets;
  int sortOrder;
  EFeatureType type;
  QuickActionItem({
    this.title,
    this.imageAssets,
    this.sortOrder,
    this.type,
  });

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'imageAssets': imageAssets,
      'sortOrder': sortOrder,
      'type': type?.rawValue,
    };
  }

  factory QuickActionItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return QuickActionItem(
      title: map['title'],
      imageAssets: map['imageAssets'],
      sortOrder: map['sortOrder'],
      type: EFeatureTypeExt.valueOf(map['type']),
    );
  }

  String toJson() => json.encode(toMap());

  factory QuickActionItem.fromJson(String source) =>
      QuickActionItem.fromMap(json.decode(source));
}
