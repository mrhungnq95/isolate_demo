//
// Created by nqhung on 11/11/2020.
//

class ErrorData {
  /// Http status code.
  int statusCode;

  /// Returns the reason phrase associated with the status code.
  /// The reason phrase must be set before the body is written
  /// to. Setting the reason phrase after writing to the body.
  String statusMessage;

  dynamic data;

  ///
  /// Messsage tuỳ biến
  ///
  String customizeMessage;

  ErrorData(
      {this.statusCode, this.data, this.statusMessage, this.customizeMessage});
}
