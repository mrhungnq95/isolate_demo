import 'package:MShopManager/enums/enum_notification_type.dart';

class ItemNotificationSetting {
  ENotificationType type;
  String title;
  String description;
  bool value;
  ItemNotificationSetting({
    this.type,
    this.title,
    this.description,
    this.value,
  });
}
