import 'dart:convert';

class LicenseInfo {
  int licenseType;
  String productPackCode;
  String productPackName;
  String applicationURL;
  String startDate;
  int duration;
  String expiredDate;
  int numberOfBranch;
  String subscriberNo;
  int status;
  int remain;
  int overDue;
  String subApp;
  int deviceQuantity;
  LicenseInfo({
    this.licenseType,
    this.productPackCode,
    this.productPackName,
    this.applicationURL,
    this.startDate,
    this.duration,
    this.expiredDate,
    this.numberOfBranch,
    this.subscriberNo,
    this.status,
    this.remain,
    this.overDue,
    this.subApp,
    this.deviceQuantity,
  });

  Map<String, dynamic> toMap() {
    return {
      'LicenseType': licenseType,
      'ProductPackCode': productPackCode,
      'ProductPackName': productPackName,
      'ApplicationURL': applicationURL,
      'StartDate': startDate,
      'Duration': duration,
      'ExpiredDate': expiredDate,
      'NumberOfBranch': numberOfBranch,
      'SubscriberNo': subscriberNo,
      'Status': status,
      'Remain': remain,
      'OverDue': overDue,
      'SubApp': subApp,
      'DeviceQuantity': deviceQuantity,
    };
  }

  factory LicenseInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return LicenseInfo(
      licenseType: map['LicenseType'],
      productPackCode: map['ProductPackCode'],
      productPackName: map['ProductPackName'],
      applicationURL: map['ApplicationURL'],
      startDate: map['StartDate'],
      duration: map['Duration'],
      expiredDate: map['ExpiredDate'],
      numberOfBranch: map['NumberOfBranch'],
      subscriberNo: map['SubscriberNo'],
      status: map['Status'],
      remain: map['Remain'],
      overDue: map['OverDue'],
      subApp: map['SubApp'],
      deviceQuantity: map['DeviceQuantity'],
    );
  }

  String toJson() => json.encode(toMap());

  factory LicenseInfo.fromJson(String source) =>
      LicenseInfo.fromMap(json.decode(source));
}
