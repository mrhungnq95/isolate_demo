
class ViewByAttrItemObject {
  String name;
  double buyCost;
  double sellCost;

  ViewByAttrItemObject({
    this.name,
    this.buyCost,
    this.sellCost,
  });

}
