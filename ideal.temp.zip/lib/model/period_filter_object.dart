//
// Created by nqhung on 06/11/2020.
//

import 'dart:convert';

import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

class PeriodFilterCategoryType {
  /// Kiểu kỳ báo cáo
  EDateFilterType type;

  /// Chú thích
  String description;

  /// Các loại kỳ báo cáo con:
  /// Hôm nay
  /// Hôm qua
  /// 30 ngày gần đây
  /// Tháng này
  /// ....
  List<ItemPeriodFilterObject> periodItemList;

  PeriodFilterCategoryType({this.type, this.description, this.periodItemList});
}

class ItemPeriodFilterObject {
  EReportPeriodType type;

  /// Tiêu đề: 7 ngày gần đây
  String title;

  /// Chú thích: 14 tháng 12 - 21  tháng 12
  String description;

  /// Cờ đánh dấu cho cho phép sửa lại dateRange của object không?
  /// dùng trong trường hợp Báo cáo Tuỳ chỉnh ngày tháng
  bool isCustomizeDate;

  /// Thời gian, ngày tháng của kì báo cáo
  /// [dateRange.startDate] thời gian bắt đầu
  /// [dateRange.endDate] thời gian kết thúc
  ///
  DateRange dateRange;

  ItemPeriodFilterObject(
      {this.title,
      this.type,
      this.description,
      this.dateRange,
      this.isCustomizeDate = false});

  factory ItemPeriodFilterObject.createCustomizeDate(DateRange dateRange) {
    return ItemPeriodFilterObject(
        type: EReportPeriodType.toDateCustomize,
        title: "Tuỳ chỉnh",
        isCustomizeDate: true,
        description: "",
        dateRange: dateRange);
  }
  
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'type': type.rawValue,
      'description': description,
      'isCustomizeDate': isCustomizeDate,
      'dateRange': dateRange?.toMap(),
    };
  }

  factory ItemPeriodFilterObject.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ItemPeriodFilterObject(
      title: map['title'],
      type: EReportPeriodTypeExt.valueOf(map['type']),
      description: map['description'],
      isCustomizeDate: map['isCustomizeDate'],
      dateRange: DateRange.fromMap(map['dateRange']),
    );
  }

  String toJson() => json.encode(toMap());

  factory ItemPeriodFilterObject.fromJson(String source) =>
      ItemPeriodFilterObject.fromMap(json.decode(source));
}
