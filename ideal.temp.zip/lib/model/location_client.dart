import 'dart:convert';

class LocationClient {
  String locationID;
  int kind;
  String locationName;
  LocationClient({
    this.locationID,
    this.kind,
    this.locationName,
  });

  Map<String, dynamic> toMap() {
    return {
      'LocationID': locationID,
      'Kind': kind,
      'LocationName': locationName,
    };
  }

  factory LocationClient.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return LocationClient(
      locationID: map['LocationID'],
      kind: map['Kind'],
      locationName: map['LocationName'],
    );
  }

  String toJson() => json.encode(toMap());

  factory LocationClient.fromJson(String source) =>
      LocationClient.fromMap(json.decode(source));
}

class LocationClientMerge {
  String nameSearch;
  LocationClient city;
  LocationClient district;
  LocationClientMerge({
    this.nameSearch,
    this.city,
    this.district,
  });

  Map<String, dynamic> toMap() {
    return {
      'nameSearch': nameSearch,
      'city': city?.toMap(),
      'district': district?.toMap(),
    };
  }

  factory LocationClientMerge.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return LocationClientMerge(
      nameSearch: map['nameSearch'],
      city: LocationClient.fromMap(map['city']),
      district: LocationClient.fromMap(map['district']),
    );
  }

  String toJson() => json.encode(toMap());

  factory LocationClientMerge.fromJson(String source) =>
      LocationClientMerge.fromMap(json.decode(source));
}
