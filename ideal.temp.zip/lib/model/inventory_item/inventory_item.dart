import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/model/unit/unit_convert.dart';

/// Model hàng hóa
class InventoryItem {
  String inventoryItemID;
  String parentID;
  String skuCode;
  String inventoryItemName;
  String inventoryItemNameAbbr;
  String branchID;
  int inventoryItemType;
  String inventoryItemCategoryID;
  String itemCategoryName;
  String barcode;
  double unitPrice;
  double costPrice;
  String unitID;
  double minimumStock;
  double maximumStock;
  String stockLocation;
  String showLocation;
  bool showInMenu;
  String color;
  String colourCode;
  String size;
  String material;
  String description;
  String pictureID;
  bool inactive;
  bool isInventoryItem;
  DateTime importDate;
  DateTime createDate;
  String createBy;
  DateTime modifiedDate;
  String modifiedBy;
  bool isPrintedStamp;
  int pictureType;
  String inventoryItemNameNoAccent;
  DateTime dateOfNewArrival;
  double modelPrice;
  String extensionStr;

  /// Refactor Name
  int fileType;
  String keySearch;
  bool hasChild;
  bool samePrice;
  bool samePriceConsultant;
  double unitPriceConsultant;
  double discountRate;
  double discountAmount;
  String unitName;
  String ext;
  String inventoryItemNameHash;
// // Danh sách hàng hóa || Danh sách dữ liệu thuộc tính
//   List<InventoryItem> listDetail;
// // Danh sách đơn vị tính chuyển đổi
//   List<UnitConvert> listUnitConvert;
  int editMode;
// Tồn kho
  double quantity;
  double weight;
  double length;
  double width;
  double height;
  int sortOrder;
// Thiết lập quản lý theo lô - HSD - serial - iemi
  int manageType;
  double sellBeforeDay;
  int sellBeforeType;
  String lotID;
  String lotDetailID;
  DateTime expiryDate;
  String lotNo;
  String serials;
// Số serial kiểm kê
  String serialAudit;
// số serial trong sổ lúc kiểm
  String serialOnBook;
// Khi quét serial để tìm hàng hóa từ api InventoryItemMobile/Barcode trả về trường serial này
  String serialNo;
// nếu isChangedExpiryDate = true
  // -> ExpiryDate không tự cập nhật theo lô (khi refresh ở màn hình EditItemViewController)
  // nếu thay đổi lô
  // thì set isChangedExpiryDate = false
  // -> ExpiryDate phải cập nhật theo lô
  bool isChangedExpiryDate;
  double convertRate;

  InventoryItem({
    this.inventoryItemID,
    this.parentID,
    this.skuCode,
    this.inventoryItemName,
    this.inventoryItemNameAbbr,
    this.branchID,
    this.inventoryItemType,
    this.inventoryItemCategoryID,
    this.itemCategoryName,
    this.barcode,
    this.unitPrice,
    this.costPrice,
    this.unitID,
    this.minimumStock,
    this.maximumStock,
    this.stockLocation,
    this.showLocation,
    this.showInMenu,
    this.color,
    this.colourCode,
    this.size,
    this.material,
    this.description,
    this.pictureID,
    this.inactive,
    this.isInventoryItem,
    this.importDate,
    this.createDate,
    this.createBy,
    this.modifiedDate,
    this.modifiedBy,
    this.isPrintedStamp,
    this.pictureType,
    this.inventoryItemNameNoAccent,
    this.dateOfNewArrival,
    this.modelPrice,
    this.extensionStr,
    this.fileType,
    this.keySearch,
    this.hasChild,
    this.samePrice,
    this.samePriceConsultant,
    this.unitPriceConsultant,
    this.discountRate,
    this.discountAmount,
    this.unitName,
    this.ext,
    this.inventoryItemNameHash,
    // this.listDetail,
    // this.listUnitConvert,
    this.editMode,
    this.quantity,
    this.weight,
    this.length,
    this.width,
    this.height,
    this.sortOrder,
    this.manageType,
    this.sellBeforeDay,
    this.sellBeforeType,
    this.lotID,
    this.lotDetailID,
    this.expiryDate,
    this.lotNo,
    this.serials,
    this.serialAudit,
    this.serialOnBook,
    this.serialNo,
    this.isChangedExpiryDate,
    this.convertRate,
  });

  Map<String, dynamic> toMap() {
    return {
      'InventoryItemID': inventoryItemID,
      'ParentID': parentID,
      'SKUCode': skuCode,
      'InventoryItemName': inventoryItemName,
      'InventoryItemNameAbbr': inventoryItemNameAbbr,
      'BranchID': branchID,
      'InventoryItemType': inventoryItemType,
      'InventoryItemCategoryID': inventoryItemCategoryID,
      'ItemCategoryName': itemCategoryName,
      'Barcode': barcode,
      'UnitPrice': unitPrice,
      'CostPrice': costPrice,
      'UnitID': unitID,
      'MinimumStock': minimumStock,
      'MaximumStock': maximumStock,
      'StockLocation': stockLocation,
      'ShowLocation': showLocation,
      'ShowInMenu': showInMenu,
      'Color': color,
      'ColourCode': colourCode,
      'Size': size,
      'Material': material,
      'Description': description,
      'PictureID': pictureID,
      'Inactive': inactive,
      'IsInventoryItem': isInventoryItem,
      'ImportDate': DateTimeFormatHelper.formatDate2String(importDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreateDate': DateTimeFormatHelper.formatDate2String(createDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreateBy': createBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'IsPrintedStamp': isPrintedStamp,
      'PictureType': pictureType,
      'InventoryItemNameNoAccent': inventoryItemNameNoAccent,
      'DateOfNewArrival': DateTimeFormatHelper.formatDate2String(
          dateOfNewArrival,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModelPrice': modelPrice,
      'Extension': extensionStr,
      'FileType': fileType,
      'KeySearch': keySearch,
      'HasChild': hasChild,
      'SamePrice': samePrice,
      'SamePriceConsultant': samePriceConsultant,
      'UnitPriceConsultant': unitPriceConsultant,
      'DiscountRate': discountRate,
      'DiscountAmount': discountAmount,
      'UnitName': unitName,
      'Ext': ext,
      'InventoryItemNameHash': inventoryItemNameHash,
      // 'ListDetail': listDetail?.map((x) => x?.toMap())?.toList(),
      // 'ListUnitConvert': listUnitConvert?.map((x) => x?.toMap())?.toList(),
      'EditMode': editMode,
      'Quantity': quantity,
      'Weight': weight,
      'Length': length,
      'Width': width,
      'Height': height,
      'SortOrder': sortOrder,
      'ManageType': manageType,
      'SellBeforeDay': sellBeforeDay,
      'SellBeforeType': sellBeforeType,
      'LotID': lotID,
      'LotDetailID': lotDetailID,
      'ExpiryDate': DateTimeFormatHelper.formatDate2String(expiryDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'LotNo': lotNo,
      'Serials': serials,
      'SerialAudit': serialAudit,
      'SerialOnBook': serialOnBook,
      'SerialNo': serialNo,
      'IsChangedExpiryDate': isChangedExpiryDate,
      'ConvertRate': convertRate,
    };
  }

  factory InventoryItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return InventoryItem(
      inventoryItemID: map['InventoryItemID'],
      parentID: map['ParentID'],
      skuCode: map['SKUCode'],
      inventoryItemName: map['InventoryItemName'],
      inventoryItemNameAbbr: map['InventoryItemNameAbbr'],
      branchID: map['BranchID'],
      inventoryItemType: map['InventoryItemType'],
      inventoryItemCategoryID: map['InventoryItemCategoryID'],
      itemCategoryName: map['ItemCategoryName'],
      barcode: map['Barcode'],
      unitPrice: map['UnitPrice'],
      costPrice: map['CostPrice'],
      unitID: map['UnitID'],
      minimumStock: map['MinimumStock'],
      maximumStock: map['MaximumStock'],
      stockLocation: map['StockLocation'],
      showLocation: map['ShowLocation'],
      showInMenu: map['ShowInMenu'],
      color: map['Color'],
      colourCode: map['ColourCode'],
      size: map['Size'],
      material: map['Material'],
      description: map['Description'],
      pictureID: map['PictureID'],
      inactive: map['Inactive'],
      isInventoryItem: map['IsInventoryItem'],
      importDate: DateTimeFormatHelper.parseString2Date(map['ImportDate']),
      createDate: DateTimeFormatHelper.parseString2Date(map['CreateDate']),
      createBy: map['CreateBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      isPrintedStamp: map['IsPrintedStamp'],
      pictureType: map['PictureType'],
      inventoryItemNameNoAccent: map['InventoryItemNameNoAccent'],
      dateOfNewArrival:
          DateTimeFormatHelper.parseString2Date(map['DateOfNewArrival']),
      modelPrice: map['ModelPrice'],
      extensionStr: map['Extension'],
      fileType: map['FileType'],
      keySearch: map['KeySearch'],
      hasChild: map['HasChild'],
      samePrice: map['SamePrice'],
      samePriceConsultant: map['SamePriceConsultant'],
      unitPriceConsultant: map['UnitPriceConsultant'],
      discountRate: map['DiscountRate'],
      discountAmount: map['DiscountAmount'],
      unitName: map['UnitName'],
      ext: map['Ext'],
      inventoryItemNameHash: map['InventoryItemNameHash'],
      // listDetail: List<InventoryItem>.from(
      //     map['ListDetail']?.map((x) => InventoryItem.fromMap(x))),
      // listUnitConvert: List<UnitConvert>.from(
      //     map['ListUnitConvert']?.map((x) => UnitConvert.fromMap(x))),
      editMode: map['EditMode'],
      quantity: map['Quantity'],
      weight: map['Weight'],
      length: map['Length'],
      width: map['Width'],
      height: map['Height'],
      sortOrder: map['SortOrder'],
      manageType: map['ManageType'],
      sellBeforeDay: map['SellBeforeDay'],
      sellBeforeType: map['SellBeforeType'],
      lotID: map['LotID'],
      lotDetailID: map['LotDetailID'],
      expiryDate: DateTimeFormatHelper.parseString2Date(map['ExpiryDate']),
      lotNo: map['LotNo'],
      serials: map['Serials'],
      serialAudit: map['SerialAudit'],
      serialOnBook: map['SerialOnBook'],
      serialNo: map['SerialNo'],
      isChangedExpiryDate: map['IsChangedExpiryDate'],
      convertRate: map['ConvertRate'],
    );
  }

  String toJson() => json.encode(toMap());

  factory InventoryItem.fromJson(String source) =>
      InventoryItem.fromMap(json.decode(source));
}
