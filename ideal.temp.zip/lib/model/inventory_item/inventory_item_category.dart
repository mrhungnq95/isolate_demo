import 'dart:convert';
import 'package:MShopManager/utils/ext/dart_ext/iterable.dart';


/// Model Danh mục hàng hóa
class InventoryItemCategory {

  String inventoryItemCategoryID;
  String parentID;
  String itemCategoryCode;
  String itemCategoryName;
  String description;
  String misaCode;
  bool isLeaf;
  int grade;
  bool inactive;
  int editMode;
  bool expanded;
  bool isAll;
  int sortOrder;
  List<InventoryItemCategory> listChild;

  InventoryItemCategory({
    this.inventoryItemCategoryID,
    this.parentID,
    this.itemCategoryCode,
    this.itemCategoryName,
    this.description,
    this.misaCode,
    this.isLeaf,
    this.grade,
    this.inactive,
    this.editMode,
    this.expanded,
    this.isAll,
    this.sortOrder,
    this.listChild
  });

  Map<String, dynamic> toMap() {
    return {
      'InventoryItemCategoryID': inventoryItemCategoryID,
      'ParentID': parentID,
      'ItemCategoryCode': itemCategoryCode,
      'ItemCategoryName': itemCategoryName,
      'Description': description,
      'MisaCode': misaCode,
      'IsLeaf': isLeaf,
      'Grade': grade,
      'Inactive': inactive,
      'EditMode': editMode,
      'Expanded': expanded,
      'IsAll': isAll,
      'SortOrder': sortOrder,
      'ListChild': sortOrder,
    };
  }

  factory InventoryItemCategory.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return InventoryItemCategory(
      inventoryItemCategoryID: map['InventoryItemCategoryID'],
      parentID: map['ParentID'],
      itemCategoryCode: map['ItemCategoryCode'],
      itemCategoryName: map['ItemCategoryName'],
      description: map['Description'],
      misaCode: map['MisaCode'],
      isLeaf: map['IsLeaf'],
      grade: map['Grade'],
      inactive: map['Inactive'],
      editMode: map['EditMode'],
      expanded: map['Expanded'],
      isAll: map['IsAll'],
      sortOrder: map['SortOrder'],
      listChild: map['ListChild'],
    );
  }

  String toJson() => json.encode(toMap());

  factory InventoryItemCategory.fromJson(String source) =>
      InventoryItemCategory.fromMap(json.decode(source));

  /// 
  /// Có item con hay không?
  /// [Return true]: nếu có con
  /// 
  bool isNotEmptyChild() {
    return this.listChild?.isEmptyOrNull == false;
  }
  
}
