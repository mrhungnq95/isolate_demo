import 'dart:convert';
import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/enums/enum_inventory_item_sort_by.dart';
import 'package:MShopManager/enums/enum_inventory_item_state.dart';
import 'package:MShopManager/enums/enum_inventory_item_view_type.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/inventory_item/inventory_item_category.dart';

/// Dữ liệu màn hình filter
class ListInventoryItemFilterSetting {

  // Xem theo: Hàng hóa, Mẫu mã
  /// TODO - VNLONG - Mới bổ sung type này Service chưa đáp ứng
  EInventoryItemViewType viewType;

  /// Sort Type
  EInventoryItemSortType sortType;

  // Chi nhánh xem
  Branch branch;

  // Nhóm hàng hóa
  InventoryItemCategory inventoryItemCategory;

  // Trạng thái: Đang kinh doanh, ngừng kinh doanh
  EInventoryItemState state;
  ListInventoryItemFilterSetting({
    this.viewType,
    this.sortType,
    this.branch,
    this.inventoryItemCategory,
    this.state,
  });

  /// Khởi tạo giá trị mặc định
  factory ListInventoryItemFilterSetting.newDefault({Branch branchDefault}) {
    ListInventoryItemFilterSetting param = ListInventoryItemFilterSetting();
    param.branch = branchDefault;
    param.viewType = EInventoryItemViewType.models; 
    param.inventoryItemCategory = InventoryItemCategory(
        itemCategoryName: 'Tất cả',
        inventoryItemCategoryID: AppConstant.UUID_EMPTY);
    param.state = EInventoryItemState.all;
    param.sortType = EInventoryItemSortType.name;
    return param;
  }

  ListInventoryItemFilterSetting copyWith({
    EInventoryItemViewType viewType,
    EInventoryItemSortType sortType,
    Branch branch,
    InventoryItemCategory inventoryItemCategory,
    EInventoryItemState state,
  }) {
    return ListInventoryItemFilterSetting(
      viewType: viewType ?? this.viewType,
      sortType: sortType ?? this.sortType,
      branch: branch ?? this.branch,
      inventoryItemCategory:
          inventoryItemCategory ?? this.inventoryItemCategory,
      state: state ?? this.state,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'viewType': viewType.value,
      'sortType': sortType.value,
      'branch': branch?.toMap(),
      'inventoryItemCategory': inventoryItemCategory?.toMap(),
      'state': state.value,
    };
  }

  factory ListInventoryItemFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ListInventoryItemFilterSetting(
      viewType: EInventoryItemViewTypeExt.valueOf(map['viewType']),
      sortType: EInventoryItemSortTypeExt.valueOf(map['sortType']),
      branch: Branch.fromMap(map['branch']),
      inventoryItemCategory:
          InventoryItemCategory.fromMap(map['inventoryItemCategory']),
      state: EInventoryItemStateExt.valueOf(map['state']),
    );
  }

  String toJson() => json.encode(toMap());
  factory ListInventoryItemFilterSetting.fromJson(String source) =>
      ListInventoryItemFilterSetting.fromMap(json.decode(source));
}
