import 'dart:convert';

class UnitConvert {
  int editMode;
  // mã đơn vị chuyển đổi
  String unitConvertID;
  // mã hàng hóa
  String inventoryItemID;
  // mã đơn vị chuyển đổi
  String unitID;
  // tỉ lệ chuyển đổi
  double convertRate;
  // toán tử chuyển đổi
  String convertRateOperator;
  // mô tả
  String description;
  // giá bán nếu dùng đơn vị tính
  double salePrice;
  // giá mua nếu dùng đơn vị tính
  double costPrice;
  // thứ tự
  int sortOrder;
  // mặc định là giá nhập
  bool isCostUnit;
  // mặc định là đơn vị bán
  bool isSaleUnit;
  // Có là đơn vị mặc định hay không
  bool isBaseUnit;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String unitName;

  UnitConvert();

  Map<String, dynamic> toMap() {
    return {
      'EditMode': editMode,
      // mã đơn vị chuyển đổi
      'UnitConvertID': unitConvertID,
      // mã hàng hóa
      'InventoryItemID': inventoryItemID,
      // mã đơn vị chuyển đổi
      'UnitID': unitID,
      // tỉ lệ chuyển đổi
      'ConvertRate': convertRate,
      // toán tử chuyển đổi
      'ConvertRateOperator': convertRateOperator,
      // mô tả
      'Description': description,
      // giá bán nếu dùng đơn vị tính
      'SalePrice': salePrice,
      // giá mua nếu dùng đơn vị tính
      'CostPrice': costPrice,
      // thứ tự
      'SortOrder': sortOrder,
      // mặc định là giá nhập
      'IsCostUnit': isCostUnit,
      // mặc định là đơn vị bán
      'IsSaleUnit': isSaleUnit,
      // Có là đơn vị mặc định hay không
      'IsBaseUnit': isBaseUnit,
      'CreatedDate': createdDate,
      'CreatedBy': createdBy,
      'ModifiedDate': modifiedDate,
      'ModifiedBy': modifiedBy,
      'UnitName': unitName,
    };
  }

  factory UnitConvert.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return UnitConvert()
      ..editMode = map['EditMode']
      // mã đơn vị chuyển đổi
      ..unitConvertID = map['UnitConvertID']
      // mã hàng hóa
      ..inventoryItemID = map['InventoryItemID']
      // mã đơn vị chuyển đổi
      ..unitID = map['UnitID']
      // tỉ lệ chuyển đổi
      ..convertRate = map['ConvertRate']
      // toán tử chuyển đổi
      ..convertRateOperator = map['ConvertRateOperator']
      // mô tả
      ..description = map['Description']
      // giá bán nếu dùng đơn vị tính
      ..salePrice = map['SalePrice']
      // giá mua nếu dùng đơn vị tính
      ..costPrice = map['CostPrice']
      // thứ tự
      ..sortOrder = map['SortOrder']
      // mặc định là giá nhập
      ..isCostUnit = map['IsCostUnit']
      // mặc định là đơn vị bán
      ..isSaleUnit = map['IsSaleUnit']
      // Có là đơn vị mặc định hay không
      ..isBaseUnit = map['IsBaseUnit']
      ..createdDate = map['CreatedDate']
      ..createdBy = map['CreatedBy']
      ..modifiedDate = map['ModifiedDate']
      ..modifiedBy = map['ModifiedBy']
      ..unitName = map['UnitName'];
  }

  String toJson() => json.encode(toMap());
}
