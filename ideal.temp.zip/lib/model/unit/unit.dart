import 'dart:convert';

class Unit {
  String unitID;
  String unitName;
  String description;
  bool inactive;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;

  // region Trường tạm không map
  bool isSelected = false;
  // endregion

  Unit();

  Map<String, dynamic> toMap() {
    return {
      'UnitID': unitID,
      'UnitName': unitName,
      'Description': description,
      'Inactive': inactive,
      'CreatedDate': createdDate,
      'CreatedBy': createdBy,
      'ModifiedDate': modifiedDate,
      'ModifiedBy': modifiedBy,
    };
  }

  factory Unit.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return Unit()
      ..unitID = map['UnitID']
      ..unitName = map['UnitName']
      ..description = map['Description']
      ..inactive = map['Inactive']
      ..createdDate = map['CreatedDate']
      ..createdBy = map['CreatedBy']
      ..modifiedDate = map['ModifiedDate']
      ..modifiedBy = map['ModifiedBy'];
  }

  String toJson() => json.encode(toMap());

}
