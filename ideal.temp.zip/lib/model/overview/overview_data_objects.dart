import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:flutter/foundation.dart';

import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/enums/enum_overview_view_type.dart';
import 'package:MShopManager/model/overview/abstract_overview_data_object.dart';
import 'package:MShopManager/model/overview/cash_receipt_status_day.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/model/overview/invoice_today.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/model/report_compare_result.dart';

class OverviewHeaderObject extends OverviewDataObject {
  List<OverviewHeaderMasterObject> childList;
  OverviewHeaderObject({
    this.childList,
  });

  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.header;
  }
}

class OverviewHeaderMasterObject {
  String imageAsset;
  OverviewSheetHeaderDataObject header;

  List<ValuePropertyObject> childList;

  OverviewHeaderMasterObject({
    this.imageAsset,
    this.header,
    this.childList,
  });
}

class OverviewChartObject extends OverviewDataObject {
  final CashReceiptStatusDay cashReceiptStatusDay;
  ReportCompareResult diff;
  OverviewChartObject(
      {@required this.cashReceiptStatusDay, @required this.diff});

  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.chart;
  }
}

class OverviewQuickActionObject extends OverviewDataObject {
  final List<QuickActionItem> quickActionList;

  OverviewQuickActionObject(this.quickActionList);

  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.quick_action;
  }
}

class OverviewTitleNValueObject extends OverviewDataObject {
  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.title_n_value;
  }

  String imageAssets;
  String title;
  String description;
  String value;

  EOverviewSheetType viewType;

  ReportCompareResult diff;

  OverviewTitleNValueObject(
      {this.viewType,
      this.imageAssets,
      this.title,
      this.description,
      this.value,
      this.diff});
}

class OverviewTitleNListValueObject extends OverviewDataObject {
  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.title_n_list_value;
  }

  String imageAssets;
  String title;
  String description;
  String value;

  List<ValuePropertyObject> childList = [];

  EOverviewSheetType viewType;

  OverviewTitleNListValueObject(
      {this.imageAssets,
      this.viewType,
      this.title,
      this.description,
      this.value,
      @required this.childList});
}

class OverviewOrderNCustomerObject extends OverviewDataObject {
  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.order_n_customer;
  }

  String orderQuantity;
  ReportCompareResult orderDiff;
  InvoiceToday invoiceToday;

  String customerQuantity;
  ReportCompareResult customerDiff;
  CustomerToday customerToday;

  OverviewOrderNCustomerObject(
      {this.orderQuantity,
      this.orderDiff,
      this.invoiceToday,
      this.customerQuantity,
      this.customerDiff,
      this.customerToday});
}

class OverviewInventoryItemInStoreObject extends OverviewDataObject {
  @override
  EOverviewDrawViewType provideViewType() {
    return EOverviewDrawViewType.inventory_item_in_store;
  }

  String inventoryItemQuantity;
  String inventoryItemAmount;

  OverviewInventoryItemInStoreObject(
      {this.inventoryItemQuantity, this.inventoryItemAmount});
}
