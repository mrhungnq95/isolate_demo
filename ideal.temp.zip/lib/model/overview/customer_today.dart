class CustomerToday {
  double totalAmountCustomer = 0;
  double quantity = 0;
  double previousPeriodQuantity = 0;
  double previousPeriodTotalCustomer = 0;
}
