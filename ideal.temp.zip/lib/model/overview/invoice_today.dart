class InvoiceToday {
  //tổng tiền hóa đơn
  double totalInvoiceAmount;
  double previousPeriodTotalInvoiceAmount;

  //tổng tiền tại cửa hàng
  double totalInStoreAmount;
  double previousPeriodTotalInStoreAmount;

  //tổng số hóa đơn tại cửa hàng
  double totalInStoreQuantity;
  double previousPeriodTotalInStoreQuantity;

  //tổng tiền giao hàng
  double totalDeliveryAmount;
  double previousPeriodTotalDeliveryAmount;

  //tổng số hóa đơn giao hàng
  double totalDeliveryQuantity;
  double previousPeriodTotalDeliveryQuantity;

  //chờ thanh toán
  double waitingPayAmount;
  double previousPeriodWaitingPayAmount;

  //đã thanh toán
  double paidAmount;
  double previousPeriodPaidAmount;

  //đã hủy
  double cancelInStoreAmount;
  double cancelInStoreQuantity;
  double previousPeriodCancelInStoreAmount;

  //chưa giao
  double pendingDeliveryAmount;
  double pendingDeliveryQuantity;
  double previousPeriodPendingDeliveryAmount;

  //chờ thu cod
  double pendingReceiveCODAmount;
  double pendingReceiveCODQuantity;
  double previousPeriodPendingReceiveCODAmount;

  //đang giao
  double deliveringAmount;
  double deliveringQuantity;
  double previousPeriodDeliveringAmount;

  //đã hoàn thành
  double deliveredAmount;
  double deliveredQuantity;
  double previousPeriodDeliveredAmount;

  //thất bại
  double failedAmount;
  double failedQuantity;
  double previousPeriodFailedAmount;

  //chuyển khoản
  double reTransferAmount;
  double reTransferQuantity;
  double previousPeriodReTransferAmount;

  //đã hủy
  double cancelDeliveryAmount;
  double cancelDeliveryQuantity;
  double previousPeriodCancelDeliveryAmount;

  double getTotalQuantityInvoice() {
    return (totalInStoreQuantity ?? 0) + (totalDeliveryQuantity ?? 0);
  }

  double getPreviousPeriodTotalQuantityInvoice() {
    return (previousPeriodTotalInStoreQuantity ?? 0) +
        (previousPeriodTotalDeliveryQuantity ?? 0);
  }
}
