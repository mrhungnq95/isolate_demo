import 'dart:convert';

import 'package:MShopManager/enums/enum_report_item_code.dart';

class ReportDailyItem {
  EReportItemCode code;
  int group;
  String name;
  num quantity;
  num totalAmount;
  num previousPeriodTotalAmount;
  num previousPeriodQuantity;

  ReportDailyItem({
    this.code,
    this.group,
    this.name,
    this.quantity,
    this.totalAmount,
    this.previousPeriodTotalAmount,
    this.previousPeriodQuantity,
  });

  ReportDailyItem copyWith({
    EReportItemCode code,
    int group,
    String name,
    num quantity,
    num totalAmount,
    num previousPeriodTotalAmount,
    num previousPeriodQuantity,
  }) {
    return ReportDailyItem(
      code: code ?? this.code,
      group: group ?? this.group,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      totalAmount: totalAmount ?? this.totalAmount,
      previousPeriodTotalAmount:
          previousPeriodTotalAmount ?? this.previousPeriodTotalAmount,
      previousPeriodQuantity:
          previousPeriodQuantity ?? this.previousPeriodQuantity,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'Code': code.rawValue,
      'Group': group,
      'Name': name,
      'Quantity': quantity,
      'TotalAmount': totalAmount,
      'PreviousPeriodTotalAmount': previousPeriodTotalAmount,
      'PreviousPeriodQuantity': previousPeriodQuantity,
    };
  }

  factory ReportDailyItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ReportDailyItem(
      code: EReportItemCodeExt.valueOf(map['Code']),
      group: map['Group'],
      name: map['Name'],
      quantity: map['Quantity']?.toDouble() ?? 0.0,
      totalAmount: map['TotalAmount']?.toDouble() ?? 0.0,
      previousPeriodTotalAmount: map['PreviousPeriodTotalAmount'],
      previousPeriodQuantity: map['PreviousPeriodQuantity'],
    );
  }

  String toJson() => json.encode(toMap());

  factory ReportDailyItem.fromJson(String source) =>
      ReportDailyItem.fromMap(json.decode(source));

  @override
  String toString() {
    return 'ReportDailyItem(code: $code, group: $group, name: $name, quantity: $quantity, totalAmount: $totalAmount, previousPeriodTotalAmount: $previousPeriodTotalAmount, previousPeriodQuantity: $previousPeriodQuantity)';
  }

  @override
  bool operator ==(Object o) {
    if (identical(this, o)) return true;

    return o is ReportDailyItem &&
        o.code == code &&
        o.group == group &&
        o.name == name &&
        o.quantity == quantity &&
        o.totalAmount == totalAmount &&
        o.previousPeriodTotalAmount == previousPeriodTotalAmount &&
        o.previousPeriodQuantity == previousPeriodQuantity;
  }

  @override
  int get hashCode {
    return code.hashCode ^
        group.hashCode ^
        name.hashCode ^
        quantity.hashCode ^
        totalAmount.hashCode ^
        previousPeriodTotalAmount.hashCode ^
        previousPeriodQuantity.hashCode;
  }
}
