import 'dart:convert';

import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

class OverViewChainFilterSettings {
  EReportPeriodType type;

  /// Thời gian, ngày tháng của kì báo cáo [EReportPeriodType]
  /// [dateRange.startDate] thời gian bắt đầu
  /// [dateRange.endDate] thời gian kết thúc
  ///
  DateRange dateRange;

  /// Thời gian Lấy báo của device
  DateTime fetchReportDateTime;

  OverViewChainFilterSettings({
    this.type,
    this.dateRange,
    this.fetchReportDateTime,
  });

  factory OverViewChainFilterSettings.newDefault() {
    return OverViewChainFilterSettings();
  }

  Map<String, dynamic> toMap() {
    return {
      'type': type?.rawValue,
      'dateRange': dateRange?.toMap(),
      'fetchReportDateTime': fetchReportDateTime?.millisecondsSinceEpoch,
    };
  }

  factory OverViewChainFilterSettings.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return OverViewChainFilterSettings(
      type: EReportPeriodTypeExt.valueOf(map['type']),
      dateRange: DateRange.fromMap(map['dateRange']),
      fetchReportDateTime:
          DateTime.fromMillisecondsSinceEpoch(map['fetchReportDateTime']),
    );
  }

  String toJson() => json.encode(toMap());

  factory OverViewChainFilterSettings.fromJson(String source) =>
      OverViewChainFilterSettings.fromMap(json.decode(source));
}
