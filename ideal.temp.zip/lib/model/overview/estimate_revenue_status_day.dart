class EstimateRevenueStatusDay {
  //Doanh thu ước tính
  double estimateRevenue;
  double previousPeriodEstimateRevenue;

  // --->*** Thông tin hoá đơn đã thanh toán
  // SL hoá đơn đã thanh toán: Thanh toán + nợ + Thu hộ
  double totalInvoicePaidQuantity;

  // Tổng tiền thu được
  double totalInvoicePaidAmount;
  double previousPeriodTotalInvoicePaidAmount;

  //Đã thu được tiền
  double paidAmount;
  double previousPeriodPaidAmount;
  // Số lượng hóa đơn thanh toán
  double invoicePaidQuantity;
  double previousPeriodTotalInvoicePaidQuantity;

  //Khách nợ
  double debtAmount;
  double debtQuantity;
  double previousPeriodDebtAmount;

  // Thu hộ
  double rentCollectorAmount;
  double rentCollectorQuantity;
  double previousPeriodRentCollectorAmount;

  // <---*** Thông tin hoá đơn đã thanh toán

  // --->*** Thông tin hoá đơn chờ xử lý
  //Hóa đơn đang xử lý
  double totalInvoiceProcessingAmount;
  double previousPeriodTotalInvoiceProcessingAmount;

  //Số lượng hóa đơn đang xử lý
  double totalInvoiceProcessingQuantity;
  double previousPeriodTotalInvoiceProcessingQuantity;

  //Chờ thanh toán
  double waitingPayAmount;
  double waitingPayQuantity;
  double previousPeriodWaitingPayAmount;

  //Chưa giao hàng
  double pendingDeliveryAmount;
  double pendingDeliveryQuantity;
  double previousPeriodPendingDeliveryAmount;

  //Đang giao hàng
  double deliveringAmount;
  double deliveringQuantity;
  double previousPeriodDeliveringAmount;

  ///
  /// Tính tổng số hoá đơn đã thanh toán
  /// Created by NQHung
  ///
  void updateTotalInvoicePaidQuantity() {
    totalInvoicePaidQuantity = invoicePaidQuantity ?? 0;
    totalInvoicePaidQuantity +=
        debtQuantity ?? 0 + (rentCollectorQuantity ?? 0);
  }
}
