import 'package:MShopManager/enums/enum_overview_child_view_type.dart';

abstract class OverviewSheetChildDataObject {
  EOverviewChildViewType provideViewType();
}