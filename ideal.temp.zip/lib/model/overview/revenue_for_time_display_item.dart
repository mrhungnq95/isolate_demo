import 'dart:convert';

class RevenueForTimeDisplayItem {
  String timeName; // Thời gian
  double totalAmount; // Giá trị tương ứng với thời gian
  RevenueForTimeDisplayItem({
    this.timeName,
    this.totalAmount,
  });

  Map<String, dynamic> toMap() {
    return {
      'TimeName': timeName,
      'TotalAmount': totalAmount,
    };
  }

  factory RevenueForTimeDisplayItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return RevenueForTimeDisplayItem(
      timeName: map['TimeName'],
      totalAmount: map['TotalAmount'],
    );
  }

  String toJson() => json.encode(toMap());

  factory RevenueForTimeDisplayItem.fromJson(String source) =>
      RevenueForTimeDisplayItem.fromMap(json.decode(source));
}
