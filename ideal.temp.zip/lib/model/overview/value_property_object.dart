class ValuePropertyObject {
  String title;
  String amount;
  String quantity;

  ValuePropertyObject({this.title, this.amount, this.quantity});
}
