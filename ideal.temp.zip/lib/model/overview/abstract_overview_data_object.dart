import 'package:MShopManager/enums/enum_overview_view_type.dart';

abstract class OverviewDataObject {
  EOverviewDrawViewType provideViewType();
}
