import 'dart:convert';

class ReportBranchItem {
  String branchName;
  String branchId;

  double totalInvoice;

  double totalAmount;

  double totalAmountYesterday;

  double totalAmountLastWeek;

  ReportBranchItem({
    this.branchName,
    this.branchId,
    this.totalInvoice,
    this.totalAmount,
    this.totalAmountYesterday,
    this.totalAmountLastWeek,
  });

  Map<String, dynamic> toMap() {
    return {
      'branchName': branchName,
      'branchId': branchId,
      'totalInvoice': totalInvoice,
      'totalAmount': totalAmount,
      'totalAmountYesterday': totalAmountYesterday,
      'totalAmountLastWeek': totalAmountLastWeek,
    };
  }

  factory ReportBranchItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ReportBranchItem(
      branchName: map['branchName'],
      branchId: map['branchId'],
      totalInvoice: map['totalInvoice'],
      totalAmount: map['totalAmount'],
      totalAmountYesterday: map['totalAmountYesterday'],
      totalAmountLastWeek: map['totalAmountLastWeek'],
    );
  }

  String toJson() => json.encode(toMap());

  factory ReportBranchItem.fromJson(String source) =>
      ReportBranchItem.fromMap(json.decode(source));
}
