class CashReceiptStatusDay {
    //tổng tiền thu trong ngày
    double receiptAmountInDay;
    double previousPeriodReceiptAmountInDay;
    
    //tổng tiền mặt
    double totalCashAmount;
    double previousPeriodTotalCashAmount;
    
    //tồng tiền thẻ
    double totalCardAmount;
    double previousPeriodTotalCardAmount;
    
    //tổng tiền voucher
    double totalVoucherAmount;
    double previousPeriodTotalVoucherAmount;
    
    //tổng tiền chuyển khoản
    double totalTransferAmount;
    double previousPeriodTotalTransferAmount;
    
    //bán hàng
    double saleTotalAmount;
    double previousPeriodSaleTotalAmount;
    double saleCashAmount;
    double previousPeriodSaleCashAmount;
    double saleCardAmount;
    double previousPeriodSaleCardAmount;
    double saleVoucherAmount;
    double previousPeriodSaleVoucherAmount;
    double saleTransferAmount;
    double previousPeriodSaleTransferAmount;
    
    //thu nợ
    double receiptTotalAmount;
    double previousPeriodReceiptTotalAmount;
    double receiptCashAmount;
    double previousPeriodReceiptCashAmount;
    double receiptCardAmount;
    double previousPeriodReceiptCardAmount;
    double receiptTransferAmount;
    double previousPeriodReceiptTransferAmount;
    
    //khách đặt cọc
    double depositTotalAmount;
    double previousPeriodDepositTotalAmount;
    double depositCashAmount;
    double previousPeriodDepositCashAmount;
    double depositCardAmount;
    double previousPeriodDepositCardAmount;
    double depositTransferAmount;
    double previousPeriodDepositTransferAmount;
    double otherTransferAmount;
    double previousPeriodOtherTransferAmount;
    double otherCashAmount;
    double previousPeriodOtherCashAmount;
    
    // Thu khác
    double totalOtherAmount;
    double previousPeriodTotalOtherAmount;
}