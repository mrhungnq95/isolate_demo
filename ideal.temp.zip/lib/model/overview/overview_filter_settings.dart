import 'dart:convert';

import 'package:MShopManager/enums/enum_branch_filter.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/model/period_filter_object.dart';

class OverViewFilterSettings {
  List<String> branchIdList;
  EOverviewBranchFilter eBranchSelected;

  /// Kỳ thời gian: Ngày, Tuần, Tháng, Tuỳ chọn
  EDateFilterType eDateFilterType = EDateFilterType.day;

  /// Khoảng thời gian để lấy báo cáo
  ItemPeriodFilterObject periodReport;

  /// Khoảng thời gian để compare với khoảng thời gian lấy báo cáo
  ItemPeriodFilterObject previuosPeriodReport;

  /// Thời gian Lấy báo của device
  DateTime fetchReportDateTime;

  OverViewFilterSettings({
    this.branchIdList,
    this.eBranchSelected,
    this.eDateFilterType,
    this.periodReport,
    this.previuosPeriodReport,
    this.fetchReportDateTime,
  });

  Map<String, dynamic> toMap() {
    return {
      'branchIdList': branchIdList,
      'eBranchSelected': eBranchSelected.rawValue,
      'eDateFilterType': eDateFilterType.rawValue,
      'periodReport': periodReport?.toMap(),
      'previuosPeriodReport': previuosPeriodReport?.toMap(),
      'fetchReportDateTime': fetchReportDateTime.millisecondsSinceEpoch
    };
  }

  factory OverViewFilterSettings.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return OverViewFilterSettings(
        branchIdList: map['branchIdList'] != null
            ? List<String>.from(map['branchIdList'])
            : null,
        eBranchSelected:
            EOverviewBranchFilterExt.valueOf(map['eBranchSelected']),
        eDateFilterType: EDateFilterTypeExt.valueOf(map['eDateFilterType']),
        periodReport: ItemPeriodFilterObject.fromMap(map['periodReport']),
        previuosPeriodReport:
            ItemPeriodFilterObject.fromMap(map['previuosPeriodReport']),
        fetchReportDateTime:
            DateTime.fromMillisecondsSinceEpoch(map['fetchReportDateTime']));
  }

  String toJson() => json.encode(toMap());

  factory OverViewFilterSettings.fromJson(String source) =>
      OverViewFilterSettings.fromMap(json.decode(source));
}
