import 'package:MShopManager/enums/enum_overview_child_view_type.dart';
import 'package:MShopManager/model/overview/abstract_overview_sheet_child_data_object.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/model/report_compare_result.dart';

class OverviewSheetHeaderDataObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.headerView;
  }

  String title;
  String amount;
  ReportCompareResult diff;

  String totalAmount;

  OverviewSheetHeaderDataObject(
      {this.title, this.amount, this.diff, this.totalAmount});
}

class ExpandedChildObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.sectionExpandedChildView;
  }

  String imageAssets;
  String titleSection;
  String totalAmount;
  String totalQuantity;

  List<ValuePropertyObject> childList = [];

  ExpandedChildObject(
      {this.imageAssets,
      this.titleSection,
      this.totalAmount,
      this.totalQuantity,
      this.childList});
}

class GroupPaymentTypeObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.sectionGroupPaymentTypeView;
  }

  List<ValuePropertyObject> childList = [];

  GroupPaymentTypeObject({this.childList});
}

class IncomingMoneyObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.sectionIncomingMoneyView;
  }

  String imageAssets;
  String titleSection;
  String totalAmount;

  List<ValuePropertyObject> childList = [];

  IncomingMoneyObject(
      {this.imageAssets, this.titleSection, this.totalAmount, this.childList});
}

class CustomerMoneyObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.sectionCustomerTypeView;
  }

  String customerName;
  String customerCode;
  String date;
  String totalAmount;

  CustomerMoneyObject(
      {this.customerName, this.customerCode, this.date, this.totalAmount});
}

class OrderTypeObject extends OverviewSheetChildDataObject {
  @override
  EOverviewChildViewType provideViewType() {
    return EOverviewChildViewType.sectionExpandOrderTypeView;
  }

  String imageAssets;
  String titleSection;
  String totalAmount;
  List<ValuePropertyObject> childList = [];

  OrderTypeObject(
      {this.imageAssets, this.titleSection, this.totalAmount, this.childList});
}

class OverviewSheetChildDataWrapper {
  OverviewSheetHeaderDataObject headerObject;
  List<OverviewSheetChildDataObject> childObject;

  OverviewSheetChildDataWrapper(this.headerObject, this.childObject);
}
