class InstockToday {
  double totalAmount = 0;
  double quantity = 0;
  double previousPeriodTotalAmount = 0;
  double previousPeriodQuantity = 0;
}
