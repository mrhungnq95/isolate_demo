import 'package:MShopManager/model/service/login_response.dart';
import 'package:MShopManager/model/service/login_error_response.dart';

class LoginResultWrapper {
  LoginResponse loginResponse;
  LoginErrorResponse loginErrorResponse;
  bool isContinue;

  LoginResultWrapper(
      {this.loginResponse, this.loginErrorResponse, this.isContinue});
}
