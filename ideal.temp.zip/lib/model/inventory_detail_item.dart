class InvoiceDetailItem {
  String itemName;
  double unitPrice;
  double quantity;
  double amount;

  InvoiceDetailItem(
      {this.itemName, this.unitPrice, this.quantity, this.amount});
}
