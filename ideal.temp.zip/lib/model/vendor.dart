import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

/// Nhà cung cấp
class Vendor {
  String vendorID;
  int type;
  String vendorCode;
  String vendorName;
  int vendorType;
  String address;
  String taxCode;
  String tel;
  String fax;
  String email;
  double maximizeDebtAmount;
  int dueTime;
  String vendorCategoryID;
  String bankAccount;
  String bankName;
  String bankBranchName;
  String contactName;
  String contactPrefix;
  String contactTitle;
  String contactAddress;
  String contactTel;
  String contactEmail;
  String identificationNumber;
  String issueBy;
  DateTime issueDate;
  bool inactive;
  String listService;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String vendorCategoryName;
  bool isSystem;
  bool isConnected;
  String oCMPartnerID;
  String website;
  int editMode;

  Vendor(
      {this.vendorID,
      this.type,
      this.vendorCode,
      this.vendorName,
      this.vendorType,
      this.address,
      this.taxCode,
      this.tel,
      this.fax,
      this.email,
      this.maximizeDebtAmount,
      this.dueTime,
      this.vendorCategoryID,
      this.bankAccount,
      this.bankName,
      this.bankBranchName,
      this.contactName,
      this.contactPrefix,
      this.contactTitle,
      this.contactAddress,
      this.contactTel,
      this.contactEmail,
      this.identificationNumber,
      this.issueBy,
      this.issueDate,
      this.inactive,
      this.listService,
      this.createdDate,
      this.createdBy,
      this.modifiedDate,
      this.modifiedBy,
      this.vendorCategoryName,
      this.isSystem,
      this.isConnected,
      this.oCMPartnerID,
      this.website,
      this.editMode});

  Map<String, dynamic> toMap() {
    return {
      'VendorID': vendorID,
      'Type': type,
      'VendorCode': vendorCode,
      'VendorName': vendorName,
      'VendorType': vendorType,
      'Address': address,
      'TaxCode': taxCode,
      'Tel': tel,
      'Fax': fax,
      'Email': email,
      'MaximizeDebtAmount': maximizeDebtAmount,
      'DueTime': dueTime,
      'VendorCategoryID': vendorCategoryID,
      'BankAccount': bankAccount,
      'BankName': bankName,
      'BankBranchName': bankBranchName,
      'ContactName': contactName,
      'ContactPrefix': contactPrefix,
      'ContactTitle': contactTitle,
      'ContactAddress': contactAddress,
      'ContactTel': contactTel,
      'ContactEmail': contactEmail,
      'IdentificationNumber': identificationNumber,
      'IssueBy': issueBy,
      'IssueDate': DateTimeFormatHelper.formatDate2String(issueDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'Inactive': inactive,
      'ListService': listService,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'VendorCategoryName': vendorCategoryName,
      'IsSystem': isSystem,
      'IsConnected': isConnected,
      'OCMPartnerID': oCMPartnerID,
      'Website': website,
      'EditMode': editMode,
    };
  }

  factory Vendor.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Vendor(
      vendorID: map['VendorID'],
      type: map['Type'],
      vendorCode: map['VendorCode'],
      vendorName: map['VendorName'],
      vendorType: map['VendorType'],
      address: map['Address'],
      taxCode: map['TaxCode'],
      tel: map['Tel'],
      fax: map['Fax'],
      email: map['Email'],
      maximizeDebtAmount: map['MaximizeDebtAmount'],
      dueTime: map['DueTime'],
      vendorCategoryID: map['VendorCategoryID'],
      bankAccount: map['BankAccount'],
      bankName: map['BankName'],
      bankBranchName: map['BankBranchName'],
      contactName: map['ContactName'],
      contactPrefix: map['ContactPrefix'],
      contactTitle: map['ContactTitle'],
      contactAddress: map['ContactAddress'],
      contactTel: map['ContactTel'],
      contactEmail: map['ContactEmail'],
      identificationNumber: map['IdentificationNumber'],
      issueBy: map['IssueBy'],
      issueDate: DateTimeFormatHelper.parseString2Date(map['IssueDate']),
      inactive: map['Inactive'],
      listService: map['ListService'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      vendorCategoryName: map['VendorCategoryName'],
      isSystem: map['IsSystem'],
      isConnected: map['IsConnected'],
      oCMPartnerID: map['OCMPartnerID'],
      website: map['Website'],
      editMode: map['EditMode'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Vendor.fromJson(dynamic source) => Vendor.fromMap(json.decode(source));
}
