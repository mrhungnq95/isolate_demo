import 'dart:convert';

//
// Created by nqhung on 09/11/2020.
//

class RevenueInventoryItems {
  String inventoryItemName;

  String inventoryItemID;

  String unitName;

  double totalAmount;

  double quantity;

  bool isInventoryItem;

  List<RevenueInventoryItems> inventoryItemsList;

  RevenueInventoryItems({
    this.inventoryItemName,
    this.inventoryItemID,
    this.unitName,
    this.totalAmount,
    this.quantity,
    this.isInventoryItem,
    this.inventoryItemsList,
  });

  // static List<RevenueInventoryItems> _dataFromJson<RevenueInventoryItems>(
  //     Object json) {
  //   if (json is List) {
  //     return json
  //         .map((e) => RevenueInventoryItems.fromJson(e as Map<String, dynamic>))
  //         .toList();
  //   }
  //
  //   throw ArgumentError.value(
  //     json,
  //     'json',
  //     'Cannot convert the provided data.',
  //   );
  // }

  Map<String, dynamic> toMap() {
    return {
      'InventoryItemName': inventoryItemName,
      'InventoryItemID': inventoryItemID,
      'UnitName': unitName,
      'TotalAmount': totalAmount,
      'Quantity': quantity,
      'IsInventoryItem': isInventoryItem,
      'InventoryItems:': inventoryItemsList?.map((x) => x?.toMap())?.toList(),
    };
  }

  factory RevenueInventoryItems.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return RevenueInventoryItems(
        inventoryItemName: map['InventoryItemName'],
        inventoryItemID: map['InventoryItemID'],
        unitName: map['UnitName'],
        totalAmount: map['TotalAmount'],
        quantity: map['Quantity'],
        isInventoryItem: map['IsInventoryItem'],
        inventoryItemsList: map['InventoryItems']
            ?.map<RevenueInventoryItems>(
                (x) => RevenueInventoryItems.fromMap(x))
            ?.toList());
  }

  String toJson() => json.encode(toMap());

  factory RevenueInventoryItems.fromJson(String source) =>
      RevenueInventoryItems.fromMap(json.decode(source));
}
