import 'dart:convert';

import 'package:MShopManager/model/inventory_item/inventory_item.dart';
// 
/// Result Lấy ds hàng hóa
/// 
class GetListInventoryItemResponse {

  List<InventoryItem> listInventoryItem = [];
  int total = 0;
  
  GetListInventoryItemResponse({
    this.listInventoryItem,
    this.total,});


}
