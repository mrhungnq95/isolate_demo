import 'dart:convert';

///
/// Param lấy danh sách thông báo
/// 
class ListNofiticationParam {
  int pageIndex = 1;
  int pageSize = 20;

  ListNofiticationParam();

  Map<String, dynamic> toMap() {
    return {
      'PageIndex': pageIndex,
      'PageSize': pageSize,
    };
  }

  factory ListNofiticationParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ListNofiticationParam();
  }

  String toJson() => json.encode(toMap());

  factory ListNofiticationParam.fromJson(String source) =>
      ListNofiticationParam.fromMap(json.decode(source));
}