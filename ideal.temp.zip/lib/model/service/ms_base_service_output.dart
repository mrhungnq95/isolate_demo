//
// Created by nqhung on 09/11/2020.
//

import 'package:MShopManager/utils/misa_common.dart';

class MSOutputService<T> {
  int code;

  int total;

  bool success;

  int errorType;

  String primaryKeyValue;

  String tokenPage;

  String errorMessage;

  List<T> data;

  dynamic summaryData;

  MSOutputService(
      {this.code,
      this.total,
      this.success,
      this.errorType,
      this.primaryKeyValue,
      this.tokenPage,
      this.errorMessage,
      this.data,
      this.summaryData});

  bool hasData() {
    return data != null && data.isNotEmpty;
  }

  T first() {
    return data?.first;
  }

  factory MSOutputService.fromJson(
      Map<String, dynamic> json, Function decodeDataObject) {
    var data = List<T>();

    final dataMap = json['Data'];

    if (!MISACommon.isNullOrEmpty(dataMap)) {
      if (dataMap is List) {
        json['Data'].forEach((v) {
          final item = decodeDataObject?.call(v);
          if (item != null) {
            data.add(item);
          }
        });
      } else {
        final item = decodeDataObject?.call(dataMap);
        if (item != null) {
          data.add(item);
        }
      }
    }

    return MSOutputService<T>(
        code: json["Code"],
        total: json["Total"],
        success: json["Success"],
        errorType: json["ErrorType"],
        primaryKeyValue: json["PimaryKeyValue"],
        tokenPage: json["TokenPage"],
        errorMessage: json["ErrorMessage"],
        data: data,
        summaryData: json["SummaryData"]);
  }

  Map<String, dynamic> toJson(Function(T object) toJsonGeneric) {
    final Map<String, dynamic> output = Map<String, dynamic>();
    output['Code'] = this.code;
    output['Total'] = this.total;
    output['Success'] = this.success;
    output['ErrorType'] = this.errorType;
    output['SummaryData'] = this.summaryData;
    output['PimaryKeyValue'] = this.primaryKeyValue;
    output['TokenPage'] = this.tokenPage;
    output['ErrorMessage'] = this.errorMessage;

    if (this.data != null) {
      output['Data'] = this.data.map((v) => toJsonGeneric(v)).toList();
    }

    return output;
  }
}
