//
// Created by nqhung on 11/11/2020.
//

import 'package:MShopManager/model/role_permission.dart';

class GetRolesPermissionResponse {
  List<RolePermission> data;
  GetRolesPermissionResponse(this.data);
}
