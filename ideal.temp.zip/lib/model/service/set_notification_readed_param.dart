import 'dart:convert';

///
/// Param cập nhât trạng thái đã đọc của thông báo
///
class SetNotificationReadedParam {

  String userID;
  String notificationDataId;

  SetNotificationReadedParam({
    this.userID,
    this.notificationDataId,
  });

  Map<String, dynamic> toMap() {
    return {
      'UserID': userID,
      'NotificationDataId': notificationDataId,
    };
  }

  factory SetNotificationReadedParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return SetNotificationReadedParam(
      userID: map['UserID'],
      notificationDataId: map['NotificationDataId'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SetNotificationReadedParam.fromJson(String source) => SetNotificationReadedParam.fromMap(json.decode(source));
}
