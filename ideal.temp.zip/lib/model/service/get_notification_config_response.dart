import 'dart:convert';

import 'package:MShopManager/model/notification/notification_config.dart';

/// 
/// Lấy thông tin config thông báo
/// 
class GetNotificationConfigResponse {

  String userID;
  String branchID;
  NotificationConfig configContent;

  GetNotificationConfigResponse(
    this.userID,
    this.branchID,
    this.configContent
  );


  Map<String, dynamic> toMap() {
    return {
      'UserID': userID,
      'BranchID': branchID,
      'ConfigContent': configContent?.toMap(),
    };
  }

  factory GetNotificationConfigResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetNotificationConfigResponse(
      map['UserID'],
      map['BranchID'],
      NotificationConfig.fromJson(map['ConfigContent']),
    );
  }

  String toJson() => json.encode(toMap());

  factory GetNotificationConfigResponse.fromJson(String source) => GetNotificationConfigResponse.fromMap(json.decode(source));
}
