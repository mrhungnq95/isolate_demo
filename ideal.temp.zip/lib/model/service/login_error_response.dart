import 'dart:convert';

//
// Created by nqhung on 11/11/2020.
//

class LoginErrorResponse {
  String error;

  String errorDescription;
  LoginErrorResponse({
    this.error,
    this.errorDescription,
  });

  Map<String, dynamic> toMap() {
    return {
      'error': error,
      'error_description': errorDescription,
    };
  }

  factory LoginErrorResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return LoginErrorResponse(
      error: map['error'],
      errorDescription: map['error_description'],
    );
  }

  String toJson() => json.encode(toMap());

  factory LoginErrorResponse.fromJson(String source) =>
      LoginErrorResponse.fromMap(json.decode(source));
}
