import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:MShopManager/model/base/sumary_data_info.dart';
import 'package:MShopManager/model/invoice/group_invoice.dart';

/// 
/// Lấy ds thông báo
/// 
class GetListInvoiceResponse {

  List<GroupInvoice> listGroupInvoice;
  SummaryNormalData summaryData;

  GetListInvoiceResponse({
    this.listGroupInvoice,
    this.summaryData,
  });

}
