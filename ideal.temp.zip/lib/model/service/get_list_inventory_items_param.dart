import 'dart:convert';

import 'package:flutter/material.dart';

///
/// Param Lấy danh sách Hàng hóa
///
class GetListInventoryItemParam {
  
  String branchId;
  String inventoryItemCategoryID;
  String keyword;
  int orderBy;
  int filterType;
  int pageSize;
  int pageIndex;
  

  GetListInventoryItemParam({
    @required this.branchId,
    @required this.inventoryItemCategoryID,
    this.keyword = '',
    @required this.orderBy,
    @required this.filterType,
    this.pageSize = 20,
    this.pageIndex = 1,
  });
    

  Map<String, dynamic> toMap() {
    return {
      'BranchId': branchId,
      'InventoryItemCategoryID': inventoryItemCategoryID,
      'Keyword': keyword,
      'OrderBy': orderBy,
      'FilterType': filterType,
      'PageSize': pageSize,
      'PageIndex': pageIndex,
    };
  }

  factory GetListInventoryItemParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetListInventoryItemParam(
      branchId: map['BranchId'],
      inventoryItemCategoryID: map['InventoryItemCategoryID'],
      keyword: map['Keyword'],
      orderBy: map['OrderBy'],
      filterType: map['FilterType'],
      pageSize: map['PageSize'],
      pageIndex: map['PageIndex'],
    );
  }

  String toJson() => json.encode(toMap());

  factory GetListInventoryItemParam.fromJson(String source) => GetListInventoryItemParam.fromMap(json.decode(source));
} 
