import 'dart:convert';

import 'package:flutter/material.dart';

///
/// Param Lấy danh sách Category Hàng hóa
///
class GetListInventoryItemCategoryParam {
  
  int editMode;
  int page;
  int start;
  int litmit;

  GetListInventoryItemCategoryParam({
    this.editMode,
    this.page,
    this.start,
    this.litmit,
  });


  Map<String, dynamic> toMap() {
    return {
      'editMode': editMode,
      'page': page,
      'start': start,
      'litmit': litmit,
    };
  }

  factory GetListInventoryItemCategoryParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetListInventoryItemCategoryParam(
      editMode: map['editMode'],
      page: map['page'],
      start: map['start'],
      litmit: map['litmit'],
    );
  }

  String toJson() => json.encode(toMap());

  factory GetListInventoryItemCategoryParam.fromJson(String source) => GetListInventoryItemCategoryParam.fromMap(json.decode(source));
}
