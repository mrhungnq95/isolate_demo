//
// Created by nqhung on 10/11/2020.
//
import 'dart:convert';

import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:json_annotation/json_annotation.dart';

import 'package:MShopManager/model/branch.dart';

///part 'login_response.g.dart';

///@JsonSerializable()
class LoginResponse {
  ///@JsonKey(name: 'access_token')
  String accessToken;

  ///@JsonKey(name: 'token_type')
  String tokenType;

  ///@JsonKey(name: 'expires_in')
  int expriresIn;

  ///@JsonKey(name: 'refresh_token')
  String refreshToken;

  ///@JsonKey(name: 'roles')
  String roles;

  ///@JsonKey(name: 'userId')
  String userId;

  ///@JsonKey(name: 'userName')
  String userName;

  ///@JsonKey(name: 'deviceTokenId')
  String deviceTokenId;

  ///@JsonKey(name: 'fullName')
  String fullName;

  ///@JsonKey(name: 'avatar')
  String avatar;

  ///@JsonKey(name: 'mobile')
  String mobile;

  ///@JsonKey(name: 'email')
  String email;

  ///@JsonKey(name: 'branch')
  List<Branch> branchList;

  ///@JsonKey(name: 'branch_all')
  List<Branch> branchAllList;

  ///@JsonKey(name: 'environment')
  String environment;

  ///@JsonKey(name: 'isuselotno')
  String isUseLotNo;

  ///@JsonKey(name: 'isuseserial')
  String isUseSerial;

  ///@JsonKey(name: 'error')
  String error;

  ///@JsonKey(name: 'tel_info')
  String telInfo;

  ///@JsonKey(name: 'main_currency')
  String mainCurrency;

  ///@JsonKey(name: 'license_type')
  String licenseType;

  ///@JsonKey(name: 'misaid_account_status')
  String misaIDAccountStatus;

  ///@JsonKey(name: 'device_info')
  String deviceInfo;

  ///@JsonKey(name: 'license_info')
  LicenseInfo licenseInfo;

  String activeBranch;

  ///@JsonKey(name: 'misa_common_access_token')
  String misaCommonAccessToken;

  LoginResponse(
      this.accessToken,
      this.tokenType,
      this.expriresIn,
      this.refreshToken,
      this.roles,
      this.userId,
      this.userName,
      this.deviceTokenId,
      this.fullName,
      this.avatar,
      this.mobile,
      this.email,
      this.branchList,
      this.branchAllList,
      this.environment,
      this.isUseLotNo,
      this.isUseSerial,
      this.error,
      this.telInfo,
      this.mainCurrency,
      this.licenseType,
      this.misaIDAccountStatus,
      this.deviceInfo,
      this.licenseInfo,
      this.misaCommonAccessToken,
      this.activeBranch,
      this.roleList);

  List<int> roleList;

  //factory LoginResponse.fromJson(Map<String, dynamic> json) =>
  //    _$LoginResponseFromJson(json);

  //Map<String, dynamic> toJson() => _$LoginResponseToJson(this);

  Map<String, dynamic> toMap() {
    return {
      'access_token': accessToken,
      'token_type': tokenType,
      'expires_in': expriresIn,
      'refresh_token': refreshToken,
      'roles': roles,
      'userId': userId,
      'userName': userName,
      'deviceTokenId': deviceTokenId,
      'fullName': fullName,
      'avatar': avatar,
      'mobile': mobile,
      'email': email,
      //'branch': branchList?.map((x) => x?.toMap())?.toList(),
      //'branch_all': branchAllList?.map((x) => x?.toMap())?.toList(),
      'branch': json.encode(branchList?.map((x) => x?.toMap())?.toList()),
      'branch_all':
          json.encode(branchAllList?.map((x) => x?.toMap())?.toList()),
      'environment': environment,
      'isuselotno': isUseLotNo,
      'isuseserial': isUseSerial,
      'error': error,
      'tel_info': telInfo,
      'main_currency': mainCurrency,
      'license_type': licenseType,
      'misaid_account_status': misaIDAccountStatus,
      'device_info': deviceInfo,
      'license_info': licenseInfo,
      'misa_common_access_token': misaCommonAccessToken,
      'activeBranch': activeBranch
    };
  }

  factory LoginResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return LoginResponse(
        map['access_token'],
        map['token_type'],
        map['expires_in'],
        map['refresh_token'],
        map['roles'],
        map['userId'],
        map['userName'],
        map['deviceTokenId'],
        map['fullName'],
        map['avatar'],
        map['mobile'],
        map['email'],
        List<Branch>.from(
            json.decode(map['branch'])?.map((x) => Branch.fromMap(x)) ?? []),
        List<Branch>.from(
            json.decode(map['branch_all'])?.map((x) => Branch.fromMap(x)) ??
                []),
        map['environment'],
        map['isuselotno'],
        map['isuseserial'],
        map['error'],
        map['tel_info'],
        map['main_currency'],
        map['license_type'],
        map['misaid_account_status'],
        map['device_info'],
        LicenseInfo.fromJson(map['license_info']),
        map['misa_common_access_token'],
        map['active_branch'],
        UserPermissionUtils.convertRoleValueToList(map['roles']));
  }

  String toJson() => json.encode(toMap());

  factory LoginResponse.fromJson(String source) =>
      LoginResponse.fromMap(json.decode(source));
}
