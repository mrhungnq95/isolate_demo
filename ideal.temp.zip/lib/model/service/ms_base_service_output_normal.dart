import 'dart:convert';

//
// Created by VNLONG on 31/12/2020.
//

class MSOutputServiceNormal {
  int code;

  int total;

  bool success;

  int errorType;

  dynamic summaryData;

  MSOutputServiceNormal(
    this.code,
    this.total,
    this.success,
    this.errorType,
    this.summaryData
  );


  Map<String, dynamic> toMap() {
    return {
      'Code': code,
      'Total': total,
      'Success': success,
      'ErrorType': errorType,
      'SummaryData': summaryData,
    };
  }

  factory MSOutputServiceNormal.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return MSOutputServiceNormal(
      map['Code'],
      map['Total'],
      map['Success'],
      map['ErrorType'],
      map['SummaryData'],
    );
  }

  String toJson() => json.encode(toMap());

  factory MSOutputServiceNormal.fromJson(String source) => MSOutputServiceNormal.fromMap(json.decode(source));
}
