import 'dart:convert';

///
/// Param lấy ds thiết lập thông báo
///
class GetNotificationConfigParam {
  
  String userID;
  String branchID;

  GetNotificationConfigParam({
    this.userID,
    this.branchID,
  });

  Map<String, dynamic> toMap() {
    return {
      'UserID': userID,
      'BranchID': branchID,
    };
  }

  factory GetNotificationConfigParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetNotificationConfigParam(
      userID: map['UserID'],
      branchID: map['BranchID'],
    );
  }

  String toJson() => json.encode(toMap());

  factory GetNotificationConfigParam.fromJson(String source) => GetNotificationConfigParam.fromMap(json.decode(source));
}
