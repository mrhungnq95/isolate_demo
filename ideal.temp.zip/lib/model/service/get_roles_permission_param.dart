import 'dart:convert';

//
// Created by nqhung on 11/11/2020.
//

class GetRolesPermissionParam {
  String masterID;

  GetRolesPermissionParam(this.masterID);

  Map<String, dynamic> toMap() {
    return {
      'masterID': masterID,
    };
  }

  factory GetRolesPermissionParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return GetRolesPermissionParam(
      map['masterID'],
    );
  }

  String toJson() => json.encode(toMap());

  factory GetRolesPermissionParam.fromJson(String source) =>
      GetRolesPermissionParam.fromMap(json.decode(source));
}
