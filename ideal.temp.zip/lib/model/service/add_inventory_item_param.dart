import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/enums/enum_manage_item_type.dart';
import 'package:MShopManager/enums/enum_sell_before_type.dart';
import 'package:MShopManager/model/inventory_item/inventory_item.dart';
import 'package:MShopManager/model/unit/unit_convert.dart';


/// Param add inventoryItem
class AddInventoryItemParam {
  int editMode;
  String inventoryItemName;
  String inventoryItemCategoryId;
  String itemCategoryName;
  String skuCode;
  String barCode;
  double unitPrice;
  double costPrice;
  String unitId;
  String colors;
  String sizes;
  String unitName;
  double quantity;
  String description;
  bool showInMenu;
  // lưu tạm dữ liệu để chuyển từ màn hình thêm mới hàng hoá sang màn hình thêm đơn vị chuyển đổi
  UnitConvert currentUnitConvert;
  // danh sách dữ liệu đơn vị chuyển đổi
  List<UnitConvert> listUnitConvert;
  // danh sách dữ liệu thuộc tính
  List<InventoryItem> listDetail;
  String branchID;
  // Ảnh upload hàng hoá
  String pictureID;
  int pictureType;
  //
  String extensionStr;
  String inventoryItemID;
  int inventoryItemType;
  bool inactive;
  double avgUnitPrice;
  List<InventoryItem> listDetailFromServer;
  double weight;
  double length;
  double width;
  double height;
  int sortOrder;
  // Thiết lập quản lý theo lô - hsd || serial - imei
  EManageItemType manageType;
  double sellBeforeDay;
  ESellBeforeType sellBeforeType;
  String lotID;
  String lotDetailID;
  DateTime expiryDate;
  String lotNo;
  String serials;
  // vi tri hang hoa trong kho/trung bay
  String stockLocation;
  String showLocation;
  DateTime dateOfNewArrival;


  AddInventoryItemParam({
    this.editMode,
    this.inventoryItemName,
    this.inventoryItemCategoryId,
    this.itemCategoryName,
    this.skuCode,
    this.barCode,
    this.unitPrice,
    this.costPrice,
    this.unitId,
    this.colors,
    this.sizes,
    this.unitName,
    this.quantity,
    this.description,
    this.showInMenu,
    this.currentUnitConvert,
    this.listUnitConvert,
    this.listDetail,
    this.branchID,
    this.pictureID,
    this.pictureType,
    this.extensionStr,
    this.inventoryItemID,
    this.inventoryItemType,
    this.inactive,
    this.avgUnitPrice,
    this.listDetailFromServer,
    this.weight,
    this.length,
    this.width,
    this.height,
    this.sortOrder,
    this.manageType,
    this.sellBeforeDay,
    this.sellBeforeType,
    this.lotID,
    this.lotDetailID,
    this.expiryDate,
    this.lotNo,
    this.serials,
    this.stockLocation,
    this.showLocation,
    this.dateOfNewArrival,
  });

  Map<String, dynamic> toMap() {
    return {
      'EditMode': editMode,
      'InventoryItemName': inventoryItemName,
      'InventoryItemCategoryId': inventoryItemCategoryId,
      'ItemCategoryName': itemCategoryName,
      'SkuCode': skuCode,
      'BarCode': barCode,
      'UnitPrice': unitPrice,
      'CostPrice': costPrice,
      'UnitId': unitId,
      'Colors': colors,
      'Sizes': sizes,
      'UnitName': unitName,
      'Quantity': quantity,
      'Description': description,
      'ShowInMenu': showInMenu,
      'CurrentUnitConvert': currentUnitConvert?.toMap(),
      'ListUnitConvert': listUnitConvert?.map((x) => x?.toMap())?.toList(),
      'ListDetail': listDetail?.map((x) => x?.toMap())?.toList(),
      'BranchID': branchID,
      'PictureID': pictureID,
      'PictureType': pictureType,
      'ExtensionStr': extensionStr,
      'InventoryItemID': inventoryItemID,
      'InventoryItemType': inventoryItemType,
      'Inactive': inactive,
      'AvgUnitPrice': avgUnitPrice,
      'ListDetailFromServer':
          listDetailFromServer?.map((x) => x?.toMap())?.toList(),
      'Weight': weight,
      'Length': length,
      'Width': width,
      'Height': height,
      'SortOrder': sortOrder,
      'ManageType': manageType.value,
      'SellBeforeDay': sellBeforeDay,
      'SellBeforeType': sellBeforeType.rawValue,
      'LotID': lotID,
      'LotDetailID': lotDetailID,
      'ExpiryDate': DateTimeFormatHelper.formatDate2String(expiryDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'LotNo': lotNo,
      'Serials': serials,
      'StockLocation': stockLocation,
      'ShowLocation': showLocation,
      'DateOfNewArrival': DateTimeFormatHelper.formatDate2String(dateOfNewArrival,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
    };
  }

  factory AddInventoryItemParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return AddInventoryItemParam(
      editMode: map['EditMode'],
      inventoryItemName: map['InventoryItemName'],
      inventoryItemCategoryId: map['InventoryItemCategoryId'],
      itemCategoryName: map['ItemCategoryName'],
      skuCode: map['SkuCode'],
      barCode: map['BarCode'],
      unitPrice: map['UnitPrice'],
      costPrice: map['CostPrice'],
      unitId: map['UnitId'],
      colors: map['Colors'],
      sizes: map['Sizes'],
      unitName: map['UnitName'],
      quantity: map['Quantity'],
      description: map['Description'],
      showInMenu: map['ShowInMenu'],
      currentUnitConvert: UnitConvert.fromMap(map['CurrentUnitConvert']),
      listUnitConvert: List<UnitConvert>.from(
          map['ListUnitConvert']?.map((x) => UnitConvert.fromMap(x))),
      listDetail: List<InventoryItem>.from(
          map['ListDetail']?.map((x) => InventoryItem.fromMap(x))),
      branchID: map['BranchID'],
      pictureID: map['PictureID'],
      pictureType: map['PictureType'],
      extensionStr: map['Extension'],
      inventoryItemID: map['InventoryItemID'],
      inventoryItemType: map['InventoryItemType'],
      inactive: map['Inactive'],
      avgUnitPrice: map['AvgUnitPrice'],
      listDetailFromServer: List<InventoryItem>.from(
          map['ListDetailFromServer']?.map((x) => InventoryItem.fromMap(x))),
      weight: map['Weight'],
      length: map['Length'],
      width: map['Width'],
      height: map['Height'],
      sortOrder: map['SortOrder'],
      manageType: EManageItemTypeExt.fromValue(map['ManageType']),
      sellBeforeDay: map['SellBeforeDay'],
      sellBeforeType: ESellBeforeTypeExtension.fromValue(map['SellBeforeType']),
      lotID: map['LotID'],
      lotDetailID: map['LotDetailID'],
      expiryDate: DateTimeFormatHelper.parseString2Date(map['ExpiryDate']),
      lotNo: map['LotNo'],
      serials: map['Serials'],
      stockLocation: map['StockLocation'],
      showLocation: map['ShowLocation'],
      dateOfNewArrival:
          DateTimeFormatHelper.parseString2Date(map['DateOfNewArrival']),
    );
  }

  String toJson() => json.encode(toMap());

  factory AddInventoryItemParam.fromJson(String source) =>
      AddInventoryItemParam.fromMap(json.decode(source));
}
