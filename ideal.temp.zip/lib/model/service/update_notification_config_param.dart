import 'dart:convert';

import 'package:MShopManager/model/notification/notification_config.dart';

///
/// Param lấy ds thiết lập thông báo
///
class UpdateNotificationConfigParam {

  String userID;
  String branchID;
  NotificationConfig notificationConfig;


  UpdateNotificationConfigParam({
    this.userID,
    this.branchID,
    this.notificationConfig
  });

  Map<String, dynamic> toMap() {
    return {
      'UserID': userID,
      'BranchID': branchID,
      'NotificationConfig': notificationConfig,
      
    };
  }

  factory UpdateNotificationConfigParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return UpdateNotificationConfigParam(
      userID: map['UserID'],
      branchID: map['BranchID'],
      notificationConfig: map['NotificationConfig'],
    );
  }

  String toJson() => json.encode(toMap());

  factory UpdateNotificationConfigParam.fromJson(String source) => UpdateNotificationConfigParam.fromMap(json.decode(source));
}
