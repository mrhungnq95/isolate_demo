
class MSOutputServiceMasterData<T> {
  int code;

  int total;

  bool success;

  int errorType;

  String primaryKeyValue;

  String errorMessage;

  List<T> data;

  dynamic summaryData;

  MSOutputServiceMasterData(
      {this.code,
      this.total,
      this.success,
      this.errorType,
      this.primaryKeyValue,
      this.errorMessage,
      this.data,
      this.summaryData});

  bool hasData() {
    return data != null && data.isNotEmpty;
  }

  T first() {
    return data?.first;
  }

  factory MSOutputServiceMasterData.fromJson(
      Map<String, dynamic> json, Function decodeDataObject) {
    var data = List<T>();

    var dataMap = json['MasterData'];

    if (dataMap is List) {
      json['MasterData'].forEach((v) {
        final item = decodeDataObject(v);
        if (item != null) {
          data.add(item);
        }
      });
    } else {
      final item = decodeDataObject(json['MasterData']);
      if (item != null) {
        data.add(item);
      }
    }

    return MSOutputServiceMasterData<T>(
        code: json["Code"],
        total: json["Total"],
        success: json["Success"],
        errorType: json["ErrorType"],
        primaryKeyValue: json["PimaryKeyValue"],
        errorMessage: json["ErrorMessage"],
        data: data,
        summaryData: json["SummaryData"]);
  }

  Map<String, dynamic> toJson(Function(T object) toJsonGeneric) {
    final Map<String, dynamic> output = Map<String, dynamic>();
    output['Code'] = this.code;
    output['Total'] = this.total;
    output['Success'] = this.success;
    output['ErrorType'] = this.errorType;
    output['SummaryData'] = this.summaryData;
    output['PimaryKeyValue'] = this.primaryKeyValue;
    output['ErrorMessage'] = this.errorMessage;

    if (this.data != null) {
      output['MasterData'] = this.data.map((v) => toJsonGeneric(v)).toList();
    }

    return output;
  }
}
