import 'dart:convert';

//
// Created by nqhung on 09/11/2020.
//

class RateInventoryItem {
  String inventoryItemName;

  String inventoryItemId;

  double totalAmount;

  String unitName;

  double rate;

  RateInventoryItem({
    this.inventoryItemName,
    this.inventoryItemId,
    this.totalAmount,
    this.unitName,
    this.rate,
  });

  Map<String, dynamic> toMap() {
    return {
      'InventoryItemName': inventoryItemName,
      'InventoryItemId': inventoryItemId,
      'TotalAmount': totalAmount,
      'UnitName': unitName,
      'Rate': rate,
    };
  }

  factory RateInventoryItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return RateInventoryItem(
      inventoryItemName: map['InventoryItemName'],
      inventoryItemId: map['InventoryItemID'],
      totalAmount: map['TotalAmount'],
      unitName: map['UnitName'],
      rate: map['Rate'],
    );
  }

  String toJson() => json.encode(toMap());

  factory RateInventoryItem.fromJson(String source) =>
      RateInventoryItem.fromMap(json.decode(source));
}
