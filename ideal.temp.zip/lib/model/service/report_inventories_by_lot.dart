import '../summary_data.dart';

/// param lấy báo cáo tồn kho theo Lô
class ReportInventoriesByLotParam {
  int pageIndex;
  int pageSize = 20;
  int sellStatus;
  String listBranchID;
  String toDate;
  String fromDate;
  String stockID;
  String unitID;
  String keyword;
}

/// kết quả trả về báo cáo tồn kho theo Lô
class ReportInventoriesByLotResponse {
  List<InventoryByLot> data;
  SummaryData summaryData;
}

class InventoryByLot {
  String SKUCode;
  String inventoryItemID;
  String inventoryItemName;
  String unitName;
  String unitID;
  int reportStatus;
  int exceedDay;
  int expiryStatus;
  DateTime expiryDate;
  DateTime sellBeforeDate;
  double remainDay;
  String lotID;
  String lotNo;
  double closeQuantity;
  double closeAmount;
  int sellStatus;
}