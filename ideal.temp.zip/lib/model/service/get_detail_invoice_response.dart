//
// Created by nqhung on 11/11/2020.
//

import 'dart:convert';

import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/model/invoice/invoice_coupon.dart';
import 'package:MShopManager/model/invoice/invoice_detail.dart';
import 'package:MShopManager/model/invoice/invoice_payment.dart';

class GetDetailInvoiceResponse {

  SAInvoice saInvoice;
  List<SAInvoiceDetail> saInvoiceDetails;
  List<SAInvoicePayment> saInvoicePayments;
  SAInvoiceCoupon invoiceCoupon;

  GetDetailInvoiceResponse({
    this.saInvoice,
    this.saInvoiceDetails,
    this.saInvoicePayments,
    this.invoiceCoupon,
  });


  Map<String, dynamic> toMap() {
    return {
      'SAInvoice': saInvoice?.toMap(),
      'SAInvoiceDetails': saInvoiceDetails?.map((x) => x?.toMap())?.toList(),
      'SAInvoicePayments': saInvoicePayments?.map((x) => x?.toMap())?.toList(),
      'SAInvoiceCoupon': invoiceCoupon?.toMap(),
    };
  }

  factory GetDetailInvoiceResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetDetailInvoiceResponse(
      saInvoice: SAInvoice.fromMap(map['SAInvoice']),
      saInvoiceDetails: List<SAInvoiceDetail>.from(map['SAInvoiceDetails']?.map((x) => SAInvoiceDetail.fromMap(x))),
      saInvoicePayments: List<SAInvoicePayment>.from(map['SAInvoicePayments']?.map((x) => SAInvoicePayment.fromMap(x))),
      invoiceCoupon: SAInvoiceCoupon.fromMap(map['SAInvoiceCoupon']),
    );
  }

  String toJson() => json.encode(toMap());

  factory GetDetailInvoiceResponse.fromJson(String source) => GetDetailInvoiceResponse.fromMap(json.decode(source));


  /// 
  /// Tính tổng SL các mặt hàng
  /// VNLONG - 05/01/2021
  /// 
  double getQuantityListInvoiceDetail() {
    double totalQuantity = 0;
    (saInvoiceDetails ?? []).forEach((SAInvoiceDetail invoiceDetailItem) { totalQuantity += invoiceDetailItem.quantity ?? 0.0;});
    return totalQuantity;
  }
}
