//
// Created by  on 09/11/2020.
//

import 'dart:convert';

import 'package:MShopManager/model/service/rate_inventory_item.dart';
import 'package:MShopManager/model/service/revenue_inventory_items.dart';

class RevenueByItemsInfo {
  List<RevenueInventoryItems> bestRevenueItemList;

  List<RateInventoryItem> rateRevenueItemList;

  RevenueByItemsInfo({
    this.bestRevenueItemList,
    this.rateRevenueItemList,
  });

  ///
  /// Kiểm tra DS tỷ trọng nhóm hàng hoá có dữ liệu không
  ///
  bool hasRateRevenueItemListData() {
    return rateRevenueItemList != null && rateRevenueItemList.isNotEmpty;
  }

  ///
  /// Kiểm tra DS Mặt hàng doanh thu cao nhất có dữ liệu không
  ///
  bool hasBestRevenueItemListData() {
    return bestRevenueItemList != null && bestRevenueItemList.isNotEmpty;
  }

  Map<String, dynamic> toMap() {
    return {
      'BestRevenueModels':
          bestRevenueItemList?.map((x) => x?.toMap())?.toList(),
      'RateRevenueInventoryItemMoblies':
          rateRevenueItemList?.map((x) => x?.toMap())?.toList(),
    };
  }

  factory RevenueByItemsInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return RevenueByItemsInfo(
      bestRevenueItemList: map['BestRevenueModels']
          ?.map<RevenueInventoryItems>((x) => RevenueInventoryItems.fromMap(x))
          ?.toList(),
      rateRevenueItemList: map['RateRevenueInventoryItemMoblies']
          ?.map<RateInventoryItem>((x) => RateInventoryItem.fromMap(x))
          ?.toList(),
    );
  }

  String toJson() => json.encode(toMap());

  factory RevenueByItemsInfo.fromJson(String source) =>
      RevenueByItemsInfo.fromMap(json.decode(source));
}
