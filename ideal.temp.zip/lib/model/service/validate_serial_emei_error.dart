import 'dart:convert';

import 'package:MShopManager/enums/enum_ref_type.dart';
import 'package:MShopManager/enums/enum_validate_serial_error.dart';

///
/// [Description]  Lỗi khi kiểm tra serial từ BE
///
/// Created by TTLOI on 13/01/2021 (11:19).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class ValidateSerialIMEIError {
  String serialNo;
  String inventoryItemName;
  int errorType;
  String errorName;

  ValidateSerialIMEIError({
    this.serialNo,
    this.errorType,
    this.inventoryItemName,
    this.errorName,
  });

  ///
  /// kiểm tra mã lỗi serial/imei trả về thông báo lỗi
  ///
  /// VD: Lỗi trả về 3 nghĩa là sẽ chứa 2 mã lỗi 1 vs 2 vì: 3 | 2 = 3 -> (Lỗi) hoặc  3 | 1 = 3 -> (Lỗi), TH: 3 | 4 = 7 (Không lỗi)
  ///
  List<EValidateSerialIMEIError> getListError() {
    final List<EValidateSerialIMEIError> errors = [];
    int value = 1;
    // duyệt hết danh sách enum EValidateSerialExt xem cái nào lỗi thì add vào List
    while (value == EValidateSerialExt.fromValue(value)?.value) {
      // chia nhị phân để tìm lỗi
      if ((errorType | value) == errorType) {
        errors.add(EValidateSerialExt.fromValue(value));
      }
      value *= 2;
    }
    return errors;
  }

  /// lấy lỗi đầu tiên trong ds lỗi trả về
  EValidateSerialIMEIError get firstError {
    final listError = getListError();
    if (listError != null && listError.isNotEmpty) {
      return listError.first;
    }
    return null;
  }

  factory ValidateSerialIMEIError.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return ValidateSerialIMEIError(
      serialNo: map['SerialNo'],
      errorType: map['ErrorType'],
      inventoryItemName: map['InventoryItemName'],
      errorName: map['ErrorName'],
    );
  }

  factory ValidateSerialIMEIError.fromJson(String source) =>
      ValidateSerialIMEIError.fromMap(json.decode(source));

  Map<String, dynamic> toMap() {
    return {
      'SerialNo': serialNo,
      'ErrorType': errorType,
      'InventoryItemName': inventoryItemName,
      'ErrorName': errorName,
    };
  }

  String toJson() => json.encode(toMap());
}
