import 'dart:convert';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_period.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

///
/// Param Lấy danh sách hóa đơn
///
class GetListInvoiceParam {
  String branchId;
  DateTime fromDate;
  DateTime toDate;
  int pageSize = 20;
  int pageIndex = 1;
  String keySearch = '';
  int paymentStatus = EPaymentStatus.all.rawValue;

  GetListInvoiceParam(
      {this.branchId,
      this.fromDate,
      this.toDate,
      this.keySearch,
      this.paymentStatus,
      this.pageIndex,
      EReportPeriodType timePeriod = EReportPeriodType.thisDay}) {
    if (timePeriod != EReportPeriodType.custom) {
      final dateTimeInfo =
          DateTimeHelper.getDateRangeByPeriod(DateTime.now(), timePeriod);
      this.fromDate = dateTimeInfo.startDate;
      this.toDate = dateTimeInfo.endDate;
    }
    this.branchId = branchId;
  }

  Map<String, dynamic> toMap() {
    return {
      'BranchId': branchId,
      'FromDate': DateTimeFormatHelper.formatDate2String(fromDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ToDate': DateTimeFormatHelper.formatDate2String(toDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'PageSize': pageSize,
      'PageIndex': pageIndex,
      'KeySearch': keySearch,
      'PaymentStatus': paymentStatus,
    };
  }

  factory GetListInvoiceParam.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return GetListInvoiceParam(
      branchId: map['BranchId'],
      fromDate: DateTimeFormatHelper.parseString2Date(map['FromDate']),
      toDate: DateTimeFormatHelper.parseString2Date(map['ToDate']),
      keySearch: map['KeySearch'],
      paymentStatus: map['PaymentStatus'],
      timePeriod: null,
    );
  }

  String toJson() => json.encode(toMap());

  factory GetListInvoiceParam.fromJson(String source) =>
      GetListInvoiceParam.fromMap(json.decode(source));
}
