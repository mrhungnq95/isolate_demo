
import 'dart:convert';
import 'package:MShopManager/model/customer/debt_customer.dart';

/// 
/// Response lấy công nợ khách hàng
/// 
class GetListDebtResponse {
  
  List<DebtCustomer> listCustomer;
  double totalDept;

  GetListDebtResponse({
    this.listCustomer,
    this.totalDept,
  });

  
  Map<String, dynamic> toMap() {
    return {
      'ListCustomer': listCustomer?.map((x) => x?.toMap())?.toList(),
      'TotalDept': totalDept,
    };
  }

  factory GetListDebtResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return GetListDebtResponse(
      listCustomer: List<DebtCustomer>.from(map['ListCustomer']?.map((x) => DebtCustomer.fromMap(x))),
      totalDept: map['TotalDept'],
    );
  }

  String toJson() => json.encode(toMap());

  factory GetListDebtResponse.fromJson(String source) => GetListDebtResponse.fromMap(json.decode(source));
}
