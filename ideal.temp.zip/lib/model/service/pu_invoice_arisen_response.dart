import 'dart:convert';

///
/// [Description]  Kiểm tra chứng từ đã phát sinh hay chưa
///
/// Created by TTLOI on 18/01/2021 (09:15).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class PUInvoiceArisenResponse {
  bool isArisen;
  String arisenRefNo;

  PUInvoiceArisenResponse({
    this.isArisen,
    this.arisenRefNo,
  });


  factory PUInvoiceArisenResponse.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return PUInvoiceArisenResponse(
      isArisen: map['IsArisen'],
      arisenRefNo: map['ArisenRefNo'],
    );
  }

  factory PUInvoiceArisenResponse.fromJson(String source) =>
      PUInvoiceArisenResponse.fromMap(json.decode(source));

  Map<String, dynamic> toMap() {
    return {
      'IsArisen': isArisen,
      'ArisenRefNo': arisenRefNo,
    };
  }

  String toJson() => json.encode(toMap());
}
