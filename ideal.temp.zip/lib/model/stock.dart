import 'dart:convert';

class Stock {
  String stockID;
  String stockName;
  String stockCode;
  String branchID;
  int stockType;
  // kho bán hàng mặc định - tự sinh - không sửa được, khi list không có isDefault thì isSystem vừa là bán, nhập mặc định
  int isSystem;
  // Kho nhập mặc định
  int isDefault;
  int isRenamed;

  // region: Không map trường này
  bool isSelected = false;
  // endregion

  Stock();

  Map<String, dynamic> toMap() {
    return {
      'StockID': stockID,
      'StockName': stockName,
      'StockCode': stockCode,
      'BranchID': branchID,
      'StockType': stockType,
      'IsSystem': isSystem,
      'IsDefault': isDefault,
      'IsRenamed': isRenamed,
    };
  }

  factory Stock.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return Stock()
      ..stockID = map['StockID']
      ..stockName = map['StockName']
      ..stockCode = map['StockCode']
      ..branchID = map['BranchID']
      ..stockType = map['StockType']
      ..isSystem = map['IsSystem']
      ..isDefault = map['IsDefault']
      ..isRenamed = map['IsRenamed'];
  }

  String toJson() => json.encode(toMap());
}
