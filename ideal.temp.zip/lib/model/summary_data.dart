import 'dart:convert';

class SummaryData {
  double openQuantity;
  double openAmount;
  double inQuantity;
  double inAmount;
  double outAmount;
  double outQuantity;
  double closeQuantity;
  double closeAmount;
  double totalAmount;
  double totalQuantity;
  int total;

  SummaryData({
    this.openQuantity = 0,
    this.openAmount = 0,
    this.inQuantity = 0,
    this.inAmount = 0,
    this.outAmount = 0,
    this.outQuantity = 0,
    this.closeQuantity = 0,
    this.closeAmount = 0,
    this.totalAmount = 0,
    this.totalQuantity = 0,
    this.total = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'OpenQuantity': openQuantity,
      'OpenAmount': openAmount,
      'InQuantity': inQuantity,
      'InAmount': inAmount,
      'OutAmount': outAmount,
      'OutQuantity': outQuantity,
      'CloseQuantity': closeQuantity,
      'CloseAmount': closeAmount,
      'TotalAmount': totalAmount,
      'TotalQuantity': totalQuantity,
      'Total': total,
    };
  }

  factory SummaryData.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return SummaryData(
      openQuantity: map['OpenQuantity'],
      openAmount: map['OpenAmount'],
      inQuantity: map['InQuantity'],
      inAmount: map['InAmount'],
      outAmount: map['OutAmount'],
      outQuantity: map['OutQuantity'],
      closeQuantity: map['CloseQuantity'],
      closeAmount: map['CloseAmount'],
      totalAmount: map['TotalAmount'],
      totalQuantity: map['TotalQuantity'],
      total: map['Total'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SummaryData.fromJson(dynamic source) => SummaryData.fromMap(json.decode(source));

}
