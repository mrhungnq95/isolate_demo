import 'dart:convert';

class CustomerCategory {
  String customerCategoryID;
  String parentID;
  String customerCategoryCode;
  String customerCategoryName;
  String description;
  String misaCode;
  bool isLeaf;
  int grade;
  bool inactive;

  CustomerCategory({
    this.customerCategoryID,
    this.parentID,
    this.customerCategoryCode,
    this.customerCategoryName,
    this.description,
    this.misaCode,
    this.isLeaf,
    this.grade,
    this.inactive,
  });

  Map<String, dynamic> toMap() {
    return {
      'CustomerCategoryID': customerCategoryID,
      'ParentID': parentID,
      'CustomerCategoryCode': customerCategoryCode,
      'CustomerCategoryName': customerCategoryName,
      'Description': description,
      'MISACode': misaCode,
      'IsLeaf': isLeaf,
      'Grade': grade,
      'Inactive': inactive,
    };
  }

  factory CustomerCategory.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return CustomerCategory(
      customerCategoryID: map['CustomerCategoryID'],
      parentID: map['ParentID'],
      customerCategoryCode: map['CustomerCategoryCode'],
      customerCategoryName: map['CustomerCategoryName'],
      description: map['Description'],
      misaCode: map['MISACode'],
      isLeaf: map['IsLeaf'],
      grade: map['Grade'],
      inactive: map['Inactive'],
    );
  }

  String toJson() => json.encode(toMap());

  factory CustomerCategory.fromJson(String source) =>
      CustomerCategory.fromMap(json.decode(source));
}
