import 'dart:convert';

import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/enums/enum_edit_mode.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:flutter/material.dart';

class Customer {
  double totalAmount;
  double totalInvoice;
  String customerID;
  String customerCode;
  String customerName;
  String tel;
  String address;
  int gender;
  bool inactive;
  int refType;
  String standardTel;
  String normalizedTel;
  String membershipCode;
  String memberLevelName;
  num membershipID;
  bool isInviteUseFiveShop;
  bool hadChangedTel;
  double totalPayment;
  int errorImport;
  String error;
  String columnError;
  int importMode;
  int rowIndex;
  bool isImportSucess;
  bool isSkip;
  int editMode;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  bool isAutoGenPrimaryKey;
  String clientID;
  String customerCategoryID;
  String customerCategoryName;
  String email;
  DateTime birthday;
  String description;
  String memberCardNo;
  String identifyNumber;
  String companyName;
  String companyTaxCode;
  String addressProvince;
  String addressDistrict;
  String addressVillage;
  String exportProvince;
  String exportDistrict;
  String exportVillage;

  /// local variable
  String avatarName;
  Color avatarColor;

  Customer({
    this.totalAmount,
    this.totalInvoice,
    this.customerID,
    this.customerCode,
    this.customerName,
    this.tel,
    this.address,
    this.gender,
    this.inactive,
    this.refType,
    this.standardTel,
    this.normalizedTel,
    this.membershipCode,
    this.memberLevelName,
    this.membershipID,
    this.isInviteUseFiveShop,
    this.hadChangedTel,
    this.totalPayment,
    this.errorImport,
    this.error,
    this.columnError,
    this.importMode,
    this.rowIndex,
    this.isImportSucess,
    this.isSkip,
    this.editMode,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.isAutoGenPrimaryKey,
    this.clientID,
    this.customerCategoryID,
    this.customerCategoryName,
    this.email,
    this.birthday,
    this.description,
    this.memberCardNo,
    this.identifyNumber,
    this.companyName,
    this.companyTaxCode,
    this.addressProvince,
    this.addressDistrict,
    this.addressVillage,
    this.exportProvince,
    this.exportDistrict,
    this.exportVillage,
    this.avatarName,
    this.avatarColor,
  });

  factory Customer.newDefault() {
    final userId = UserCredential.currentSession?.loginResponse?.userId;
    return Customer(
        editMode: EditMode.add.value,
        createdDate: DateTime.now(),
        createdBy: userId,
        modifiedBy: userId,
        modifiedDate: DateTime.now());
  }

  Map<String, dynamic> toMap() {
    return {
      'TotalAmount': totalAmount,
      'TotalInvoice': totalInvoice,
      'CustomerID': customerID,
      'CustomerCode': customerCode,
      'CustomerName': customerName,
      'Tel': tel,
      'Address': address,
      'Gender': gender,
      'Inactive': inactive,
      'RefType': refType,
      'StandardTel': standardTel,
      'NormalizedTel': normalizedTel,
      'MembershipCode': membershipCode,
      'MemberLevelName': memberLevelName,
      'MembershipID': membershipID,
      'IsInviteUseFiveShop': isInviteUseFiveShop,
      'HadChangedTel': hadChangedTel,
      'TotalPayment': totalPayment?.toDouble() ?? 0.0,
      'ErrorImport': errorImport,
      'Error': error,
      'ColumnError': columnError,
      'ImportMode': importMode,
      'RowIndex': rowIndex,
      'IsImportSucess': isImportSucess,
      'IsSkip': isSkip,
      'EditMode': editMode,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'IsAutoGenPrimaryKey': isAutoGenPrimaryKey,
      'ClientID': clientID,
      'CustomerCategoryID': customerCategoryID,
      'CustomerCategoryName': customerCategoryName,
      'Email': email,
      'Birthday': DateTimeFormatHelper.formatDate2String(birthday,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'Description': description,
      'MemberCardNo': memberCardNo,
      'IdentifyNumber': identifyNumber,
      'CompanyName': companyName,
      'CompanyTaxCode': companyTaxCode,
      'AddressProvince': addressProvince,
      'AddressDistrict': addressDistrict,
      'AddressVillage': addressVillage,
      'ExportProvince': exportProvince,
      'ExportDistrict': exportDistrict,
      'ExportVillage': exportVillage,
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Customer(
        totalAmount: map['TotalAmount']?.toDouble() ?? 0.0,
        totalInvoice: map['TotalInvoice']?.toDouble() ?? 0.0,
        customerID: map['CustomerID'],
        customerCode: map['CustomerCode'],
        customerName: map['CustomerName'],
        tel: map['Tel'],
        address: map['Address'],
        gender: map['Gender'],
        inactive: map['Inactive'],
        refType: map['RefType'],
        standardTel: map['StandardTel'],
        normalizedTel: map['NormalizedTel'],
        membershipCode: map['MembershipCode'],
        membershipID: map['MembershipID'],
        memberLevelName: map['MemberLevelName'],
        isInviteUseFiveShop: map['IsInviteUseFiveShop'],
        hadChangedTel: map['HadChangedTel'],
        totalPayment: map['TotalPayment'],
        errorImport: map['ErrorImport'],
        error: map['Error'],
        columnError: map['ColumnError'],
        importMode: map['ImportMode'],
        rowIndex: map['RowIndex'],
        isImportSucess: map['IsImportSucess'],
        isSkip: map['IsSkip'],
        editMode: map['EditMode'],
        createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
        createdBy: map['CreatedBy'],
        modifiedDate:
            DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
        modifiedBy: map['ModifiedBy'],
        isAutoGenPrimaryKey: map['IsAutoGenPrimaryKey'],
        clientID: map['ClientID'],
        customerCategoryID: map['CustomerCategoryID'],
        customerCategoryName: map['CustomerCategoryName'],
        email: map['Email'],
        birthday: DateTimeFormatHelper.parseString2Date(map['Birthday']),
        description: map['Description'],
        memberCardNo: map['MemberCardNo'],
        identifyNumber: map['IdentifyNumber'],
        companyName: map['CompanyName'],
        companyTaxCode: map['CompanyTaxCode'],
        addressProvince: map['AddressProvince'],
        addressDistrict: map['AddressDistrict'],
        addressVillage: map['AddressVillage'],
        exportProvince: map['ExportProvince'],
        exportDistrict: map['ExportDistrict'],
        exportVillage: map['ExportVillage']);
  }

  String toJson() => json.encode(toMap());

  factory Customer.fromJson(String source) =>
      Customer.fromMap(json.decode(source));
}
