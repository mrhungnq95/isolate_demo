import 'dart:convert';


class SummaryNormalData {
  int totalQuantity;
  double totalAmount;

  SummaryNormalData({
    this.totalQuantity = 0,
    this.totalAmount = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'TotalQuantity': totalQuantity,
      'TotalAmount': totalAmount,
    };
  }

  factory SummaryNormalData.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return SummaryNormalData(
      totalQuantity: map['TotalQuantity'],
      totalAmount: map['TotalAmount'],
    );
  }

  String toJson() => json.encode(toMap());
  factory SummaryNormalData.fromJson(String source) => SummaryNormalData.fromMap(json.decode(source));
}
