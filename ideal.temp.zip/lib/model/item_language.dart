class ItemLanguage {
  String nameLocalize; //Tiếng Anh
  String nameGlobalize; //(English)
  ItemLanguage({
    this.nameLocalize,
    this.nameGlobalize,
  });
}
