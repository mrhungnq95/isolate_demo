import 'package:MShopManager/enums/enum_revenue_draw_view_type.dart';

abstract class RevenueDataObjectAbstract {
  ERevenueDrawViewType provideViewType();
}
