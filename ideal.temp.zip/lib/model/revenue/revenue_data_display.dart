import 'package:MShopManager/model/chart_data_source.dart';
import 'package:MShopManager/model/service/revenue_by_items_info.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';
import 'package:mp_chart/mp/core/entry/pie_entry.dart';
import 'package:MShopManager/model/overview/revenue_for_time_display_item.dart';
import 'package:MShopManager/model/revenue/revenue_inventory_item_proportion.dart';

class RevenueItemReportDataDisplay {
  /// Tổng số: Tỷ trọng doanh thu nhóm mặt hàng
  double totalItemAmount;

  /// DS các Nhóm mặt hàng dùng để hiển thị
  /// Đã được tính toán lại: Tỷ lệ %
  List<RevenueInventoryItemProportion> displayList;

  ///
  /// Dữ liệu để vẽ trên biểu đồ
  ///
  List<PieEntry> entryList;

  RevenueByItemsInfo originalData;

  RevenueItemReportDataDisplay({
    this.totalItemAmount,
    this.displayList,
    this.originalData,
    this.entryList,
  });
}

///
/// Object lưu các thông tin cần thiết cho báo cáo Doanh thu theo thời gan
///
class RevenueTimeReportDataDisplay {
  ///
  /// Tổng doanh thu
  ///
  double totalItemAmount;

  ///
  /// DS các dữ liệu báo cáo theo Giờ, Tuần, Ngày, Tháng, Quý, Năm
  /// dùng để hiển thị bên ngoài
  ///
  List<ReportRevenueDataObject> displayList;

  ///
  /// Dữ liệu để vẽ trên biểu đồ
  ///
  LineChartEntry lineEntry;

  /// Biểu đồ cột theo thời gian
  List<BarDataSet> barDataSetList;

  /// Dữ liệu gốc báo cáo theo Giờ, Tuần, Ngày, Tháng, Quý, Năm
  List<RevenueForTimeDisplayItem> originalDataList;

  RevenueTimeReportDataDisplay({
    this.totalItemAmount,
    this.displayList,
    this.lineEntry,
    this.barDataSetList,
    this.originalDataList,
  });
}

class ReportRevenueDataObject {
  double index;
  String title;
  double amount;
  ReportRevenueDataObject({
    this.index,
    this.title,
    this.amount,
  });
}
