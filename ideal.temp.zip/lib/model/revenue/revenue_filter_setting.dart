import 'dart:convert';

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_report_view_type.dart';
import 'package:MShopManager/enums/enum_revenue_report_type.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';

class RevenueFilterSetting {
  ///
  /// Cửa hàng được chọn, ngăn cách nhau bởi dấu ,
  /// nếu là Toàn chuỗi : 00000000-0000-0000-0000-000000000000
  ///
  String listBranchID;

  ///
  /// Chọn loại filter cửa hàng
  ///
  /// [BranchFilterMode.ALL]
  /// [BranchFilterMode.CUSTOM]
  ///
  BranchFilterMode branchFilterMode;

  ///
  /// Xem theo
  ///
  EReportViewType eReportViewType;

  ///
  /// Loại kiểu xem [EReportViewType.viewByPeriodTime] "Xem theo thời gian"
  ///
  ERevenueReportType eRevenueReportType;

  ///
  /// Kỳ báo cáo
  ///
  EReportPeriodType eReportPeriodType;

  ///
  /// Khoảng thời gian lấy báo cáo
  ///
  DateRange dateRange;

  ///
  /// Thời gian Lấy báo của device
  ///
  DateTime fetchReportDateTime;

  RevenueFilterSetting({
    this.branchFilterMode,
    this.listBranchID,
    this.eReportViewType,
    this.eRevenueReportType,
    this.eReportPeriodType,
    this.dateRange,
    this.fetchReportDateTime,
  });

  factory RevenueFilterSetting.newDefault() {
    RevenueFilterSetting defSetting = RevenueFilterSetting();
    
    /// Xem theo mặt hàng
    defSetting.eReportViewType = EReportViewType.viewByInventoryItem;

    /// Xem theo thời gian - theo giờ
    defSetting.eRevenueReportType = ERevenueReportType.byHour;

    /// Mặc định xem là hôm nay
    defSetting.eReportPeriodType = EReportPeriodType.thisDay;

    /// Tất cả cửa hàng
    defSetting.listBranchID = AppConstant.UUID_EMPTY;

    defSetting.branchFilterMode = BranchFilterMode.ALL;
    defSetting.dateRange = DateTimeHelper.getDateRangeByPeriod(
        DateTime.now(), defSetting.eReportPeriodType);
    return defSetting;
  }

  Map<String, dynamic> toMap() {
    return {
      'fetchReportDateTime': fetchReportDateTime?.millisecondsSinceEpoch,
      'branchFilterMode': branchFilterMode.rawValue,
      'listBranchID': listBranchID,
      'eReportViewType': eReportViewType?.rawValue,
      'eRevenueReportType': eRevenueReportType?.rawValue,
      'eReportPeriodType': eReportPeriodType?.rawValue,
      'dateRange': dateRange?.toMap()
    };
  }

  factory RevenueFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return RevenueFilterSetting(
        fetchReportDateTime:
            DateTime.fromMillisecondsSinceEpoch(map['fetchReportDateTime']),
        branchFilterMode: BranchFilterModeExt.valueOf(map['branchFilterMode']),
        listBranchID: map['listBranchID'],
        eReportViewType: EReportViewTypeExt.valueOf(map['eReportViewType']),
        eRevenueReportType:
            ERevenueReportTypeExt.valueOf(map['eRevenueReportType']),
        eReportPeriodType:
            EReportPeriodTypeExt.valueOf(map['eReportPeriodType']),
        dateRange: DateRange.fromMap(map['dateRange']));
  }

  String toJson() => json.encode(toMap());

  factory RevenueFilterSetting.fromJson(String source) =>
      RevenueFilterSetting.fromMap(json.decode(source));
}
