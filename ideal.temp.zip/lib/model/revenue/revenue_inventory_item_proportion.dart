import 'package:MShopManager/enums/enum_revenue_draw_view_type.dart';
import 'package:flutter/material.dart';

import 'abstract_revenue_data_object.dart';

///
/// View-model thể hiện dữ liệu từng mặt hàng theo tỷ trọng
///
class RevenueInventoryItemProportion extends RevenueDataObjectAbstract {
  final Color color;
  final String inventoryItemID;
  final String inventoryItemName;
  final double percent;
  final double amount;

  RevenueInventoryItemProportion(
      {this.color,
      this.inventoryItemID,
      this.inventoryItemName,
      this.percent,
      this.amount});

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.property;
  }
}
