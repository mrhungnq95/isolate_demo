import 'dart:ui';

import 'package:MShopManager/model/service/revenue_inventory_items.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';
import 'package:mp_chart/mp/core/entry/pie_entry.dart';

import 'package:MShopManager/enums/enum_revenue_draw_view_type.dart';
import 'package:MShopManager/model/chart_data_source.dart';
import 'package:MShopManager/model/revenue/abstract_revenue_data_object.dart';

class RevenueHeaderObject extends RevenueDataObjectAbstract {
  ///
  /// Tổng doanh thu
  ///
  double totalItemAmount;

  RevenueHeaderObject({
    this.totalItemAmount,
  });

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.header;
  }
}

class RevenueItemsChartObject extends RevenueDataObjectAbstract {
  ///
  /// Tổng doanh thu
  ///
  double totalItemAmount;

  ///
  /// Dữ liệu để vẽ trên biểu đồ
  ///
  List<PieEntry> entryList;

  RevenueItemsChartObject({
    this.entryList,
    this.totalItemAmount,
  });

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.chart;
  }
}

class RevenueTimeChartObject extends RevenueDataObjectAbstract {
  ///
  /// Dữ liệu để vẽ trên biểu đồ
  ///
  LineChartEntry lineEntry;

  /// Biểu đồ cột theo thời gian
  List<BarDataSet> barDataSetList;

  RevenueTimeChartObject({
    this.lineEntry,
    this.barDataSetList,
  });

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.chart;
  }
}

class RevenueItemsObject extends RevenueDataObjectAbstract {
  final RevenueInventoryItems item;

  RevenueItemsObject(this.item);

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.items;
  }
}

class RevenuePropertyObject extends RevenueDataObjectAbstract {
  double index;
  String title;
  double amount;

  RevenuePropertyObject({
    this.index,
    this.title,
    this.amount,
  });

  @override
  ERevenueDrawViewType provideViewType() {
    return ERevenueDrawViewType.property;
  }
}

// ///
// /// View-model thể hiện dữ liệu từng mặt hàng theo tỷ trọng
// ///
// class RevenueInventoryItemProportion extends RevenueDataObjectAbstract {
//   final Color color;
//   final String inventoryItemID;
//   final String inventoryItemName;
//   final double percent;
//   final double amount;

//   RevenueInventoryItemProportion(
//       {this.color,
//       this.inventoryItemID,
//       this.inventoryItemName,
//       this.percent,
//       this.amount});

//   @override
//   ERevenueDrawViewType provideViewType() {
//     return ERevenueDrawViewType.property;
//   }
// }
