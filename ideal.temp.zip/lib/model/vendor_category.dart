import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';

/// Nhóm Nhà cung cấp
class VendorCategory {
  String vendorCategoryID;
  String parentID;
  String parentNameNew;
  String parentNameOld;
  String vendorCategoryCode;
  String vendorCategoryName;
  String description;
  String MISACode;
  bool isLeaf;
  int grade;
  bool inactive;
  String clientID;
  String note;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  int editMode;

  /// Trường tạm dùng để hiển thị
  List<VendorCategory> listChild = [];

  VendorCategory({
    this.vendorCategoryID,
    this.parentID,
    this.parentNameNew,
    this.parentNameOld,
    this.vendorCategoryCode,
    this.vendorCategoryName,
    this.description,
    this.MISACode,
    this.isLeaf,
    this.grade,
    this.inactive,
    this.clientID,
    this.note,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.editMode,
  });

  Map<String, dynamic> toMap() {
    return {
      'VendorCategoryID': vendorCategoryID,
      'ParentID': parentID,
      'ParentNameNew': parentNameNew,
      'ParentNameOld': parentNameOld,
      'VendorCategoryCode': vendorCategoryCode,
      'VendorCategoryName': vendorCategoryName,
      'Description': description,
      'MISACode': MISACode,
      'IsLeaf': isLeaf,
      'Grade': grade,
      'Inactive': inactive,
      'ClientID': clientID,
      'Note': note,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'EditMode': editMode,
    };
  }

  factory VendorCategory.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return VendorCategory(
      vendorCategoryID: map['VendorCategoryID'],
      parentID: map['ParentID'],
      parentNameNew: map['ParentNameNew'],
      parentNameOld: map['ParentNameOld'],
      vendorCategoryCode: map['VendorCategoryCode'],
      vendorCategoryName: map['VendorCategoryName'],
      description: map['Description'],
      MISACode: map['MISACode'],
      isLeaf: map['IsLeaf'],
      grade: map['Grade'],
      inactive: map['Inactive'],
      clientID: map['ClientID'],
      note: map['Note'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      editMode: map['EditMode'],
    );
  }

  String toJson() => json.encode(toMap());

  factory VendorCategory.fromJson(dynamic source) =>
      VendorCategory.fromMap(json.decode(source));
}
