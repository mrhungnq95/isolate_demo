import 'dart:convert';

import 'package:MShopManager/enums/enum_customer_transaction_history_view_by_type.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_time_sort_status.dart';

class CustomerTransactionHistoryFilterSetting {
  ///
  /// Cửa hàng được chọn. Toàn chuỗi:
  /// 00000000-0000-0000-0000-000000000000
  ///
  String branchId;

  /// Thời gian lấy báo cáo
  EReportPeriodType timePeriod;

  /// Xem theo
  ECustomerTransactionHistoryViewType viewType;

  /// Sắp xếp
  ETimeSortStatus sortStatus;

  /// Trạng thái hoá dơn
  List<EPaymentStatus> paymentStatus;

  CustomerTransactionHistoryFilterSetting({
    this.branchId,
    this.timePeriod,
    this.viewType,
    this.sortStatus,
    this.paymentStatus,
  });

  factory CustomerTransactionHistoryFilterSetting.newDefault() {
    return CustomerTransactionHistoryFilterSetting(
        timePeriod: EReportPeriodType.thisMonth,
        viewType: ECustomerTransactionHistoryViewType.createdDate,
        sortStatus: ETimeSortStatus.desc,
        paymentStatus: [EPaymentStatus.all]);
  }

  Map<String, dynamic> toMap() {
    return {
      'branchId': branchId,
      'timePeriod': timePeriod?.rawValue,
      'viewType': viewType?.rawValue,
      'sortStatus': sortStatus?.rawValue,
      'paymentStatus': paymentStatus.map((e) => e.rawValue).toList(),
    };
  }

  factory CustomerTransactionHistoryFilterSetting.fromMap(
      Map<String, dynamic> map) {
    if (map == null) return null;

    return CustomerTransactionHistoryFilterSetting(
      branchId: map['branchId'],
      timePeriod: EReportPeriodTypeExt.valueOf(map['timePeriod']),
      viewType: ECustomerTransactionHistoryViewTypeExt.valueOf(map['viewType']),
      sortStatus: ETimeSortStatusExt.valueOf(map['sortStatus']),
      paymentStatus: map['paymentStatus']
          ?.map<EPaymentStatus>((x) => EPaymentStatusExt.fromValue(x))
          ?.toList(),
    );
  }

  String toJson() => json.encode(toMap());

  factory CustomerTransactionHistoryFilterSetting.fromJson(String source) =>
      CustomerTransactionHistoryFilterSetting.fromMap(json.decode(source));
}
