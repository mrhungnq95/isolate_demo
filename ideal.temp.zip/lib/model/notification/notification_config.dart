import 'dart:convert';
import 'package:MShopManager/enums/enum_notification_type.dart';

///
/// Setting thông báo
///
class NotificationConfig {
  bool saleInfo; // Tổng doanh thu
  bool invoice; // Hoá đơn
  bool exchange; // Đổi trả
  bool editSAInvoice; // Sửa hoá đơn
  bool cancelSAInvoice; // Huỷ hoá đơn
  bool inStock; // Cảnh báo tồn kho
  bool importInventory; // Nhập hàng
  bool importStock ; // Nhập kho
  bool returnInventory; // Trả lại hàng mua
  bool outward; // Xuất kho
  bool sellBeforeDate; // Thông báo cận date
  bool newOrder; // Đơn đặt hàng mới
  bool processOrder; // Xử lý đơn đặt hàng

  NotificationConfig({
    this.saleInfo = false,
    this.invoice  = false,
    this.exchange  = false,
    this.editSAInvoice  = false,
    this.cancelSAInvoice  = false,
    this.inStock  = false,
    this.importInventory  = false,
    this.importStock  = false,
    this.returnInventory  = false,
    this.outward  = false,
    this.sellBeforeDate  = false,
    this.newOrder  = false,
    this.processOrder = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'SaleInfo': saleInfo,
      'Invoice': invoice,
      'Exchange': exchange,
      'EditSAInvoice': editSAInvoice,
      'CancelSAInvoice': cancelSAInvoice,
      'InStock': inStock,
      'ImportInventory': importInventory,
      'ImportStock': importStock,
      'ReturnInventory': returnInventory,
      'Outward': outward,
      'SellBeforeDate': sellBeforeDate,
      'NewOrder': newOrder,
      'ProcessOrder': processOrder,
    };
  }

  factory NotificationConfig.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationConfig(
      saleInfo: map['SaleInfo'],
      invoice: map['Invoice'],
      exchange: map['Exchange'],
      editSAInvoice: map['EditSAInvoice'],
      cancelSAInvoice: map['cancelSAInvoice'],
      inStock: map['InStock'],
      importInventory: map['ImportInventory'],
      importStock: map['ImportStock'],
      returnInventory: map['ReturnInventory'],
      outward: map['Outward'],
      sellBeforeDate: map['SellBeforeDate'],
      newOrder: map['NewOrder'],
      processOrder: map['ProcessOrder'],
    );
  }

  ///
  /// Cập nhật giá trị setting
  ///
  void updateValueSetting(ENotificationType notificationType, bool value) {
    final itemValue = value ?? false;
    switch (notificationType) {
      case ENotificationType.saleInfo:
        saleInfo = itemValue;
        break;
      case ENotificationType.saInvoice:
        invoice = itemValue;
        break;
      case ENotificationType.exchange:
        exchange = itemValue;
        break;
      case ENotificationType.editSAInvoice:
        editSAInvoice = itemValue;
        break;
      case ENotificationType.cancelSAInvoice:
        cancelSAInvoice = itemValue;
        break;
      case ENotificationType.inStock:
        inStock = itemValue;
        break;
      case ENotificationType.importInventory:
        importInventory = itemValue;
        break;
      case ENotificationType.importStock:
        importStock = itemValue;
        break;
      case ENotificationType.returnInventory:
        returnInventory = itemValue;
        break;
      case ENotificationType.iSMAC:
        break;
      case ENotificationType.outward:
        outward = itemValue;
        break;
      case ENotificationType.sellBeforeDate:
        sellBeforeDate = itemValue;
        break;
      case ENotificationType.processOrder:
      case ENotificationType.rejectOrder:
      case ENotificationType.newOrder:
      case ENotificationType.processOrderForManager:
      case ENotificationType.rejectOrderForManager:
        processOrder = itemValue;
        break;
    }
  }

  ///
  /// Trả về trạng thái setting hiện tại có được chọn hay không?
  /// Check theo thiết lập
  ///
  bool getStateSelectBySetting({ENotificationType type}) {
    switch (type) {
      case ENotificationType.saleInfo:
        return saleInfo;
      case ENotificationType.saInvoice:
        return invoice;
      case ENotificationType.exchange:
        return exchange;
      case ENotificationType.editSAInvoice:
        return editSAInvoice;
      case ENotificationType.cancelSAInvoice:
        return cancelSAInvoice;
      case ENotificationType.inStock:
        return inStock;
      case ENotificationType.importInventory:
        return importInventory;
      case ENotificationType.importStock:
        return importStock;
      case ENotificationType.returnInventory:
        return returnInventory;
      case ENotificationType.iSMAC:
        return false;
      case ENotificationType.outward:
        return outward;
      case ENotificationType.sellBeforeDate:
        return sellBeforeDate;
      case ENotificationType.newOrder:
        return newOrder;
      case ENotificationType.processOrder:
      case ENotificationType.processOrderForManager:
      case ENotificationType.rejectOrder:
      case ENotificationType.rejectOrderForManager:
        return processOrder;
      default:
        return false;
    }
  }

  String toJson() => json.encode(toMap());

  factory NotificationConfig.fromJson(String source) =>
      NotificationConfig.fromMap(json.decode(source));
}
