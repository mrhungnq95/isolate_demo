import 'dart:convert';

import 'package:MShopManager/enums/enum_order_source_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo sửa hoá đơn
/// Nội dung thông báo: "Vũ Quốc Minh đã sửa hóa đơn 19010002365 từ 200.000 thành 300.000 tại Cầu Giấy"
///
class NotificationOrder {
  String branchID; // Id chi nhánh
  double cancelReason;
  String cashierName;
  double companyCode;
  String employeeName;
  bool isOnWorker;
  int orderSourceInfo;
  String refID;
  String refNo;
  int refType;
  int reportType;
  double totalAmount;
  String userID;
  String branchName;
  String customerTel;
  String customerName;

  NotificationOrder({
    this.branchID,
    this.cancelReason,
    this.cashierName,
    this.companyCode,
    this.employeeName,
    this.isOnWorker,
    this.orderSourceInfo,
    this.refID,
    this.refNo,
    this.refType,
    this.reportType,
    this.totalAmount,
    this.userID,
    this.branchName,
    this.customerTel,
    this.customerName,
  });

  Map<String, dynamic> toMap() {
    return {
      'branchID': branchID,
      'cancelReason': cancelReason,
      'cashierName': cashierName,
      'companyCode': companyCode,
      'employeeName': employeeName,
      'isOnWorker': isOnWorker,
      'orderSourceInfo': orderSourceInfo,
      'refID': refID,
      'refNo': refNo,
      'refType': refType,
      'reportType': reportType,
      'totalAmount': totalAmount,
      'userID': userID,
      'branchName': branchName,
      'customerTel': customerTel,
      'customerName': customerName,
    };
  }

  factory NotificationOrder.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationOrder(
      branchID: map['branchID'],
      cancelReason: map['cancelReason'],
      cashierName: map['cashierName'],
      companyCode: map['companyCode'],
      employeeName: map['employeeName'],
      isOnWorker: map['isOnWorker'],
      orderSourceInfo: map['orderSourceInfo'],
      refID: map['refID'],
      refNo: map['refNo'],
      refType: map['refType'],
      reportType: map['reportType'],
      totalAmount: map['totalAmount'],
      userID: map['userID'],
      branchName: map['branchName'],
      customerTel: map['customerTel'],
      customerName: map['customerName'],
    );
  }

  ///
  /// Build nội dung câu thông báo order mới
  ///
  String getNewOrderContent() {
    var content = '';
    var actor = cashierName ?? "";
    EOrderSourceType orderSource = EOrderSourceTypeExt.valueOf(orderSourceInfo);
    final orderSourceName = orderSource.getSource();
    final refNo = this.refNo ?? '';

    if (orderSource == EOrderSourceType.website) {
      actor = actor + " ($customerTel)";
    }

    String totalAmountStr =
        (totalAmount ?? 0).toStringFormat(EDoubleFormat.money);

    if (NotificationSaleInfo.isNormalShop()) {
      content =
          "Khách hàng <b>$actor</b> vừa lập đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b> từ <b>$orderSourceName</b>";
    } else {
      content =
          "Khách hàng <b>$actor</b> vừa lập đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b> từ <b>$orderSourceName</b> tới chi nhánh <b>$branchName</b>";
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  ///
  /// Đơn vừa xử lý
  ///
  String getProcessOrderContent() {
    var content = '';
    var actor = cashierName ?? "";
    EOrderSourceType orderSource = EOrderSourceTypeExt.valueOf(orderSourceInfo);
    String orderSourceName = orderSource.getSource() ?? '';

    if (orderSource == EOrderSourceType.website) {
      actor = actor + " ($customerTel)";
    }

    String totalAmountStr =
        (totalAmount ?? 0).toStringFormat(EDoubleFormat.money);

    if (NotificationSaleInfo.isNormalShop()) {
      content =
          "<b>${cashierName ?? ''}</b> vừa xử lý đơn <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b> do <b>$actor</b> gửi từ <b>$orderSourceName</b>";
    } else {
      content =
          "<b>${cashierName ?? ''}</b> vừa xử lý đơn <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b> do <b>$actor</b> gửi từ <b>$orderSourceName</b> tới chi nhánh <b>${branchName ?? ''}</b>";
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  ///
  /// Đơn từ chối
  ///
  String getRejectOrderContent() {
    var content = '';

    EOrderSourceType orderSource = EOrderSourceTypeExt.valueOf(orderSourceInfo);
    String orderSourceName = orderSource.getSource();
    String totalAmountStr =
        (totalAmount ?? 0).toStringFormat(EDoubleFormat.money);

    if (NotificationSaleInfo.isNormalShop()) {
      content =
          "<b>${cashierName ?? ''}</b> vừa từ chối đơn <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b> từ <b>${orderSourceName ?? ''}</b>";
    } else {
      content =
          "<b>${cashierName ?? ''}</b> vừa từ chối đơn <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b> từ <b>${orderSourceName ?? ''}</b> tới chi nhánh <b>${branchName ?? ''}</b>";
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationOrder.fromJson(String source) =>
      NotificationOrder.fromMap(json.decode(source));
}
