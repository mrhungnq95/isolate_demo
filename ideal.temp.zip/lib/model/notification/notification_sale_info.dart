import 'dart:convert';

import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/utils/extension/widget_ext.dart';

/// ****** Thông báo tình hình doanh thu ******
/// Nội dung thông báo: "Ngày hôm qua toàn chuỗi đã bán được 45 hoá đơn với số tiền 27.000.000.
/// Chi nhánh 141 Cầu giấy bán được nhiều nhất với 15.000.000"
class NotificationSaleInfo implements NotificationItemBase {
  int totalInvoice; // Tổng số hoá đơn
  double totalAmount; // Tổng giá trị hoá đơn bán được trên toàn bộ chi nhánh
  String bestSaleBranchID; // Id chi nhánh bán chạy nhất
  String bestSaleBranchName; // Tên chi nhánh bán chạy nhất
  double
      bestSaleAmountBranch; // Tổng giá trị hoá đơn bán tại cửa hàng bán chạy nhất

  NotificationSaleInfo({
    this.totalInvoice,
    this.totalAmount,
    this.bestSaleBranchID,
    this.bestSaleBranchName,
    this.bestSaleAmountBranch,
  });

  Map<String, dynamic> toMap() {
    return {
      'TotalInvoice': totalInvoice,
      'TotalAmount': totalAmount,
      'BestSaleBranchID': bestSaleBranchID,
      'BestSaleBranchName': bestSaleBranchName,
      'BestSaleAmountBranch': bestSaleAmountBranch,
    };
  }

  factory NotificationSaleInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationSaleInfo(
      totalInvoice: map['TotalInvoice'],
      totalAmount: map['TotalAmount'],
      bestSaleBranchID: map['BestSaleBranchID'],
      bestSaleBranchName: map['EstSaleBranchName'],
      bestSaleAmountBranch: map['BestSaleAmountBranch'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    String totalInvoiceStr =
        (totalInvoice ?? 0).toDouble().toStringFormat(EDoubleFormat.quantity);
    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String bestSaleAmountBranchStr = (bestSaleAmountBranch ?? 0)
        .toDouble()
        .toStringFormat(EDoubleFormat.money);
    String bestSaleBranchName = this.bestSaleBranchName ?? '';

    if (totalInvoice == null || totalInvoice == 0 || totalInvoice == 1) {
      if (isNormalShop()) {
        content =
            'Ngày hôm qua toàn chuỗi đã bán được <b>$totalInvoiceStr</b> hoá đơn với số tiền <b>$totalAmountStr</b>. <b>$bestSaleBranchName</b> bán được nhiều nhất với <b>$bestSaleAmountBranchStr</b>.';
      } else {
        content =
            'Ngày hôm qua toàn chuỗi đã bán được <b>$totalInvoiceStr</b> hoá đơn với số tiền <b>$totalAmountStr</b>. <b>$bestSaleBranchName</b> bán được nhiều nhất với <b>$bestSaleAmountBranchStr</b>.';
      }
    } else if (totalInvoice > 1) {
      if (isNormalShop()) {
        content =
            'Ngày hôm qua toàn chuỗi đã bán được <b>$totalInvoiceStr</b> hoá đơn với số tiền <b>$totalAmountStr</b>. <b>$bestSaleBranchName</b> bán được nhiều nhất với <b>$bestSaleAmountBranchStr</b>.';
      } else {
        content =
            'Ngày hôm qua toàn chuỗi đã bán được <b>$totalInvoiceStr</b> hoá đơn với số tiền <b>$totalAmountStr</b>. <b>$bestSaleBranchName</b> bán được nhiều nhất với <b>$bestSaleAmountBranchStr</b>.';
      }
    }

    return buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationSaleInfo.fromJson(String source) =>
      NotificationSaleInfo.fromMap(json.decode(source));

  static bool isNormalShop() {
    return true;
  }

  static bool isChainShop() {
    return true;
  }

  ///
  /// Build HTML hiển thị
  ///
  static String buildHtml(String content) {
    return "<div>$content</div>";
  }
}
