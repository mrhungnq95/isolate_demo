import 'dart:convert';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'notification_sale_info.dart';

///
/// Thông báo sửa hoá đơn
/// Nội dung thông báo: "Vũ Quốc Minh đã sửa hóa đơn 19010002365 từ 200.000 thành 300.000 tại Cầu Giấy"
///
class NotificationCancelInvoice implements NotificationItemBase {
  String cashierName; // tên thu ngân
  String refNo; // số hoá đơn
  String refID; // id hoá đơn
  double totalAmount; // tổng tiền hóa đơn ban đầu
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationCancelInvoice({
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationCancelInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationCancelInvoice(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }


  @override
  String getHtmlContent() {
    var content = '';

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    if (NotificationSaleInfo.isNormalShop()) {
      content =
          '<b>$cashierName</b> đã huỷ hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b>.';
    } else {
      content =
          '<b>$cashierName</b> đã huỷ hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.';
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationCancelInvoice.fromJson(String source) =>
      NotificationCancelInvoice.fromMap(json.decode(source));
}
