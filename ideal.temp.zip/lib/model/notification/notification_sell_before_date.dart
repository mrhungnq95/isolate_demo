import 'dart:convert';

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo hàng hóa cận date
/// Nội dung thông báo: Có 10 hàng hóa cận date tại Cầu Giấy
///
class NotificationSellBeforeDate implements NotificationItemBase {
  double totalItem;
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationSellBeforeDate({
    this.totalItem,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'TotalInventoryItem': totalItem,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationSellBeforeDate.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationSellBeforeDate(
      totalItem: map['TotalInventoryItem'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    double totalItem = this.totalItem ?? 0;
    String totalItemStr = totalItem.toStringFormat(EDoubleFormat.quantity);
    String branchName = this.branchName ?? '';
    // String typeName = ERefTypeExt.valueOf(stockType).getTitle();

    if (totalItem == 1 || totalItem == 0) {
      if (NotificationSaleInfo.isNormalShop()) {
        /// Nếu là toàn chuỗi
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font>.";
        }
      } else {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> tại <b>$branchName</b>.";
        }
      }
    } else if (totalItem > 1) {
      if (NotificationSaleInfo.isNormalShop()) {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font>.";
        }
      } else {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>cận Date</font> tại <b>$branchName</b>.";
        }
      }
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationSellBeforeDate.fromJson(String source) =>
      NotificationSellBeforeDate.fromMap(json.decode(source));
}
