import 'dart:convert';

import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/enums/enum_feature_system.dart';
import 'package:MShopManager/enums/enum_permission_type.dart';
import 'package:MShopManager/enums/enum_ref_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo xuất kho
///
class NotificationOutward implements NotificationItemBase {
  String cashierName; // tên thu ngân
  int refType; // Loại phiếu xuất
  String refNo; // số hoá đơn
  String refID; // id hoá đơn
  double totalAmount; // tổng tiền hóa đơn ban đầu
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh
  int stockType; // Loại kho

  NotificationOutward(
      {this.cashierName,
      this.refType,
      this.refNo,
      this.refID,
      this.totalAmount,
      this.branchID,
      this.branchName,
      this.stockType});

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefType': refType,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
      'StockType': stockType,
    };
  }

  factory NotificationOutward.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationOutward(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refType: map['RefType'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
      stockType: map['StockType'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    final isVisiblePrice = UserPermissionUtils.checkPermission(EFeatureSystem.outWardTransfer.toValue, EPermissionType.viewPrice.toValue);

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String typeName = ERefTypeExt.valueOf(stockType).getTitle();
        String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    if (NotificationSaleInfo.isNormalShop()) {
      if (isVisiblePrice) {
        content =
            "<b>$cashierName</b> vừa lập phiếu xuất kho $typeName <b>$refNo</b> trị giá <b>$totalAmountStr</b>.";
      } else {
        content =
            "<b>$cashierName</b> vừa lập phiếu xuất kho $typeName <b>$refNo</b>.";
      }
    } else {
      if (isVisiblePrice) {
        content =
            "<b>$cashierName</b> vừa lập phiếu xuất kho $typeName <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.";
      } else {
        content =
            "<b>$cashierName</b> vừa lập phiếu xuất kho $typeName <b>$refNo</b> tại <b>$branchName</b>.";
      }
    }
    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationOutward.fromJson(String source) =>
      NotificationOutward.fromMap(json.decode(source));
}
