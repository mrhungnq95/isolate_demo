import 'dart:convert';

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo cảnh báo tồn kho
/// Nội dung thông báo: "Có 10 hàng hoá hết hàng tại Cầu Giấy"
/// {"TotalInventoryItem":99,"BranchName":"Minh Hoa Cosmetic","BranchID":"891c4a61-8a21-47ca-8fc5-714bd2744b7c"}
class NotificationInStock implements NotificationItemBase {
  int totalItem; // tổng
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationInStock({
    this.totalItem,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'TotalInventoryItem': totalItem,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationInStock.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationInStock(
      totalItem: map['TotalInventoryItem'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    String totalItemStr =
        (totalItem ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String branchName = this.branchName ?? '';

    if (totalItem == null || totalItem == 1) {
      if (NotificationSaleInfo.isNormalShop()) {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font>.";
        }
      } else {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> tại <b>$branchName</b>.";
        }
      }
    } else if (totalItem > 1) {
      if (NotificationSaleInfo.isNormalShop()) {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font>.";
        }
      } else {
        if (branchID == null || branchID == AppConstant.UUID_EMPTY) {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> trên toàn chuỗi.";
        } else {
          content =
              "Có <b>$totalItemStr</b> hàng hoá <font color='red'>hết hàng</font> tại <b>$branchName</b>.";
        }
      }
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationInStock.fromJson(String source) =>
      NotificationInStock.fromMap(json.decode(source));
}
