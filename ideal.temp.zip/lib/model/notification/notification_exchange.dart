import 'dart:convert';
import 'dart:math';

import 'package:MShopManager/enums/enum_notication_exchange_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

/// Thông báo đổi trả
///  Nội dung thông báo: "Vũ Quốc Minh vừa lập hóa đơn đổi trả 1900205654TH thu thêm 500.000 tại Cầu Giấy."
///                      "Vũ Quốc Minh vừa lập hóa đơn đổi trả 1900205654TH giảm nợ 200.000 tại Cầu Giấy."
///                      "Vũ Quốc Minh vừa lập hóa đơn đổi trả 1900205654TH trả lại 300.000 tại Cầu Giấy."
class NotificationExchange implements NotificationItemBase {
  int typeExchange; // loại thông báo đổi trả: thu thêm, giảm nợ , trả lại
  String cashierName; // tên thu ngân
  String refNo; // số hoá đơn
  String refID; // id hoá đơn
  double totalAmount; // tổng tiền
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationExchange({
    this.typeExchange,
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationExchange.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationExchange(
      typeExchange: map["TypeSAInvoice"],
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    String totalAmountStr =
        (totalAmount ?? 0).abs().toDouble().toStringFormat(EDoubleFormat.money);
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    switch (ENoticationExchangeTypeExt.valueOf(typeExchange)) {
      case ENoticationExchangeType.more:
        if (NotificationSaleInfo.isNormalShop()) {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> thu thêm <b>$totalAmountStr</b>.';
        } else {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> thu thêm <b>$totalAmountStr</b> tại <b>$branchName</b>.';
        }
        break;

      case ENoticationExchangeType.reduceDebt:
        if (NotificationSaleInfo.isNormalShop()) {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> giảm nợ <b>$totalAmountStr</b>.';
        } else {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> giảm nợ <b>$totalAmountStr</b> tại <b>$branchName</b>.';
        }
        break;

      case ENoticationExchangeType.refund:
        if (NotificationSaleInfo.isNormalShop()) {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> trả lại tiền <b>$totalAmountStr</b>.';
        } else {
          content =
              '<b>$cashierName</b> vừa lập hoá đơn đổi trả <b>$refNo</b> trả lại tiền <b>$totalAmountStr</b> tại <b>$branchName</b>.';
        }
        break;
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationExchange.fromJson(String source) =>
      NotificationExchange.fromMap(json.decode(source));
}
