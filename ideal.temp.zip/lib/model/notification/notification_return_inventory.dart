import 'dart:convert';

import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/enums/enum_feature_system.dart';
import 'package:MShopManager/enums/enum_permission_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo trả lại hàng mua
/// Nội dung thông báo: "Vũ Quốc Minh vừa lập phiếu trả lại hàng mua XK000068 trị giá 2.000.000 tại Cầu Giấy"
///
class NotificationReturnInventory implements NotificationItemBase {
  String cashierName; // Tên thu ngân
  String refNo; // Số hoá đơn
  String refID; // Id hoá đơn
  double totalAmount; // Tổng tiền hoá đơn ban đầu
  String branchID; // Id chi nhánh
  String branchName; // Tên chi nhánh

  NotificationReturnInventory({
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationReturnInventory.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationReturnInventory(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    final isVisiblePrice = UserPermissionUtils.checkPermission(EFeatureSystem.returnItem.toValue, EPermissionType.viewPrice.toValue);

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    if (NotificationSaleInfo.isNormalShop()) {
      if (isVisiblePrice) {
        content =
            "<b>$cashierName</b> vừa lập phiếu trả lại hàng mua <b>$refNo</b> trị giá <b>$totalAmountStr</b>.";
      } else {
        content =
            "<b>$cashierName</b> vừa lập phiếu trả lại hàng mua <b>$refNo</b>.";
      }
    } else {
      if (isVisiblePrice) {
        content =
            "<b>$cashierName</b> vừa lập phiếu trả lại hàng mua <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.";
      } else {
        content =
            "<b>$cashierName</b> vừa lập phiếu trả lại hàng mua <b>$refNo</b> tại <b>$branchName</b>.";
      }
    }
    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationReturnInventory.fromJson(String source) =>
      NotificationReturnInventory.fromMap(json.decode(source));
}
