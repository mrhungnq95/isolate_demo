import 'dart:convert';

import 'package:MShopManager/enums/enum_notification_type.dart';
import 'package:MShopManager/model/notification/notification_order_notification.dart';
import 'package:MShopManager/utils/date_format_helper.dart';

import 'notification_cancel_invoice.dart';
import 'notification_edit_invoice.dart';
import 'notification_exchange.dart';
import 'notification_import_inventory.dart';
import 'notification_import_stock.dart';
import 'notification_in_stock.dart';
import 'notification_outward.dart';
import 'notification_return_inventory.dart';
import 'notification_sainvoice.dart';
import 'notification_sale_info.dart';
import 'notification_sell_before_date.dart';

///
/// Model thông báo
///
class NotificationItem {
  String notificationDataId;
  String data;
  int notificationType;
  int bakEditMode;
  int editMode;
  bool isRead;
  bool isAutoGenPrimaryKey;
  DateTime createdDate;
  DateTime modifiedDate;

  // Biến tạm build dữ liệu hiển thị thông báo
  Object dataByType;

  NotificationItem({
    this.notificationDataId,
    this.data,
    this.notificationType,
    this.bakEditMode,
    this.editMode,
    this.isRead,
    this.isAutoGenPrimaryKey,
    this.createdDate,
    this.modifiedDate,
  });

  Map<String, dynamic> toMap() {
    return {
      'NotificationDataId': notificationDataId,
      'Data': data,
      'NotificationType': notificationType,
      'BakEditMode': bakEditMode,
      'EditMode': editMode,
      'IsRead': isRead,
      'IsAutoGenPrimaryKey': isAutoGenPrimaryKey,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
    };
  }

  factory NotificationItem.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationItem(
      notificationDataId: map['NotificationDataId'],
      data: map['Data'],
      notificationType: map['NotificationType'],
      bakEditMode: map['BakEditMode'],
      editMode: map['EditMode'],
      isRead: map['IsRead'],
      isAutoGenPrimaryKey: map['IsAutoGenPrimaryKey'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
    );
  }

  String toJson() => json.encode(toMap());

  factory NotificationItem.fromJson(String source) =>
      NotificationItem.fromMap(json.decode(source));

  ///
  /// Build dữ liệu hiển thị theo type của thông báo
  /// VNLONG
  ///
  void buildContentNotificationByType() {
    switch (ENotificationTypeExt.valueOf(notificationType)) {
      case ENotificationType.saleInfo:
        dataByType = NotificationSaleInfo.fromJson(data);
        break;
      case ENotificationType.saInvoice:
        dataByType = NotificationSAInvoice.fromJson(data);
        break;
      case ENotificationType.exchange:
        dataByType = NotificationExchange.fromJson(data);
        break;
      case ENotificationType.editSAInvoice:
        dataByType = NotificationEditInvoice.fromJson(data);
        break;
      case ENotificationType.cancelSAInvoice:
        dataByType = NotificationCancelInvoice.fromJson(data);
        break;
      case ENotificationType.inStock:
        dataByType = NotificationInStock.fromJson(data);
        break;
      case ENotificationType.importInventory:
        dataByType = NotificationImportInventory.fromJson(data);
        break;
      case ENotificationType.importStock:
        dataByType = NotificationImportStock.fromJson(data);
        break;
      case ENotificationType.returnInventory:
        dataByType = NotificationReturnInventory.fromJson(data);
        break;
      case ENotificationType.iSMAC:
        break;
      case ENotificationType.outward:
        dataByType = NotificationOutward.fromJson(data);
        break;
      case ENotificationType.sellBeforeDate:
        dataByType = NotificationSellBeforeDate.fromJson(data);
        break;
      case ENotificationType.processOrder:
      case ENotificationType.rejectOrder:
      case ENotificationType.newOrder:
      case ENotificationType.processOrderForManager:
      case ENotificationType.rejectOrderForManager:
        dataByType = NotificationOrder.fromJson(data);
        break;
    }
  }
}


abstract class NotificationItemBase {
  /// 
  /// Build nội dung câu thông báo hiển thị trên UI
  /// [String]: Câu thông báo hiển thị trên UI
  /// 
  String getHtmlContent();
}