import 'dart:ui';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_notification_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/model/notification/notification_order_notification.dart';
import 'package:flutter/material.dart';

import 'notification_cancel_invoice.dart';
import 'notification_edit_invoice.dart';
import 'notification_exchange.dart';
import 'notification_import_inventory.dart';
import 'notification_import_stock.dart';
import 'notification_in_stock.dart';
import 'notification_outward.dart';
import 'notification_return_inventory.dart';
import 'notification_sainvoice.dart';
import 'notification_sale_info.dart';
import 'notification_sell_before_date.dart';

///
/// Model thông báo hiển thị trên UI
///
class NotificationDisplay {
  
  String notificationDataId;
  ENotificationType type;
  String title;
  String content;
  bool isReaded;
  DateTime time;


  NotificationDisplay({@required NotificationItem notification}) {
    notificationDataId = notification.notificationDataId;
    time = notification.createdDate;
    type = ENotificationTypeExt.valueOf(notification.notificationType);
    isReaded = notification.isRead ?? false;

    switch (ENotificationTypeExt.valueOf(notification.notificationType)) {
      case ENotificationType.saleInfo:
        NotificationSaleInfo saleInfo =
            notification.dataByType as NotificationSaleInfo;
        content = saleInfo.getHtmlContent();
        break;
      case ENotificationType.saInvoice:
        NotificationSAInvoice saInvoiceInfo =
            notification.dataByType as NotificationSAInvoice;
        content = saInvoiceInfo.getHtmlContent();
        break;
      case ENotificationType.exchange:
        NotificationExchange exChangeInfo =
            notification.dataByType as NotificationExchange;
        content = exChangeInfo.getHtmlContent();
        break;
      case ENotificationType.editSAInvoice:
        NotificationEditInvoice editInvoiceInfo =
            notification.dataByType as NotificationEditInvoice;
        content = editInvoiceInfo.getHtmlContent();
        break;
      case ENotificationType.cancelSAInvoice:
        NotificationCancelInvoice cancelInvoiceInfo =
            notification.dataByType as NotificationCancelInvoice;
        content = cancelInvoiceInfo.getHtmlContent();
        break;
      case ENotificationType.inStock:
        NotificationInStock inStockInfo =
            notification.dataByType as NotificationInStock;
        content = inStockInfo.getHtmlContent();
        break;
      case ENotificationType.importInventory:
        NotificationImportInventory importInventoryInfo =
            notification.dataByType as NotificationImportInventory;
        content = importInventoryInfo.getHtmlContent();
        break;
      case ENotificationType.importStock:
        NotificationImportStock importStockInfo =
            notification.dataByType as NotificationImportStock;
        content = importStockInfo.getHtmlContent();
        break;
      case ENotificationType.returnInventory:
        NotificationReturnInventory returnInventoryInfo =
            notification.dataByType as NotificationReturnInventory;
        content = returnInventoryInfo.getHtmlContent();
        break;
      case ENotificationType.iSMAC:
        break;
      case ENotificationType.outward:
        NotificationOutward outwardInfo =
            notification.dataByType as NotificationOutward;
        content = outwardInfo.getHtmlContent();
        break;
      case ENotificationType.sellBeforeDate:
        NotificationSellBeforeDate sellBeforeDateInfo =
            notification.dataByType as NotificationSellBeforeDate;
        content = sellBeforeDateInfo.getHtmlContent();
        break;

      case ENotificationType.newOrder:
        NotificationOrder orderInfo =
            notification.dataByType as NotificationOrder;
        content = orderInfo.getNewOrderContent();
        break;
      case ENotificationType.processOrder:
      case ENotificationType.processOrderForManager:
        NotificationOrder orderInfo =
            notification.dataByType as NotificationOrder;
        content = orderInfo.getNewOrderContent();
        content = orderInfo.getProcessOrderContent();
        break;
      case ENotificationType.rejectOrder:
      case ENotificationType.rejectOrderForManager:
        NotificationOrder orderInfo =
            notification.dataByType as NotificationOrder;
        content = orderInfo.getNewOrderContent();
        content = orderInfo.getRejectOrderContent();
        break;
    }
  }

  /// 
  /// Lấy màu sắc background trạng thái thông báo đã đọc và chưa đọc
  /// VNLONG - 30/12/20202
  /// 
  Color getBackgroundColorByReaded() {
    return isReaded ? AppColor.white : AppColor.purple200.withAlpha(80);
  }
}
