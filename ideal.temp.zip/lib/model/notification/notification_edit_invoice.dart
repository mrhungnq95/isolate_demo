import 'dart:convert';

import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo sửa hoá đơn
/// Nội dung thông báo: "Vũ Quốc Minh đã sửa hóa đơn 19010002365 từ 200.000 thành 300.000 tại Cầu Giấy"
///
class NotificationEditInvoice implements NotificationItemBase {
  String cashierName; // tên thu ngân
  String refNo; // số hoá đơn
  String refID; // id hoá đơn
  double totalAmount; // tổng tiền
  double totalAmountEdited; // Tổng tiền hoá đơn sau khi sửa
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationEditInvoice({
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.totalAmountEdited,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'TotalAmountEdited': totalAmountEdited,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationEditInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationEditInvoice(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      totalAmountEdited: map['TotalAmountEdited'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String totalAmountEditedStr =
        (totalAmountEdited ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    if (NotificationSaleInfo.isNormalShop()) {
      content =
          '<b>$cashierName</b> đã sửa hoá đơn <b>$refNo</b> từ <b>$totalAmountStr</b> thành <b>$totalAmountEditedStr</b>.';
    } else {
      content =
          '<b>$cashierName</b> đã sửa hoá đơn <b>$refNo</b> từ <b>$totalAmountStr</b> thành <b>$totalAmountEditedStr</b> tại <b>$branchName</b>.';
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationEditInvoice.fromJson(String source) =>
      NotificationEditInvoice.fromMap(json.decode(source));
}
