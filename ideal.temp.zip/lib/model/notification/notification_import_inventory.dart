import 'dart:convert';

import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/enums/enum_feature_system.dart';
import 'package:MShopManager/enums/enum_permission_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';


/// 
/// Thông báo nhập hàng
/// Nội dung thông báo: "Vũ Quốc Minh vừa lập phiếu nhập hàng NK000068 trị giá 2.000.000 tại Cầu Giấy"
/// 
class NotificationImportInventory implements NotificationItemBase {
  
  String cashierName; // Tên thu ngân
  String refNo; // Số hoá đơn
  String refID; // Id hoá đơn
  double totalAmount; // Tổng tiền hoá đơn ban đầu
  String branchID; // Id chi nhánh
  String branchName; // Tên chi nhánh

  NotificationImportInventory({
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationImportInventory.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationImportInventory(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    final isVisiblePrice = UserPermissionUtils.checkPermission(EFeatureSystem.import.toValue, EPermissionType.viewPrice.toValue);
 
    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    
      if (NotificationSaleInfo.isNormalShop()) {
        if (isVisiblePrice) {
          content =
              "<b>${cashierName ?? ''}</b> vừa lập phiếu nhập hàng <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b>.";
        } else {
          content =
              "<b>${cashierName ?? ''}</b> vừa lập phiếu nhập hàng <b>${refNo ?? ''}</b>.";
        }
      } else {
         if (isVisiblePrice) {
            content =
              "<b>${cashierName ?? ''}</b> vừa lập phiếu nhập hàng <b>${refNo ?? ''}</b> trị giá <b>$totalAmountStr</b> tại <b>${branchName ?? ''}</b>.";
         } else {
           content = '<b>${cashierName ?? ''}</b> vừa lập phiếu nhập hàng <b>${refNo ?? ''}</b> tại <b>${branchName ?? ''}</b>.';
         }
    }
    return NotificationSaleInfo.buildHtml(content);
  }


  String toJson() => json.encode(toMap());

  factory NotificationImportInventory.fromJson(String source) =>
      NotificationImportInventory.fromMap(json.decode(source));
}
