import 'dart:convert';

import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/enums/enum_feature_system.dart';
import 'package:MShopManager/enums/enum_permission_type.dart';
import 'package:MShopManager/enums/enum_ref_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Thông báo nhập kho
/// {"CashierName":"admin","StockType":2095,"StockTypeName":"Nhập kho","TotalAmount":1500000.0,"ReportType":7,"CompanyCode":"namfashion","IsOnWorker":false,"UserID":"d09da357-8902-4422-a7fb-3c08c75ac066","RefID":"829da4fb-7567-43bd-adc2-095fb0ff7aa1","RefNo":"NK00248","BranchID":"b5adbc99-dc19-4639-85a6-34b94f744ee1"}
///  Nội dung thông báo: "Vũ Quốc Minh vừa lập phiếu nhập kho khác NK000068 trị giá 2.000.000 tại Cầu Giấy"
///    Loại phiếu gồm:
///    nhập kho khác
///    nhập kho điều chuyển
///    nhập kho kiểm kê
class NotificationImportStock implements NotificationItemBase {
  String cashierName;
  int stockType; // Loại kho
  String stockTypeName; // Tên loại kho
  String refID; // Số phiếu nhập
  String refNo; // Mã phiếu
  double totalAmount; // Tổng tiền hóa đơn ban đầu
  String branchID; // Tên chi nhánh
  String branchName;
  bool isOnWorker; // Có phải tự sinh hay không?

  NotificationImportStock({
    this.cashierName,
    this.stockType,
    this.stockTypeName,
    this.refID,
    this.refNo,
    this.totalAmount,
    this.branchID,
    this.branchName,
    this.isOnWorker,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'StockType': stockType,
      'StockTypeName': stockTypeName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'IsOnWorker': isOnWorker,
    };
  }

  factory NotificationImportStock.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationImportStock(
      stockType: map['StockType'],
      cashierName: map['CashierName'],
      stockTypeName: map['StockTypeName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
      isOnWorker: map['IsOnWorker'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    final isVisiblePrice = UserPermissionUtils.checkPermission(EFeatureSystem.inWardTransfer.toValue, EPermissionType.viewPrice.toValue);
    
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String typeName = ERefTypeExt.valueOf(stockType).getTitle();

    if (NotificationSaleInfo.isNormalShop()) {
      if (isVisiblePrice) {
        if (isOnWorker ?? false) {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập kho hàng trả lại $typeName <b>$refNo</b> trị giá <b>$totalAmountStr</b>.";
        } else {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập $typeName <b>$refNo</b> trị giá <b>$totalAmountStr</b>.";
        }
      } else {
        if (isOnWorker ?? false) {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập kho hàng trả lại $typeName <b>$refNo</b>.";
        } else {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập $typeName <b>$refNo</b>.";
        }
      }
    } else {
      if (isVisiblePrice) {
        if (isOnWorker ?? false) {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập kho hàng trả lại $typeName <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.";
        } else {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập kho <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>";
        }
      } else {
        if (isOnWorker ?? false) {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập kho hàng trả lại $typeName <b>$refNo</b> tại <b>$branchName</b>.";
        } else {
          content =
              "<b>$cashierName</b> vừa lập phiếu nhập $typeName <b>$refNo</b> tại <b>$branchName</b>.";
        }
      }
    }
    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationImportStock.fromJson(String source) =>
      NotificationImportStock.fromMap(json.decode(source));
}
