import 'dart:convert';

import 'package:MShopManager/enums/enum_notication_invoice_type.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/utils/number_format_helper.dart';

import 'notification_sale_info.dart';

///
/// Model hiển thị thông báo hóa đơn
/// Nội dung thông báo: "Vũ Quốc Minh đã lập hóa đơn 19010100056 trị giá 1.000.000 tại Cầu Giấy."
///                     "Vũ Quốc Minh đã nhập bù hóa đơn 1901020006NB trị giá 250,000 tại Cầu Giấy."
class NotificationSAInvoice implements NotificationItemBase {
  int typeSAInvoice; // loại thông báo hoá đơn: lập hoá đơn, nhập bù hoá đơn, hoá đơn giao hàng
  String cashierName; // tên thu ngân
  String refNo; // số hoá đơn
  String refID; // id hoá đơn
  double totalAmount; // tổng tiền
  String branchID; // id chi nhánh
  String branchName; // tên chi nhánh

  NotificationSAInvoice({
    this.typeSAInvoice,
    this.cashierName,
    this.refNo,
    this.refID,
    this.totalAmount,
    this.branchID,
    this.branchName,
  });

  Map<String, dynamic> toMap() {
    return {
      'CashierName': cashierName,
      'RefID': refID,
      'RefNo': refNo,
      'TotalAmount': totalAmount,
      'BranchID': branchID,
      'BranchName': branchName,
    };
  }

  factory NotificationSAInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return NotificationSAInvoice(
      cashierName: map['CashierName'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      totalAmount: map['TotalAmount'],
      branchID: map['BranchID'],
      branchName: map['BranchName'],
    );
  }

  @override
  String getHtmlContent() {
    var content = '';

    String totalAmountStr =
        (totalAmount ?? 0).toDouble().toStringFormat(EDoubleFormat.money);
    String cashierName = this.cashierName ?? '';
    String refNo = this.refNo ?? '';
    String branchName = this.branchName ?? '';

    switch (ENoticationInvoiceTypeExt.valueOf(typeSAInvoice)) {
      case ENoticationInvoiceType.compensationInvoice:
        if (NotificationSaleInfo.isNormalShop()) {
          content =
              '<b>$cashierName</b> đã nhập bù hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b>.';
        } else {
          content =
              '<b>$cashierName</b> đã nhập bù hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.';
        }
        break;
      default:
        if (NotificationSaleInfo.isNormalShop()) {
          content =
              '<b>$cashierName</b> đã lập hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b>.';
        } else {
          content =
              '<b>$cashierName</b> đã lập hoá đơn <b>$refNo</b> trị giá <b>$totalAmountStr</b> tại <b>$branchName</b>.';
        }
    }

    return NotificationSaleInfo.buildHtml(content);
  }

  String toJson() => json.encode(toMap());

  factory NotificationSAInvoice.fromJson(String source) =>
      NotificationSAInvoice.fromMap(json.decode(source));
}
