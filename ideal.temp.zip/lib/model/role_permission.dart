//
// Created by nqhung on 11/11/2020.
//
import 'dart:convert';


class RolePermission {
  int SubSystemID;
  int Permission;
  int RoleID;
  String BranchID;

  RolePermission({
    this.SubSystemID,
    this.Permission,
    this.RoleID,
    this.BranchID,
  });

  Map<String, dynamic> toMap() {
    return {
      'SubSystemID': SubSystemID,
      'Permission': Permission,
      'RoleID': RoleID,
      'BranchID': BranchID,
    };
  }

  factory RolePermission.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return RolePermission(
      SubSystemID: map['SubSystemID'],
      Permission: map['Permission'],
      RoleID: map['RoleID'],
      BranchID: map['BranchID'],
    );
  }

  String toJson() => json.encode(toMap());

  factory RolePermission.fromJson(dynamic source) => RolePermission.fromMap(json.decode(source));
}
