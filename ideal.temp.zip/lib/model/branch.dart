//
// Created by nqhung on 11/11/2020.
//

import 'dart:convert';

import 'package:MShopManager/app/app_constant.dart';

class Branch {

  String branchId;

  String branchName;

  String address;

  List<int> roles;

  int virtualBranch;

  int inActive;

  bool isSelected = false;

  Branch(
      {this.branchId,
      this.branchName,
      this.address,
      this.roles,
      this.inActive = 0,
      this.virtualBranch});

  factory Branch.systemBranch() {
    return Branch(
        branchId: AppConstant.UUID_EMPTY,
        branchName: "Chuỗi nhà hàng",
        address: "Tất cả các cửa hàng");
  }

  ///factory Branch.fromJson(Map<String, dynamic> json) => _$BranchFromJson(json);

  ///Map<String, dynamic> toJson() => _$BranchToJson(this);

  Map<String, dynamic> toMap() {
    return {
      'BranchID': branchId,
      'BranchName': branchName,
      'Address': address,
      'Roles': roles,
      'IsVirtualBranch': virtualBranch,
      'Inactive': inActive,
    };
  }

  factory Branch.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return Branch(
      branchId: map['BranchID'],
      branchName: map['BranchName'],
      address: map['Address'],
      roles: map['Roles'] != null ? List<int>.from(map['Roles']) : null,
      virtualBranch: map['IsVirtualBranch'],
      inActive: map['Inactive'],
    );
  }

  String toJson() => json.encode(toMap());

  factory Branch.fromJson(dynamic source) =>
      Branch.fromMap(json.decode(source));
}

extension BranchExt on Branch {
  ///
  /// Kiểm tra có phải kho Tổng không?
  ///
  bool isVirtualBranch() {
    return this.virtualBranch != 0;
  }
}
