import 'dart:convert';

import 'package:MShopManager/enums/enum_provider_sort_type.dart';
import 'package:MShopManager/enums/enum_provider_view_type.dart';

class VendorFilterSetting {
  /// Sắp xếp
  EProviderSortType sortType;

  /// Xem theo
  EProviderViewType viewType;

  VendorFilterSetting({this.sortType, this.viewType});


  Map<String, dynamic> toMap() {
    return {
      'sortType': sortType.value,
      'viewType': viewType.value,
    };
  }

  factory VendorFilterSetting.newDefault() {
    return VendorFilterSetting(
      sortType: EProviderSortType.name,
      viewType: EProviderViewType.active,
    );
  }

  factory VendorFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return VendorFilterSetting(
      sortType: EProviderSortTypeExtension.fromValue(map['sortType']),
      viewType: EViewTypeExtension.fromValue(map['viewType']),
    );
  }

  String toJson() => json.encode(toMap());

  factory VendorFilterSetting.fromJson(String source) =>
      VendorFilterSetting.fromMap(json.decode(source));
}