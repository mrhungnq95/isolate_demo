import 'package:flutter/widgets.dart';

class ReportCompareResult {
  String fluctuationsTitle;
  IconData fluctuationsIcon;
  Color fluctuationsColor;
  ReportCompareResult({
    this.fluctuationsTitle,
    this.fluctuationsIcon,
    this.fluctuationsColor,
  });
}
