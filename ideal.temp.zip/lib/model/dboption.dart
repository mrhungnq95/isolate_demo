import 'dart:convert';

class DBOption {
  String dBOptionID;
  String optionID;
  String userID;
  String branchID;
  String optionValue;
  int valueType;
  String description;
  bool isSystem;
  bool isSynchronizeOption;
  String tableSchema;

  DBOption({
    this.dBOptionID,
    this.optionID,
    this.userID,
    this.branchID,
    this.optionValue,
    this.valueType,
    this.description,
    this.isSystem,
    this.isSynchronizeOption,
    this.tableSchema,
  });

  Map<String, dynamic> toMap() {
    return {
      'DBOptionID': dBOptionID,
      'OptionID': optionID,
      'UserID': userID,
      'BranchID': branchID,
      'OptionValue': optionValue,
      'ValueType': valueType,
      'Description': description,
      'IsSystem': isSystem,
      'IsSynchronizeOption': isSynchronizeOption,
      'TableSchema': tableSchema,
    };
  }

  factory DBOption.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return DBOption(
      dBOptionID: map['DBOptionID'],
      optionID: map['OptionID'],
      userID: map['UserID'],
      branchID: map['BranchID'],
      optionValue: map['OptionValue'],
      valueType: map['ValueType'],
      description: map['Description'],
      isSystem: map['IsSystem'],
      isSynchronizeOption: map['IsSynchronizeOption'],
      tableSchema: map['TableSchema'],
    );
  }

  String toJson() => json.encode(toMap());

  factory DBOption.fromJson(dynamic source) =>
      DBOption.fromMap(json.decode(source));
}
