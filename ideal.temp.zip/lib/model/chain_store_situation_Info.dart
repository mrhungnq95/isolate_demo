import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:mp_chart/mp/core/data_set/bar_data_set.dart';

class ChainStoreSituationInfo {
  //Tên cửa hàng
  String name;

  //True nếu là toàn chuỗi, false thì là cửa hàng
  bool isChain;

  //Địa chỉ cửa hàng
  String address;

  //Doanh thu
  double revenueAmount;

  //Chi phí
  double costAmount;

  //Lợi nhuận
  double profitAmount;

  //Màu sắc hiển thị trên biểu đồ
  Colors color;

  List<BarDataSet> barDataSet;

  ChainStoreSituationInfo({
    this.name,
    this.isChain,
    this.address,
    this.revenueAmount,
    this.costAmount,
    this.profitAmount,
    this.barDataSet
  });

  Map<String, dynamic> toMap() {
    return {
      'Name': name,
      'IsChain': isChain,
      'Address': address,
      'RevenueAmount': revenueAmount,
      'CostAmount': costAmount,
      'ProfitAmount': profitAmount,
    };
  }

  factory ChainStoreSituationInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return ChainStoreSituationInfo(
      name: map['Name'],
      isChain: map['IsChain'],
      address: map['Address'],
      revenueAmount: map['RevenueAmount'],
      costAmount: map['CostAmount'],
      profitAmount: map['ProfitAmount'],
    );
  }

  String toJson() => json.encode(toMap());

  factory ChainStoreSituationInfo.fromJson(String source) =>
      ChainStoreSituationInfo.fromMap(json.decode(source));
}
