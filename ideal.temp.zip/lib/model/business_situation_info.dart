import 'dart:convert';

class BusinessSituationInfo {
  String name;
  double revenueAmount;
  double costAmount;
  double profitAmount;
  BusinessSituationInfo({
    this.name,
    this.revenueAmount,
    this.costAmount,
    this.profitAmount,
  });

  Map<String, dynamic> toMap() {
    return {
      'Name': name,
      'RevenueAmount': revenueAmount,
      'CostAmount': costAmount,
      'ProfitAmount': profitAmount,
    };
  }

  factory BusinessSituationInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return BusinessSituationInfo(
      name: map['Name'],
      revenueAmount: map['RevenueAmount'],
      costAmount: map['CostAmount'],
      profitAmount: map['ProfitAmount'],
    );
  }

  String toJson() => json.encode(toMap());

  factory BusinessSituationInfo.fromJson(String source) =>
      BusinessSituationInfo.fromMap(json.decode(source));
}
