import 'dart:convert';

///
/// Item doanh thu chuỗi cửa hàng
///
class RevenueShopChainInfo {

  String address;
  double costAmount;
  bool isChain;
  String name;
  double profitAmount;
  double revenueAmount;


  RevenueShopChainInfo({
    this.address,
    this.costAmount,
    this.isChain,
    this.name,
    this.profitAmount,
    this.revenueAmount,
  });
  

  Map<String, dynamic> toMap() {
    return {
      'Address': address,
      'CostAmount': costAmount,
      'IsChain': isChain,
      'Name': name,
      'ProfitAmount': profitAmount,
      'RevenueAmount': revenueAmount,
    };
  }

  factory RevenueShopChainInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return RevenueShopChainInfo(
      address: map['Address'],
      costAmount: map['CostAmount'],
      isChain: map['IsChain'],
      name: map['Name'],
      profitAmount: map['ProfitAmount'],
      revenueAmount: map['RevenueAmount'],
    );
  }

  String toJson() => json.encode(toMap());

  factory RevenueShopChainInfo.fromJson(String source) => RevenueShopChainInfo.fromMap(json.decode(source));
}
