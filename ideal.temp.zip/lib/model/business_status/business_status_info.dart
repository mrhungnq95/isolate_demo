import 'dart:convert';

import 'package:MShopManager/model/customer/debt_customer.dart';

///
/// Thông tin tình hình kinh doanh
///
class BusinessStatusInfo {

  /// Chi phí
  double costAmount;

  /// Lợi nhuận
  double profitAmount;

  /// Thống kê theo tháng: Hiển thị từ tháng 1 đến tháng 12 ; Quý: Quý 1->4; Năm: Hiển thị Năm
  String name;

  /// Doanh thu
  double revenueAmount;

  BusinessStatusInfo({
    this.costAmount,
    this.profitAmount,
    this.name,
    this.revenueAmount,
  });

  Map<String, dynamic> toMap() {
    return {
      'CostAmount': costAmount,
      'ProfitAmount': profitAmount,
      'Name': name,
      'RevenueAmount': revenueAmount,
    };
  }

  factory BusinessStatusInfo.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return BusinessStatusInfo(
      costAmount: map['CostAmount'],
      profitAmount: map['ProfitAmount'],
      name: map['Name'],
      revenueAmount: map['RevenueAmount'],
    );
  }

  String toJson() => json.encode(toMap());

  factory BusinessStatusInfo.fromJson(String source) =>
      BusinessStatusInfo.fromMap(json.decode(source));
}
