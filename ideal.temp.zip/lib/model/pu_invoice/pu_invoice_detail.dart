import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';

///
/// [Description] Chi tiết chứng từ
///
/// Created by TTLOI on 13/01/2021 (10:06).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class PUInvoiceDetail {
  String refDetailID;
  String refID;
  String refNo;
  String skuCode;
  String inventoryItemID;
  String parentID;
  String inventoryItemName;
  String vendorID;
  String stockID;
  String stockName;
  String stockCode;
  String unitID;
  String unitName;
  double quantity;
  double unitPrice;
  double amount;
  double discountRate;
  double discountAmount;
  double vatRate;
  double vatAmount;
  double payAmount;
  String puOrderID;
  String puOrderDetailID;
  String budgetItemID;
  int sortOrder;
  double quantityReturn;
  int importMode;
  int editMode;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String clientID;
  String oldData;
  int bakEditMode;
  String note;
  int manageType; // kiểu lô hay imei
  DateTime sellBeforeDay; //ngày cận date
  int sellBeforeType; //type Kiểu giá trị ngày cận date: 1. Ngày 2. Tháng
  String serials; //list serial/imei
  String lotID; //lô
  String lotNo; //lô
  String lotDetailID;
  DateTime expiryDate;

  PUInvoiceDetail({
    this.refDetailID,
    this.refID,
    this.refNo,
    this.skuCode,
    this.inventoryItemID,
    this.parentID,
    this.inventoryItemName,
    this.vendorID,
    this.stockID,
    this.stockName,
    this.stockCode,
    this.unitID,
    this.unitName,
    this.quantity,
    this.unitPrice,
    this.amount,
    this.discountRate,
    this.discountAmount,
    this.vatRate,
    this.vatAmount,
    this.payAmount,
    this.puOrderID,
    this.puOrderDetailID,
    this.budgetItemID,
    this.sortOrder,
    this.quantityReturn,
    this.importMode,
    this.editMode,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.clientID,
    this.oldData,
    this.bakEditMode,
    this.note,
    this.manageType,
    this.sellBeforeDay,
    this.sellBeforeType,
    this.serials,
    this.lotID,
    this.lotNo,
    this.lotDetailID,
    this.expiryDate,
  });

  factory PUInvoiceDetail.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return PUInvoiceDetail(
      refDetailID: map['RefDetailID'],
      refID: map['RefID'],
      refNo: map['RefNo'],
      skuCode: map['SKUCode'],
      inventoryItemID: map['InventoryItemID'],
      parentID: map['ParentID'],
      inventoryItemName: map['InventoryItemName'],
      vendorID: map['VendorID'],
      stockID: map['StockID'],
      stockName: map['StockName'],
      stockCode: map['StockCode'],
      unitID: map['UnitID'],
      unitName: map['UnitName'],
      quantity: map['Quantity'],
      unitPrice: map['UnitPrice'],
      amount: map['Amount'],
      discountRate: map['DiscountRate'],
      discountAmount: map['DiscountAmount'],
      vatRate: map['VATRate'],
      vatAmount: map['VATAmount'],
      payAmount: map['PayAmount'],
      puOrderID: map['PUOrderID'],
      puOrderDetailID: map['PUOrderDetailID'],
      budgetItemID: map['BudgetItemID'],
      sortOrder: map['SortOrder'],
      quantityReturn: map['QuantityReturn'],
      importMode: map['ImportMode'],
      editMode: map['EditMode'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      clientID: map['ClientID'],
      oldData: map['OldData'],
      bakEditMode: map['BakEditMode'],
      note: map['Note'],
      manageType: map['ManageType'], // kiểu lô hay imei
      sellBeforeDay: DateTimeFormatHelper.parseString2Date(map['SellBeforeDay']), //ngày cận date
      sellBeforeType: map['SellBeforeType'], //type Kiểu giá trị ngày cận date: 1. Ngày 2. Tháng
      serials: map['Serials'], //list serial/imei
      lotID: map['LotID'], //lô
      lotNo: map['LotNo'], //lô
      lotDetailID: map['LotDetailID'],
      expiryDate: DateTimeFormatHelper.parseString2Date(map['ExpiryDate']), //ngày hết hạn
    );
  }

  factory PUInvoiceDetail.fromJson(String source) =>
      PUInvoiceDetail.fromMap(json.decode(source));

  Map<String, dynamic> toMap() {
    return {
      'RefDetailID': refDetailID,
      'RefID': refID,
      'RefNo': refNo,
      'SKUCode': skuCode,
      'InventoryItemID': inventoryItemID,
      'ParentID': parentID,
      'InventoryItemName': inventoryItemName,
      'VendorID': vendorID,
      'StockID': stockID,
      'StockName': stockName,
      'StockCode': stockCode,
      'UnitID': unitID,
      'UnitName': unitName,
      'Quantity': quantity,
      'UnitPrice': unitPrice,
      'Amount': amount,
      'DiscountRate': discountRate,
      'DiscountAmount': discountAmount,
      'VATRate': vatRate,
      'VATAmount': vatAmount,
      'PayAmount': payAmount,
      'PUOrderID': puOrderID,
      'PUOrderDetailID': puOrderDetailID,
      'BudgetItemID': budgetItemID,
      'SortOrder': sortOrder,
      'QuantityReturn': quantityReturn,
      'ImportMode': importMode,
      'EditMode': editMode,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'ClientID': clientID,
      'OldData': oldData,
      'BakEditMode': bakEditMode,
      'Note': note,
      'ManageType': manageType, // kiểu lô hay imei
      'SellBeforeDay': DateTimeFormatHelper.formatDate2String(sellBeforeDay, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT), //ngày cận date
      'SellBeforeType': sellBeforeType, //type Kiểu giá trị ngày cận date: 1. Ngày 2. Tháng
      'Serials': serials, //list serial/imei
      'LotID': lotID, //lô
      'LotNo': lotNo, //lô
      'LotDetailID': lotDetailID,
      'ExpiryDate': DateTimeFormatHelper.formatDate2String(expiryDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT), //ngày hết hạn
    };
  }

  String toJson() => json.encode(toMap());
}
