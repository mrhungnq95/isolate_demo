import 'dart:convert';

import 'package:MShopManager/model/pu_invoice/pu_invoice_detail.dart';
import 'package:MShopManager/utils/date_format_helper.dart';

///
/// [Description] Chứng từ
///
/// Created by TTLOI on 13/01/2021 (09:09).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class PUInvoice {
  String refID;
  String refNo;
  String branchID;
  String vendorID;
  String vendorCode;
  String vendorName;
  String contactName;
  String receiverName;
  String address;
  String journalMemo;
  String caRefNo;
  DateTime invDate;
  String companyTaxCode;
  DateTime refDate;
  String employeeID;
  String employeeName;
  String employeeCode;
  int paymentType;
  bool includeInvoice;
  String invNo;
  double totalAmount;
  DateTime caRefDate;
  int refType;
  String vendorBankAccount;
  String vendorBankName;
  String caJournalMemo;
  bool bankReconside;
  DateTime bankReconsideDate;
  String editVersion;
  bool isUpdateCARefNo;
  int editMode;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String clientID;
  String oldData;
  int bakEditMode;
  String note;
  List<String> detailFieldConfig;
  bool isArisen;
  String arisenRefNo;
  String branchName;
  List<PUInvoiceDetail> puInvoiceDetails;
  List<PUInvoiceDetail> detailsOld;

  PUInvoice({
    this.refID,
    this.refNo,
    this.branchID,
    this.vendorID,
    this.vendorCode,
    this.vendorName,
    this.contactName,
    this.receiverName,
    this.address,
    this.journalMemo,
    this.caRefNo,
    this.invDate,
    this.companyTaxCode,
    this.refDate,
    this.employeeID,
    this.employeeName,
    this.employeeCode,
    this.paymentType,
    this.includeInvoice,
    this.invNo,
    this.totalAmount,
    this.caRefDate,
    this.refType,
    this.vendorBankAccount,
    this.vendorBankName,
    this.caJournalMemo,
    this.bankReconside,
    this.bankReconsideDate,
    this.editVersion,
    this.isUpdateCARefNo,
    this.editMode,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.clientID,
    this.oldData,
    this.bakEditMode,
    this.note,
    this.detailFieldConfig,
    this.isArisen,
    this.arisenRefNo,
    this.branchName,
    this.puInvoiceDetails,
    this.detailsOld,
  });

  factory PUInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    return PUInvoice(
      refID: map['RefID'],
      refNo: map['RefNo'],
      branchID: map['BranchID'],
      vendorID: map['VendorID'],
      vendorCode: map['VendorCode'],
      vendorName: map['VendorName'],
      contactName: map['ContactName'],
      receiverName: map['ReceiverName'],
      address: map['Address'],
      journalMemo: map['JournalMemo'],
      caRefNo: map['CARefNo'],
      invDate: DateTimeFormatHelper.parseString2Date(map['InvDate']),
      companyTaxCode: map['CompanyTaxCode'],
      refDate: DateTimeFormatHelper.parseString2Date(map['RefDate']),
      employeeID: map['EmployeeID'],
      employeeName: map['EmployeeName'],
      employeeCode: map['EmployeeCode'],
      paymentType: map['PaymentType'],
      includeInvoice: map['IncludeInvoice'],
      invNo: map['InvNo'],
      totalAmount: map['TotalAmount'],
      caRefDate: DateTimeFormatHelper.parseString2Date(map['CARefDate']),
      refType: map['RefType'],
      vendorBankAccount: map['VendorBankAccount'],
      vendorBankName: map['VendorBankName'],
      caJournalMemo: map['CAJournalMemo'],
      bankReconside: map['BankReconside'],
      bankReconsideDate: DateTimeFormatHelper.parseString2Date(map['BankReconsideDate']),
      editVersion: map['EditVersion'],
      isUpdateCARefNo: map['IsUpdateCARefNo'],
      editMode: map['EditMode'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      clientID: map['ClientID'],
      oldData: map['OldData'],
      bakEditMode: map['BakEditMode'],
      note: map['Note'],
      detailFieldConfig: map['DetailFieldConfig'],
      isArisen: map['IsArisen'],
      arisenRefNo: map['ArisenRefNo'],
      branchName: map['BranchName'],
      puInvoiceDetails: (map['PUInvoiceDetails'] as List)?.map((e) => PUInvoiceDetail.fromMap(e))?.toList(),
      detailsOld: (map['DetailsOld'] as List)?.map((e) => PUInvoiceDetail.fromMap(e)),
    );
  }

  factory PUInvoice.fromJson(String source) =>
      PUInvoice.fromMap(json.decode(source));

  Map<String, dynamic> toMap() {
    return {
      'RefID': refID,
      'RefNo': refNo,
      'BranchID': branchID,
      'VendorID': vendorID,
      'VendorCode': vendorCode,
      'VendorName': vendorName,
      'ContactName': contactName,
      'ReceiverName': receiverName,
      'Address': address,
      'JournalMemo': journalMemo,
      'CARefNo': caRefNo,
      'InvDate': DateTimeFormatHelper.formatDate2String(invDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CompanyTaxCode': companyTaxCode,
      'RefDate': DateTimeFormatHelper.formatDate2String(refDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'EmployeeID': employeeID,
      'EmployeeName': employeeName,
      'EmployeeCode': employeeCode,
      'PaymentType': paymentType,
      'IncludeInvoice': includeInvoice,
      'InvNo': invNo,
      'TotalAmount': totalAmount,
      'CARefDate': DateTimeFormatHelper.formatDate2String(caRefDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'RefType': refType,
      'VendorBankAccount': vendorBankAccount,
      'VendorBankName': vendorBankName,
      'CAJournalMemo': caJournalMemo,
      'BankReconside': bankReconside,
      'BankReconsideDate': DateTimeFormatHelper.formatDate2String(bankReconsideDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'EditVersion': editVersion,
      'IsUpdateCARefNo': isUpdateCARefNo,
      'EditMode': editMode,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate, format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'ClientID': clientID,
      'OldData': oldData,
      'BakEditMode': bakEditMode,
      'Note': note,
      'DetailFieldConfig': detailFieldConfig,
      'IsArisen': isArisen,
      'ArisenRefNo': arisenRefNo,
      'BranchName': branchName,
      'PUInvoiceDetails': puInvoiceDetails.map((e) => e.toMap()).toList(),
      'DetailsOld': detailsOld.map((e) => e.toMap()).toList(),
    };
  }

  String toJson() => json.encode(toMap());
}
