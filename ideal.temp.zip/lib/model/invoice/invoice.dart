import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';

class SAInvoice {
  int additionBillType;
  int bakEditMode;
  String branchID;
  int cancelDeviceType;
  int cancelReasonType;
  String cashierID;
  String cashierName;
  double changeAmount;
  double changeDeductedAmount;
  String clientID;
  String createdBy;
  String createdDate;
  String customerID;
  String customerName;
  String deliveryAddress;
  double deliveryAmount;
  String deliveryCode;
  DateTime deliveryDate;
  String deliveryNote;
  String deliveryService;
  double depositAmount;
  String depositRefDate;
  int depositRefType;
  String deviceID;
  double discountAmount;
  double discountRate;
  int editMode;
  String employeeID;
  String employeeName;
  bool hasConnectedShippingPartner;
  bool isCOD;
  bool isFromOCM;
  bool isReceiveCOD;
  double itemHeight;
  double itemLength;
  double itemWeight;
  double itemWidth;
  String modifiedBy;
  String modifiedDate;
  double notTakeChangeAmount;
  int paymentStatus;
  String promotionID;
  String promotionName;
  double receiveAmount;
  String recipientID;
  String recipientName;
  String recipientNameNoAccent;
  String recipientTel;
  DateTime refDate;
  String refID;
  String refNo;
  int refType;
  double remainAmount;
  double returnExchangeAmount;
  String saleChannelID;
  String saleChannelName;
  int scopeOfApplication;
  int serviceID;
  String shiftRecordID;
  double shippingPartnerAmount;
  String shippingPartnerID;
  String shippingPartnerName;
  String shippingPartnerNameNoAccent;
  String shippingPartnerTel;
  int shippingPartnerType;
  String tableSchema;
  double totalActualAmount;
  double totalAmount;
  double totalAmountPaymented;
  double totalItemAmount;
  double totalItemDiscountAmount;
  double vATAmount;
  double vATRate;
  String customerTel;
  double voucherAmount;
  double cashAmount;
  double cardAmount;
  String returnExchangeRefNo;
  String returnExchangeBranchId;
  String returnExchangeBranchName;
  double transferAmount;
  double debtReductionAmount;
  double debitAmount;
  bool isDebit;
  String description;
  bool isLoadMore = false;
  DateTime createInvoiceDate;
  DateTime completeInvoiceDate;
  int usedPoint = 0;
  int availablePoint = 0;
  int addPoint = 0;
  String partnerStatusName;


  SAInvoice({
    this.additionBillType,
    this.bakEditMode,
    this.branchID,
    this.cancelDeviceType,
    this.cancelReasonType,
    this.cashierID,
    this.cashierName,
    this.changeAmount,
    this.changeDeductedAmount,
    this.clientID,
    this.createdBy,
    this.createdDate,
    this.customerID,
    this.customerName,
    this.deliveryAddress,
    this.deliveryAmount,
    this.deliveryCode,
    this.deliveryDate,
    this.deliveryNote,
    this.deliveryService,
    this.depositAmount,
    this.depositRefDate,
    this.depositRefType,
    this.deviceID,
    this.discountAmount,
    this.discountRate,
    this.editMode,
    this.employeeID,
    this.employeeName,
    this.hasConnectedShippingPartner,
    this.isCOD,
    this.isFromOCM,
    this.isReceiveCOD,
    this.itemHeight,
    this.itemLength,
    this.itemWeight,
    this.itemWidth,
    this.modifiedBy,
    this.modifiedDate,
    this.notTakeChangeAmount,
    this.paymentStatus,
    this.promotionID,
    this.promotionName,
    this.receiveAmount,
    this.recipientID,
    this.recipientName,
    this.recipientNameNoAccent,
    this.recipientTel,
    this.refDate,
    this.refID,
    this.refNo,
    this.refType,
    this.remainAmount,
    this.returnExchangeAmount,
    this.saleChannelID,
    this.saleChannelName,
    this.scopeOfApplication,
    this.serviceID,
    this.shiftRecordID,
    this.shippingPartnerAmount,
    this.shippingPartnerID,
    this.shippingPartnerName,
    this.shippingPartnerNameNoAccent,
    this.shippingPartnerTel,
    this.shippingPartnerType,
    this.tableSchema,
    this.totalActualAmount,
    this.totalAmount,
    this.totalAmountPaymented,
    this.totalItemAmount,
    this.totalItemDiscountAmount,
    this.vATAmount,
    this.vATRate,
    this.customerTel,
    this.voucherAmount,
    this.cashAmount,
    this.cardAmount,
    this.returnExchangeRefNo,
    this.returnExchangeBranchId,
    this.returnExchangeBranchName,
    this.transferAmount,
    this.debtReductionAmount,
    this.debitAmount,
    this.isDebit,
    this.description,
    this.isLoadMore,
    this.createInvoiceDate,
    this.completeInvoiceDate,
    this.usedPoint,
    this.availablePoint,
    this.addPoint,
    this.partnerStatusName,
  });

  Map<String, dynamic> toMap() {
    return {
      'AdditionBillType': additionBillType,
      'BakEditMode': bakEditMode,
      'BranchID': branchID,
      'CancelDeviceType': cancelDeviceType,
      'CancelReasonType': cancelReasonType,
      'CashierID': cashierID,
      'CashierName': cashierName,
      'ChangeAmount': changeAmount,
      'ChangeDeductedAmount': changeDeductedAmount,
      'ClientID': clientID,
      'CreatedBy': createdBy,
      'CreatedDate': createdDate,
      'CustomerID': customerID,
      'CustomerName': customerName,
      'DeliveryAddress': deliveryAddress,
      'DeliveryAmount': deliveryAmount,
      'DeliveryCode': deliveryCode,
      'DeliveryDate': DateTimeFormatHelper.formatDate2String(deliveryDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'DeliveryNote': deliveryNote,
      'DeliveryService': deliveryService,
      'DepositAmount': depositAmount,
      'DepositRefDate': depositRefDate,
      'DepositRefType': depositRefType,
      'DeviceID': deviceID,
      'DiscountAmount': discountAmount,
      'DiscountRate': discountRate,
      'EditMode': editMode,
      'EmployeeID': employeeID,
      'EmployeeName': employeeName,
      'HasConnectedShippingPartner': hasConnectedShippingPartner,
      'IsCOD': isCOD,
      'IsFromOCM': isFromOCM,
      'IsReceiveCOD': isReceiveCOD,
      'ItemHeight': itemHeight,
      'ItemLength': itemLength,
      'ItemWeight': itemWeight,
      'ItemWidth': itemWidth,
      'ModifiedBy': modifiedBy,
      'modifiedDate': modifiedDate,
      'NotTakeChangeAmount': notTakeChangeAmount,
      'PaymentStatus': paymentStatus,
      'PromotionID': promotionID,
      'PromotionName': promotionName,
      'ReceiveAmount': receiveAmount,
      'RecipientID': recipientID,
      'RecipientName': recipientName,
      'RecipientNameNoAccent': recipientNameNoAccent,
      'RecipientTel': recipientTel,
      'RefDate': DateTimeFormatHelper.formatDate2String(refDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT), 
      'RefID': refID,
      'RefNo': refNo,
      'RefType': refType,
      'RemainAmount': remainAmount,
      'ReturnExchangeAmount': returnExchangeAmount,
      'SaleChannelID': saleChannelID,
      'SaleChannelName': saleChannelName,
      'ScopeOfApplication': scopeOfApplication,
      'ServiceID': serviceID,
      'ShiftRecordID': shiftRecordID,
      'ShippingPartnerAmount': shippingPartnerAmount,
      'ShippingPartnerID': shippingPartnerID,
      'ShippingPartnerName': shippingPartnerName,
      'ShippingPartnerNameNoAccent': shippingPartnerNameNoAccent,
      'ShippingPartnerTel': shippingPartnerTel,
      'ShippingPartnerType': shippingPartnerType,
      'TableSchema': tableSchema,
      'TotalActualAmount': totalActualAmount,
      'TotalAmount': totalAmount,
      'TotalAmountPaymented': totalAmountPaymented,
      'TotalItemAmount': totalItemAmount,
      'TotalItemDiscountAmount': totalItemDiscountAmount,
      'VATAmount': vATAmount,
      'VATRate': vATRate,
      'CustomerTel': customerTel,
      'VoucherAmount': voucherAmount,
      'CashAmount': cashAmount,
      'CardAmount': cardAmount,
      'ReturnExchangeRefNo': returnExchangeRefNo,
      'ReturnExchangeBranchId': returnExchangeBranchId,
      'ReturnExchangeBranchName': returnExchangeBranchName,
      'TransferAmount': transferAmount,
      'DebtReductionAmount': debtReductionAmount,
      'DebitAmount': debitAmount,
      'IsDebit': isDebit,
      'Description': description,
      'IsLoadMore': isLoadMore,
      'createInvoiceDate': DateTimeFormatHelper.formatDate2String(createInvoiceDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'completeInvoiceDate':
          DateTimeFormatHelper.formatDate2String(completeInvoiceDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'UsedPoint': usedPoint,
      'AvailablePoint': availablePoint,
      'AddPoint': addPoint,
      'PartnerStatusName': partnerStatusName,
    };
  }

  factory SAInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return SAInvoice(
      additionBillType: map['AdditionBillType'],
      bakEditMode: map['BakEditMode'],
      branchID: map['BranchID'],
      cancelDeviceType: map['CancelDeviceType'],
      cancelReasonType: map['CancelReasonType'],
      cashierID: map['CashierID'],
      cashierName: map['CashierName'],
      changeAmount: map['ChangeAmount'],
      changeDeductedAmount: map['ChangeDeductedAmount'],
      clientID: map['ClientID'],
      createdBy: map['CreatedBy'],
      createdDate: map['CreatedDate'],
      customerID: map['CustomerID'],
      customerName: map['CustomerName'],
      deliveryAddress: map['DeliveryAddress'],
      deliveryAmount: map['DeliveryAmount'],
      deliveryCode: map['DeliveryCode'],
      deliveryDate:
          DateTimeFormatHelper.parseString2Date(map['DeliveryDate']),
      deliveryNote: map['DeliveryNote'],
      deliveryService: map['DeliveryService'],
      depositAmount: map['DepositAmount'],
      depositRefDate: map['depositRefDate'],
      depositRefType: map['DepositRefType'],
      deviceID: map['DeviceID'],
      discountAmount: map['DiscountAmount'],
      discountRate: map['DiscountRate'],
      editMode: map['EditMode'],
      employeeID: map['EmployeeID'],
      employeeName: map['EmployeeName'],
      hasConnectedShippingPartner: map['HasConnectedShippingPartner'],
      isCOD: map['IsCOD'],
      isFromOCM: map['IsFromOCM'],
      isReceiveCOD: map['IsReceiveCOD'],
      itemHeight: map['ItemHeight'],
      itemLength: map['ItemLength'],
      itemWeight: map['ItemWeight'],
      itemWidth: map['ItemWidth'],
      modifiedBy: map['ModifiedBy'],
      modifiedDate: map['modifiedDate'],
      notTakeChangeAmount: map['NotTakeChangeAmount'],
      paymentStatus: map['PaymentStatus'],
      promotionID: map['PromotionID'],
      promotionName: map['PromotionName'],
      receiveAmount: map['ReceiveAmount'],
      recipientID: map['RecipientID'],
      recipientName: map['RecipientName'],
      recipientNameNoAccent: map['RecipientNameNoAccent'],
      recipientTel: map['RecipientTel'],
      refDate: DateTimeFormatHelper.parseString2Date(map['RefDate']),
      refID: map['RefID'],
      refNo: map['RefNo'],
      refType: map['RefType'],
      remainAmount: map['RemainAmount'],
      returnExchangeAmount: map['ReturnExchangeAmount'],
      saleChannelID: map['SaleChannelID'],
      saleChannelName: map['SaleChannelName'],
      scopeOfApplication: map['ScopeOfApplication'],
      serviceID: map['ServiceID'],
      shiftRecordID: map['ShiftRecordID'],
      shippingPartnerAmount: map['ShippingPartnerAmount'],
      shippingPartnerID: map['ShippingPartnerID'],
      shippingPartnerName: map['ShippingPartnerName'],
      shippingPartnerNameNoAccent: map['ShippingPartnerNameNoAccent'],
      shippingPartnerTel: map['ShippingPartnerTel'],
      shippingPartnerType: map['ShippingPartnerType'],
      tableSchema: map['TableSchema'],
      totalActualAmount: map['TotalActualAmount'],
      totalAmount: map['TotalAmount'],
      totalAmountPaymented: map['TotalAmountPaymented'],
      totalItemAmount: map['TotalItemAmount'],
      totalItemDiscountAmount: map['TotalItemDiscountAmount'],
      vATAmount: map['VATAmount'],
      vATRate: map['VATRate'],
      customerTel: map['CustomerTel'],
      voucherAmount: map['VoucherAmount'],
      cashAmount: map['CashAmount'],
      cardAmount: map['CardAmount'],
      returnExchangeRefNo: map['ReturnExchangeRefNo'],
      returnExchangeBranchId: map['ReturnExchangeBranchId'],
      returnExchangeBranchName: map['ReturnExchangeBranchName'],
      transferAmount: map['TransferAmount'],
      debtReductionAmount: map['DebtReductionAmount'],
      debitAmount: map['DebitAmount'],
      isDebit: map['IsDebit'],
      description: map['Description'],
      isLoadMore: map['IsLoadMore'],
      createInvoiceDate:
          DateTimeFormatHelper.parseString2Date(map['createInvoiceDate']),
      completeInvoiceDate:
          DateTimeFormatHelper.parseString2Date(map['completeInvoiceDate']),
      usedPoint: map['UsedPoint'],
      availablePoint: map['AvailablePoint'],
      addPoint: map['AddPoint'],
      partnerStatusName: map['PartnerStatusName'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SAInvoice.fromJson(String source) =>
      SAInvoice.fromMap(json.decode(source));
}
