import 'dart:convert';

import 'package:MShopManager/utils/date_format_helper.dart';

class SAInvoiceCoupon {

  String saInvoiceCouponID;
  String refID;
  String couponCode;
  String promotionName;
  int discountType;
  double discountPercent;
  double discountAmount;
  DateTime applyFromDate;
  DateTime applyToDate;
  String applyCondition;
  String createdBy;
  String modifiedBy;
  DateTime createDate; 
  DateTime modifiedDate; 
  String deviceID;
  int couponID;
  bool isUnlimitedApply;
  double invoiceDiscountAmount;
  DateTime couponCodeTimeoutDateTime;
  int applyConditionBy;
  double applyConditionTotalAmount;
  int applyConditionType;
  // Thứ tự áp dụng 
  // 1. Trước khuyến mại hóa đơn
  // 2. Sau khuyến mại hóa đơn
  int applyNumber;


  SAInvoiceCoupon({
    this.saInvoiceCouponID,
    this.refID,
    this.couponCode,
    this.promotionName,
    this.discountType,
    this.discountPercent,
    this.discountAmount,
    this.applyFromDate,
    this.applyToDate,
    this.applyCondition,
    this.createdBy,
    this.modifiedBy,
    this.createDate,
    this.modifiedDate,
    this.deviceID,
    this.couponID,
    this.isUnlimitedApply,
    this.invoiceDiscountAmount,
    this.couponCodeTimeoutDateTime,
    this.applyConditionBy,
    this.applyConditionTotalAmount,
    this.applyConditionType,
    this.applyNumber,
  });

  Map<String, dynamic> toMap() {
    return {
      'SAInvoiceCouponID': saInvoiceCouponID,
      'RefID': refID,
      'CouponCode': couponCode,
      'PromotionName': promotionName,
      'DiscountType': discountType,
      'DiscountPercent': discountPercent,
      'DiscountAmount': discountAmount,
      'ApplyFromDate': DateTimeFormatHelper.formatDate2String(applyFromDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ApplyToDate': DateTimeFormatHelper.formatDate2String(applyToDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ApplyCondition': applyCondition,
      'CreatedBy': createdBy,
      'ModifiedBy': modifiedBy,
      'CreateDate': DateTimeFormatHelper.formatDate2String(createDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'DeviceID': deviceID,
      'CouponID': couponID,
      'IsUnlimitedApply': isUnlimitedApply,
      'InvoiceDiscountAmount': invoiceDiscountAmount,
      'CouponCodeTimeoutDateTime': DateTimeFormatHelper.formatDate2String(couponCodeTimeoutDateTime,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ApplyConditionBy': applyConditionBy,
      'ApplyConditionTotalAmount': applyConditionTotalAmount,
      'ApplyConditionType': applyConditionType,
      'ApplyNumber': applyNumber,
    };
  }

  factory SAInvoiceCoupon.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return SAInvoiceCoupon(
      saInvoiceCouponID: map['SAInvoiceCouponID'],
      refID: map['RefID'],
      couponCode: map['CouponCode'],
      promotionName: map['PromotionName'],
      discountType: map['DiscountType'],
      discountPercent: map['DiscountPercent'],
      discountAmount: map['DiscountAmount'],
      applyFromDate: DateTimeFormatHelper.parseString2Date(map['ApplyFromDate']),
      applyToDate: DateTimeFormatHelper.parseString2Date(map['ApplyToDate']),
      applyCondition: map['ApplyCondition'],
      createdBy: map['CreatedBy'],
      modifiedBy: map['ModifiedBy'],
      createDate: DateTimeFormatHelper.parseString2Date(map['CreateDate']),
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      deviceID: map['DeviceID'],
      couponID: map['CouponID'],
      isUnlimitedApply: map['IsUnlimitedApply'],
      invoiceDiscountAmount: map['InvoiceDiscountAmount'],
      couponCodeTimeoutDateTime: DateTimeFormatHelper.parseString2Date(map['CouponCodeTimeoutDateTime']),
      applyConditionBy: map['ApplyConditionBy'],
      applyConditionTotalAmount: map['ApplyConditionTotalAmount'],
      applyConditionType: map['ApplyConditionType'],
      applyNumber: map['ApplyNumber'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SAInvoiceCoupon.fromJson(String source) => SAInvoiceCoupon.fromMap(json.decode(source));
}
