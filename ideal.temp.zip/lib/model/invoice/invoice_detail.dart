import 'dart:convert';
import 'package:MShopManager/business/dboption_utils.dart';
import 'package:MShopManager/enums/enum_dboption_key.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/ext/dart_ext/strings.dart';

class SAInvoiceDetail {
  String refDetailID;
  String refID;
  int refDetailType;
  String parentID;
  String inventoryItemID;
  String sKUCode;
  String inventoryItemName;
  int inventoryItemType;
  String unitID;
  double quantity;
  double quantityReturned;
  double unitPrice;
  double amount;
  String promotionID;
  String promotionName;
  double discountRate;
  double discountAmount;
  double allocationAmount;
  String modelID;
  int sortOrder;
  double rateConvert;
  String unitName;
  double unitPriceOriginal;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String color;
  String colourCode;
  String size;
  // Lô, Serial/Imei
  String lotID;
  String lotDetailID;
  DateTime expiryDate;
  String serials;
  int manageType;


  SAInvoiceDetail({
    this.refDetailID,
    this.refID,
    this.refDetailType,
    this.parentID,
    this.inventoryItemID,
    this.sKUCode,
    this.inventoryItemName,
    this.inventoryItemType,
    this.unitID,
    this.quantity,
    this.quantityReturned,
    this.unitPrice,
    this.amount,
    this.promotionID,
    this.promotionName,
    this.discountRate,
    this.discountAmount,
    this.allocationAmount,
    this.modelID,
    this.sortOrder,
    this.rateConvert,
    this.unitName,
    this.unitPriceOriginal,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.color,
    this.colourCode,
    this.size,
    this.lotID,
    this.lotDetailID,
    this.expiryDate,
    this.serials,
    this.manageType,
  });

  Map<String, dynamic> toMap() {
    return {
      'RefDetailID': refDetailID,
      'RefID': refID,
      'RefDetailType': refDetailType,
      'ParentID': parentID,
      'InventoryItemID': inventoryItemID,
      'SKUCode': sKUCode,
      'InventoryItemName': inventoryItemName,
      'InventoryItemType': inventoryItemType,
      'UnitID': unitID,
      'Quantity': quantity,
      'QuantityReturned': quantityReturned,
      'UnitPrice': unitPrice,
      'Amount': amount,
      'PromotionID': promotionID,
      'PromotionName': promotionName,
      'DiscountRate': discountRate,
      'DiscountAmount': discountAmount,
      'AllocationAmount': allocationAmount,
      'ModelID': modelID,
      'SortOrder': sortOrder,
      'RateConvert': rateConvert,
      'UnitName': unitName,
      'UnitPriceOriginal': unitPriceOriginal,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'Color': color,
      'ColourCode': colourCode,
      'Size': size,
      'LotID': lotID,
      'LotDetailID': lotDetailID,
      'ExpiryDate': DateTimeFormatHelper.formatDate2String(expiryDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'Serials': serials,
      'ManageType': manageType,
    };
  }

  factory SAInvoiceDetail.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return SAInvoiceDetail(
      refDetailID: map['RefDetailID'],
      refID: map['RefID'],
      refDetailType: map['RefDetailType'],
      parentID: map['ParentID'],
      inventoryItemID: map['InventoryItemID'],
      sKUCode: map['SKUCode'],
      inventoryItemName: map['InventoryItemName'],
      inventoryItemType: map['InventoryItemType'],
      unitID: map['UnitID'],
      quantity: map['Quantity'],
      quantityReturned: map['QuantityReturned'],
      unitPrice: map['UnitPrice'],
      amount: map['Amount'],
      promotionID: map['PromotionID'],
      promotionName: map['PromotionName'],
      discountRate: map['DiscountRate'],
      discountAmount: map['DiscountAmount'],
      allocationAmount: map['AllocationAmount'],
      modelID: map['ModelID'],
      sortOrder: map['SortOrder'],
      rateConvert: map['RateConvert'],
      unitName: map['UnitName'],
      unitPriceOriginal: map['UnitPriceOriginal'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      color: map['Color'],
      colourCode: map['ColourCode'],
      size: map['Size'],
      lotID: map['LotID'],
      lotDetailID: map['LotDetailID'],
      expiryDate: DateTimeFormatHelper.parseString2Date(map['ExpiryDate']),
      serials: map['Serials'],
      manageType: map['ManageType'],
    );
  }

  String toJson() => json.encode(toMap());

  factory SAInvoiceDetail.fromJson(String source) => SAInvoiceDetail.fromMap(json.decode(source));


  /// 
  /// Build tên với tên đơn vị tính
  /// VNLONG - 07/01/2021
  /// 
  String getInventoryItemWithUnitName() {
    String name = this.inventoryItemName;
    final unitName = this.unitName;
    if (DboptionUtils.getDBOptionValueByKey(EDBOptionKey.isUseUnitConvert.value)) {
      return '$name ${unitName?.isEmptyOrNull == false ? ' - $unitName' : ''}';
    } else {
      return name;
    }
  }
}
