import 'dart:convert';
import 'package:MShopManager/utils/date_format_helper.dart';

class SAInvoicePayment {

  String sAInvoicePaymentID;
  String refID;
  int paymentType;
  String paymentName;
  double amount;
  String cardID;
  String cardName;
  String debitCustomerID;
  String debitCustomerName;
  int sortOrder;
  DateTime createdDate;
  String createdBy;
  DateTime modifiedDate;
  String modifiedBy;
  String voucherID;
  String voucherCode;
  String voucherName;
  double voucherQuantity;
  double voucherAmount;

  SAInvoicePayment({
    this.sAInvoicePaymentID,
    this.refID,
    this.paymentType,
    this.paymentName,
    this.amount,
    this.cardID,
    this.cardName,
    this.debitCustomerID,
    this.debitCustomerName,
    this.sortOrder,
    this.createdDate,
    this.createdBy,
    this.modifiedDate,
    this.modifiedBy,
    this.voucherID,
    this.voucherCode,
    this.voucherName,
    this.voucherQuantity,
    this.voucherAmount,
  });


  factory SAInvoicePayment.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return SAInvoicePayment(
      sAInvoicePaymentID: map['SAInvoicePaymentID'],
      refID: map['RefID'],
      paymentType: map['PaymentType'],
      paymentName: map['PaymentName'],
      amount: map['Amount'],
      cardID: map['CardID'],
      cardName: map['CardName'],
      debitCustomerID: map['DebitCustomerID'],
      debitCustomerName: map['DebitCustomerName'],
      sortOrder: map['SortOrder'],
      createdDate: DateTimeFormatHelper.parseString2Date(map['CreatedDate']),
      createdBy: map['CreatedBy'],
      modifiedDate: DateTimeFormatHelper.parseString2Date(map['ModifiedDate']),
      modifiedBy: map['ModifiedBy'],
      voucherID: map['VoucherID'],
      voucherCode: map['VoucherCode'],
      voucherName: map['VoucherName'],
      voucherQuantity: map['VoucherQuantity'],
      voucherAmount: map['VoucherAmount'],
    );
  }

  factory SAInvoicePayment.fromJson(String source) => SAInvoicePayment.fromMap(json.decode(source));

  Map<String, dynamic> toMap() {
    return {
      'SAInvoicePaymentID': sAInvoicePaymentID,
      'RefID': refID,
      'PaymentType': paymentType,
      'PaymentName': paymentName,
      'Amount': amount,
      'CardID': cardID,
      'CardName': cardName,
      'DebitCustomerID': debitCustomerID,
      'DebitCustomerName': debitCustomerName,
      'SortOrder': sortOrder,
      'CreatedDate': DateTimeFormatHelper.formatDate2String(createdDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'CreatedBy': createdBy,
      'ModifiedDate': DateTimeFormatHelper.formatDate2String(modifiedDate,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
      'ModifiedBy': modifiedBy,
      'VoucherID': voucherID,
      'VoucherCode': voucherCode,
      'VoucherName': voucherName,
      'VoucherQuantity': voucherQuantity,
      'VoucherAmount': voucherAmount,
    };
  }

  String toJson() => json.encode(toMap());
}
