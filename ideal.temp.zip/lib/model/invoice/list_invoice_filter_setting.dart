import 'dart:convert';

import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

class ListInvoiceFilterSetting {
  
  // Thời gian xem báo cáo
  EReportPeriodType timePeriod = EReportPeriodType.thisDay;
  // Chi nhánh đang chọn
  Branch branch;
  // Trạng thái hóa đơn
  EPaymentStatus paymentStatus = EPaymentStatus.all;
  // Case custom date
  DateRange dateRange;


  ListInvoiceFilterSetting({
    this.timePeriod,
    this.branch,
    this.paymentStatus,
    this.dateRange,
  });
  

 /// Khởi tạo giá trị mặc định
  factory ListInvoiceFilterSetting.newDefault({Branch branchDefault}) {
    ListInvoiceFilterSetting param = ListInvoiceFilterSetting();
    param.branch = branchDefault;
    param.timePeriod = EReportPeriodType.thisDay;
    param.paymentStatus = EPaymentStatus.all;
    param.dateRange = DateRange(startDate: DateTime.now(), endDate: DateTime.now());
    return param;
  }


  Map<String, dynamic> toMap() {
    return {
      'timePeriod': timePeriod?.rawValue,
      'branch': branch?.toMap(),
      'paymentStatus': paymentStatus.rawValue,
      'dateRange': dateRange?.toMap(),
    };
  }

  factory ListInvoiceFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return ListInvoiceFilterSetting(
      timePeriod: EReportPeriodTypeExt.valueOf(map['timePeriod']),
      branch: Branch.fromMap(map['branch']),
      paymentStatus: EPaymentStatusExt.fromValue(map['paymentStatus']),
      dateRange: DateRange.fromMap(map['dateRange'])
    );
  }

  String toJson() => json.encode(toMap());

  factory ListInvoiceFilterSetting.fromJson(String source) => ListInvoiceFilterSetting.fromMap(json.decode(source));
}
