import 'dart:convert';

import 'package:MShopManager/enums/enum_invoice_detail_type.dart';
import 'package:flutter/material.dart';

/// Item Detail hóa đơn
class InvoiceDetailItemDisplay {

    EInvoiceDetailType type;
    String title;
    String value;
    bool isBoldTitle;
    bool isBoldValue;
    double titleFontSize;
    double valueFontSize;
    bool isChild;
    bool isUsedOneColumn;

  InvoiceDetailItemDisplay({
    this.type,
    this.title,
    this.value,
    this.isBoldTitle = false,
    this.isBoldValue = false,
    this.titleFontSize,
    this.valueFontSize,
    this.isChild = false,
    this.isUsedOneColumn = false
  });
}
