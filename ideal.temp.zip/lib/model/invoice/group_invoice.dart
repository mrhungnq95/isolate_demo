import 'dart:convert';

import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/utils/date_format_helper.dart';

class GroupInvoice {
  DateTime date;
  List<SAInvoice> saInvoices;
  double total;

  GroupInvoice({
    this.date,
    this.saInvoices,
    this.total,
  });

  Map<String, dynamic> toMap() {
    return {
      'SAInvoices': saInvoices,
      'Total': total,
      'Date': DateTimeFormatHelper.formatDate2String(date,
          format: DateTimeFormatConstant.DATE_TIME_WITH_TIMEZONE_ISO_FORMAT),
    };
  }

  factory GroupInvoice.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    var listInvoice = List<SAInvoice>();

    map['SAInvoices'].forEach((v) {
      listInvoice.add(SAInvoice.fromMap(v));
    });

    return GroupInvoice(
      saInvoices: listInvoice,
      total: map['Total'],
      date: DateTimeFormatHelper.parseString2Date(map['Date']),
    );
  }

  String toJson() => json.encode(toMap());

  factory GroupInvoice.fromJson(String source) =>
      GroupInvoice.fromMap(json.decode(source));
}
