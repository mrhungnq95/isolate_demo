import 'package:MShopManager/model/customer/item_user_info_property.dart';

class CustomerDataDisplay {
  String _customerName;
  String _totalInvoiceQuantityValue;
  String _totalInvoiceAmountValue;

  List<ItemUserInfoProperty> _itemUserInfoPropList = [];

  CustomerDataDisplay(
    this._customerName,
    this._totalInvoiceQuantityValue,
    this._totalInvoiceAmountValue,
    this._itemUserInfoPropList,
  );

  /// DS các property hiển thị trên màn hình
  List<ItemUserInfoProperty> get itemUserInfoPropList => _itemUserInfoPropList;

  /// Tên khách hàng
  String get customerName => _customerName;

  /// Tổng hoá đơn
  String get totalInvoiceQuantityValue => _totalInvoiceQuantityValue;

  /// Tổng tiền từ Hoá đơn
  String get totalInvoiceAmountValue => _totalInvoiceAmountValue;
}
