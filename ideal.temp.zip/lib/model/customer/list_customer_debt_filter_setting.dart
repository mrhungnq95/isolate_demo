import 'dart:convert';

import 'package:MShopManager/enums/enum_debit_customer_filter_type.dart';
import 'package:MShopManager/model/branch.dart';

/// 
/// Tham số setting cho filter
/// 
class ListCustomerDebtFilterSetting {

  /// Bộ lọc
  EDebitCustomerFilterType orderType;

  // Chi nhánh xem báo cáo
  Branch branch;


  ListCustomerDebtFilterSetting({
    this.orderType,
    this.branch,
  });
  

  ListCustomerDebtFilterSetting copyWith({
    EDebitCustomerFilterType filterType,
    Branch branch,
  }) {
    return ListCustomerDebtFilterSetting(
      orderType: filterType ?? this.orderType,
      branch: branch ?? this.branch,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'filterType': orderType?.rawValue,
      'branch': branch?.toMap(),
    };
  }

  factory ListCustomerDebtFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return ListCustomerDebtFilterSetting(
      orderType: EDebitCustomerFilterTypeExtension.fromValue(map['filterType']),
      branch: Branch.fromMap(map['branch']),
    );
  }

  String toJson() => json.encode(toMap());

  factory ListCustomerDebtFilterSetting.fromJson(String source) => ListCustomerDebtFilterSetting.fromMap(json.decode(source));
}
