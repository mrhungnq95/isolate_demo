class ItemUserInfoProperty {
  String title;
  String value;
  ItemUserInfoProperty({
    this.title,
    this.value,
  });
}
