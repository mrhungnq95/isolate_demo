import 'dart:convert';

import 'package:flutter/material.dart';

/// Model Thông tin công nợ khách hàng
class DebtCustomer {
  
  String customerID;
  String customerCode;
  String customerName;
  double closeAmount;
  String tel;

  DebtCustomer({
    this.customerID,
    this.customerCode,
    this.customerName,
    this.closeAmount,
    this.tel,
  });


  Map<String, dynamic> toMap() {
    return {
      'CustomerID': customerID,
      'CustomerCode': customerCode,
      'CustomerName': customerName,
      'CloseAmount': closeAmount,
      'Tel': tel,
    };
  }

  factory DebtCustomer.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
  
    return DebtCustomer(
      customerID: map['CustomerID'],
      customerCode: map['CustomerCode'],
      customerName: map['CustomerName'],
      closeAmount: map['CloseAmount'],
      tel: map['Tel'],
    );
  }

  String toJson() => json.encode(toMap());

  factory DebtCustomer.fromJson(String source) => DebtCustomer.fromMap(json.decode(source));
}
