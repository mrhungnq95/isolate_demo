import 'dart:convert';

import 'package:MShopManager/enums/enum_follow_status.dart';
import 'package:MShopManager/enums/enum_sort_customer.dart';

class CustomerListFilterSetting {
  ESortCustomerStatus sortType;

  EFollowStatus filterType;
  CustomerListFilterSetting({
    this.sortType,
    this.filterType,
  });

  factory CustomerListFilterSetting.newDefault() {
    return CustomerListFilterSetting(
        sortType: ESortCustomerStatus.customer_name,
        filterType: EFollowStatus.following);
  }

  Map<String, dynamic> toMap() {
    return {
      'sortType': sortType?.rawValue,
      'filterType': filterType?.rawValue,
    };
  }

  factory CustomerListFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;

    return CustomerListFilterSetting(
      sortType: ESortCustomerStatusExt.valueOf(map['sortType']),
      filterType: EFollowStatusExt.valueOf(map['filterType']),
    );
  }

  String toJson() => json.encode(toMap());

  factory CustomerListFilterSetting.fromJson(String source) =>
      CustomerListFilterSetting.fromMap(json.decode(source));
}
