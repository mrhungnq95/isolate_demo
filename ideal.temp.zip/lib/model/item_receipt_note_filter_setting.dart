import 'dart:convert';

import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

///
/// [Description]  bộ lọc phiếu nhập hàng
///
/// Created by TTLOI on 14/01/2021 (16:10).
/// Copyright (c) 2021 MISA JSC. All rights reserved.
/// ----------------------------------------------------------------------------
class ItemReceiptNoteFilterSetting {
  EReportPeriodType period;
  DateRange dateRange;
  String branchID;

  ItemReceiptNoteFilterSetting({
    this.period,
    this.dateRange,
    this.branchID,
  });

  /// lấy kỳ báo cáo
  DateRange getDateRange() {
    if (period == EReportPeriodType.custom) {
      return dateRange;
    }
    /// lấy lại dateRange theo thười điểm hiện tại
    return DateTimeHelper.getDateRangeByPeriod(DateTime.now(), period);
  }

  Map<String, dynamic> toMap() {
    return {
      'Period': period.rawValue,
      'DateRange': dateRange.toServerMap(),
      'BranchID': branchID,
    };
  }

  factory ItemReceiptNoteFilterSetting.newDefault(String branchID) {
    var dateRangeByPeriod = DateTimeHelper.getDateRangeByPeriod(
        DateTime.now(), EReportPeriodType.thisDay);
    return ItemReceiptNoteFilterSetting(
      period: EReportPeriodType.thisDay,
      dateRange: dateRangeByPeriod,
      branchID: branchID,
    );
  }

  factory ItemReceiptNoteFilterSetting.fromMap(Map<String, dynamic> map) {
    if (map == null) return null;
    print('fromMap: ' + map.toString());

    return ItemReceiptNoteFilterSetting(
      period: EReportPeriodTypeExt.valueOf(map['Period']),
      dateRange: DateRange.fromServerMap(map['DateRange']),
      branchID: map['BranchID'],
    );
  }

  String toJson() => json.encode(toMap());

  factory ItemReceiptNoteFilterSetting.fromJson(String source) =>
      ItemReceiptNoteFilterSetting.fromMap(json.decode(source));
}
