import 'package:mp_chart/mp/core/entry/entry.dart';

class LineChartEntry {
  List<String> label;
  List<Entry> entry;
  LineChartEntry({
    this.label,
    this.entry,
  });
}
