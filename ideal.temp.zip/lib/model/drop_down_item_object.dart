//
// Created by nqhung on 09/11/2020.
//

class DropDownItemObject<T> {
  String title;
  T object;

  DropDownItemObject(this.title, this.object);

  @override
  String toString() {
    return "$object";
  }
}
