class ItemAreaAddress {
  String title;

  String cityName;
  String cityId;

  String districtName;
  String districtId;

  String wardName;
  String wardId;

  bool isSelected;

  factory ItemAreaAddress.createArea(
      {String title,
      String cityId,
      String cityName,
      String districtId,
      String districtName,
      bool isSelected}) {
    return ItemAreaAddress._(
        title: title,
        cityId: cityId,
        cityName: cityName,
        districtId: districtId,
        districtName: districtName,
        isSelected: isSelected);
  }

  factory ItemAreaAddress.createWard(
      {String title, String wardId, String wardName, bool isSelected}) {
    return ItemAreaAddress._(
        title: title,
        wardId: wardId,
        wardName: wardName,
        isSelected: isSelected);
  }

  ItemAreaAddress._(
      {this.title,
      this.cityName,
      this.cityId,
      this.districtName,
      this.districtId,
      this.wardName,
      this.wardId,
      this.isSelected});
}
