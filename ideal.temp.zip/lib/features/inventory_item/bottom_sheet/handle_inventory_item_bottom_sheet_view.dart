import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/inventory_item/list_inventory_item/provider/inventory_item_view_model.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';


class HandleInventoryItemBottomSheetView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<InventoryItemViewModel>.nonReactive(
      builder: (context, model, child) {
        return Container(
          padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
          height: ScreenUtils.height * 0.85,
          child: Column(
            children: [
              Expanded(
                child: Container(
                  padding: kPaddingScreen,
                  margin: const EdgeInsets.all(kVerticalSpaceLarge),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    color: AppColor.white,
                  ),
                  child: ListView(
                    children: [
                      ExpandedView.horizontal(
                          child: MSButton(
                              onPressed: () {
                                Navigator.of(context).maybePop();
                              },
                              label: "Chuyển nhóm hàng hóa")),
                      kVerticalSpaceMediumBox,
                      ExpandedView.horizontal(
                          child: MSButton(
                              onPressed: () {
                                Navigator.of(context).maybePop();
                              },
                              label: "In tem mã")),
                      kVerticalSpaceMediumBox,
                      Divider(
                        height: 1,
                        thickness: 1,
                        color: AppColor.grey400,
                      ),
                      kVerticalSpaceMediumBox,
                      ExpandedView.horizontal(
                          child: MSButton(
                              onPressed: () {
                                Navigator.of(context).maybePop();
                              },
                              label: "Đặt hàng")),
                      kVerticalSpaceMediumBox,
                      ExpandedView.horizontal(
                          child: MSButton(
                              onPressed: () {
                                Navigator.of(context).maybePop();
                              },
                              label: "Nhập hàng")),
                              kVerticalSpaceMediumBox,
                      Divider(
                        height: 1,
                        thickness: 1,
                        color: AppColor.grey400,
                      ),
                      kVerticalSpaceMediumBox,
                    ],
                  ),
                ),
              ),
              ExpandedView.horizontal(
                  child: Padding(
                padding: const EdgeInsets.all(kHorizontalSpaceLarge),
                child: MSButton(
                    onPressed: () {
                      Navigator.of(context).maybePop();
                    },
                    label: "Đặt hàng"),
              ))
            ],
          ),
        );
      },
      viewModelBuilder: () {},
    );
  }
}
