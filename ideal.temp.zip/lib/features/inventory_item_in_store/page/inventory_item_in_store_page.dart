import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_stock_issue_detail_type.dart';
import 'package:MShopManager/enums/enum_stock_issue_option.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_view_model.dart';
import 'package:MShopManager/features/report/chain_store/widget/radio_option_card_view.dart';
import 'package:MShopManager/widget/inventory_item_view.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class InventoryItemInStorePage extends StatefulWidget {
  @override
  _InventoryItemInStorePageState createState() =>
      _InventoryItemInStorePageState();
}

class _InventoryItemInStorePageState
    extends State<InventoryItemInStorePage> {
  @override
  Widget build(BuildContext context) {
    return _InventoryItemInStoreContentPage();
  }
}

class _InventoryItemInStoreContentPage
    extends MSBaseCupertinoViewModelBuilder<InventoryItemInStoreViewModel> {
  @override
  Color provideStatusBarColor() {
    return Colors.white;
  }

  @override
  Brightness provideBrightnessColor(BuildContext context) {
    return Brightness.light;
  }

  @override
  Widget onBuildFloatingButton(
      BuildContext context, InventoryItemInStoreViewModel model) {
    return FloatingActionButton(
      onPressed: () {},
      child: Image.asset(
        AppResources.icBarcode,
        color: AppColor.white,
      ),
    );
  }

  @override
  Widget onBuildBody(
      BuildContext context, InventoryItemInStoreViewModel model, Widget child) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          MSEShopSliverAppBar(
            pinned: true,
            floating: true,
            title: "Tồn kho",
            customTitle: _TitleView(),
            onTrailingTap: () {
              Navigator.of(context, rootNavigator: true).pushNamed(
                  AppRouterName.inventory_item_in_store_filter.value());
            },
            bottom: _BottomAppBar(),
            onLeadingTap: () {
              Navigator.of(context).maybePop();
            },
          ),
          SliverList(
              delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return InventoryItemView(
                onPress: () {
                  Navigator.of(context).pushNamed(
                      AppRouterName.inventory_item_detail_in_store.value(),
                      arguments: EStockIssueDetailType.detail_by_property);
                },
              );
            },
            childCount: 20,
          ))
        ],
      ),
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  InventoryItemInStoreViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<InventoryItemInStoreViewModel>();
  }

  @override
  void onViewModelCreated(InventoryItemInStoreViewModel model) {}
}

class _TitleView extends StatelessWidget {
  const _TitleView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<InventoryItemInStoreViewModel>(
      builder: (context, viewModel, child) {
        return GestureDetector(
          onTap: () {
            showGeneralDialog(
              useRootNavigator: true,
              barrierDismissible: false,
              //barrierColor: Colors.transparent,
              barrierColor: Colors.black.withOpacity(0.5),
              //transitionDuration: Duration(milliseconds: 400),
              context: context,
              pageBuilder: (context, anim1, anim2) {
                return RadioOptionCardView<EStockIssueOption>(
                  onValueChanged: (value) {
                    viewModel.stockIssueOption = value;
                  },
                  optionList: [
                    EStockIssueOption.stock_issue,
                    EStockIssueOption.tranfering,
                    EStockIssueOption.incomming
                  ],
                  itemOption: viewModel.stockIssueOption,
                  titleBuilder: (EStockIssueOption item) {
                    print("titleBuilder $item");
                    return item.getTitle();
                    // item.getTitle();
                  },
                );
              },
            );
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(viewModel.stockIssueOption.getTitle(),
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontWeight: FontWeight.bold)),
              Icon(
                Icons.arrow_drop_down,
                color: AppColor.black,
              )
            ],
          ),
        );
      },
    );
  }
}

class _BottomAppBar extends StatelessWidget with PreferredSizeWidget {
  @override
  Size get preferredSize => const Size.fromHeight(100.0);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          kVerticalSpaceMediumBox,
          SearchBox(
            height: 40,
            placeholder: 'Nhập tên hàng hóa, mã SKU...',
            onSearch: (value) {},
          ),
          kVerticalSpaceMediumBox,
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _totalView(),
              Text(
                "150.002.000",
                style: Theme.of(context).textTheme.subtitle1,
              ),
            ],
          ),
          kVerticalSpaceMediumBox,
        ],
      ),
    );
  }

  Widget _totalView() {
    return Builder(
      builder: (context) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Tổng: ",
              style: Theme.of(context).textTheme.subtitle1,
            ),
            TextValueBorderView(
              value: "300",
            )
          ],
        );
      },
    );
  }
}
