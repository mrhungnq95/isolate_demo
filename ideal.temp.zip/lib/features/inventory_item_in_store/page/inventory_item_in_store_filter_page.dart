import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/app/routes/app_router.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_category_filter.dart';
import 'package:MShopManager/enums/enum_sort_status.dart';
import 'package:MShopManager/enums/enum_stock_issue_items_status.dart';
import 'package:MShopManager/enums/enum_unit_filter.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_filter_view_model.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/many_option_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_cuptertino_navigation_bar.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:MShopManager/widget/select_category_item_view.dart';
import 'package:MShopManager/widget/time_period_filter_view.dart';
import 'package:MShopManager/widget/two_option_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class InventoryItemInStoreFilterPage extends StatefulWidget {
  @override
  _InventoryItemInStoreFilterPageState createState() =>
      _InventoryItemInStoreFilterPageState();
}

class _InventoryItemInStoreFilterPageState
    extends State<InventoryItemInStoreFilterPage> {
  @override
  Widget build(BuildContext context) {
    return _InventoryItemInStoreFilterContentPage();
  }
}

class _InventoryItemInStoreFilterContentPage
    extends MSBaseCupertinoViewModelBuilder<
        InventoryItemInStoreFilterViewModel> {
  @override
  bool get reactive => false;

  @override
  Color provideBackgroundColor() {
    return Colors.white;
  }

  @override
  Color provideStatusBarColor() {
    return Colors.white;
  }

  @override
  Widget onBuildBody(BuildContext context,
      InventoryItemInStoreFilterViewModel model, Widget child) {
    return Column(
      children: [
        Expanded(
          child: CustomScrollView(
            slivers: [
              MSEShopSliverAppBar(
                pinned: true,
                floating: false,
                title: "Bộ lọc",
                onLeadingTap: () {
                  Navigator.of(context).maybePop();
                },
                automaticallyImplyTrailing: true,
              ),
              SliverPadding(
                padding: const EdgeInsets.all(kVerticalSpaceLarge),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    children: [
                      BranchFilterView(
                        controller: model.branchFilterController,
                      ),
                      _StatusFilterView(),
                      _SortFilterView(),
                      _TimePeriodFilter(),
                      _UnitFilterView(),
                      _CategoryItemView(),
                      kVerticalSpaceLargeBox,
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
        ExpandedView.horizontal(
            child: Padding(
          padding: const EdgeInsets.all(kHorizontalSpaceLarge),
          child: MSButton(
              onPressed: () {
                Navigator.of(context).maybePop();
              },
              label: "Lọc"),
        ))
      ],
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  InventoryItemInStoreFilterViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<InventoryItemInStoreFilterViewModel>();
  }

  @override
  void onViewModelCreated(InventoryItemInStoreFilterViewModel model) {}
}

class _StatusFilterView extends StatelessWidget {
  const _StatusFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreFilterViewModel>(context);
    print("_StatusFilterView build");
    return ManyOptionView<EStockIssueItemsStatus>(
      title: 'Trạng thái',
      groupValue: model.eStockIssueItemsStatus,
      itemCount: model.stockIssueItemStatusList.length,
      valueBuilder: (index) => model.stockIssueItemStatusList[index],
      titleBuilder: (value) => Text(
        value.getTitle(),
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: (value) {
        model.eStockIssueItemsStatus = value;
      },
    );
  }
}

class _SortFilterView extends StatelessWidget {
  const _SortFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreFilterViewModel>(context);
    return ManyOptionView<ESortStatus>(
      title: 'Sắp xếp',
      groupValue: model.eSortStatus,
      itemCount: model.sortFilterItemList.length,
      valueBuilder: (index) => model.sortFilterItemList[index],
      titleBuilder: (value) => Text(
        value.getTitle(),
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: (value) {
        model.eSortStatus = value;
      },
    );
  }
}

///
/// Thời gian filter
///
class _TimePeriodFilter extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreFilterViewModel>(context);
    print("_TimePeriodFilter build");
    return TimePeriodFilter(
      dateRange: DateTimeHelper.getDateRangeByPeriod(DateTime.now(), model.eTimePeriod),
      groupValue: model.eTimePeriod,
      items: model.timePeriodFilterList,
      onChanged: (period, dateRange) {
        model.eTimePeriod = period;
      },
    );
  }
}

///
/// Đơn vị tính
///
class _UnitFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreFilterViewModel>(context);
    print("_UnitFilterView build");
    return Column(
      children: [
        TwoOptionView<EUnitFilter>(
          option1Value: EUnitFilter.all,
          option2Value: EUnitFilter.custom,
          groupValue: model.eUnitFilter,
          onChanged: (value) {
            model.eUnitFilter = value;
          },
          title: 'Đơn vị tính',
          option1: Text(
            'Tất cả đơn vị tính',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          option2: Text(
            'Khác',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          ratio: 1,
        ),
        ExpandedSection(
          expand: model.eUnitFilter == EUnitFilter.custom,
          child: Padding(
            padding: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
            child: SelectCategoryItemView(
              value: "Bộ",
              onPressed: () {
                Navigator.of(context, rootNavigator: true)
                    .pushNamed(AppRouterName.select_unit.value());
              },
            ),
          ),
        )
      ],
    );
  }
}

class _CategoryItemView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreFilterViewModel>(context);
    print("_CategoryItemView build");
    return Column(
      children: [
        TwoOptionView<ECategoryFilter>(
          option1Value: ECategoryFilter.all,
          option2Value: ECategoryFilter.custom,
          groupValue: model.eCategoryFilter,
          onChanged: (value) {
            model.eCategoryFilter = value;
          },
          title: 'Nhóm hàng hoá',
          option1: Text(
            'Tất cả nhóm',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          option2: Text(
            'Khác',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          ratio: 1,
        ),
        ExpandedSection(
          expand: model.eCategoryFilter == ECategoryFilter.custom,
          child: SelectCategoryItemView(
            value: "Tất cả nhóm hàng hóa",
            onPressed: () {
              Navigator.of(context, rootNavigator: true)
                  .pushNamed(AppRouterName.category_inventory_item.value());
            },
          ),
        )
      ],
    );
  }
}
