import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/features/inventory_item_in_store/provider/inventory_item_in_store_detail_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_stock_issue_detail_type.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/inventory_item_view.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';

class InventoryItemInStoreDetailPage extends StatefulWidget {
  @override
  _InventoryItemInStoreDetailPage createState() =>
      _InventoryItemInStoreDetailPage();
}

class _InventoryItemInStoreDetailPage
    extends State<InventoryItemInStoreDetailPage> {
  EStockIssueDetailType _eStockIssueDetailType;

  @override
  Widget build(BuildContext context) {
    _eStockIssueDetailType = ModalRoute.of(context).settings.arguments;
    print("_eStockIssueDetailType $_eStockIssueDetailType");
    return _InventoryItemInStoreContentPage(
        title: "Áo khoác kaki Zara",
        eStockIssueDetailType: _eStockIssueDetailType);
  }
}

class _InventoryItemInStoreContentPage extends MSBaseCupertinoViewModelBuilder<
    InventoryItemInStoreDetailViewModel> {
  final String title;
  final EStockIssueDetailType eStockIssueDetailType;

  _InventoryItemInStoreContentPage({this.title, this.eStockIssueDetailType});

  @override
  Color provideStatusBarColor() {
    return Colors.white;
  }

  @override
  Brightness provideBrightnessColor(BuildContext context) {
    return Brightness.light;
  }

  @override
  Widget onBuildBody(BuildContext context,
      InventoryItemInStoreDetailViewModel model, Widget child) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          MSEShopSliverAppBar(
            pinned: true,
            floating: true,
            title: title,
            automaticallyImplyTrailing: true,
            bottom: _BottomAppBar(),
            onLeadingTap: () {
              Navigator.of(context).maybePop();
            },
          ),
          _ContentView()
        ],
      ),
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  InventoryItemInStoreDetailViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<InventoryItemInStoreDetailViewModel>();
  }

  @override
  void onViewModelCreated(InventoryItemInStoreDetailViewModel model) {
    model.eStockIssueDetailType = eStockIssueDetailType;
  }
}

class _BottomAppBar extends StatelessWidget with PreferredSizeWidget {
  @override
  Size get preferredSize => const Size.fromHeight(60.0);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          kVerticalSpaceMediumBox,
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _totalView(),
              Text(
                "100.002.000",
                style: Theme.of(context).textTheme.subtitle1,
              ),
            ],
          ),
          kVerticalSpaceMediumBox,
        ],
      ),
    );
  }

  Widget _totalView() {
    return Builder(
      builder: (context) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Tổng: ",
              style: Theme.of(context).textTheme.subtitle1,
            ),
            TextValueBorderView(
              value: "156",
            )
          ],
        );
      },
    );
  }
}

class _ContentView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<InventoryItemInStoreDetailViewModel>(context);
    return SliverList(
        delegate: SliverChildBuilderDelegate(
      (BuildContext context, int index) {
        if (model.eStockIssueDetailType ==
            EStockIssueDetailType.detail_by_property) {
          return InventoryItemView(
            onPress: () {
              Navigator.of(context).pushNamed(
                  AppRouterName.inventory_item_detail_in_store.value(),
                  arguments: EStockIssueDetailType.detail_by_branch);
            },
          );
        } else {
          return _StockIssueItemByBranchView();
        }
      },
      childCount: 20,
    ));
  }
}

class _StockIssueItemByBranchView extends StatefulWidget {
  @override
  _StockIssueItemByBranchViewState createState() =>
      _StockIssueItemByBranchViewState();
}

class _StockIssueItemByBranchViewState
    extends State<_StockIssueItemByBranchView> {
  bool isExpand = false;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(minHeight: 70),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _HeaderSectionView(
              onPress: () {
                setState(() {
                  isExpand = !isExpand;
                });
              },
            ),
            ExpandedSection(
              expand: isExpand,
              child: ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return _RepositoryItemView();
                },
                itemCount: 5,
              ),
            )
          ],
        ),
      ),
    );
  }
}

class _HeaderSectionView extends StatelessWidget {
  final VoidCallback onPress;

  const _HeaderSectionView({
    Key key,
    @required this.onPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPress,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 23,
            child: Image.asset(
              AppResources.icItem,
              width: 24,
              height: 24,
              fit: BoxFit.fill,
            ),
            backgroundColor: AppColor.indigoA200.withOpacity(0.1),
          ),
          kHorizontalSpaceSmallBox,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Thời trang Sài Gòn New",
                  style: Theme.of(context).textTheme.bodyText1,
                ),
                Text(
                  "10.002.000",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(fontWeight: FontWeight.bold),
                )
              ],
            ),
          ),
          TextValueBorderView(
            value: "223",
          ),
          Icon(
            Icons.keyboard_arrow_up,
            color: AppColor.grey600,
          )
        ],
      ),
    );
  }
}

class _RepositoryItemView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 52,
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Kho Sai Gon New 1",
                  style: Theme.of(context).textTheme.bodyText1,
                ),
                Text("5.000.000",
                    style: Theme.of(context)
                        .textTheme
                        .bodyText2
                        .copyWith(fontWeight: FontWeight.bold))
              ],
            ),
          ),
          TextValueBorderView(
            value: "223",
          ),
          SizedBox(
            width: 24,
          )
        ],
      ),
    );
  }
}
