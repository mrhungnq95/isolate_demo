import 'package:MShopManager/enums/enum_stock_issue_detail_type.dart';

class StockIssueDetailArgs {
  EStockIssueDetailType eStockIssueDetailType;
  String title;

  StockIssueDetailArgs({
    this.eStockIssueDetailType,
    this.title,
  });
}
