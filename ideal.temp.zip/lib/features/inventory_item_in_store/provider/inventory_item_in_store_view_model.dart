import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_stock_issue_option.dart';

class InventoryItemInStoreViewModel extends MSBaseViewModel {
  EStockIssueOption _stockIssueOption = EStockIssueOption.stock_issue;
  EStockIssueOption get stockIssueOption => _stockIssueOption;
  set stockIssueOption(EStockIssueOption newValue) {
    _stockIssueOption = newValue;
    notifyListeners();
  }
}
