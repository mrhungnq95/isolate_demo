import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_stock_issue_detail_type.dart';

class InventoryItemInStoreDetailViewModel extends MSBaseViewModel {
  EStockIssueDetailType _eStockIssueDetailType;

  EStockIssueDetailType get eStockIssueDetailType => _eStockIssueDetailType;
  set eStockIssueDetailType(EStockIssueDetailType newValue) =>
      _eStockIssueDetailType = newValue;
}
