import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_category_filter.dart';
import 'package:MShopManager/enums/enum_period.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_sort_status.dart';
import 'package:MShopManager/enums/enum_stock_issue_items_status.dart';
import 'package:MShopManager/enums/enum_unit_filter.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';

class InventoryItemInStoreFilterViewModel extends MSBaseViewModel {
  ///
  /// Controller quản lý View Cửa hàng
  ///
  BranchFilterController _branchFilterController = BranchFilterController();
  BranchFilterController get branchFilterController => _branchFilterController;

  /// Đơn vị tính
  EUnitFilter _eUnitFilter = EUnitFilter.all;
  EUnitFilter get eUnitFilter => _eUnitFilter;
  set eUnitFilter(EUnitFilter newValue) {
    _eUnitFilter = newValue;
    notifyListeners();
  }

  /// Sắp xếp
  ESortStatus _eSortStatus = ESortStatus.asc;
  ESortStatus get eSortStatus => _eSortStatus;
  set eSortStatus(ESortStatus newValue) {
    _eSortStatus = newValue;
    notifyListeners();
  }

  List<ESortStatus> _sortFilterItemList = [ESortStatus.asc, ESortStatus.desc];
  List<ESortStatus> get sortFilterItemList => _sortFilterItemList;

  EStockIssueItemsStatus _eStockIssueItems = EStockIssueItemsStatus.all;
  EStockIssueItemsStatus get eStockIssueItemsStatus => _eStockIssueItems;
  set eStockIssueItemsStatus(EStockIssueItemsStatus newValue) {
    _eStockIssueItems = newValue;
    notifyListeners();
  }

  /// Trạng thái
  List<EStockIssueItemsStatus> _stockIssueItemStatusList = [
    EStockIssueItemsStatus.all,
    EStockIssueItemsStatus.availablle,
    EStockIssueItemsStatus.out_of_stock
  ];
  List<EStockIssueItemsStatus> get stockIssueItemStatusList =>
      _stockIssueItemStatusList;

  /// Kỳ báo cáo
  EReportPeriodType _eTimePeriod = EReportPeriodType.thisDay;
  EReportPeriodType get eTimePeriod => _eTimePeriod;
  set eTimePeriod(EReportPeriodType newValue) {
    _eTimePeriod = newValue;
    notifyListeners();
  }

  /// Thời gian
  List<EReportPeriodType> _timePeriodFilterList = [
    EReportPeriodType.thisDay,
    EReportPeriodType.yesterday,
    EReportPeriodType.thisWeek,
    EReportPeriodType.custom
  ];
  List<EReportPeriodType> get timePeriodFilterList => _timePeriodFilterList;

  /// Nhóm hàng hoá
  ECategoryFilter _eCategoryFilter = ECategoryFilter.all;
  ECategoryFilter get eCategoryFilter => _eCategoryFilter;
  set eCategoryFilter(ECategoryFilter newValue) {
    _eCategoryFilter = newValue;
    notifyListeners();
  }
}
