// import 'package:MShopManager/app/app_expose.dart';
// import 'package:MShopManager/app/routes/app_route_name.dart';
// import 'package:MShopManager/features/riverpod_test/provider_pod.dart';
// import 'package:MShopManager/widget/circle_button_view.dart';
// import 'package:MShopManager/widget/quantity_border_style_view.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:flutter_hooks/flutter_hooks.dart';
// import 'package:hooks_riverpod/all.dart';

// class CounterPage extends StatefulWidget {
//   @override
//   _CounterPageState createState() => _CounterPageState();
// }

// class _CounterPageState extends State<CounterPage> {
//   @override
//   Widget build(BuildContext context) {
//     return ProviderScope(observers: [Logger()], child: _ContentView());
//   }
// }

// class _ContentView extends HookWidget {
//   @override
//   Widget build(BuildContext context) {
//     print("_ContentView");
//     return Container(
//         child: Scaffold(
//       body: Column(
//         children: [_ChangeQuantityView(), _FuokFuokContentView()],
//       ),
//     ));
//   }
// }

// class _ChangeQuantityView extends HookWidget {
//   @override
//   Widget build(BuildContext context) {
//     print("_ChangeQuantityView");
//     //final quantityState = useProvider(counterStateNotiProvider);
//     return Center(
//       child: Row(
//         children: <Widget>[
//           Padding(
//             padding: const EdgeInsets.only(right: kHorizontalSpaceSmall),
//             child: CircleButtonView(
//               onTap: () {
//                 //quantityState.subtract();
//                 //context.read(counterStateNotiProvider).notChange();

//                 Navigator.of(context)
//                     .pushNamed(AppRouterName.notification_setting.value());
//               },
//               icon: Icon(
//                 Icons.remove,
//                 color: AppColor.pink,
//               ),
//             ),
//           ),
//           _QuantityView(),
//           CircleButtonView(
//             onTap: () {
//               //quantityState.add();
//               context.read(counterStateNotiProvider).add();
//             },
//             icon: Icon(
//               Icons.add,
//               color: AppColor.indigo700,
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }

// class _QuantityView extends HookWidget {
//   const _QuantityView({
//     Key key,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     print("_QuantityView");
//     final quantityQuantityState = useProvider(counterStateNotiProvider.state);
//     return Padding(
//       padding: const EdgeInsets.only(right: kHorizontalSpaceSmall),
//       child: QuantityBorderStyleView(
//           quantity: quantityQuantityState.toDouble(), onPressed: () {}),
//     );
//   }
// }

// class _FuokFuokContentView extends HookWidget {
//   @override
//   Widget build(BuildContext context) {
//     print("_FuokFuokContentView");
//     final fuokfuokFutureBuilder =
//         useProvider(futureProviderWithFamily("#2020"));

//     final fuokState = useProvider(counterStateProvider);

//     return fuokfuokFutureBuilder.map(data: (value) {
//       return Container(
//         child: Column(
//           children: [
//             Text(value.value),
//             Text(fuokState.state),
//           ],
//         ),
//       );
//     }, loading: (asyncLoading) {
//       return Text("Loading...");
//     }, error: (asyncError) {
//       return Text("Error!");
//     });
//   }
// }

// class Logger extends ProviderObserver {
//   @override
//   void didUpdateProvider(ProviderBase provider, Object newValue) {
//     print('''
// {
//   "provider": "${provider.name ?? provider.runtimeType}",
//   "newValue": "$newValue"
// }''');
//   }
// }
