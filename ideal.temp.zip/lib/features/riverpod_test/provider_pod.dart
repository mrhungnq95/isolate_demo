// import 'package:hooks_riverpod/all.dart';

// /// FutureProvider .autoDispose + Future method
// final futureProvider = FutureProvider.autoDispose<String>((ref) async {
//   await Future.delayed(Duration(seconds: 1));

//   ref.onDispose(() {
//     print("FutureProvider dispose!");
//   });
//   return Future.value("FuokFuokFuture");
// });

// /// FutureProvider .autoDispose .family + Future method
// final futureProviderWithFamily =
//     FutureProvider.autoDispose.family<String, String>((ref, id) async {
//   await Future.delayed(Duration(seconds: 2));

//   ref.onDispose(() {
//     print("FutureProvider dispose!");
//   });
//   ref.maintainState = true;
//   return Future.value("FuokFuture_autoDispose_family args $id");
// });

// /// StreamProvider .autoDispose  + Stream method
// final streamProvider = StreamProvider.autoDispose<String>((ref) {
//   return Stream.periodic(Duration(seconds: 2), (value) {
//     return value.toString();
//   });
// });

// /// StreamProvider .family  + Stream method
// final streamProviderWithFamily =
//     StreamProvider.autoDispose.family<String, String>((ref, args) {
//   return Stream.periodic(Duration(seconds: 2), (value) {
//     return "$args : ${value.toString()}";
//   });
// });

// /// StateProvider
// final counterStateProvider = StateProvider<String>((ref) {
//   return "=> Counter State Provider <=";
// });

// /// StateNotifiterProvider + StateNotifier
// final counterStateNotiProvider =
//     StateNotifierProvider<CounterStateNotifier>((ref) {
//   return CounterStateNotifier(1);
// });

// class CounterStateNotifier extends StateNotifier<int> {
//   CounterStateNotifier(int state) : super(state);

//   void add() {
//     state++;
//   }

//   void subtract() {
//     state--;
//   }

//   void notChange() {
//     //state = state;
//   }
// }

// ///

// ///

// ///

// ///

// ///
