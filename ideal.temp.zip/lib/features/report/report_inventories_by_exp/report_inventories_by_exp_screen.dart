import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_load_data.dart';
import 'package:MShopManager/features/report/report_inventories_by_exp/provider/report_inventories_by_exp_view_model.dart';
import 'package:MShopManager/model/service/report_inventories_by_exp.dart';
import 'package:MShopManager/widget/info_filter_view.dart';
import 'package:MShopManager/widget/item_loading_view_binder.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_navigation_button.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:MShopManager/widget/total_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'component/Inventory_by_expiry_date_view.dart';

/// Màn hình báo cáo tồn kho theo hạn sử dụng
class ReportInventoriesByExpScreen extends StatefulWidget {
  @override
  _ReportInventoriesByExpState createState() => _ReportInventoriesByExpState();
}

class _ReportInventoriesByExpState extends State<ReportInventoriesByExpScreen> {
  @override
  Widget build(BuildContext context) {
    return _ReportInventoriesByExpPage();
  }
}

class _ReportInventoriesByExpPage
    extends MSBaseCupertinoViewModelBuilder<ReportInventoriesByExpViewModel> {
  @override
  Color provideStatusBarColor() {
    return AppColor.white;
  }

  @override
  ObstructingPreferredSizeWidget onBuildAppBar(
      BuildContext context, ReportInventoriesByExpViewModel model) {
    return null;
  }

  @override
  Widget onBuildBody(BuildContext context,
      ReportInventoriesByExpViewModel model, Widget child) {
    return CustomScrollView(
      controller: model.scrollController,
      slivers: [
        _AppbarView(
          onLeadingTap: () {
            Navigator.of(context).maybePop();
          },
          onTrailingTap: () => _onFilter(context),
          bottom: _BottomAppbarView(
            onSearch: (value) => _onSearch(model, value),
          ),
        ),
        Consumer<ReportInventoriesByExpViewModel>(
          builder: (context, viewModel, child) => SliverPadding(
            padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  var item = model.items[index];
                  if (item is InventoryByExpiryDate) {
                    return InventoryByExpiryDateView(
                      data: item,
                      onTap: () {
                        Navigator.of(context).pushNamed(AppRouterName
                            .report_inventories_by_expiry_detail
                            .value());
                      },
                    );
                  } else if (item is LoadingObject) {
                    return ItemLoadingViewBinder();
                  }
                  return Container();
                },
                childCount: model.items.length,
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// Xử lý tìm kiếm
  void _onSearch(ReportInventoriesByExpViewModel model, String value) {
    model.param.keyword = value;
    model.loadData(ELoadDataType.SEARCH);
  }

  /// mở màn hình filter
  void _onFilter(BuildContext context) {
    Navigator.of(context, rootNavigator: true)
        .pushNamed(AppRouterName.report_inventories_by_expiry_filter.value());
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  ReportInventoriesByExpViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<ReportInventoriesByExpViewModel>();
  }

  @override
  void onViewModelCreated(ReportInventoriesByExpViewModel model) {
    model.loadData(ELoadDataType.RELOAD);
  }
}

class _AppbarView extends StatelessWidget {
  final Widget bottom;
  final VoidCallback onLeadingTap;
  final VoidCallback onTrailingTap;

  const _AppbarView({Key key, this.bottom, this.onLeadingTap, this.onTrailingTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      toolbarHeight: 145,
      titleSpacing: 0,
      bottom: bottom,
      backgroundColor: AppColor.white,
      pinned: true,
      snap: false,
      floating: true,
      title: _TitleView(
        onLeadingTap: onLeadingTap,
        onTrailingTap: onTrailingTap,
      ),
      automaticallyImplyLeading: false,
    );
  }
}

class _TitleView extends StatelessWidget {
  final VoidCallback onLeadingTap;
  final VoidCallback onTrailingTap;

  const _TitleView(
      {Key key, @required this.onLeadingTap, @required this.onTrailingTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.only(right: kHorizontalSpaceMedium),
          height: 55,
          child: Row(
            children: [
              MSNavigationButton(
                  iconData: Icons.arrow_back_ios_rounded,
                  buttonColor:
                      Colors.transparent, //AppColor.white.withOpacity(0.3),
                  onTap: onLeadingTap),
              Expanded(
                child: Text('Tồn kho theo HSD',
                    textAlign: TextAlign.center,
                    style: Theme.of(context)
                        .textTheme
                        .subtitle2
                        .copyWith(fontWeight: FontWeight.bold)),
              ),
              MSCircleButton(
                  elevation: 5,
                  color: AppColor.white,
                  size: 40,
                  imageAsset: AppResources.icFilter,
                  imageAssetColor: AppColor.indigo900,
                  onTap: onTrailingTap),
            ],
          ),
        ),
        InfoFilterView(),
      ],
    );
  }
}

class _BottomAppbarView extends StatelessWidget with PreferredSizeWidget {
  final ValueChanged<String> onSearch;

  const _BottomAppbarView({Key key, this.onSearch}) : super(key: key);

  @override
  Size get preferredSize => Size.fromHeight(95);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
      child: Column(
        children: [
          SearchBox(
            height: 40,
            placeholder: 'Nhập tên hàng hóa, mã SKU...',
            onSearch: onSearch,
          ),
          kVerticalSpaceMediumBox,
          Consumer<ReportInventoriesByExpViewModel>(
            builder: (context, viewModel, child) => TotalView(
              totalLabel: 'Tồn kho',
              totalQuantity: viewModel.summaryData.totalQuantity,
            ),
          ),
          kVerticalSpaceMediumBox,
        ],
      ),
    );
  }
}
