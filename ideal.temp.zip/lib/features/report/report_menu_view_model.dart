import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_report_type.dart';

class ReportMenuViewModel extends MSBaseViewModel {
  
  final List<EReportType> _reportItems = [...EReportType.values];
  List<EReportType> get reportItems => _reportItems;

}