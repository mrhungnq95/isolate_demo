import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/other/storehouse_receipt/page/choose_item_sheet_view.dart';
import 'package:MShopManager/features/report/checking/provider/add_checking_view_model.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/dashed_border_with_bottom_action_view.dart';
import 'package:MShopManager/widget/info_item_view.dart';
import 'package:MShopManager/widget/keyboard_general_dialog.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:MShopManager/widget/quantity_border_style_view.dart';
import 'package:MShopManager/widget/text_with_icon_button_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';

class AddCheckingPage extends StatefulWidget {
  final bool isEdit;

  const AddCheckingPage({Key key, this.isEdit}) : super(key: key);

  @override
  _AddCheckingPageState createState() => _AddCheckingPageState();
}

class _AddCheckingPageState extends State<AddCheckingPage> {
  @override
  Widget build(BuildContext context) {
    bool isEdit = ModalRoute.of(context).settings.arguments;
    return _AddCheckingPage(isEdit);
  }
}

class _CheckingHeaderItemView extends StatelessWidget {
  final String title;
  final double value;
  final double width;

  _CheckingHeaderItemView({this.title, this.value, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceMedium),
      width: width,
      child: Column(
        children: <Widget>[
          Text(
            title,
            style: Theme.of(context).textTheme.bodyText1,
            maxLines: 1,
          ),
          SizedBox(
            height: 2,
          ),
          Text(
            value.toStringFormat(EDoubleFormat.quantity),
            style: Theme.of(context).textTheme.bodyText1.copyWith(
                fontWeight: FontWeight.bold,
                color: value > 0 ? AppColor.indigo900 : Colors.red),
          )
        ],
      ),
    );
  }
}

class _AddCheckingPage
    extends MSBaseCupertinoViewModelBuilder<AddCheckingViewModel> {
  final bool isEdit;

  _AddCheckingPage(this.isEdit);

  @override
  ObstructingPreferredSizeWidget onBuildAppBar(
      BuildContext context, AddCheckingViewModel model) {
    return null;
  }

  @override
  Color provideStatusBarColor() {
    return Colors.transparent;
  }

  @override
  Color provideBackgroundColor() {
    return Colors.white;
  }

  @override
  Widget onBuildBody(
      BuildContext context, AddCheckingViewModel model, Widget child) {
    return SafeArea(
      child: Column(
        children: [
          SizedBox(
            height: 55,
            child: CustomScrollView(
              slivers: [
                MSEShopSliverAppBar(
                  toolbarHeight: 55,
                  pinned: true,
                  title: "Phiếu kiểm kê",
                  onLeadingTap: () {
                    Navigator.of(context).maybePop();
                  },
                  actions: [
                    Visibility(
                      visible: isEdit,
                      child: TextWithIconButtonView(
                        iconTrailing: Icon(
                          Icons.keyboard_arrow_down,
                          color: AppColor.black,
                        ),
                        title: 'Tất cả',
                        colorTitle: AppColor.black,
                        onTap: () {},
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
          InfoItemView(
            height: 70,
            imageAssetLeading: AppResources.icStorageCheck,
            iconTrailing: Icon(
              Icons.keyboard_arrow_right,
              color: AppColor.grey600,
            ),
            title: 'NK0006',
            subTitle: '08/08/2020 16: 30',
            onTap: () {},
          ),
          kVerticalSpaceMediumBox,
          _HeaderListCheckingItemView(),
          kVerticalSpaceMediumBox,
          Expanded(
            child: DashedBorderWithBottomActionView(
              listBottomAction: [
                MSCircleButton(
                    elevation: 10,
                    color: AppColor.white,
                    size: 60,
                    icon: Icon(Icons.search, color: AppColor.primaryColor),
                    onTap: () {
                      showModalBottomSheet(
                          elevation: 10,
                          context: context,
                          backgroundColor: Colors.transparent,
                          isScrollControlled: true,
                          builder: (c) => ChooseItemBottomSheet());
                    }),
                kHorizontalSpaceLargeBox,
                MSCircleButton(
                    elevation: 10,
                    color: AppColor.white,
                    size: 60,
                    imageAsset: AppResources.icBarcode,
                    imageAssetColor: AppColor.primaryColor,
                    onTap: () {}),
              ],
              child: _ListInventoryItemView(isEdit: isEdit),
              isShowEmptyView: model.listItem.isEmpty,
              isShowBottomActionView: isEdit,
              titleEmpty: 'Chưa chọn hàng hóa nào',
              subTitleEmpty: 'Chọn hàng hóa hoặc quét mã hàng hóa',
            ),
          ),
          kVerticalSpaceMediumBox,
          ExpandedView.horizontal(
              child: Padding(
                  padding: EdgeInsets.only(
                    left: kVerticalSpaceLarge,
                    right: kVerticalSpaceLarge,
                  ),
                  child: MSButton(
                      onPressed: () {
                        Fluttertoast.showToast(
                            msg: "Thêm phiếu thành công!",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.BOTTOM,
                            timeInSecForIosWeb: 1,
                            backgroundColor: AppColor.grey700,
                            textColor: Colors.white,
                            fontSize: 16.0);
                        Navigator.pop(context);
                      },
                      label: isEdit ? "Lưu phiếu kiểm kê" : "Xong")))
        ],
      ),
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  AddCheckingViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<AddCheckingViewModel>();
  }

  @override
  void onViewModelCreated(AddCheckingViewModel model) {}
}

///
/// Danh sách hàng hóa
///
class _ListInventoryItemView extends StatelessWidget {
  final bool isEdit;
  _ListInventoryItemView({this.isEdit});

  @override
  Widget build(BuildContext context) {
    final model = Provider.of<AddCheckingViewModel>(context);
    return Container(
        child: ListView.builder(
      padding: EdgeInsets.only(
          top: kVerticalSpaceMedium,
          bottom: isEdit ? 68 : kVerticalSpaceMedium),
      itemCount: model.listItem.length,
      itemBuilder: (BuildContext context, int index) {
        return _CheckingItemView(title: model.listItem[index], isEdit: isEdit);
      },
    ));
  }
}

///
/// Header hiển thị trên ds hàng hóa kiểm kê
///
class _HeaderListCheckingItemView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: kHorizontalSpaceMedium),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Hàng hóa',
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                  SizedBox(
                    height: 2,
                  ),
                  Text(
                    '2',
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1
                        .copyWith(fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          _CheckingHeaderItemView(
            title: 'Trên sổ',
            value: -30,
            width: ScreenUtils.width * (1 / 5),
          ),
          _CheckingHeaderItemView(
            title: 'Kiểm kê',
            value: 20,
            width: ScreenUtils.width * (1 / 5),
          ),
          _CheckingHeaderItemView(
            title: 'Lệch',
            value: -10,
            width: ScreenUtils.width * (1 / 5),
          ),
        ],
      ),
    );
  }
}

class _CheckingItemView extends StatelessWidget {
  final String title;
  final bool isEdit;

  _CheckingItemView({this.title, this.isEdit});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: AppColor.splashColor,
      highlightColor: AppColor.splashColor,
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: kVerticalSpaceSmall),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: kHorizontalSpaceMedium),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1
                          .copyWith(fontWeight: FontWeight.bold),
                      maxLines: 1,
                    ),
                    Text(
                      'AK0001',
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1
                          .copyWith(color: Colors.grey[600]),
                      maxLines: 1,
                    )
                  ],
                ),
              ),
            ),
            _QuantityItemView(value: 20),
            _BuildQuantityItemView(isEdit: isEdit),
            _QuantityItemView(value: -10)
          ],
        ),
      ),
    );
  }
}

/// 
/// Build View SL
/// 
class _BuildQuantityItemView extends StatelessWidget {
  final bool isEdit;

  _BuildQuantityItemView({this.isEdit});

  @override
  Widget build(BuildContext context) {
    if (isEdit) {
      return _ChooseQuantityView();
    } else {
      return _QuantityItemView(value: 20);
    }
  }
}

///
/// View hiển thị SL item
///
class _QuantityItemView extends StatelessWidget {
  final double value;

  _QuantityItemView({this.value});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: ScreenUtils.width * (1 / 5),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceMedium),
        child: Text(
          value.toStringFormat(EDoubleFormat.quantity),
          style: Theme.of(context)
              .textTheme
              .bodyText1
              .copyWith(color: value > 0 ? AppColor.black : Colors.red),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

///
/// View hiển thị SL
///
class _ChooseQuantityView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: ScreenUtils.width * (1 / 5),
        child: Align(
            alignment: Alignment.center,
            child: QuantityBorderStyleView(
              quantity: 100,
              colorBackground: AppColor.white,
              width: 50,
              onPressed: () {
                showDialog(
                    context: context,
                    child: KeyboardGeneralDialog(
                      type: EDoubleFormat.quantity,
                      titleDialog: 'Nhập số lượng',
                      callback: (value) {
                        Navigator.pop(context);
                      },
                    ));
              },
            )));
  }
}
