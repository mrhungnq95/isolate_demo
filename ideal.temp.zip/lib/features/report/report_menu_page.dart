import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_report_type.dart';
import 'package:MShopManager/features/report/report_menu_view_model.dart';
import 'package:MShopManager/widget/item_category_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class ReportMenuPage extends StatefulWidget {
  @override
  _ReportMenuPageState createState() => _ReportMenuPageState();
}

class _ReportMenuPageState extends State<ReportMenuPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<ReportMenuViewModel>(
        viewModelBuilder: (context) =>
            LocatorService.shared.get<ReportMenuViewModel>(),
        reactive: true,
        onViewModelReady: (model) {},
        backgroundColor: Colors.white,
        brightnessColor: Brightness.light,
        statusBarColor: Colors.transparent,
        builder: (context, model, child) {
          return MSScrollContainerAnimated(
            reactiveNavigationBottomBar: true,
            isAlwaysShowToolbar: true,
            titleExpanded: "Báo cáo",
            body: _ContentView(),
          );
        });
  }
}

class _ContentView extends ViewModelWidget<ReportMenuViewModel> {
  @override
  Widget build(BuildContext context, ReportMenuViewModel model) {
    return GridView.builder(
        padding: const EdgeInsets.only(
            top: kVerticalSpaceLarge,
            left: kHorizontalSpaceLarge,
            right: kHorizontalSpaceLarge,
            bottom: 260),
        itemBuilder: ((context, index) {
          final itemCategory = model.reportItems[index];
          return ItemCategoryView(
            title: itemCategory.getTitle(),
            iconPath: itemCategory.getIconPath(),
            position: index,
            onPressed: (item) {
              _navigateToReportScreen(context, itemCategory);
            },
          );
        }),
        itemCount: model.reportItems?.length ?? 0,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 166 / 110,
            crossAxisSpacing: kHorizontalSpaceMedium,
            mainAxisSpacing: kHorizontalSpaceMedium));
  }

  /// Chuyến sang các màn hình báo cáo theo type
  void _navigateToReportScreen(BuildContext context, EReportType type) {
    //showToastFeatureDeveloping();
    switch (type) {
      case EReportType.BUSINESS:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.business_situation);
        break;
      case EReportType.REVENUE:
        NavigationHelper.shared.navigateTo(routeName: AppRouterName.revenue);
        break;
      case EReportType.REVENUE_EXPEND:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.revenue_expenditure);
        break;
      case EReportType.INVENTORY:
        //Tồn kho
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.inventory_item_in_store);
        break;
      case EReportType.INVENTORY_BY_LOT_DATE:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.report_inventories_by_lot);
        break;
      case EReportType.DEBT:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.debt_customer_page);
        break;
      case EReportType.BEST_SELLER:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.best_seller);
        break;
    }
  }
}
