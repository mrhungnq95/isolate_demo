//
// Created by nqhung on 30/10/2020.
//

import 'dart:async';

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/mixin/ms_vm_event_validate_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/business/branch_business.dart';
import 'package:MShopManager/business/license_info_business.dart';
import 'package:MShopManager/business/permission_utils.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/data/remote/dboption_data_remote.dart';
import 'package:MShopManager/data/remote/mobile_data_remote.dart';
import 'package:MShopManager/data/repository/auth_respository.dart';
import 'package:MShopManager/data/repository/dboption_repository.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/enums/enum_app_license.dart';
import 'package:MShopManager/enums/enum_license_view_type.dart';
import 'package:MShopManager/enums/enum_login_error_type.dart';
import 'package:MShopManager/enums/enum_package_license.dart';
import 'package:MShopManager/features/signin/signin_form_data_util.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/dboption.dart';
import 'package:MShopManager/model/login_result_wrapper.dart';
import 'package:MShopManager/model/role_permission.dart';
import 'package:MShopManager/model/service/get_roles_permission_param.dart';

import 'package:MShopManager/model/service/login_error_response.dart';
import 'package:MShopManager/model/service/login_response.dart';
import 'package:MShopManager/service/api/authenticate_api.dart';
import 'package:MShopManager/service/api/mobile_api.dart';
import 'package:MShopManager/service/api/dboption_api.dart';
import 'package:MShopManager/service/api/impl/authenticate_api_client.dart';
import 'package:MShopManager/service/api/impl/mobile_api_client.dart';
import 'package:MShopManager/service/api/impl/dboption_api_client.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/utils/global_utils.dart';
import 'package:MShopManager/utils/logger_utils.dart';
import 'package:flutter/widgets.dart';
import 'package:rxdart/rxdart.dart';
import 'package:MShopManager/features/signin/event/event_sign_in_state.dart';

class SignInViewModel extends MSBaseViewModel
    with MSEventValidateMixin<EventSignInState> {
  ///
  /// BehaviorSubject quản lý value của Field Mã nhà hàng
  ///
  final _branchCodeSubject = BehaviorSubject<String>();
  Stream<String> get branchCodeStream => _branchCodeSubject.stream;
  Sink<String> get branchCodeSink => _branchCodeSubject.sink;

  ///
  /// BehaviorSubject quản lý state validate của Field Mã nhà hàng
  ///
  final _branchCodeStateSubject = BehaviorSubject<bool>();
  Stream<bool> get branchCodeStateStream => _branchCodeStateSubject.stream;
  Sink<bool> get branchCodeStateSink => _branchCodeStateSubject.sink;

  ///
  /// BehaviorSubject quản lý value của Field Tài khoản
  ///
  final _userNameSubject = BehaviorSubject<String>();
  Stream<String> get userNameStream => _userNameSubject.stream;
  Sink<String> get userNameSink => _userNameSubject.sink;

  ///
  /// BehaviorSubject quản lý state validate của Field Tài khoản
  ///
  final _userNameStateSubject = BehaviorSubject<bool>();
  Stream<bool> get userNameStateStream => _userNameStateSubject.stream;
  Sink<bool> get userNameStateSink => _userNameStateSubject.sink;

  ///
  /// BehaviorSubject quản lý value của Field Mật khẩu
  ///
  final _passwordSubject = BehaviorSubject<String>();
  Stream<String> get passwordStream => _passwordSubject.stream;
  Sink<String> get passwordSink => _passwordSubject.sink;

  ///
  /// BehaviorSubject quản lý state validate của Field Mật khẩu
  ///
  final _passwordStateSubject = BehaviorSubject<bool>();
  Stream<bool> get passwordStateStream => _passwordStateSubject.stream;
  Sink<bool> get passwordStateSink => _passwordStateSubject.sink;

  ///
  /// BehaviorSubject quản lý state validate của button Đăng nhập
  ///
  final _buttonStateSubject = BehaviorSubject<bool>();
  Stream<bool> get buttonStream => _buttonStateSubject.stream;

  StreamSubscription<String> _branchCodeSubscription;
  StreamSubscription<String> _userNameSubscription;
  StreamSubscription<String> _passwordSubscription;
  StreamSubscription<bool> _formDataSubscription;

  ///var branchCodeStateTransform =
  ///    StreamTransformer<String, bool>.fromHandlers(handleData: (text, sink) {});

  //Service ====================================================================
  AuthRepository _authRepository;
  MobileRepository _mobileRepository;
  DBOptionRepository _dbOptionRepository;
  //Service ====================================================================

  final branchCodeController =
      TextEditingController(text: "testmshopchuoi.mshopkeeper.vn");
  final userNameController = TextEditingController(text: "dhnam");
  final passwordController = TextEditingController(text: "112233@Abc");

  final branchCodeFocus = FocusNode();
  final userNameFocus = FocusNode();
  final passwordFocus = FocusNode();

  SignInViewModel() {
    _authRepository = AuthRepositoryImpl(
        authClient: AuthenticateAPIClientImpl(AuthenticateAPI()));

    _branchCodeSubscription = branchCodeStream.listen((branchCode) {
      final result = !isNullOrEmpty(branchCode);
      _branchCodeStateSubject.sink.add(result);
    });

    _userNameSubscription = userNameStream.listen((branchCode) {
      final result = !isNullOrEmpty(branchCode);
      _userNameStateSubject.sink.add(result);
    });

    _passwordSubscription = passwordStream.listen((branchCode) {
      final result = !isNullOrEmpty(branchCode);
      _passwordStateSubject.sink.add(result);
    });

    ///
    /// Combine 3 stream lại với nhau để check validate cho button Đăng nhập
    ///
    _formDataSubscription =
        Rx.combineLatest3(branchCodeStream, userNameStream, passwordStream,
            (branchCode, userName, password) {
      final result =
          SignInFormDataUtil.isValidateFormData(branchCode, userName, password);

      if (result == ELoginValidateFormData.validated) {
        return true;
      }
      return false;
    }).listen((isValidated) {
      _buttonStateSubject.sink.add(isValidated);
    });

    ///
    /// Lắng nghe sự kiện focus trên field Mã nhà hàng
    ///
    branchCodeFocus.addListener(() {
      if (branchCodeFocus.hasFocus == false) {
        final branchCode = branchCodeController.text;

        if (hasContentData(branchCode)) {
          final branchCodeRefactor =
              SignInFormDataUtil.refactorBranchCodeWithSubDomain(branchCode);
          if (branchCode != branchCodeRefactor) {
            branchCodeController.text = branchCodeRefactor;
            branchCodeSink.add(branchCodeRefactor);
          }
        }
      }
    });

    ///
    /// INIT =================================================================
    ///
    final branchCode = branchCodeController.text;
    final userName = userNameController.text;
    final password = passwordController.text;

    branchCodeSink.add(branchCode);
    userNameSink.add(userName);
    passwordSink.add(password);

    final isValidated =
        SignInFormDataUtil.isValidateFormData(branchCode, userName, password);

    if (isValidated == ELoginValidateFormData.validated) {
      _buttonStateSubject.sink.add(true);
    }
  }

  void dispose() {
    super.dispose();

    _branchCodeSubscription?.cancel();
    _formDataSubscription?.cancel();
    _userNameSubscription?.cancel();
    _passwordSubscription?.cancel();

    _branchCodeSubject?.close();
    _userNameSubject?.close();
    _passwordSubject?.close();

    branchCodeController.dispose();
    userNameController.dispose();
    passwordController.dispose();

    branchCodeFocus.dispose();
    userNameFocus.dispose();
    passwordFocus.dispose();
  }

  ///
  /// Thực hiện đăng nhập
  /// [onSuccesss] sự kiện đăng nhập thành công
  /// [onError] sự kiện đăng nhập lỗi
  /// [onAccessDenined] sự kiện user không có quyền đăng nhập
  /// [onHandleLicenseView] sự kiện cần show thông báo về License
  ///
  void _requestSignIn(
      String userName,
      String password,
      String branchCode,
      String subDomain,
      {@required
          Function(LoginResponse loginResponse) onSuccess,
      @required
          Function(LoginErrorResponse loginErrorResponse) onError,
      @required
          Function(LoginResponse loginResponse, bool isAdmin) onLicense,
      @required
          Function onOcmLicense,
      @required
          Function(double stepValue, int activeBranch, int numberBranchRegister,
                  bool isShowUpgradeButton)
              onBranchOutOfQuotaChainStore,
      @required
          Function(String productPackageName, bool isShowUpgradeButton)
              onVirtualBranchTrailLicense,
      @required
          Function onAccessDenined}) async {
    /// testmshopchuoi", "dhnam", "112233@Abc"

    /// Thực hiện gọi service login
    final loginResponse =
        await _authRepository.login(branchCode, userName, password);

    await loginResponse.when(success: (loginResponse) async {
      /// + Check licenseType
      final licenseTye =
          EAppLicenseExt.valueOf(loginResponse.licenseInfo?.licenseType);

      /// OCM
      if (licenseTye == EAppLicense.OCM) {
        /// => Show OCM license

        ///onHandleLicenseView(ELicenseViewType.ocm_license);

        onOcmLicense?.call();
      } else {
        final licenseInfoBusiness =
            LicenseInfoBusiness.newInstance(loginResponse.licenseInfo);

        if (UserPermissionUtils.isAdmin(loginResponse.roles)) {
          if (licenseInfoBusiness.isShowLicenseTrial()) {
            /// => Show thông tin license dùng thử
            ///
            /// showLicenseDialog
            /// onHandleLicenseView(ELicenseViewType.trail_license);

            final isAdmin =
                _hasSystemAdminOrChainManagerPermission(loginResponse.roles);

            onLicense?.call(loginResponse, isAdmin);
          } else {
            EventSignInState status = checkLicense(loginResponse);

            if (status == null) {
              /// Nếu thoả mãn đăng nhập và các yêu cầu về License thì tiếp tục
              /// Lấy tiếp DBOption và Permission
              onSuccess(loginResponse);
            } else {
              status.maybeWhen(
                  orElse: () => true,
                  branchOutOfQuotaChainStore: (double stepValue,
                      int activeBranch,
                      int numberBranchRegister,
                      bool isShowUpgradeButton) {
                    onBranchOutOfQuotaChainStore?.call(stepValue, activeBranch,
                        numberBranchRegister, isShowUpgradeButton);
                  },
                  virtualBranchTrailLicense:
                      (String productPackageName, bool isShowUpgradeButton) {
                    onVirtualBranchTrailLicense?.call(
                        productPackageName, isShowUpgradeButton);
                  });
            }
          }
        } else {
          /// => Show thông báo không có quyền
          /// Dừng việc đăng nhập
          onAccessDenined();
        }
      }
    }, failure: (errorData, httpException) {
      onError(errorData?.data);
    });
  }

  ///
  /// Kiểm tra license
  /// [loginResponse] thông tin đăng nhập
  ///
  EventSignInState checkLicense(LoginResponse loginResponse) {
    final licenseInfoBusiness =
        LicenseInfoBusiness.newInstance(loginResponse.licenseInfo);

    final activeBranch = int.tryParse(loginResponse.activeBranch) ?? 0;

    /// Check license đã mua chính thức
    if (licenseInfoBusiness.isChainStoreOutOfQuota(
        numBranchActive: activeBranch)) {
      /// => Show thông tin license dùng thử

      //showUpgradeAccountDialog
      //onHandleLicenseView(
      //    ELicenseViewType.branch_out_of_quota_chain_store);

      double stepValue = 0;

      ELicenseType licenseType =
          ELicenseTypeExt.valueOf(loginResponse.licenseInfo.productPackCode);

      if (licenseType == ELicenseType.LicensePackageStarter) {
        stepValue = 0.5;
      } else if (licenseType == ELicenseType.LicensePackagePro) {
        stepValue = 1;
      }

      final numberBranchRegister =
          loginResponse.licenseInfo?.numberOfBranch ?? 1;

      final isShowUpgradeButton =
          _hasSystemAdminOrChainManagerPermission(loginResponse.roles);

      return EventSignInState.branchOutOfQuotaChainStore(
          stepValue, activeBranch, numberBranchRegister, isShowUpgradeButton);
    } else {
      final branchGrantedPermissionList =
          UserPermissionUtils.selectBranchsGranted(loginResponse.branchList);

      if (branchGrantedPermissionList.length == 1) {
        /// nếu danh sách chi nhánh trả về chỉ có 1 phần tử và là kho
        /// tổng và giấy phép không có chain store
        final branch = branchGrantedPermissionList.first;
        if (branch.isVirtualBranch() &&
            licenseInfoBusiness.isNotTrailLicenseForChainStore()) {
          //showUpgradeChainStoreDialog
          //onHandleLicenseView(
          //    ELicenseViewType.virtual_branch_trail_license);

          final isShowUpgradeButton =
              _hasSystemAdminOrChainManagerPermission(loginResponse.roles);

          return EventSignInState.virtualBranchTrailLicense(
              loginResponse.licenseInfo.productPackName, isShowUpgradeButton);
        }
      }
    }
    return null;
  }

  ///
  ///  Kiểm tra có quyền Quản lý hệ thống hoặc chuỗi không?
  /// [roles] DS các quyền của user
  ///
  bool _hasSystemAdminOrChainManagerPermission(String roles) {
    final roleList = UserPermissionUtils.convertRoleValueToList(roles);

    return UserPermissionUtils.hasSystemAdminOrChainManagerPermission(roleList);
  }

  ///
  /// Lấy DBOption và Permission theo [userId] của User
  ///
  Future<void> fetchDBOptionAndPermissionDataForUser(String userId) async {
    final localStorage = LocalStorage.shared;
    final userCredential = UserCredential.currentSession;

    /// Tiếp tục lấy Permission và DBOption
    _mobileRepository = MobileRepositoryImpl(
        mobileDataRemote:
            MobileDataRemoteImpl(apiClient: MobileAPIClientImpl(MobileAPI())));
    _dbOptionRepository = DBOptionRepositoryImpl(
        dbOptionDataRemote: DBOptionDataRemoteImpl(
            apiClient: DBOptionAPIClientImpl(DBOptionAPI())));

    final permissionList = await fetchPermissionList(userId);

    /// Lưu Permission vào LocalStorage
    /// Lưu vào Permission Manager
    userCredential.rolePermissionList = permissionList;

    final dbOptionResult = await fetchDBOptionList();

    /// Lưu DBOption vào LocalStorage
    localStorage.setDBOptionList(dbOptionResult);
  }

  ///
  /// Đăng nhập
  ///
  void signIn() async {
    FLogger.shared.log("Bắt đầu...");

    validate(EventSignInState.loading());

    final userName = userNameController.text;
    final password = passwordController.text;
    final branchCode =
        SignInFormDataUtil.getBranchCodeFromFullUrl(branchCodeController.text);
    final subDomain =
        SignInFormDataUtil.getSubDomainFromFullUrl(branchCodeController.text);

    await _requestSignIn(userName, password, branchCode, subDomain,
        onSuccess: (loginResponse) async {
      _handleSignIn(branchCode, subDomain, loginResponse);
    }, onError: (loginErrorResponse) async {
      FLogger.shared.log("Đăng nhập lỗi!");

      /// Dismiss loading dialog
      validate(EventSignInState.dismissLoading());

      /// Lỗi Login được trả về trong Body của Data
      ///
      final loginError = ESignInErrorTypeExt.valueOf(loginErrorResponse?.error);

      if (loginError != null) {
        validate(EventSignInState.signInError(loginError));
      } else {
        validate(EventSignInState.unknowException());
      }
    }, onAccessDenined: () {
      /// Dismiss loading dialog
      validate(EventSignInState.accessDenined());

      /// Toast
      /// You are not authorized to access this app. Please check again.
    }, onBranchOutOfQuotaChainStore: (double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton) {
      ///
      ///
      validate(
        EventSignInState.branchOutOfQuotaChainStore(
            stepValue, activeBranch, numberBranchRegister, isShowUpgradeButton),
      );
    }, onVirtualBranchTrailLicense:
            (String productPackageName, bool isShowUpgradeButton) {
      ///
      ///
      validate(
        EventSignInState.virtualBranchTrailLicense(
            productPackageName, isShowUpgradeButton),
      );
    }, onOcmLicense: () {
      validate(EventSignInState.ocmLicense());
    }, onLicense: (LoginResponse loginResponse, bool isAdmin) {
      validate(EventSignInState.license(
          branchCode, subDomain, loginResponse, isAdmin));
    });
  }

  ///
  /// Request API lấy Permission của User
  /// [userId] id của User cần lấy
  ///
  Future<List<RolePermission>> fetchPermissionList(String userId) async {
    /// Lấy tiếp DBOption và Permission
    final rolePermissionParams = GetRolesPermissionParam(userId);

    /// Request API lấy Permission
    final permissionRequest =
        await _mobileRepository.getRolesPermission(rolePermissionParams);
    final permissionResult =
        permissionRequest.when<List<RolePermission>>(success: (data) {
      return data.data;
    }, commonError: (e) {
      /// không bắt exception  thì return ra mảng rỗng
      return [];
    }, apiError: (errorData, ex) {
      /// không bắt exception  thì return ra mảng rỗng
      return [];
    });
    return Future.value(permissionResult);
  }

  ///
  /// Request API lấy DBOption
  ///
  Future<List<DBOption>> fetchDBOptionList() async {
    /// Request API lấy DBOption
    final dbOptionRequest =
        await _dbOptionRepository.getDBOptionByBranchID(AppConstant.UUID_EMPTY);

    final dbOptionResult =
        dbOptionRequest.when<List<DBOption>>(success: (data) {
      FLogger.shared.log("Get DBOption Success!");
      return data;
    }, commonError: (e) {
      /// không bắt exception  thì return ra mảng rỗng
      return [];
    }, apiError: (errorData, ex) {
      /// không bắt exception  thì return ra mảng rỗng
      return [];
    });
    return Future.value(dbOptionResult);
  }

  ///
  /// Thực hiện tiép tục luồng đăng nhập sau khi kiểm tra license
  /// [branchCode] mã cửa hàng
  /// [subDomain] domain của cửa hàng. VD: mshopkeeper.com / mshopkeeper.vn
  /// [loginResponse] thông tin đăng nhập thành công
  ///
  void continueAfterCheckingLicense(
      String branchCode, String subDomain, LoginResponse loginResponse) {
    EventSignInState status = checkLicense(loginResponse);

    if (status == null) {
      /// Nếu thoả mãn đăng nhập và các yêu cầu về License thì tiếp tục
      /// Lấy tiếp DBOption và Permission
      _handleSignIn(branchCode, subDomain, loginResponse);
    } else {
      status.maybeWhen(
          orElse: () => validate(EventSignInState.unknowException()),
          branchOutOfQuotaChainStore: (double stepValue, int activeBranch,
              int numberBranchRegister, bool isShowUpgradeButton) {
            validate(
              EventSignInState.branchOutOfQuotaChainStore(stepValue,
                  activeBranch, numberBranchRegister, isShowUpgradeButton),
            );
          },
          virtualBranchTrailLicense:
              (String productPackageName, bool isShowUpgradeButton) {
            validate(
              EventSignInState.virtualBranchTrailLicense(
                  productPackageName, isShowUpgradeButton),
            );
          });
    }
  }

  ///
  /// Handle sự kiện login thành công
  /// [branchCode] mã cửa hàng
  /// [subDomain] domain của cửa hàng. VD: mshopkeeper.com / mshopkeeper.vn
  /// [loginResponse] thông tin đăng nhập thành công
  ///
  void _handleSignIn(
      String branchCode, String subDomain, LoginResponse loginResponse) async {
    FLogger.shared.log("Đăng nhập thành công!");

    final localStorage = LocalStorage.shared;
    final userCredential = UserCredential.newSession();

    /// IMPORTANT! -
    localStorage.setBranchCode(branchCode);
    localStorage.setSubDomain(subDomain);
    localStorage.setEnvironment(loginResponse.environment);

    /// IMPORTANT! -
    /// Lưu thêm một số thông tin từ Login Response, trước khi
    /// reset lại UrlHelper
    ///
    final branchGrantedByUser =
        UserPermissionUtils.selectBranchsGranted(loginResponse.branchList);

    userCredential.auth = true;
    userCredential.branchList = branchGrantedByUser;
    userCredential.licenseInfo = loginResponse.licenseInfo;
    userCredential.token = loginResponse.accessToken;
    userCredential.refreshToken = loginResponse.refreshToken;
    userCredential.loginResponse = loginResponse;

    ///  Bao gồm cả Kho tổng và các cửa hàng đã được sort theo A-Z
    final allBranchGrantedPermissionList = BranchBusiness.getBranchList(
        branchGrantedByUser,
        isDisplayVirtualBranch: true,
        isGetAllChainBranch: false);
    userCredential.branchAndStorehouseSortedList =
        allBranchGrantedPermissionList;

    /// IMPORTANT! - Phải reset Url trước khi khởi tạo API
    /// ở đây vì phụ thuộc vào BranchCode của cửa hàng user đăng nhập
    UrlHelper.resetInstance();

    /// Lấy DBOption và Permission theo [userId] của User
    await fetchDBOptionAndPermissionDataForUser(loginResponse.userId);

    /// Dismiss loading dialog
    validate(EventSignInState.dismissLoading());

    /// Navigate sang màn main
    await navigationService.navigateReplacementNamed(
        routeName: AppRouterName.main);
  }

  @override
  bool get sync => false;
}
