// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'event_sign_in_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$EventSignInStateTearOff {
  const _$EventSignInStateTearOff();

// ignore: unused_element
  Loading loading() {
    return const Loading();
  }

// ignore: unused_element
  DismissLoading dismissLoading() {
    return const DismissLoading();
  }

// ignore: unused_element
  OcmLicense ocmLicense() {
    return const OcmLicense();
  }

// ignore: unused_element
  License license(String branchCode, String subDomain,
      LoginResponse loginResponse, bool isAdmin) {
    return License(
      branchCode,
      subDomain,
      loginResponse,
      isAdmin,
    );
  }

// ignore: unused_element
  BranchOutOfQuotaChainStore branchOutOfQuotaChainStore(double stepValue,
      int activeBranch, int numberBranchRegister, bool isShowUpgradeButton) {
    return BranchOutOfQuotaChainStore(
      stepValue,
      activeBranch,
      numberBranchRegister,
      isShowUpgradeButton,
    );
  }

// ignore: unused_element
  VirtualBranchTrailLicense virtualBranchTrailLicense(
      String productPackageName, bool isShowUpgradeButton) {
    return VirtualBranchTrailLicense(
      productPackageName,
      isShowUpgradeButton,
    );
  }

// ignore: unused_element
  SignInError signInError(ESignInErrorType errorType) {
    return SignInError(
      errorType,
    );
  }

// ignore: unused_element
  AccessDenined accessDenined() {
    return const AccessDenined();
  }

// ignore: unused_element
  UnknowException unknowException() {
    return const UnknowException();
  }
}

/// @nodoc
// ignore: unused_element
const $EventSignInState = _$EventSignInStateTearOff();

/// @nodoc
mixin _$EventSignInState {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $EventSignInStateCopyWith<$Res> {
  factory $EventSignInStateCopyWith(
          EventSignInState value, $Res Function(EventSignInState) then) =
      _$EventSignInStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$EventSignInStateCopyWithImpl<$Res>
    implements $EventSignInStateCopyWith<$Res> {
  _$EventSignInStateCopyWithImpl(this._value, this._then);

  final EventSignInState _value;
  // ignore: unused_field
  final $Res Function(EventSignInState) _then;
}

/// @nodoc
abstract class $LoadingCopyWith<$Res> {
  factory $LoadingCopyWith(Loading value, $Res Function(Loading) then) =
      _$LoadingCopyWithImpl<$Res>;
}

/// @nodoc
class _$LoadingCopyWithImpl<$Res> extends _$EventSignInStateCopyWithImpl<$Res>
    implements $LoadingCopyWith<$Res> {
  _$LoadingCopyWithImpl(Loading _value, $Res Function(Loading) _then)
      : super(_value, (v) => _then(v as Loading));

  @override
  Loading get _value => super._value as Loading;
}

/// @nodoc
class _$Loading implements Loading {
  const _$Loading();

  @override
  String toString() {
    return 'EventSignInState.loading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is Loading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return loading();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (loading != null) {
      return loading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return loading(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (loading != null) {
      return loading(this);
    }
    return orElse();
  }
}

abstract class Loading implements EventSignInState {
  const factory Loading() = _$Loading;
}

/// @nodoc
abstract class $DismissLoadingCopyWith<$Res> {
  factory $DismissLoadingCopyWith(
          DismissLoading value, $Res Function(DismissLoading) then) =
      _$DismissLoadingCopyWithImpl<$Res>;
}

/// @nodoc
class _$DismissLoadingCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $DismissLoadingCopyWith<$Res> {
  _$DismissLoadingCopyWithImpl(
      DismissLoading _value, $Res Function(DismissLoading) _then)
      : super(_value, (v) => _then(v as DismissLoading));

  @override
  DismissLoading get _value => super._value as DismissLoading;
}

/// @nodoc
class _$DismissLoading implements DismissLoading {
  const _$DismissLoading();

  @override
  String toString() {
    return 'EventSignInState.dismissLoading()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is DismissLoading);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return dismissLoading();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (dismissLoading != null) {
      return dismissLoading();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return dismissLoading(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (dismissLoading != null) {
      return dismissLoading(this);
    }
    return orElse();
  }
}

abstract class DismissLoading implements EventSignInState {
  const factory DismissLoading() = _$DismissLoading;
}

/// @nodoc
abstract class $OcmLicenseCopyWith<$Res> {
  factory $OcmLicenseCopyWith(
          OcmLicense value, $Res Function(OcmLicense) then) =
      _$OcmLicenseCopyWithImpl<$Res>;
}

/// @nodoc
class _$OcmLicenseCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $OcmLicenseCopyWith<$Res> {
  _$OcmLicenseCopyWithImpl(OcmLicense _value, $Res Function(OcmLicense) _then)
      : super(_value, (v) => _then(v as OcmLicense));

  @override
  OcmLicense get _value => super._value as OcmLicense;
}

/// @nodoc
class _$OcmLicense implements OcmLicense {
  const _$OcmLicense();

  @override
  String toString() {
    return 'EventSignInState.ocmLicense()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is OcmLicense);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return ocmLicense();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ocmLicense != null) {
      return ocmLicense();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return ocmLicense(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ocmLicense != null) {
      return ocmLicense(this);
    }
    return orElse();
  }
}

abstract class OcmLicense implements EventSignInState {
  const factory OcmLicense() = _$OcmLicense;
}

/// @nodoc
abstract class $LicenseCopyWith<$Res> {
  factory $LicenseCopyWith(License value, $Res Function(License) then) =
      _$LicenseCopyWithImpl<$Res>;
  $Res call(
      {String branchCode,
      String subDomain,
      LoginResponse loginResponse,
      bool isAdmin});
}

/// @nodoc
class _$LicenseCopyWithImpl<$Res> extends _$EventSignInStateCopyWithImpl<$Res>
    implements $LicenseCopyWith<$Res> {
  _$LicenseCopyWithImpl(License _value, $Res Function(License) _then)
      : super(_value, (v) => _then(v as License));

  @override
  License get _value => super._value as License;

  @override
  $Res call({
    Object branchCode = freezed,
    Object subDomain = freezed,
    Object loginResponse = freezed,
    Object isAdmin = freezed,
  }) {
    return _then(License(
      branchCode == freezed ? _value.branchCode : branchCode as String,
      subDomain == freezed ? _value.subDomain : subDomain as String,
      loginResponse == freezed
          ? _value.loginResponse
          : loginResponse as LoginResponse,
      isAdmin == freezed ? _value.isAdmin : isAdmin as bool,
    ));
  }
}

/// @nodoc
class _$License implements License {
  const _$License(
      this.branchCode, this.subDomain, this.loginResponse, this.isAdmin)
      : assert(branchCode != null),
        assert(subDomain != null),
        assert(loginResponse != null),
        assert(isAdmin != null);

  @override
  final String branchCode;
  @override
  final String subDomain;
  @override
  final LoginResponse loginResponse;
  @override
  final bool isAdmin;

  @override
  String toString() {
    return 'EventSignInState.license(branchCode: $branchCode, subDomain: $subDomain, loginResponse: $loginResponse, isAdmin: $isAdmin)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is License &&
            (identical(other.branchCode, branchCode) ||
                const DeepCollectionEquality()
                    .equals(other.branchCode, branchCode)) &&
            (identical(other.subDomain, subDomain) ||
                const DeepCollectionEquality()
                    .equals(other.subDomain, subDomain)) &&
            (identical(other.loginResponse, loginResponse) ||
                const DeepCollectionEquality()
                    .equals(other.loginResponse, loginResponse)) &&
            (identical(other.isAdmin, isAdmin) ||
                const DeepCollectionEquality().equals(other.isAdmin, isAdmin)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(branchCode) ^
      const DeepCollectionEquality().hash(subDomain) ^
      const DeepCollectionEquality().hash(loginResponse) ^
      const DeepCollectionEquality().hash(isAdmin);

  @override
  $LicenseCopyWith<License> get copyWith =>
      _$LicenseCopyWithImpl<License>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return license(branchCode, subDomain, loginResponse, isAdmin);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (license != null) {
      return license(branchCode, subDomain, loginResponse, isAdmin);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return license(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (license != null) {
      return license(this);
    }
    return orElse();
  }
}

abstract class License implements EventSignInState {
  const factory License(String branchCode, String subDomain,
      LoginResponse loginResponse, bool isAdmin) = _$License;

  String get branchCode;
  String get subDomain;
  LoginResponse get loginResponse;
  bool get isAdmin;
  $LicenseCopyWith<License> get copyWith;
}

/// @nodoc
abstract class $BranchOutOfQuotaChainStoreCopyWith<$Res> {
  factory $BranchOutOfQuotaChainStoreCopyWith(BranchOutOfQuotaChainStore value,
          $Res Function(BranchOutOfQuotaChainStore) then) =
      _$BranchOutOfQuotaChainStoreCopyWithImpl<$Res>;
  $Res call(
      {double stepValue,
      int activeBranch,
      int numberBranchRegister,
      bool isShowUpgradeButton});
}

/// @nodoc
class _$BranchOutOfQuotaChainStoreCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $BranchOutOfQuotaChainStoreCopyWith<$Res> {
  _$BranchOutOfQuotaChainStoreCopyWithImpl(BranchOutOfQuotaChainStore _value,
      $Res Function(BranchOutOfQuotaChainStore) _then)
      : super(_value, (v) => _then(v as BranchOutOfQuotaChainStore));

  @override
  BranchOutOfQuotaChainStore get _value =>
      super._value as BranchOutOfQuotaChainStore;

  @override
  $Res call({
    Object stepValue = freezed,
    Object activeBranch = freezed,
    Object numberBranchRegister = freezed,
    Object isShowUpgradeButton = freezed,
  }) {
    return _then(BranchOutOfQuotaChainStore(
      stepValue == freezed ? _value.stepValue : stepValue as double,
      activeBranch == freezed ? _value.activeBranch : activeBranch as int,
      numberBranchRegister == freezed
          ? _value.numberBranchRegister
          : numberBranchRegister as int,
      isShowUpgradeButton == freezed
          ? _value.isShowUpgradeButton
          : isShowUpgradeButton as bool,
    ));
  }
}

/// @nodoc
class _$BranchOutOfQuotaChainStore implements BranchOutOfQuotaChainStore {
  const _$BranchOutOfQuotaChainStore(this.stepValue, this.activeBranch,
      this.numberBranchRegister, this.isShowUpgradeButton)
      : assert(stepValue != null),
        assert(activeBranch != null),
        assert(numberBranchRegister != null),
        assert(isShowUpgradeButton != null);

  @override
  final double stepValue;
  @override
  final int activeBranch;
  @override
  final int numberBranchRegister;
  @override
  final bool isShowUpgradeButton;

  @override
  String toString() {
    return 'EventSignInState.branchOutOfQuotaChainStore(stepValue: $stepValue, activeBranch: $activeBranch, numberBranchRegister: $numberBranchRegister, isShowUpgradeButton: $isShowUpgradeButton)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is BranchOutOfQuotaChainStore &&
            (identical(other.stepValue, stepValue) ||
                const DeepCollectionEquality()
                    .equals(other.stepValue, stepValue)) &&
            (identical(other.activeBranch, activeBranch) ||
                const DeepCollectionEquality()
                    .equals(other.activeBranch, activeBranch)) &&
            (identical(other.numberBranchRegister, numberBranchRegister) ||
                const DeepCollectionEquality().equals(
                    other.numberBranchRegister, numberBranchRegister)) &&
            (identical(other.isShowUpgradeButton, isShowUpgradeButton) ||
                const DeepCollectionEquality()
                    .equals(other.isShowUpgradeButton, isShowUpgradeButton)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(stepValue) ^
      const DeepCollectionEquality().hash(activeBranch) ^
      const DeepCollectionEquality().hash(numberBranchRegister) ^
      const DeepCollectionEquality().hash(isShowUpgradeButton);

  @override
  $BranchOutOfQuotaChainStoreCopyWith<BranchOutOfQuotaChainStore>
      get copyWith =>
          _$BranchOutOfQuotaChainStoreCopyWithImpl<BranchOutOfQuotaChainStore>(
              this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return branchOutOfQuotaChainStore(
        stepValue, activeBranch, numberBranchRegister, isShowUpgradeButton);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (branchOutOfQuotaChainStore != null) {
      return branchOutOfQuotaChainStore(
          stepValue, activeBranch, numberBranchRegister, isShowUpgradeButton);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return branchOutOfQuotaChainStore(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (branchOutOfQuotaChainStore != null) {
      return branchOutOfQuotaChainStore(this);
    }
    return orElse();
  }
}

abstract class BranchOutOfQuotaChainStore implements EventSignInState {
  const factory BranchOutOfQuotaChainStore(
      double stepValue,
      int activeBranch,
      int numberBranchRegister,
      bool isShowUpgradeButton) = _$BranchOutOfQuotaChainStore;

  double get stepValue;
  int get activeBranch;
  int get numberBranchRegister;
  bool get isShowUpgradeButton;
  $BranchOutOfQuotaChainStoreCopyWith<BranchOutOfQuotaChainStore> get copyWith;
}

/// @nodoc
abstract class $VirtualBranchTrailLicenseCopyWith<$Res> {
  factory $VirtualBranchTrailLicenseCopyWith(VirtualBranchTrailLicense value,
          $Res Function(VirtualBranchTrailLicense) then) =
      _$VirtualBranchTrailLicenseCopyWithImpl<$Res>;
  $Res call({String productPackageName, bool isShowUpgradeButton});
}

/// @nodoc
class _$VirtualBranchTrailLicenseCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $VirtualBranchTrailLicenseCopyWith<$Res> {
  _$VirtualBranchTrailLicenseCopyWithImpl(VirtualBranchTrailLicense _value,
      $Res Function(VirtualBranchTrailLicense) _then)
      : super(_value, (v) => _then(v as VirtualBranchTrailLicense));

  @override
  VirtualBranchTrailLicense get _value =>
      super._value as VirtualBranchTrailLicense;

  @override
  $Res call({
    Object productPackageName = freezed,
    Object isShowUpgradeButton = freezed,
  }) {
    return _then(VirtualBranchTrailLicense(
      productPackageName == freezed
          ? _value.productPackageName
          : productPackageName as String,
      isShowUpgradeButton == freezed
          ? _value.isShowUpgradeButton
          : isShowUpgradeButton as bool,
    ));
  }
}

/// @nodoc
class _$VirtualBranchTrailLicense implements VirtualBranchTrailLicense {
  const _$VirtualBranchTrailLicense(
      this.productPackageName, this.isShowUpgradeButton)
      : assert(productPackageName != null),
        assert(isShowUpgradeButton != null);

  @override
  final String productPackageName;
  @override
  final bool isShowUpgradeButton;

  @override
  String toString() {
    return 'EventSignInState.virtualBranchTrailLicense(productPackageName: $productPackageName, isShowUpgradeButton: $isShowUpgradeButton)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is VirtualBranchTrailLicense &&
            (identical(other.productPackageName, productPackageName) ||
                const DeepCollectionEquality()
                    .equals(other.productPackageName, productPackageName)) &&
            (identical(other.isShowUpgradeButton, isShowUpgradeButton) ||
                const DeepCollectionEquality()
                    .equals(other.isShowUpgradeButton, isShowUpgradeButton)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(productPackageName) ^
      const DeepCollectionEquality().hash(isShowUpgradeButton);

  @override
  $VirtualBranchTrailLicenseCopyWith<VirtualBranchTrailLicense> get copyWith =>
      _$VirtualBranchTrailLicenseCopyWithImpl<VirtualBranchTrailLicense>(
          this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return virtualBranchTrailLicense(productPackageName, isShowUpgradeButton);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (virtualBranchTrailLicense != null) {
      return virtualBranchTrailLicense(productPackageName, isShowUpgradeButton);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return virtualBranchTrailLicense(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (virtualBranchTrailLicense != null) {
      return virtualBranchTrailLicense(this);
    }
    return orElse();
  }
}

abstract class VirtualBranchTrailLicense implements EventSignInState {
  const factory VirtualBranchTrailLicense(
          String productPackageName, bool isShowUpgradeButton) =
      _$VirtualBranchTrailLicense;

  String get productPackageName;
  bool get isShowUpgradeButton;
  $VirtualBranchTrailLicenseCopyWith<VirtualBranchTrailLicense> get copyWith;
}

/// @nodoc
abstract class $SignInErrorCopyWith<$Res> {
  factory $SignInErrorCopyWith(
          SignInError value, $Res Function(SignInError) then) =
      _$SignInErrorCopyWithImpl<$Res>;
  $Res call({ESignInErrorType errorType});
}

/// @nodoc
class _$SignInErrorCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $SignInErrorCopyWith<$Res> {
  _$SignInErrorCopyWithImpl(
      SignInError _value, $Res Function(SignInError) _then)
      : super(_value, (v) => _then(v as SignInError));

  @override
  SignInError get _value => super._value as SignInError;

  @override
  $Res call({
    Object errorType = freezed,
  }) {
    return _then(SignInError(
      errorType == freezed ? _value.errorType : errorType as ESignInErrorType,
    ));
  }
}

/// @nodoc
class _$SignInError implements SignInError {
  const _$SignInError(this.errorType) : assert(errorType != null);

  @override
  final ESignInErrorType errorType;

  @override
  String toString() {
    return 'EventSignInState.signInError(errorType: $errorType)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is SignInError &&
            (identical(other.errorType, errorType) ||
                const DeepCollectionEquality()
                    .equals(other.errorType, errorType)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^ const DeepCollectionEquality().hash(errorType);

  @override
  $SignInErrorCopyWith<SignInError> get copyWith =>
      _$SignInErrorCopyWithImpl<SignInError>(this, _$identity);

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return signInError(errorType);
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (signInError != null) {
      return signInError(errorType);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return signInError(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (signInError != null) {
      return signInError(this);
    }
    return orElse();
  }
}

abstract class SignInError implements EventSignInState {
  const factory SignInError(ESignInErrorType errorType) = _$SignInError;

  ESignInErrorType get errorType;
  $SignInErrorCopyWith<SignInError> get copyWith;
}

/// @nodoc
abstract class $AccessDeninedCopyWith<$Res> {
  factory $AccessDeninedCopyWith(
          AccessDenined value, $Res Function(AccessDenined) then) =
      _$AccessDeninedCopyWithImpl<$Res>;
}

/// @nodoc
class _$AccessDeninedCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $AccessDeninedCopyWith<$Res> {
  _$AccessDeninedCopyWithImpl(
      AccessDenined _value, $Res Function(AccessDenined) _then)
      : super(_value, (v) => _then(v as AccessDenined));

  @override
  AccessDenined get _value => super._value as AccessDenined;
}

/// @nodoc
class _$AccessDenined implements AccessDenined {
  const _$AccessDenined();

  @override
  String toString() {
    return 'EventSignInState.accessDenined()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is AccessDenined);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return accessDenined();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (accessDenined != null) {
      return accessDenined();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return accessDenined(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (accessDenined != null) {
      return accessDenined(this);
    }
    return orElse();
  }
}

abstract class AccessDenined implements EventSignInState {
  const factory AccessDenined() = _$AccessDenined;
}

/// @nodoc
abstract class $UnknowExceptionCopyWith<$Res> {
  factory $UnknowExceptionCopyWith(
          UnknowException value, $Res Function(UnknowException) then) =
      _$UnknowExceptionCopyWithImpl<$Res>;
}

/// @nodoc
class _$UnknowExceptionCopyWithImpl<$Res>
    extends _$EventSignInStateCopyWithImpl<$Res>
    implements $UnknowExceptionCopyWith<$Res> {
  _$UnknowExceptionCopyWithImpl(
      UnknowException _value, $Res Function(UnknowException) _then)
      : super(_value, (v) => _then(v as UnknowException));

  @override
  UnknowException get _value => super._value as UnknowException;
}

/// @nodoc
class _$UnknowException implements UnknowException {
  const _$UnknowException();

  @override
  String toString() {
    return 'EventSignInState.unknowException()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is UnknowException);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result loading(),
    @required Result dismissLoading(),
    @required Result ocmLicense(),
    @required
        Result license(String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin),
    @required
        Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton),
    @required
        Result virtualBranchTrailLicense(
            String productPackageName, bool isShowUpgradeButton),
    @required Result signInError(ESignInErrorType errorType),
    @required Result accessDenined(),
    @required Result unknowException(),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return unknowException();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result loading(),
    Result dismissLoading(),
    Result ocmLicense(),
    Result license(String branchCode, String subDomain,
        LoginResponse loginResponse, bool isAdmin),
    Result branchOutOfQuotaChainStore(double stepValue, int activeBranch,
        int numberBranchRegister, bool isShowUpgradeButton),
    Result virtualBranchTrailLicense(
        String productPackageName, bool isShowUpgradeButton),
    Result signInError(ESignInErrorType errorType),
    Result accessDenined(),
    Result unknowException(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (unknowException != null) {
      return unknowException();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result loading(Loading value),
    @required Result dismissLoading(DismissLoading value),
    @required Result ocmLicense(OcmLicense value),
    @required Result license(License value),
    @required
        Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    @required Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    @required Result signInError(SignInError value),
    @required Result accessDenined(AccessDenined value),
    @required Result unknowException(UnknowException value),
  }) {
    assert(loading != null);
    assert(dismissLoading != null);
    assert(ocmLicense != null);
    assert(license != null);
    assert(branchOutOfQuotaChainStore != null);
    assert(virtualBranchTrailLicense != null);
    assert(signInError != null);
    assert(accessDenined != null);
    assert(unknowException != null);
    return unknowException(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result loading(Loading value),
    Result dismissLoading(DismissLoading value),
    Result ocmLicense(OcmLicense value),
    Result license(License value),
    Result branchOutOfQuotaChainStore(BranchOutOfQuotaChainStore value),
    Result virtualBranchTrailLicense(VirtualBranchTrailLicense value),
    Result signInError(SignInError value),
    Result accessDenined(AccessDenined value),
    Result unknowException(UnknowException value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (unknowException != null) {
      return unknowException(this);
    }
    return orElse();
  }
}

abstract class UnknowException implements EventSignInState {
  const factory UnknowException() = _$UnknowException;
}
