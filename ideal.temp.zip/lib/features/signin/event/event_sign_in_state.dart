import 'package:MShopManager/enums/enum_login_error_type.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:MShopManager/model/service/login_response.dart';

import 'package:freezed_annotation/freezed_annotation.dart';

part 'event_sign_in_state.freezed.dart';

@freezed
abstract class EventSignInState with _$EventSignInState {
  const factory EventSignInState.loading() = Loading;
  const factory EventSignInState.dismissLoading() = DismissLoading;

  const factory EventSignInState.ocmLicense() = OcmLicense;

  const factory EventSignInState.license(String branchCode, String subDomain,
      LoginResponse loginResponse, bool isAdmin) = License;

  const factory EventSignInState.branchOutOfQuotaChainStore(
      double stepValue,
      int activeBranch,
      int numberBranchRegister,
      bool isShowUpgradeButton) = BranchOutOfQuotaChainStore;

  const factory EventSignInState.virtualBranchTrailLicense(
          String productPackageName, bool isShowUpgradeButton) =
      VirtualBranchTrailLicense;

  const factory EventSignInState.signInError(ESignInErrorType errorType) =
      SignInError;
  const factory EventSignInState.accessDenined() = AccessDenined;
  const factory EventSignInState.unknowException() = UnknowException;
}
