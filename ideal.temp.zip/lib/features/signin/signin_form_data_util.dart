//
// Created by nqhung on 11/11/2020.
//

import 'package:MShopManager/app/app_config.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/service/storage/local_storage.dart';
import 'package:MShopManager/utils/app_utils.dart';
import 'package:MShopManager/utils/global_utils.dart';
import 'package:flutter/material.dart';

enum ELoginValidateFormData {
  validated,
  branchCodeIsEmpty,
  branchCodeNotMatchPattern,
  userNameIsEmpty,
  passwordIsEmpty
}

class SignInFormDataUtil {
  static final String PATTERN_DOMAIN_FORMAT =
      r"^([\w_]+)(\.mshopkeeper(\.com|\.vn|\.misa\.local|\.com\.local))$";

  //static final String PATTERN_BRANCH_CODE_FORMAT = r"^[\w]+$";

  ///
  /// Lấy BranchCode từ mã nhà hàng [fullBranchCodeUrl] đã bao gồm sub-domain
  /// (vllong.mshopkeeper.vn -> vllong)
  /// Nếu chưa có sub-domain thì return luôn BranchCode
  ///
  static String getBranchCodeFromFullUrl(String fullBranchCodeUrl) {
    RegExp regExp = RegExp(PATTERN_DOMAIN_FORMAT);
    Iterable<Match> matches = regExp.allMatches(fullBranchCodeUrl);

    if (matches != null) {
      if (matches.elementAt(0)?.groupCount == 3) {
        final element0 = matches.elementAt(0);
        if (element0 != null) {
          return element0.group(1);
        }
      }
    }
    return fullBranchCodeUrl;
  }

  ///
  /// Lấy Sub-Dmain từ mã nhà hàng [fullBranchCodeUrl]
  /// (vllong.mshopkeeper.vn -> mshopkeeper.vn)
  ///
  static String getSubDomainFromFullUrl(String fullBranchCodeUrl) {
    RegExp regExp = RegExp(PATTERN_DOMAIN_FORMAT);
    Iterable<Match> matches = regExp.allMatches(fullBranchCodeUrl);

    if (matches != null) {
      if (matches.elementAt(0)?.groupCount == 3) {
        final element0 = matches.elementAt(0);
        if (element0 != null) {
          return element0.group(2);
        }
      }
    }
    return null;
  }

  ///
  /// Refactor lại thông tin [branchCode] Mã cửa hàng từ trên Form truyền vào
  /// Nếu mã này chưa có phần subdomain (.mshopkeeper.vn hoặc .mshopkeeper.com)
  /// thì sẽ tự động thêm vào giống của lần đăng nhập thành công gần nhất
  ///
  static String refactorBranchCodeWithSubDomain(String branchCode) {
    RegExp regExp = RegExp(PATTERN_DOMAIN_FORMAT);
    if (!regExp.hasMatch(branchCode)) {
      var suggestSubDomain = "";
      if (AppConfig.isRelease) {
        suggestSubDomain = getSuggestSubDomain(isOffline: false);
      } else {
        final isAuthInternet = UserCredential.currentSession.isAuth;
        suggestSubDomain = getSuggestSubDomain(isOffline: !isAuthInternet);
      }
      return "$branchCode$suggestSubDomain";
    }
    return branchCode;
  }

  ///
  /// Lấy subdomain gợi ý , [isOffline] true nếu đăng nhập Offline (không có mạng)
  /// VD: .mshopkeeper.vn hoặc .mshopkeeper.com
  ///
  /// Created by nqhung on 16/11/2020
  static String getSuggestSubDomain({@required bool isOffline}) {
    final subDomain = LocalStorage.shared.getSubDomain();

    if (isNullOrEmpty(subDomain)) {
      if (isOffline) {
        return LocaleUtils.isVietnamLanguage()
            ? UrlHelper.LOCAL_HOST_VN
            : UrlHelper.LOCAL_HOST_COM;
      } else {
        return LocaleUtils.isVietnamLanguage()
            ? UrlHelper.INTERNET_HOST_VN
            : UrlHelper.INTERNET_HOST_COM;
      }
    } else {
      return subDomain;
    }
  }

  ///
  /// Kiểm tra xem địa chỉ truy cập cửa hàng có đúng không?
  /// VD: vllong.mshopkeeper.vn -> matched
  /// VD: vllong.mshopkeeper.vl -> not matches
  ///
  /// Created by nqhung on 16/11/2020
  static bool isBranchCodeMatchedPattern(String branchAddress) {
    RegExp regExp = RegExp(PATTERN_DOMAIN_FORMAT);
    return regExp.hasMatch(branchAddress);
  }

  /// Validate dữ liệu trên trên form từ các stream
  /// [branchCode]  mã nhà hàng
  /// [userName]    tên đăng nhập
  /// [password]    mật khẩu
  ///
  /// Created by nqhung on 11/11/2020
  static ELoginValidateFormData isValidateFormData(
      String branchCode, String userName, String password) {
    /// Kiểm tra Mã nhà hàng (đã bao gồm subDomain hoặc chưa)
    if (isNullOrEmpty(branchCode)) {
      return ELoginValidateFormData.branchCodeIsEmpty;
    }

    /// Kiểm tra Mã nhà hàng (đã bao gồm subDomain hoặc chưa)
    if (!isBranchCodeMatchedPattern(branchCode)) {
      return ELoginValidateFormData.branchCodeNotMatchPattern;
    }

    /// Kiểm tra User name
    if (isNullOrEmpty(userName)) {
      return ELoginValidateFormData.userNameIsEmpty;
    }

    /// Kiểm tra Password
    if (isNullOrEmpty(password)) {
      return ELoginValidateFormData.passwordIsEmpty;
    }
    return ELoginValidateFormData.validated;
  }
}
