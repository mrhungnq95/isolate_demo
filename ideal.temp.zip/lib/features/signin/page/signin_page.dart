import 'dart:async';

import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/mixin/ms_vm_event_validate_mixin.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_license_negative_button.dart';
import 'package:MShopManager/enums/enum_license_view_type.dart';
import 'package:MShopManager/enums/enum_login_error_type.dart';
import 'package:MShopManager/features/signin/provider/signin_view_model.dart';
import 'package:MShopManager/model/service/login_response.dart';
import 'package:MShopManager/widget/dialog/license/license_view.dart';
import 'package:MShopManager/model/license_info.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/dialog/upgrade_account/upgrade_account_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_edittext.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/cupertino/page_scaffold.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:provider/provider.dart';
import 'package:MShopManager/features/signin/event/event_sign_in_state.dart';

class SignInPage extends StatefulWidget {
  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return KeyboardDismissOnTap(
      child: _SignInContentPage(),
    );
  }
}

class _SignInContentPage
    extends MSBaseCupertinoViewModelBuilder<SignInViewModel> {
  _SignInContentPage();

  @override
  ObstructingPreferredSizeWidget onBuildAppBar(
      BuildContext context, SignInViewModel model) {
    return null;
  }

  @override
  bool resizeToAvoidBottomInset() {
    return false;
  }

  @override
  Brightness provideBrightnessColor(BuildContext context) {
    return Brightness.dark;
  }

  @override
  Widget onBuildBody(
      BuildContext context, SignInViewModel model, Widget child) {
    return Stack(
      children: [
        _BackgroundView(),
        _LoginView()
        // Positioned(top: 50, right: 0, left: 0, child: _LogoView()),
        // Positioned(
        //   bottom: 0,
        //   left: 0,
        //   right: 0,
        //   child: _LoginView(),
        // )
      ],
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  SignInViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<SignInViewModel>();
  }

  @override
  void onViewModelCreated(SignInViewModel model) {}
}

class _BackgroundView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.primaryColor,
    );
  }
}

class _LogoView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(
          AppResources.icLogoWithText,
          fit: BoxFit.fill,
          width: 190,
        ),
        kVerticalSpaceSmallBox,
        Text(
          "Dành cho Quản lý",
          style: Theme.of(context)
              .textTheme
              .bodyText1
              .copyWith(color: AppColor.white),
        ),
      ],
    );
  }
}

class _LoginView extends StatefulWidget {
  @override
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<_LoginView>
    with
        MSEventValidateListenerMixin<_LoginView, EventSignInState,
            SignInViewModel> {
  StreamSubscription<bool> _keyboardSubscription;

  bool _isLogoAppVisible = true;
  bool _isKeyboardVisible;
  double _heightKeyboard;
  double _paddingKeyboard;

  @override
  void initState() {
    super.initState();

    _isKeyboardVisible = KeyboardVisibility.isVisible;

    WidgetsBinding.instance.addPostFrameCallback((Duration _) {
      //_paddingKeyboard = 344 + ScreenUtils.bottomSafeAreaHeight;
      _keyboardSubscription =
          KeyboardVisibility.onChange.listen((bool visible) {
        print("$_isKeyboardVisible");

        if (mounted) {
          setState(() {
            _isKeyboardVisible = visible;
          });
        }
      });
    });
  }

  @override
  void dispose() {
    _keyboardSubscription?.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _heightKeyboard = WidgetsBinding.instance.window.viewInsets.bottom;
    //double paddingKeyboard = (_heightKeyboard - (kVerticalSpaceMedium + 88 + 44 + 20 + 88 + 20 + 20));
    SignInViewModel model = context.watch<SignInViewModel>();

    return SafeArea(
      bottom: false,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        mainAxisSize: MainAxisSize.max,
        children: [
          Visibility(
              visible: !_isKeyboardVisible,
              child: Expanded(child: _LogoView())),
          Container(
              padding: const EdgeInsets.only(
                  top: 31, left: 46, right: 46, bottom: 20),
              decoration: const BoxDecoration(
                  color: AppColor.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Đăng nhập",
                    style: Theme.of(context).textTheme.headline1,
                  ),
                  kVerticalSpaceHugeBox,
                  StreamBuilder<bool>(
                      stream: model.branchCodeStateStream,
                      initialData: true,
                      builder: (context, snapshot) {
                        return MSEditText(
                          controller: model.branchCodeController,
                          focusNode: model.branchCodeFocus,
                          prefixIconAsset: AppResources.icBranch,
                          textInputAction: TextInputAction.next,
                          isShowClearTextButton: true,
                          hintText: "Mã cửa hàng",
                          isValidated: snapshot.data,
                          onChanged: (value) {
                            model.branchCodeSink.add(value);
                          },
                          onSubmitted: (value) {
                            FocusScope.of(context)
                                .requestFocus(model.userNameFocus);
                          },
                        );
                      }),
                  kVerticalSpaceMediumBox,
                  StreamBuilder<bool>(
                      stream: model.userNameStateStream,
                      initialData: true,
                      builder: (context, snapshot) {
                        return MSEditText(
                          isValidated: snapshot.data,
                          controller: model.userNameController,
                          focusNode: model.userNameFocus,
                          hintText: "Tên đăng nhập",
                          isShowClearTextButton: true,
                          textInputAction: TextInputAction.next,
                          prefixIconAsset: AppResources.icUserName,
                          onChanged: (value) {
                            model.userNameSink.add(value);
                          },
                          onSubmitted: (value) {
                            FocusScope.of(context)
                                .requestFocus(model.passwordFocus);
                          },
                        );
                      }),
                  kVerticalSpaceMediumBox,
                  StreamBuilder(
                    stream: model.passwordStateStream,
                    initialData: true,
                    builder: (context, snapShot) {
                      return MSEditText(
                        isValidated: snapShot.data,
                        controller: model.passwordController,
                        focusNode: model.passwordFocus,
                        hintText: "Mật khẩu",
                        prefixIconAsset: AppResources.icPassword,
                        isPassword: true,
                        textInputAction: TextInputAction.done,
                        onChanged: (value) {
                          model.passwordSink.add(value);
                        },
                        onSubmitted: (value) {
                          FocusScope.of(context).unfocus();
                        },
                      );
                    },
                  ),
                  kVerticalSpaceMediumBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context, rootNavigator: true).pushNamed(
                              AppRouterName.recovery_password.value());
                        },
                        child: Text(
                          "Quên mật khẩu?",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1
                              .copyWith(color: AppColor.indigo900),
                        ),
                      )
                    ],
                  ),
                  kVerticalSpaceMediumBox,
                  ExpandedView.horizontal(
                    child: StreamBuilder<bool>(
                        initialData: false,
                        stream: model.buttonStream,
                        builder: (context, snapshot) {
                          return MSButton(
                              onPressed: snapshot.data ? processSignIn : null,
                              label: "Đăng nhập");
                        }),
                  ),
                  // SizedBox(
                  //   height: _isKeyboardVisible ? 140 : kVerticalSpaceMedium,
                  // ),
                  ExpandedSection(
                    expand: _isKeyboardVisible,
                    child: SizedBox(
                      height: 144,
                    ),
                    listener: (animation) {
                      print(animation);
                      if (animation == AnimationStatus.forward) {
                        setState(() {
                          _isLogoAppVisible = !_isKeyboardVisible;
                        });
                      } else if (animation == AnimationStatus.dismissed) {
                        setState(() {
                          _isLogoAppVisible = !_isKeyboardVisible;
                        });
                      }
                    },
                  ),
                  kVerticalSpaceMediumBox,
                  ExpandedView.horizontal(
                    child: MSButton(
                        onPressed: () {
                          Navigator.of(context)
                              .pushReplacementNamed(AppRouterName.main.value());
                        },
                        buttonColor: AppColor.white,
                        textColor: AppColor.black,
                        imageAsset: AppResources.icFaceid,
                        imageAssetColor: Colors.indigo,
                        borderColor: AppColor.indigo900,
                        label: "Mở khoá bằng FaceID"),
                  ),
                  kVerticalSpaceHugeBox,
                  ExpandedView.horizontal(
                    child: Text(
                      "Chính sách bảo mật",
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.caption,
                    ),
                  ),
                ],
              )),
        ],
      ),
    );
  }

  ///
  /// Thực hiện khi press vào nút Đăng nhập
  ///
  void processSignIn() {
    FocusScope.of(context).unfocus();
    context.read<SignInViewModel>().signIn();
  }

  ///
  /// Hiển thị dialog license
  ///
  Future<T> showDialog<T>(Widget dialog) async {
    return showGeneralDialog<T>(
      context: context,
      useRootNavigator: false,
      barrierDismissible: false,
      //barrierColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.5),
      //transitionDuration: Duration(milliseconds: 400),
      pageBuilder: (_context, anim1, anim2) {
        return dialog;
      },
    );
  }

  @override
  get validateEvent => (BuildContext context, EventSignInState event) {
        event?.when(loading: () {
          EasyLoading.show(
            status: 'Đang đăng nhập',
          );
        }, dismissLoading: () {
          EasyLoading.dismiss();
        }, signInError: (errorType) {
          EasyLoading.dismiss();

          switch (errorType) {
            case ESignInErrorType.INVALID_GRANT:

              /// Toast
              /// Username or password is incorrect. Please check again.
              showToast(
                  "Tên đăng nhập hoặc mật khẩu không chính xác. Vui lòng kiểm tra lại.");
              break;
            case ESignInErrorType.INVALID_CLIENT_ID:

              /// Toast
              /// Username or password is incorrect. Please check again.
              showToast(
                  "Tên đăng nhập hoặc mật khẩu không chính xác. Vui lòng kiểm tra lại.");
              break;
            case ESignInErrorType.ACCESS_DENIED:

              /// Toast
              ///  You are not authorized to access this app. Please check again.
              showToast(
                  "Bạn không có quyền truy cập ứng dụng này. Vui lòng kiểm tra lại.");
              break;
            case ESignInErrorType.INVALID_COMPANY_CODE:

              /// Toast
              /// Shop ID is incorrect. Please check again.
              showToast("Mã cửa hàng không đúng. Vui lòng kiểm tra lại.");
              break;
          }
        }, unknowException: () {
          showToast("Có lỗi xảy ra, vui lòng thử lại.");

          EasyLoading.dismiss();
        }, accessDenined: () {
          showToast(
              "Bạn không có quyền truy cập ứng dụng này. Vui lòng kiểm tra lại.");

          EasyLoading.dismiss();
        }, license: (String branchCode, String subDomain,
            LoginResponse loginResponse, bool isAdmin) {
          EasyLoading.dismiss();

          showDialog(LicenseView(
            licenseInfo: loginResponse.licenseInfo,
            isAdmin: isAdmin,
            onNegativePressed: (type) {
              if (type == ELicenseNegativeButton.close ||
                  type == ELicenseNegativeButton.skip) {
                EasyLoading.show(
                  status: 'Đang đăng nhập',
                );
                context.read<SignInViewModel>().continueAfterCheckingLicense(
                    branchCode, subDomain, loginResponse);
              }
            },
          ));
        }, ocmLicense: () {
          showDialog(UpgradeAccountView(
            licenseViewType: ELicenseViewType.ocm_license,
          ));
        }, branchOutOfQuotaChainStore: (double stepValue, int activeBranch,
            int numberBranchRegister, bool isShowUpgradeButton) {
          EasyLoading.dismiss();

          showDialog(UpgradeAccountView(
              licenseViewType: ELicenseViewType.branch_out_of_quota_chain_store,
              activeBranch: activeBranch,
              numberBranchRegister: numberBranchRegister,
              progressValue: stepValue));
        }, virtualBranchTrailLicense:
            (String productPackageName, bool isShowUpgradeButton) {
          EasyLoading.dismiss();

          showDialog(UpgradeAccountView(
              licenseViewType: ELicenseViewType.virtual_branch_trail_license,
              productPackageName: productPackageName,
              isShowUpgradeButton: isShowUpgradeButton));
        });
      };
}
