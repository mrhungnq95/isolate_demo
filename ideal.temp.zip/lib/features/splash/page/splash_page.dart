import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/widget/dialog/license/license_view.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/dialog/upgrade_account/upgrade_account_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Future.delayed(Duration(seconds: 2), () async {
        return true;

        // return await showGeneralDialog(
        //   context: context,
        //   useRootNavigator: false,
        //   barrierDismissible: false,
        //   //barrierColor: Colors.transparent,
        //   barrierColor: Colors.black.withOpacity(0.5),
        //   //transitionDuration: Duration(milliseconds: 400),

        //   pageBuilder: (_context, anim1, anim2) {
        //     return UpgradeAccountView();
        //   },
        // );
      }).then((value) async {
        print(value);
        if (value) {
          if (UserCredential.currentSession.isAuth) {
            await NavigationHelper.shared
                .navigateReplacementNamed(routeName: AppRouterName.main);
          } else {
            await NavigationHelper.shared
                .navigateReplacementNamed(routeName: AppRouterName.signin);
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          Image.asset(
            AppResources.bgSplash,
            fit: BoxFit.cover,
            width: ScreenUtils.width,
            height: ScreenUtils.height,
          ),
          Align(
              alignment: Alignment.center,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 60),
                child: Image.asset(
                  AppResources.icLogoWithText,
                  fit: BoxFit.fill,
                ),
              )),
          Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  "Copyright © 2017 MISA JSC",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1
                      .copyWith(color: Colors.white),
                ),
              )),
        ],
      ),
    );
  }
}
