import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/mixin/ms_vm_event_validate_mixin.dart';
import 'package:MShopManager/enums/enum_edit_mode.dart';
import 'package:MShopManager/features/customer/args/add_customer_args.dart';
import 'package:MShopManager/features/customer/args/customer_detail_args.dart';
import 'package:MShopManager/features/customer/event/event_add_customer_validate_result.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/customer/provider/customer_detail_view_model.dart';
import 'package:MShopManager/model/customer/item_user_info_property.dart';
import 'package:MShopManager/utils/app_utils.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:stacked/stacked.dart';

class CustomerDetailPage extends StatefulWidget {
  @override
  _CustomerDetailPageState createState() => _CustomerDetailPageState();
}

class _CustomerDetailPageState extends State<CustomerDetailPage> {
  @override
  Widget build(BuildContext context) {
    CustomerDetailArgs customerDetailArgs =
        ModalRoute.of(context).settings.arguments;
    if (customerDetailArgs == null) {
      return kSpaceShrinkBox;
    }
    return MSBaseCupertinoWidgetBuilderV2<CustomerDetailViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<CustomerDetailViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {
        model.fetchDataByCustomerId(customerDetailArgs.customerId);
      },
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return _PageContentView(customerDetailArgs: customerDetailArgs);
      },
    );
  }
}

class _PageContentView extends StatefulWidget {
  final CustomerDetailArgs customerDetailArgs;

  const _PageContentView({Key key, this.customerDetailArgs}) : super(key: key);

  @override
  _PageContentViewState createState() => _PageContentViewState();
}

class _PageContentViewState extends State<_PageContentView>
    with
        MSEventValidateListenerMixin<_PageContentView,
            EventAddCustomerValidateResult, CustomerDetailViewModel> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        MSScrollContainerAnimated(
          isPrimary: false,
          titleExpanded: "Chi tiết",
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          body: _ContentView(
            customerDetailArgs: widget.customerDetailArgs,
          ),
        ),
        _ButtonBottom()
      ],
    );
  }

  @override
  get validateEvent => handleValidateEvent;

  ///
  /// Xử lý event
  /// [context] context
  /// [event] sự kiện khi obs view model
  ///
  void handleValidateEvent(
      BuildContext context, EventAddCustomerValidateResult event) {
    event?.maybeWhen(orElse: () {
      print("Không làm gì.");
      EasyLoading.dismiss();
    }, dismissLoading: () {
      EasyLoading.dismiss();
    }, showLoading: () {
      EasyLoading.show(status: 'Đang xử lý');
    }, saveCustomerSuccess: (editMode) {
      EasyLoading.dismiss();
      showToast('Xoá khách hàng thành công!');
      NavigationHelper.shared.pop(data: true);
    }, deleteCustomerFailed: (error) {
      EasyLoading.dismiss();
      showToast('Có lỗi xảy ra, vui lòng thử lại!');
    }, unknowError: () {
      EasyLoading.dismiss();
      showToast('Có lỗi xảy ra, vui lòng thử lại!');
    }, objectUsed: (Customer customer) {
      EasyLoading.dismiss();
      showConfirmDialog(
          context: context,
          negativeTextButtonTitle: "Đồng ý",
          positiveTextButtonTitle: "Tìm hiểu thêm",
          content:
              'Không xoá được khách hàng <b>${customer.customerName ?? ""}</b> do khách hàng đã có phát sinh.',
          onAcceptPressed: () {
            NavigationHelper.shared.pop();
          },
          onCancelPressed: () => NavigationHelper.shared.pop());
    });
  }
}

class _ContentView extends ViewModelWidget<CustomerDetailViewModel> {
  final CustomerDetailArgs customerDetailArgs;

  const _ContentView({
    Key key,
    @required this.customerDetailArgs,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, CustomerDetailViewModel model) {
    return model.obs(
        widget: (state) => ListView(
              padding: const EdgeInsets.only(
                  top: kVerticalSpaceLarge,
                  left: kVerticalSpaceLarge,
                  right: kVerticalSpaceLarge,
                  bottom: kNavPaddingContent),
              children: [
                _CustomerHeaderView(
                  avatarColor: customerDetailArgs.avatarColor,
                  firstCharName: customerDetailArgs.firstNameChar,
                  customerName: state.customerName,
                  totalInvoiceQuantityValue: state.totalInvoiceQuantityValue,
                  totalInvoiceAmountValue: state.totalInvoiceAmountValue,
                ),
                kVerticalSpaceMediumBox,
                _FeatureItemView(
                    imageAsset: AppResources.icInvoice,
                    title: "Lịch sử mua hàng",
                    onPressed: () {
                      final customerId = customerDetailArgs?.customerId;
                      Navigator.of(context, rootNavigator: true).pushNamed(
                          AppRouterName.customer_transaction_history.value(),
                          arguments: customerId);
                    }),
                kVerticalSpaceMediumBox,
                _FeatureItemView(
                    imageAsset: AppResources.icPinkCash,
                    title: "Công nợ",
                    onPressed: () {}),
                kVerticalSpaceLargeBox,
                _CustomerInfoView(
                  itemUserInfoPropList: state.itemUserInfoPropList,
                )
              ],
            ));
  }
}

class _ButtonBottom extends StatelessWidget {
  ///
  /// Hiển thị dialog xác nhận xoá khách hàng
  /// [context]
  /// [customerName]  tên khách hàng
  ///
  void showConfirmDeleteCustomer(BuildContext context, String customerName) {
    showConfirmDialog(
        context: context,
        content:
            'Bạn có chắc muốn xoá khách hàng <b>${customerName ?? ""}</b> không?',
        onAcceptPressed: () {
          context.read<CustomerDetailViewModel>().deleteCustomer();
          NavigationHelper.shared.pop();
        },
        onCancelPressed: () => NavigationHelper.shared.pop());
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 25,
      left: 0,
      right: 0,
      child: Center(
        child: Container(
          width: ScreenUtils.width * 0.65,
          height: 50,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(25),
              color: AppColor.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 7,
                    offset: Offset(0, 3))
              ]),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              MSCircleButton(
                color: null,
                size: 40,
                onTap: () {
                  final model = context.read<CustomerDetailViewModel>();
                  showConfirmDeleteCustomer(context, model.value?.customerName);
                },
                imageAsset: AppResources.icTrash,
                imageAssetColor: null,
              ),
              MSCircleButton(
                color: null,
                size: 40,
                onTap: () {},
                imageAsset: AppResources.icMail,
                imageAssetColor: null,
              ),
              MSCircleButton(
                color: null,
                size: 40,
                onTap: () {},
                imageAsset: AppResources.icPhone,
                imageAssetColor: null,
              ),
              MSCircleButton(
                color: null,
                size: 40,
                onTap: () async {
                  final model = context.read<CustomerDetailViewModel>();
                  final customer = model.customer;
                  bool isReloadData = await NavigationHelper.shared.navigateTo(
                      routeName: AppRouterName.add_customer,
                      argument: AddCustomerArgs(
                          editMode: EditMode.edit, customer: customer));

                  if (isReloadData == true && customer != null) {
                    model.fetchDataByCustomerId(customer.customerID);
                  }
                },
                imageAsset: AppResources.icEdit,
                imageAssetColor: null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

///
/// Header của KH
///
class _CustomerHeaderView extends StatelessWidget {
  final Color avatarColor;
  final String firstCharName;
  final String customerName;
  final String totalInvoiceQuantityValue;
  final String totalInvoiceAmountValue;

  const _CustomerHeaderView(
      {Key key,
      @required this.avatarColor,
      @required this.firstCharName,
      @required this.customerName,
      @required this.totalInvoiceQuantityValue,
      @required this.totalInvoiceAmountValue})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppColor.teal.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: avatarColor ?? AppColor.cyan,
            child: Text(
              firstCharName ?? "",
              style: Theme.of(context)
                  .textTheme
                  .bodyText2
                  .copyWith(color: AppColor.white, fontWeight: FontWeight.w700),
            ),
          ),
          kHorizontalSpaceMediumBox,
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  customerName ?? "",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1
                      .copyWith(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                kVerticalSpaceOverSmallBox,
                Divider(
                  height: 1,
                  thickness: 1,
                  color: AppColor.grey350.withOpacity(0.4),
                ),
                kVerticalSpaceOverSmallBox,
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Hóa đơn",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(
                                    fontSize: 14,
                                    color: AppColor.textCaptionColor),
                          ),
                          Text(
                            totalInvoiceQuantityValue ?? "10",
                            maxLines: 1,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(
                                    fontSize: 16,
                                    color: AppColor.textCaptionColor,
                                    fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ),
                    kHorizontalSpaceMediumBox,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Tổng doanh thu",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(
                                    fontSize: 14,
                                    color: AppColor.textCaptionColor),
                          ),
                          Text(
                            totalInvoiceAmountValue ?? "0",
                            maxLines: 1,
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(
                                    fontSize: 16,
                                    color: AppColor.teal,
                                    fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    )
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class _FeatureItemView extends StatelessWidget {
  final String imageAsset;
  final String title;
  final VoidCallback onPressed;

  const _FeatureItemView(
      {Key key,
      @required this.imageAsset,
      @required this.title,
      this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      colorBackground: AppColor.grey200,
      borderRadius: 10,
      onPressed: onPressed,
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.all(kVerticalSpaceMedium),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              imageAsset,
              width: 20,
              height: 20,
            ),
            kHorizontalSpaceSmallBox,
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.bodyText1,
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: AppColor.grey600,
            )
          ],
        ),
      ),
    );
  }
}

class _CustomerInfoView extends StatelessWidget {
  final List<ItemUserInfoProperty> itemUserInfoPropList;

  const _CustomerInfoView({
    Key key,
    @required this.itemUserInfoPropList,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<CustomerDetailViewModel>(
      builder: (context, vm, child) {
        return Container(
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.grey300),
              color: AppColor.grey200,
              borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.all(kVerticalSpaceMedium),
          child: ListView.builder(
            padding: EdgeInsets.zero,
            itemBuilder: (context, index) {
              final prop = itemUserInfoPropList[index];
              return _CustomerInfoPropertyView(
                title: prop.title,
                value: prop.value,
              );
            },
            itemCount: itemUserInfoPropList.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
          ),
        );
      },
    );
  }
}

class _CustomerInfoPropertyView extends StatelessWidget {
  final String title;
  final String value;

  const _CustomerInfoPropertyView(
      {Key key, @required this.title, @required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kVerticalSpaceSmall),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
              child: Text(
            title,
            style: Theme.of(context)
                .textTheme
                .bodyText2
                .copyWith(fontWeight: FontWeight.bold),
          )),
          Expanded(
              child: Text(
            value,
            maxLines: 3,
            textAlign: TextAlign.end,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.bodyText1.copyWith(fontSize: 16),
          ))
        ],
      ),
    );
  }
}
