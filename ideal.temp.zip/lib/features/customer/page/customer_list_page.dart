import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/search/ms_base_searchable_widget.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_edit_mode.dart';
import 'package:MShopManager/features/customer/args/add_customer_args.dart';
import 'package:MShopManager/features/customer/args/customer_detail_args.dart';
import 'package:MShopManager/features/customer/provider/customer_list_view_model.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:MShopManager/widget/total_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';

class CustomerListPage extends StatefulWidget {
  @override
  _CustomerPageState createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerListPage> {
  MSSearchableController _searchController = MSSearchableController();

  @override
  void dispose() {
    _searchController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<CustomerListViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<CustomerListViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {
        model.fetchData();
      },
      resizeToAvoidBottomInset: false,
      backgroundColor: AppColor.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSBaseSearchableWidget<Customer>(
            controller: _searchController,
            searchHint: "Nhập tên, mã khách hàng...",
            searchTask: (text) {
              return model?.searchCustomer(searchText: text);
            },
            itemResultBuilder: (int index, Customer customer) {
              return _CustomerItemView(
                customer: customer,
              );
            },
            child: MSScrollContainerAnimated(
              titleExpanded: "Khách hàng",
              //expandedHeight: 55,
              actions: [
                MSCircleButton(
                    elevation: 0,
                    color: Colors.white.withOpacity(0.1),
                    size: 40,
                    imageAsset: AppResources.icSearch,
                    imageAssetColor: null,
                    onTap: () async {
                      _searchController?.openSearch();
                    }),
                MSCircleButton(
                    elevation: 0,
                    color: Colors.white.withOpacity(0.1),
                    size: 40,
                    imageAsset: AppResources.icFilledFilter,
                    imageAssetColor: null,
                    onTap: () async {
                      final result = await NavigationHelper.shared
                          .navigateTo(routeName: AppRouterName.customer_filter);

                      if (result == true) {
                        /// Fetch lại data
                        model.fetchData(isRefreshFilterSetting: true);
                      }
                    })
              ],
              onLeadingTap: () {
                NavigationHelper.shared.pop();
              },
              body: _CustomerListView(),
              floatingButtonBuilder: (context) {
                return FloatingActionButton(
                  onPressed: () {
                    NavigationHelper.shared.navigateTo(
                        routeName: AppRouterName.add_customer,
                        argument: AddCustomerArgs(editMode: EditMode.add));
                  },
                  child: Icon(Icons.add),
                );
              },
            ));
      },
    );
  }
}

class _CustomerListView extends ViewModelWidget<CustomerListViewModel> {
  @override
  Widget build(BuildContext context, CustomerListViewModel viewModel) {
    return viewModel.obs(
      widget: (state) => Column(
        children: [
          _BottomAppBar(),
          Expanded(
            child: SmartRefresher(
              controller: viewModel.refreshController,
              enablePullDown: true,
              enablePullUp: true,
              onRefresh: () {
                viewModel.fetchData();
              },
              onLoading: () {
                viewModel.fetchData(isLoadMore: true);
              },
              child: ListView.builder(
                padding: EdgeInsets.only(
                  top: kVerticalSpaceLarge,
                  left: kHorizontalSpaceLarge,
                  right: kHorizontalSpaceLarge,
                ),
                itemBuilder: ((BuildContext context, int index) {
                  final customer = state[index];
                  return _CustomerItemView(
                    customer: customer,
                  );
                }),
                itemCount: state.length,
              ),
            ),
          )
        ],
      ),
    );
  }
}

class _BottomAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // _SearchView(),
        //kVerticalSpaceMediumBox,
        Container(
          height: 48,
          padding:
              const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
          child: _TotalView(),
        ),
        Divider(
          height: 4,
          thickness: 4,
          color: AppColor.grey400,
        )
      ],
    );
  }
}

class _TotalView extends ViewModelWidget<CustomerListViewModel> {
  @override
  Widget build(BuildContext context, CustomerListViewModel viewModel) {
    return TotalView(
      totalQuantity: viewModel.quantityVal,
      totalAmount: viewModel.totalAmountVal,
    );
  }
}

class _CustomerItemView extends StatelessWidget {
  final Customer customer;

  const _CustomerItemView({Key key, this.customer}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _CustomerView(
      amount: NumberFormatHelper.shared.formatMoney(customer.totalAmount),
      phoneNumber: customer.tel,
      customerName: customer.customerName,
      firstNameChar: customer.avatarName,
      avatarColor: customer.avatarColor,
      onPressed: () async {
        final isReloadData = await NavigationHelper.shared.navigateTo(
            routeName: AppRouterName.customer_detail,
            argument: CustomerDetailArgs(
                customerId: customer.customerID,
                avatarColor: customer.avatarColor,
                firstNameChar: customer.avatarName));

        if (isReloadData == true) {
          context.read<CustomerListViewModel>().fetchData();
        }
      },
    );
  }
}

class _CustomerView extends StatelessWidget {
  final String firstNameChar;
  final String customerName;
  final String phoneNumber;
  final String amount;
  final Color avatarColor;

  final VoidCallback onPressed;

  const _CustomerView(
      {Key key,
      @required this.onPressed,
      this.firstNameChar,
      this.customerName,
      this.phoneNumber,
      this.amount,
      this.avatarColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
      child: InkWellView(
        onPressed: onPressed,
        borderRadius: 10,
        colorBackground: AppColor.grey50,
        child: Container(
          padding: const EdgeInsets.only(
              left: kVerticalSpaceLarge,
              right: kVerticalSpaceLarge,
              top: kVerticalSpaceLarge,
              bottom: kVerticalSpaceLarge),
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 23,
                backgroundColor: avatarColor ?? AppColor.cyan,
                child: Text(
                  firstNameChar ?? "L",
                  style: Theme.of(context).textTheme.bodyText2.copyWith(
                      color: AppColor.white, fontWeight: FontWeight.w700),
                ),
              ),
              kHorizontalSpaceMediumBox,
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      customerName ?? "Vũ Ngọc Long",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1
                          .copyWith(fontSize: 16),
                    ),
                    kVerticalSpaceTinyBox,
                    Text(
                      phoneNumber ?? "0989.780.374",
                      maxLines: 1,
                      style: Theme.of(context).textTheme.bodyText1.copyWith(
                          fontSize: 14, color: AppColor.textDisableColor),
                    )
                  ],
                ),
              ),
              Text(amount ?? "0",
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1
                      .copyWith(fontSize: 16, color: AppColor.indigo900)),
            ],
          ),
        ),
      ),
    );
  }
}
