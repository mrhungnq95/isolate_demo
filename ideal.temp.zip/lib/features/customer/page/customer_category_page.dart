import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/item/item_description_view_selectable.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/customer/provider/customer_category_view_model.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:stacked/stacked.dart';

class CustomerCategoryPage extends StatefulWidget {
  @override
  _CustomerCategoryPageState createState() => _CustomerCategoryPageState();
}

class _CustomerCategoryPageState extends State<CustomerCategoryPage> {
  @override
  Widget build(BuildContext context) {
    final customerCategoryId = ModalRoute.of(context).settings.arguments;

    return MSBaseCupertinoWidgetBuilderV2<CustomerCategoryViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<CustomerCategoryViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {
        model.fetchCustomerCategoryList();
      },
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          isPrimary: false,
          titleExpanded: "Nhóm Khách hàng",
          actions: [
            MSCircleButton(
                elevation: 5,
                color: null,
                size: 40,
                imageAsset: AppResources.icSearch,
                imageAssetColor: AppColor.indigo900,
                onTap: () async {}),
          ],
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          body: _ContentView(
            customerCategoryId: customerCategoryId,
          ),
        );
      },
    );
  }
}

class _BottomAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          kVerticalSpaceMediumBox,
          _SearchView(),
          kVerticalSpaceMediumBox,
        ],
      ),
    );
  }
}

class _SearchView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = context.watch<CustomerCategoryViewModel>();
    return SearchBox(
      controller: model.searchTextController,
      height: 40,
      textInputAction: TextInputAction.done,
      placeholder: 'Nhập tên, mã nhóm khách hàng',
      onSearch: (searchText) {
        model?.searchSubject?.add(searchText ?? "");
      },
    );
  }
}

class _ContentView extends ViewModelWidget<CustomerCategoryViewModel> {
  final String customerCategoryId;

  _ContentView({@required this.customerCategoryId});

  @override
  Widget build(BuildContext context, CustomerCategoryViewModel viewModel) {
    return viewModel.obs(
        widget: (state) => ListView.builder(
              padding: const EdgeInsets.symmetric(
                  vertical: kVerticalSpaceLarge,
                  horizontal: kHorizontalSpaceLarge),
              itemBuilder: ((BuildContext context, int index) {
                final customer = state[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
                  child: ItemDescriptionViewSelectable(
                      onPressed: () {
                        NavigationHelper.shared.pop(data: customer);
                      },
                      isChecked:
                          customerCategoryId == customer.customerCategoryID,
                      title: customer.customerCategoryName,
                      description: customer.customerCategoryCode),
                );
              }),
              itemCount: state.length,
            ));
  }
}
