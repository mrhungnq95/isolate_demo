import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_follow_status.dart';
import 'package:MShopManager/enums/enum_sort_customer.dart';
import 'package:MShopManager/features/customer/provider/customer_filter_view_model.dart';
import 'package:MShopManager/widget/many_option_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class CustomerFilterPage extends StatefulWidget {
  @override
  _CustomerFilterPageState createState() => _CustomerFilterPageState();
}

class _CustomerFilterPageState extends State<CustomerFilterPage> {
  @override
  Widget build(BuildContext rootContext) {
    return MSBaseCupertinoWidgetBuilderV2<CustomerFilterViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<CustomerFilterViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {},
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          titleExpanded: "Bộ lọc",
          isPrimary: false,
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          body: _ContentFilterView(),
          bottomContainer: ExpandedView.horizontal(
              child: Padding(
            padding: EdgeInsets.only(
                left: kHorizontalSpaceLarge,
                right: kHorizontalSpaceLarge,
                top: kHorizontalSpaceLarge,
                bottom: kVerticalSpaceWithSafeArea),
            child: MSButton(
                onPressed: () {
                  model.applyFilter();
                  NavigationHelper.shared.maybePop(obj: true);
                },
                label: "Lọc"),
          )),
        );
      },
    );
  }
}

class _ContentFilterView extends StatelessWidget {
  const _ContentFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Column(
        children: [
          _SortFilterView(),
          kVerticalSpaceLargeBox,
          _FollowFilterView()
        ],
      ),
    );
  }
}

class _SortFilterView extends ViewModelWidget<CustomerFilterViewModel> {
  const _SortFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, CustomerFilterViewModel model) {
    return ManyOptionView<ESortCustomerStatus>(
      title: 'Sắp xếp',
      groupValue: model.eSortStatus,
      itemCount: model.sortFilterItemList.length,
      valueBuilder: (index) => model.sortFilterItemList[index],
      titleBuilder: (value) => Text(
        value.getTitle(),
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: (value) {
        model.eSortStatus = value;
      },
    );
  }
}

class _FollowFilterView extends ViewModelWidget<CustomerFilterViewModel> {
  @override
  Widget build(BuildContext context, CustomerFilterViewModel model) {
    print("_SortFilterView build");
    return ManyOptionView<EFollowStatus>(
      title: 'Trạng thái',
      groupValue: model.eFollowStatus,
      itemCount: model.followFilterItemList.length,
      valueBuilder: (index) => model.followFilterItemList[index],
      titleBuilder: (value) => Text(
        value.getTitle(),
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: (value) {
        model.eFollowStatus = value;
      },
    );
  }
}
