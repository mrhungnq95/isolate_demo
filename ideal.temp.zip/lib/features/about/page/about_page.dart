import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/features/about/provider/about_view_model.dart';
import 'package:MShopManager/widget/item_setting_view.dart';
import 'package:MShopManager/widget/msview/ms_navigation_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class AboutPage extends StatefulWidget {
  @override
  _AboutPageState createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AboutViewModel>.nonReactive(
        builder: (c, viewmodel, child) {
          return Scaffold(
            appBar: AppBar(
              brightness: Brightness.light,
              elevation: 0,
              backgroundColor: Colors.transparent,
              leading: MSNavigationButton(
                  iconData: Icons.arrow_back_ios_rounded,
                  buttonColor:
                      Colors.transparent, //AppColor.white.withOpacity(0.3),
                  onTap: () {
                    Navigator.of(context).maybePop();
                  }),
            ),
            body: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  kVerticalSpaceLargeBox,
                  Image.asset(
                    AppResources.bgAboutLogo,
                    width: 160,
                    height: 160,
                  ),
                  Image.asset(
                    AppResources.bgEshopLogo,
                    width: 200,
                    height: 35,
                  ),
                  Text(
                    "Dành cho Quản lý",
                    style: Theme.of(context).textTheme.bodyText2.copyWith(
                        color: AppColor.indigo900, fontWeight: FontWeight.bold),
                  ),
                  kVerticalSpaceMediumBox,
                  Text(
                    "Phiên bản hiện tại: 1.0",
                    style: Theme.of(context).textTheme.subtitle1,
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  _ItemContentView(),
                  Expanded(child: Container()),
                  Padding(
                    padding: EdgeInsets.only(bottom: kVerticalSpaceMedium),
                    child: RichText(
                      text: TextSpan(
                          text: "Copyright © 2017 - 2020 ",
                          style: Theme.of(context)
                              .textTheme
                              .caption
                              .copyWith(color: AppColor.grey600),
                          children: [
                            TextSpan(
                                text: "MISA JSC",
                                style: Theme.of(context)
                                    .textTheme
                                    .caption
                                    .copyWith(color: AppColor.indigo900))
                          ]),
                    ),
                  )
                ],
              ),
            ),
          );
        },
        viewModelBuilder: () => AboutViewModel());
  }
}

class _ItemContentView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = Provider.of<AboutViewModel>(context, listen: false);
    return ItemSettingView(
      iconLeadingAsset: AppResources.icHelp,
      iconColorLeading: null,
      title: "Trợ giúp",
      pading: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      onTap: () {
        model.openHelp();
      },
    );
  }
}
