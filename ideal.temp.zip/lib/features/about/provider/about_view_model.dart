import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutViewModel extends MSBaseViewModel {
  
  /// 
  /// Mở link help
  /// 
  void openHelp() async {
    /// TODO - VNLONG - Check ngôn ngữ đang sử dụng để show link tương ứng với ngôn ngữ đang chọn
    const url = AppConstant.link_help_vn;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

}