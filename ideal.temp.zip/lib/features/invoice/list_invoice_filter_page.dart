import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/features/invoice/provider/list_invoice_filter_view_model.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';
import 'package:MShopManager/widget/many_option_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/time_period_filter_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tuple/tuple.dart';

///
/// Màn hình bộ lọc ds hóa đơn
///
class ListInvoiceFilterPage extends StatefulWidget {
  @override
  _ListInvoiceFilterPageState createState() => _ListInvoiceFilterPageState();
}

class _ListInvoiceFilterPageState extends State<ListInvoiceFilterPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<ListInvoiceFilterViewModel>(
        viewModelBuilder: (context) =>
            LocatorService.shared.get<ListInvoiceFilterViewModel>(),
        reactive: false,
        onViewModelReady: (model) {},
        backgroundColor: Colors.white,
        brightnessColor: Brightness.light,
        statusBarColor: Colors.transparent,
        builder: (context, model, child) {
          return MSScrollContainerAnimated(
            isPrimary: false,
            titleExpanded: "Bộ lọc",
            onLeadingTap: () {
              NavigationHelper.shared.pop();
            },
            body: SingleChildScrollView(child: _ContentView()),
            bottomContainer: ExpandedView.horizontal(
                child: Padding(
              padding: EdgeInsets.only(
                  left: kHorizontalSpaceLarge,
                  right: kHorizontalSpaceLarge,
                  top: kHorizontalSpaceLarge,
                  bottom: kVerticalSpaceWithSafeArea),
              child: MSButton(
                  onPressed: () {
                    model.applyFilter();
                    NavigationHelper.shared.maybePop(obj: true);
                  },
                  label: "Lọc"),
            )),
          );
        });
  }
}

class _ContentView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Column(
        children: [
          _BranchFilterView(),
          kVerticalSpaceLargeBox,
          _TimePeriodFilterView(),
          kVerticalSpaceLargeBox,
          _ListStateInvoice()
        ],
      ),
    );
  }
}

///
/// View chọn chi nhánh
///
class _BranchFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Selector<ListInvoiceFilterViewModel, BranchFilterController>(
        selector: (_, model) => model.branchFilterController,
        builder: (contextSelector, value, child) {
          return BranchFilterView(
            controller: value,
          );
        });
  }
}

///
/// View chọn thời gian
///
class _TimePeriodFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Selector<
            ListInvoiceFilterViewModel,
            Tuple4<EReportPeriodType, List<EReportPeriodType>, String,
                DateRange>>(
        selector: (_, model) => Tuple4(model.timePeriod, model.listPeriod,
            model.getCustomeTime(), model.getDateRange()),
        builder: (contextSelector, tuple, child) {
          return TimePeriodFilter(
            groupValue: tuple.item1 ?? EReportPeriodType.thisDay,
            items: tuple.item2,
            customTitle: tuple.item3 ?? '',
            onChanged: (value, dateRange) {
              context.read<ListInvoiceFilterViewModel>().updateTimePeriod(
                  timePeriodSelected: value,
                  fromDate: dateRange.startDate,
                  toDate: dateRange.endDate);
            },
            dateRange: tuple.item4,
          );
        });
  }
}

///
/// Ds trạng thái hóa đơn
///
class _ListStateInvoice extends StatelessWidget {
  const _ListStateInvoice({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Selector<ListInvoiceFilterViewModel,
            Tuple2<List<EPaymentStatus>, EPaymentStatus>>(
        builder: (context, tuple, child) {
          return ManyOptionView<EPaymentStatus>(
            title: 'Trạng thái',
            groupValue: tuple.item2,
            itemCount: tuple.item1?.length ?? 0,
            valueBuilder: (index) => tuple.item1[index],
            titleBuilder: (value) => Text(
              value.getTitle(),
              style: Theme.of(context).textTheme.bodyText1,
            ),
            onChanged: (value) {
              context
                  .read<ListInvoiceFilterViewModel>()
                  .updatePaymentStatus(value);
            },
          );
        },
        selector: (buildContext, model) =>
            Tuple2(model.listStatus, model.paymentStatus));
  }
}
