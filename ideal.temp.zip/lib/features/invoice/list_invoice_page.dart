import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/transaction_history/bottomsheet/detail_invoice_bottom_sheet_view.dart';
import 'package:MShopManager/model/base/sumary_data_info.dart';
import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/widget/item_loading_view_binder.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/search_box.dart';
import 'package:MShopManager/widget/total_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';
import 'view/item_invoice_view.dart';
import 'provider/list_invoice_view_model.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';

/// Danh sách hoá đơn
class ListInvoiceScreen extends StatefulWidget {
  @override
  _ListInvoiceScreenState createState() => _ListInvoiceScreenState();
}

class _ListInvoiceScreenState extends State<ListInvoiceScreen> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<ListInvoiceViewModel>(
        viewModelBuilder: (context) =>
            LocatorService.shared.get<ListInvoiceViewModel>(),
        reactive: true,
        onViewModelReady: (model) {
          /// TODO - VNLONG Thêm đoạn check quyền hiển thị ds hóa đơn
        },
        backgroundColor: Colors.white,
        brightnessColor: Brightness.light,
        statusBarColor: Colors.transparent,
        builder: (context, model, child) {
          return MSScrollContainerAnimated(
            reactiveNavigationBottomBar: true,
            isAlwaysShowToolbar: true,
            titleExpanded: "Hóa đơn",
            actions: [
              MSCircleButton(
                  elevation: 0,
                  color: Colors.white.withOpacity(0.1),
                  size: 40,
                  imageAsset: AppResources.icFilter,
                  imageAssetColor: AppColor.white,
                  onTap: () async {
                    _onFilter(context);
                  }),
            ],
            body: _ListInvoiceView(),
          );
        });
  }

  /// mở màn hình filter
  void _onFilter(BuildContext context) async {
    final result = await NavigationHelper.shared
        .navigateTo(routeName: AppRouterName.list_invoice_filter);

    if (result != null) {
      context
          .read<ListInvoiceViewModel>()
          .fetchListInvoice(isReloadFilterSetting: true);
    }
  }
}

class _ListInvoiceView extends ViewModelWidget<ListInvoiceViewModel> {
  const _ListInvoiceView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, ListInvoiceViewModel model) {
    return model.obs(widget: (listInvoice) {
      return Column(
        children: [
          _BottomAppBar(),
          Expanded(
            child: SmartRefresher(
              controller: model.refreshController,
              enablePullDown: true,
              enablePullUp: true,
              onRefresh: () {
                model.fetchListInvoice();
              },
              onLoading: () {
                model.fetchListInvoice(isLoadMore: true);
              },
              child: ListView.builder(
                padding: const EdgeInsets.only(bottom: kNavPaddingContent),
                itemBuilder: ((BuildContext context, int index) {
                  var item = model.listInvoice[index];
                  if (item is SAInvoice) {
                    return InvoiceItemView(
                      invoice: item,
                      onTap: () {
                        //Todo: Chuyển sang màn hình Detail
                        showDetailInvoiceSheetView(context, item);
                      },
                    );
                  } else if (item is LoadingObject) {
                    return ItemLoadingViewBinder();
                  }
                  return kSpaceShrinkBox;
                }),
                itemCount: model.listInvoice?.length ?? 0,
              ),
            ),
          ),
        ],
      );
    }, onReloadData: () {
      model.fetchListInvoice();
    });
  }

  ///
  /// Hiển thị bottom sheet hiển thị chi tiết hoá đơn
  ///
  void showDetailInvoiceSheetView(BuildContext context, SAInvoice invoice) {
    showModalBottomSheet(
        elevation: 10,
        context: context,
        backgroundColor: Colors.transparent,
        isScrollControlled: true,
        useRootNavigator: true,
        builder: (c) => DetailInvoiceViewBottomSheet(
              refId: invoice.refID,
            ));
  }
}

class _BottomAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          height: 48,
          padding:
              const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
          child: _TotalView(),
        ),
        Divider(
          height: 4,
          thickness: 4,
          color: AppColor.grey400,
        )
      ],
    );
  }
}

///
/// Tổng
///
class _TotalView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Selector<ListInvoiceViewModel, SummaryNormalData>(
      selector: (_, model) => model.summaryData,
      builder: (context, summaryData, child) {
        return TotalView(
          totalQuantity: (summaryData?.totalQuantity ?? 0).toDouble(),
          totalAmount: summaryData?.totalAmount ?? 0.0,
        );
      },
    );
  }
}
