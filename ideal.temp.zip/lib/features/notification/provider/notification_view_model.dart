import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/model/notification/notification.dart';
import 'package:MShopManager/model/notification/notification_display_item.dart';
import 'package:MShopManager/model/service/get_notification_param.dart';
import 'package:MShopManager/model/service/set_notification_readed_param.dart';
import 'package:MShopManager/utils/logger_utils.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';

class NotificationViewModel extends MSBaseViewModel
    with MSStateMixin<List<NotificationDisplay>> {
  /// Danh sách thông báo hiển thị trên màn hình
  List<NotificationDisplay> _notificationListDisplay = [];
  List<NotificationDisplay> get notificationListDisplay =>
      _notificationListDisplay;

  MobileRepository _mobileRepository =
      LocatorService.shared.get<MobileRepository>();

  RefreshController refreshController =
      RefreshController(initialRefresh: false);

  /// Page loadMore của ds thông báo
  int _pageIndex = 1;

  SetNotificationReadedParam _setReadedNotificationItem;

  ///
  /// Lấy thông báo
  /// [isLoadMore]: Có phải case loadMore hay không?
  ///
  void fetchNotificationList({bool isLoadMore = false}) async {
    if (!isLoadMore) {
      refreshController.resetNoData();
      _notificationListDisplay = [];

      /// Reset lại page nếu k phải loadMore
      _pageIndex = 1;
      changeState(null, status: ViewStatus.loading());
    } else {
      _pageIndex += 1;
    }

    final param = _createGetListNotificationParam();

    /// Request API lấy ds Notification
    final notificationRequest =
        await _mobileRepository.getListNotification(param);
    notificationRequest.when(success: (response) {
      FLogger.shared.log("Get ListNotification Success!");
      if (response.isEmpty) {
        refreshController.loadNoData();
      } else {
        /// Build dữ liệu hiển thị
        buildContentNotification(listNotification: response ?? []);
      }

      /// Cập nhật dữ liệu lên UI
      final viewStatus = _notificationListDisplay.isEmpty
          ? ViewStatus.empty()
          : ViewStatus.success();
      changeState(_notificationListDisplay, status: viewStatus);
    }, commonError: (error) {
      _handleErrorWhenGetListNotification();
    }, apiError: (errorData, error) {
      _handleErrorWhenGetListNotification();
    });
    refreshController.loadComplete();
  }

  /// 
  /// Xử lý lỗi khi lấy danh sách thông báo từ service thất bại
  /// VNLONG - 27/01/2021
  /// 
  void _handleErrorWhenGetListNotification() {
    refreshController.loadNoData();
    changeState(null, status: ViewStatus.error());
  }

  ///
  /// Build nội dung thông báo
  /// [listNotification]: Danh sách thông báo từ service
  /// VNLONG - 20/01/2021
  ///
  void buildContentNotification(
      {@required List<NotificationItem> listNotification}) {
    // Build dữ liệu thông báo cho từng item
    for (var i = 0; i < listNotification.length; i++) {
      listNotification[i].buildContentNotificationByType();
      _notificationListDisplay
          .add(NotificationDisplay(notification: listNotification[i]));
    }
  }

  ///
  /// Khởi tạo Param lấy ds Thông báo
  ///
  ///
  ListNofiticationParam _createGetListNotificationParam() {
    final getListNotificationParam = ListNofiticationParam();
    getListNotificationParam.pageIndex = _pageIndex;
    return getListNotificationParam;
  }

  ///
  /// Set trạng thái đã đọc cho notification
  ///  VNLONG - 30/12/2020
  ///
  void setReadedNotificationItem(
      NotificationDisplay notificationDisplay) async {
    setBusy(true);
    final result =
        await setNotificationReaded(notificationDisplay: notificationDisplay);
    notificationDisplay.isReaded = result;
    setBusy(false);
  }

  ///
  /// Lưu trạng thái đã đọc cho item thông báo
  /// [notificationDisplay]: Item được chọn
  /// VNLONG - 30/12/2020
  /// TODO - VNLONG - Cần sửa lại chỗ này
  ///
  Future<bool> setNotificationReaded(
      {NotificationDisplay notificationDisplay}) async {
    final userCredential = UserCredential.currentSession;

    _setReadedNotificationItem = SetNotificationReadedParam(
        userID: userCredential.loginResponse.userId ?? '',
        notificationDataId: notificationDisplay.notificationDataId);

    // Cập nhật ds thông tin
    final result = await _mobileRepository
        .setNotificationReaded(_setReadedNotificationItem);
    final notificationResult = result.when(success: (response) {
      return response;
    }, commonError: (error) {
      return false;
    }, apiError: (errorData, error) {
      return false;
    });

    return Future.value(notificationResult);
  }
}
