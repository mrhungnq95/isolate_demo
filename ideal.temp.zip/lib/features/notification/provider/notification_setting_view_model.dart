import 'dart:async';

import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_notification_type.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/drop_down_item_object.dart';
import 'package:MShopManager/model/notification/notification_config.dart';
import 'package:MShopManager/model/service/get_notification_config_param.dart';
import 'package:MShopManager/model/service/update_notification_config_param.dart';
import 'package:MShopManager/utils/logger_utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class NotificationSettingViewModel extends MSBaseViewModel {
  /// Ds các item thiết lập
  List<ENotificationType> _itemSettingDataList = [
    ENotificationType.saleInfo,
    ENotificationType.saInvoice,
    ENotificationType.exchange,
    ENotificationType.editSAInvoice,
    ENotificationType.cancelSAInvoice,
    ENotificationType.inStock,
    ENotificationType.importInventory,
    ENotificationType.returnInventory,
    ENotificationType.importStock,
    ENotificationType.outward,
    ENotificationType.sellBeforeDate
  ];
  List<ENotificationType> get itemSettingDataList => _itemSettingDataList;
  ENotificationType a = ENotificationType.saleInfo;

  /// Thông tin thiết lập thông báo
  var _notificationConfig = NotificationConfig();
  NotificationConfig get notificationConfig => _notificationConfig;
  set notificationConfig(NotificationConfig notificationConfig) {
    _notificationConfig = notificationConfig;
  }

  /// Service
  MobileRepository _mobileRepository =
      LocatorService.shared.get<MobileRepository>();

  /// Branch
  DropDownItemObject<Branch> _branchSelected;
  DropDownItemObject<Branch> get branchSelected => _branchSelected;

  set branchSelected(newValue) {
    _branchSelected = newValue;
    notifyListeners();
  }

  List<DropDownItemObject<Branch>> _branchDropDownList = [];
  List<DropDownItemObject<Branch>> get branchDropDownList =>
      _branchDropDownList;

  ///
  /// Chuẩn bị dữ liệu
  ///
  void prepareData() {
    _fetchBranchDropDownList();
    _fetchData();
  }

  ///
  /// Cập nhật các thiết lập thông báo
  ///
  void updateNotification() async {
    setBusy(true);
    final result = await _updateNotificationConfig();
    // _saveNotificationResult.add(result);
    setBusy(false);

    await Fluttertoast.showToast(
        msg: result
            ? "Lưu thiết lập thành công!"
            : "Có lỗi xảy ra. Vui lòng thử lại!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: AppColor.grey700,
        textColor: Colors.white,
        fontSize: 16.0);

    if (result) {
      await navigationService.maybePop();
    }
  }

  ///
  /// Lấy thông tin thiết lập thông báo từ service
  ///
  void _fetchData() async {
    setBusy(true);

    final userCredential = UserCredential.currentSession;
    final getListNotificationConfigParam = GetNotificationConfigParam(
        branchID: AppConstant.UUID_EMPTY,
        userID: userCredential.loginResponse.userId ?? '');

    /// Thông tin thiết lập thông báo
    final notificationRequest = await _mobileRepository
        .getNotificationConfig(getListNotificationConfigParam);
    notificationRequest.when(success: (response) {
      FLogger.shared.log("Get ListNotificationConfig Success!");
      if (response.configContent == null) {
        handleDataErr();
      } else {
        _notificationConfig = response.configContent;
      }
    }, apiError: (errorData, httpException) {
      handleDataErr();
    }, commonError: (error) {
      handleDataErr();
    });

    setBusy(false);
  }

  ///
  /// Không lấy được thông tin config thông báo thì:
  /// - Đóng màn hình thiết lập
  /// - Show thông báo
  /// 
  void handleDataErr() {
    Fluttertoast.showToast(
        msg: "Có lỗi xảy ra. Vui lòng thử lại!",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 1,
        backgroundColor: AppColor.grey700,
        textColor: Colors.white,
        fontSize: 16.0);
    // navigationService.maybePop();
  }

  ///
  /// Set dữ liệu cho ds branch
  ///
  void _fetchBranchDropDownList() async {
    _branchDropDownList.clear();
    final userCredential = UserCredential.currentSession;
    final branchList = userCredential.branchList;
    final outputList =
        branchList.map((e) => DropDownItemObject(e.branchName, e)).toList();

    _branchDropDownList.addAll(outputList);
    _branchSelected = _branchDropDownList[0];
  }

  ///
  /// Service cập nhật lại danh sách thiết lập thông báo
  /// VNLONG - 30/12/2020
  ///
  Future<bool> _updateNotificationConfig() async {
    final userCredential = UserCredential.currentSession;
    final updateNotificationConfigParam = UpdateNotificationConfigParam(
        branchID: AppConstant.UUID_EMPTY,
        userID: userCredential.loginResponse.userId ?? '',
        notificationConfig: _notificationConfig);

    /// Thông tin thiết lập thông báo
    final notificationRequest = await _mobileRepository
        .updateNotificationConfig(updateNotificationConfigParam);
    final result = notificationRequest.when(success: (response) {
      FLogger.shared.log("Save ListNotificationConfig Success!");
      return response.success ?? false;
    }, commonError: (errorData) {
      return false;
    }, apiError: (errorData, httpException) {
      return false;
    });

    return Future.value(result);
  }
}
