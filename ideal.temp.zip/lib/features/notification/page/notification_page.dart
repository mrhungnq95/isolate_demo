import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_notification_type.dart';
import 'package:MShopManager/features/notification/provider/notification_view_model.dart';
import 'package:MShopManager/model/notification/notification_display_item.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:MShopManager/utils/extension/datetime_ext.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:provider/provider.dart';

///
/// Màn hình thông báo
///
class NotificationPage extends StatefulWidget {
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<NotificationViewModel>(
        viewModelBuilder: (context) =>
            LocatorService.shared.get<NotificationViewModel>(),
        reactive: false,
        onViewModelReady: (model) {
          model.fetchNotificationList();
        },
        backgroundColor: Colors.white,
        brightnessColor: Brightness.light,
        statusBarColor: Colors.transparent,
        builder: (context, model, child) {
          return MSScrollContainerAnimated(
            reactiveNavigationBottomBar: true,
            titleExpanded: "Thông báo",
            actions: [
              MSCircleButton(
                  elevation: 0,
                  color: Colors.white.withOpacity(0.1),
                  size: 40,
                  imageAsset: AppResources.icFlatSetting,
                  imageAssetColor: null,
                  onTap: () async {
                    showToastFeatureDeveloping();
                    // Navigator.of(context, rootNavigator: true)
                    //     .pushNamed(AppRouterName.notification_setting.value());
                  }),
            ],
            body: _NotificationContentView(),
          );
        });
  }
}

class _NotificationContentView extends ViewModelWidget<NotificationViewModel> {
  @override
  Widget build(BuildContext context, NotificationViewModel model) {
    return model.obs(widget: (listNotification) {
      return SmartRefresher(
        controller: model.refreshController,
        enablePullDown: true,
        enablePullUp: true,
        onRefresh: () {
          model.fetchNotificationList();
        },
        onLoading: () {
          model.fetchNotificationList(isLoadMore: true);
        },
        child: ListView.builder(
          padding: const EdgeInsets.only(
              top: kVerticalSpaceLarge, bottom: kNavPaddingContent),
          itemBuilder: ((BuildContext context, int index) {
            final notificationItem = model.notificationListDisplay[index];
            return _NotificationItemView(notificationDisplay: notificationItem);
          }),
          itemCount: model.notificationListDisplay.length,
        ),
      );
    }, onReloadData: () {
      context.read<NotificationViewModel>().fetchNotificationList();
    });
  }
}

///
/// Item Notification
///
class _NotificationItemView extends StatelessWidget {
  final NotificationDisplay notificationDisplay;

  const _NotificationItemView({Key key, this.notificationDisplay})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    ENotificationType type = notificationDisplay.type;
    return InkWellView(
        onPressed: () {
          // context
          //     .read<NotificationViewModel>()
          //     .setReadedNotificationItem(notificationDisplay);
        },
        colorBackground: notificationDisplay.getBackgroundColorByReaded(),
        child: Padding(
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge, vertical: kVerticalSpaceTiny),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: 60),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 0),
                  child: CircleAvatar(
                    backgroundColor: type.colorBackground ?? AppColor.orange,
                    child: Image.asset(
                      type.getImageAssetNameNotifi ??
                          AppResources.icNotification,
                      color: AppColor.white,
                    ),
                    radius: 25,
                  ),
                ),
                kHorizontalSpaceMediumBox,
                _ContentNotificationItemView(
                  notificationDisplay: notificationDisplay,
                )
              ],
            ),
          ),
        ));
  }
}

/// Nội dung thông báo
class _ContentNotificationItemView extends StatelessWidget {
  final NotificationDisplay notificationDisplay;

  _ContentNotificationItemView({@required this.notificationDisplay});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: HtmlWidget(
              notificationDisplay.content ?? '',
              textStyle: Theme.of(context).textTheme.bodyText1,
            ),
          ),
          Text(
            notificationDisplay.time.toTimeAgo() ?? '',
            style: Theme.of(context)
                .textTheme
                .caption
                .copyWith(color: AppColor.textSecondaryColor),
          )
        ],
      ),
    );
  }
}
