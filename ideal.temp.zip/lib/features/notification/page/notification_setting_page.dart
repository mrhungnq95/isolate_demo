import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/ms_base_cupertino_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_notification_type.dart';
import 'package:MShopManager/features/notification/provider/notification_setting_view_model.dart';
import 'package:MShopManager/features/report/revenue/widget/top_item_drop_down_view.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/widget/item_switch_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NotificationSettingPage extends StatefulWidget {
  @override
  _NotificationSettingPageState createState() =>
      _NotificationSettingPageState();
}

class _NotificationSettingPageState extends State<NotificationSettingPage> {
  @override
  Widget build(BuildContext context) {
    return NotificationSettingContentPage();
  }
}

class NotificationSettingContentPage
    extends MSBaseCupertinoViewModelBuilder<NotificationSettingViewModel> {
  @override
  Brightness provideBrightnessColor(BuildContext context) {
    return Brightness.light;
  }

  @override
  Color provideStatusBarColor() {
    return Colors.transparent;
  }

  @override
  Color provideBackgroundColor() {
    return Colors.white;
  }

  @override
  Widget onBuildBody(
      BuildContext context, NotificationSettingViewModel model, Widget child) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: CustomScrollView(
              slivers: [
                MSEShopSliverAppBar(
                  pinned: true,
                  floating: true,
                  title: "Thiết lập thông báo",
                  bottom: _BranchSettingView(),
                  onLeadingTap: () {
                    Navigator.of(context).maybePop();
                  },
                  automaticallyImplyTrailing: true,
                ),
                _NotificationSettingView()
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: kVerticalSpaceLarge,
                vertical: kVerticalSpaceMedium),
            child: ExpandedView.horizontal(
                child: MSButton(
                    onPressed: () {
                      model.updateNotification();
                    },
                    label: "Lưu lại")),
          ),
        ],
      ),
    );
  }

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  NotificationSettingViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<NotificationSettingViewModel>();
  }

  @override
  void onViewModelCreated(NotificationSettingViewModel model) {
    model.prepareData();
  }
}

class _BranchSettingView extends StatelessWidget with PreferredSizeWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<NotificationSettingViewModel>(
      builder: (context, viewModel, child) {
        print("_BranchSettingView");
        return Padding(
          padding: const EdgeInsets.symmetric(
              vertical: kVerticalSpaceMedium, horizontal: kVerticalSpaceLarge),
          child: Row(
            children: [
              viewModel.isBusy
                  ? kSpaceShrinkBox
                  : MSDropdownView<Branch>(
                      value: viewModel.branchSelected,
                      onValueChanged: (positon, itemSelected) {
                        viewModel.branchSelected = itemSelected;
                      },
                      items: viewModel.branchDropDownList)
            ],
          ),
        );
      },
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(48);
}

class _NotificationSettingView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<NotificationSettingViewModel>(
      builder: (context, model, child) {
        if (model.isBusy) {
          return SliverFillRemaining(
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else {
          return SliverPadding(
            padding: const EdgeInsets.only(
                left: kVerticalSpaceLarge,
                right: kVerticalSpaceLarge,
                bottom: kNavPaddingContent),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  final itemSettingType = model.itemSettingDataList[index];
                  final isEnable = model.notificationConfig
                          .getStateSelectBySetting(type: itemSettingType) ??
                      false;
                  return ItemSwitchView(
                      onChanged: (value) {
                        model.notificationConfig
                            .updateValueSetting(itemSettingType, value);
                      },
                      margin:
                          const EdgeInsets.only(bottom: kVerticalSpaceMedium),
                      title: itemSettingType.title,
                      description: itemSettingType.contentConfig,
                      isSelected: isEnable);
                },
                childCount: model.itemSettingDataList.length,
              ),
            ),
          );
        }
      },
    );
  }
}
