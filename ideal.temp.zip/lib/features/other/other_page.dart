import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/enums/enum_other_item_type.dart';
import 'package:MShopManager/features/other/other_view_model.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:MShopManager/widget/item_category_view.dart';
import 'package:MShopManager/widget/item_setting_view.dart';
import 'package:MShopManager/widget/msview/ms_cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

/// Màn hình khác
class OtherPage extends StatefulWidget {
  @override
  _OtherPageState createState() => _OtherPageState();
}

class _OtherPageState extends State<OtherPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<OtherViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<OtherViewModel>(),
      reactive: true,
      onViewModelReady: (model) {},
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
            reactiveNavigationBottomBar: true,
            titleExpanded: "Khác",
            bottomExpanded: _BottomAppBar(),
            body: SingleChildScrollView(
              child: Column(
                children: [_FeatureGridView(), _OtherListView()],
              ),
            ));
      },
    );
  }
}

class _BottomAppBar extends ViewModelWidget<OtherViewModel> {
  @override
  Widget build(BuildContext context, OtherViewModel viewModel) {
    return GestureDetector(
      onTap: () async {
        // String qrResult = await MajaScan.startScan(
        //     title: "Quét mã vạch",
        //     barColor: AppColor.indigo900,
        //     titleColor: Colors.white,
        //     qRCornerColor: Colors.white,
        //     qRScannerColor: Colors.white,
        //     flashlightEnable: true,
        //     scanAreaScale: 0.7

        //     /// value 0.0 to 1.0
        //     );
      },
      child: Row(
        children: [
          MSCachedNetworkImage(
            imageUrl: viewModel.getAvatarUrl(),
            height: 60,
            width: 60,
            borderRadius: BorderRadius.circular(30),
            imageAssetDefault: Image.asset(
              AppResources.icAvatarPlaceHolder,
              width: 60,
              height: 60,
              fit: BoxFit.fill,
            ),
          ),
          kHorizontalSpaceLargeBox,
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                viewModel.getUserName(),
                style: Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(color: AppColor.white),
              ),
              _renderEmail()
            ],
          )
        ],
      ),
    );
  }

  Widget _renderEmail() {
    return Builder(builder: (context) {
      final model = context.watch<OtherViewModel>();
      final email = model.getEmail();
      if (!MISACommon.isNullOrEmpty(email)) {
        return Text(
          email,
          style: Theme.of(context)
              .textTheme
              .caption
              .copyWith(color: AppColor.white),
        );
      } else {
        return kSpaceShrinkBox;
      }
    });
  }
}

///
/// Các chức năng khác của app:
/// + Nhập hàng, Trả lại hàng mua
/// + Nhập kho, Xuất kho
/// + Kiểm kê, Hàng hoá....
///
class _FeatureGridView extends ViewModelWidget<OtherViewModel> {
  void onItemCategoryPressed(BuildContext context, EFeatureType itemCategory) {
    switch (itemCategory) {
      case EFeatureType.import_items:
        showToastFeatureDeveloping();
        // NavigationHelper.shared.navigateTo(routeName: AppRouterName.import_inventory_item_page);
        break;
      case EFeatureType.return_items:
        showToastFeatureDeveloping();
        // NavigationHelper.shared.navigateTo(routeName: AppRouterName.return_inventory_item_page);
        break;
      case EFeatureType.store_house:
        showToastFeatureDeveloping();
        // NavigationHelper.shared.navigateTo(routeName: AppRouterName.storehouse_receipt_page);
        break;
      case EFeatureType.stock_issue:
        showToastFeatureDeveloping();
        // NavigationHelper.shared.navigateTo(routeName: AppRouterName.stock_issue_page);
        break;
      case EFeatureType.checking:
        showToastFeatureDeveloping();
        // NavigationHelper.shared.navigateTo(routeName: AppRouterName.checking_page);
        break;
      case EFeatureType.items:
        //showToastFeatureDeveloping();
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.inventory_item);
        break;
      case EFeatureType.customer:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.customer_list);
        break;
      case EFeatureType.provider:
        NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.provider_page);
        break;
      case EFeatureType.balance:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.promotion:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.promotion:
        // TODO: Handle this case.
        break;
      case EFeatureType.order_online:
        // TODO: Handle this case.
        break;
      case EFeatureType.order_ocm:
        // TODO: Handle this case.
        break;
      case EFeatureType.other:
        // TODO: Handle this case.
        break;
    }
  }

  @override
  Widget build(BuildContext context, OtherViewModel viewModel) {
    return GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: viewModel.eFeatureTypeList.length,
        padding: const EdgeInsets.only(
            top: kVerticalSpaceMedium,
            left: kVerticalSpaceLarge,
            right: kVerticalSpaceLarge,
            bottom: kVerticalSpaceMedium),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 166 / 110,
            crossAxisSpacing: kHorizontalSpaceMedium,
            mainAxisSpacing: kHorizontalSpaceMedium),
        itemBuilder: (contex, index) {
          final itemCategory = viewModel.eFeatureTypeList[index];
          return ItemCategoryView(
            title: itemCategory.getTitle(),
            iconPath: itemCategory.getIconPath(),
            position: index,
            onPressed: (item) => onItemCategoryPressed(context, itemCategory),
          );
        });
  }
}

class _OtherListView extends ViewModelWidget<OtherViewModel> {
  ///
  /// Đăng xuất
  ///
  void showConfirmSignOutDialog(BuildContext context) {
    showConfirmDialog(
        context: context,
        content: 'Bạn có chắc muốn đăng xuất không?',
        onAcceptPressed: () {
          context.read<OtherViewModel>().signOut();
          NavigationHelper.shared.navigateReplacementNamed(
            routeName: AppRouterName.signin,
          );
        },
        onCancelPressed: () => NavigationHelper.shared.pop());
  }

  ///
  /// Chọn menu trong mục Khác
  /// [itemOther] item menu được chọn
  ///
  void onItemPressed(BuildContext context, EOtherItemType itemOther) {
    final model = Provider.of<OtherViewModel>(context, listen: false);
    switch (itemOther) {
      case EOtherItemType.appSale:
        model.openAppSale();
        break;
      case EOtherItemType.appConsultant:
        model.openAppConsultant();
        break;
      case EOtherItemType.setting:
        NavigationHelper.shared.navigateTo(routeName: AppRouterName.setting);
        break;
      case EOtherItemType.shareToFriend:
        model.shareApplication();
        break;
      case EOtherItemType.rateApp:
        showToastFeatureDeveloping();
        break;
      case EOtherItemType.feedBack:
        showToastFeatureDeveloping();
        break;
      case EOtherItemType.appInfo:
        NavigationHelper.shared.navigateTo(routeName: AppRouterName.about);
        break;
      case EOtherItemType.policy:
        model.launchPolicyURL();
        break;
      case EOtherItemType.logOut:
        showConfirmSignOutDialog(context);
        break;
      case EOtherItemType.misaSupport:
        model.openAppMisaSupport();
        break;
    }
  }

  @override
  Widget build(BuildContext context, OtherViewModel viewModel) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.only(
          top: kVerticalSpaceMedium,
          left: kVerticalSpaceLarge,
          right: kVerticalSpaceLarge,
          bottom: kNavPaddingContent),
      itemBuilder: (context, index) {
        final itemOther = viewModel.eOtherItemTypeList[index];
        return ItemSettingView(
          pading: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
          iconLeadingAsset: itemOther.getIconPath(),
          title: itemOther.getTitle(),
          iconColorLeading: null,
          backgroundColor: AppColor.grey50,
          onTap: () => onItemPressed(context, itemOther),
        );
      },
      itemCount: viewModel.eOtherItemTypeList?.length ?? 0,
    );
  }
}
