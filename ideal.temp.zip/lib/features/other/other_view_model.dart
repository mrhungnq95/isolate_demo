import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/base/service/url_helper.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/enums/enum_other_item_type.dart';
import 'package:android_intent/android_intent.dart';
import 'package:device_apps/device_apps.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io' show Platform;

class OtherViewModel extends MSBaseViewModel {
  List<EFeatureType> _eFeatureTypeList = [
    EFeatureType.import_items,
    EFeatureType.return_items,
    EFeatureType.store_house,
    EFeatureType.stock_issue,
    EFeatureType.checking,
    EFeatureType.items,
    EFeatureType.customer,
    EFeatureType.promotion,
    EFeatureType.balance,
    EFeatureType.provider,
    EFeatureType.order_online,
    EFeatureType.order_ocm,
  ];
  List<EFeatureType> get eFeatureTypeList => _eFeatureTypeList;

  List<EOtherItemType> _eOtherItemTypeList = [...EOtherItemType.values];
  List<EOtherItemType> get eOtherItemTypeList => _eOtherItemTypeList;

  ///
  /// Mở url chính sách bảo mật
  ///
  void launchPolicyURL() async {
    /// TODO - VNLONG - Check ngôn ngữ đang sử dụng để show link tương ứng với ngôn ngữ đang chọn
    const url = AppConstant.privacy_policy_vn;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      showToast('Có lỗi sảy ra. Vui lòng thử lại.');
    }
  }

  ///
  /// Chia sẻ ứng dụng
  /// VNLONG - 28/01/2021
  ///
  Future<void> shareApplication() async {
    String title = 'Giới thiệu cho bạn bè';
    String contentShare = '';
    String linkShare = '';
    String namePlatform = '';

    /// TODO - VNLONG - Cần thêm link store ở đây
    if (Platform.isAndroid) {
      namePlatform = 'Android';
      linkShare = 'https://play.google.com/store?hl=vi&gl=US';
    } else {
      namePlatform = 'IOS';
      linkShare = 'https://itunes.apple.com/app/id1299032052';
    }

    contentShare =
        'Chào bạn. Bạn có thể tải phiên bản $namePlatform của ứng dụng MISA eShop - Quán lý tại địa chỉ: $linkShare \nXem thông tin chi tiết tại website: www.mshopkeeper.vn';

    await FlutterShare.share(
        title: title, text: contentShare, chooserTitle: title);
  }

  ///
  /// Mở app misa support
  /// VNLONG - 28/01/2021
  ///
  void openAppMisaSupport() {
    /// TODO - VNLONG - Check thêm đoạn nâng cấp bảo mật misa ID tại đây
    if (Platform.isAndroid) {
      openAppOnPlatformAndroid(
          packageNameAndroid: AppConstant.misa_support_android_package_name);
    } else {
      openOtherAppOnPlatformIos(
          urlAppStore: AppConstant.url_misa_support_app_store,
          urlSchemaIos: AppConstant.url_schema_ios_misa_support);
    }
  }

  ///
  /// Mở app sale
  ///
  void openAppSale() {
    if (Platform.isAndroid) {
      openAppOnPlatformAndroid(
          packageNameAndroid: AppConstant.sale_android_package_name);
    } else {
      openOtherAppOnPlatformIos(
          urlAppStore: AppConstant.url_eshop_sale_app_store,
          urlSchemaIos: AppConstant.url_schema_ios_eshop_sale);
    }
  }

  ///
  /// Mở app tư vấn
  ///
  void openAppConsultant() {
    if (Platform.isAndroid) {
      openAppOnPlatformAndroid(
          packageNameAndroid: AppConstant.consultant_android_package_name);
    } else {
      openOtherAppOnPlatformIos(
          urlAppStore: AppConstant.url_eshop_consultant_app_store,
          urlSchemaIos: AppConstant.url_schema_ios_eshop_consultant);
    }
  }

  /// Đăng xuất
  ///
  void signOut() {
    UserCredential.currentSession.signOut();
  }

  ///
  /// Tên người dùng
  ///
  String getUserName() {
    return UserCredential.currentSession.loginResponse?.fullName ?? "";
  }

  ///
  /// Email của người dùng
  ///
  String getEmail() {
    return UserCredential.currentSession.loginResponse?.email ?? "";
  }

  ///
  /// Đường dẫn url của avatar
  ///
  String getAvatarUrl() {
    final avatarId = UserCredential.currentSession.loginResponse?.avatar;
    return UrlHelper.shared.getUrlAvatar(
      avatarId: avatarId,
    );
  }
}
