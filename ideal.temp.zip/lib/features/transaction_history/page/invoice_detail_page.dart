import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/invoice/view/detail_invoice_view.dart';
import 'package:MShopManager/features/transaction_history/provider/detail_invoice_view_model.dart';
import 'package:MShopManager/widget/msview/ms_eshop_sliver_appbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// Chi tiết hóa đơn
class InvoiceDetailPage extends StatefulWidget {
  @override
  _InvoiceDetailPageState createState() => _InvoiceDetailPageState();
}

class _InvoiceDetailPageState extends State<InvoiceDetailPage> {
  @override
  Widget build(BuildContext context) {
    final String refId = ModalRoute.of(context).settings.arguments;
    return MSBaseCupertinoWidgetBuilderV2<DetailInvoiceViewModel>(
        viewModelBuilder: (context) =>
            LocatorService.shared.get<DetailInvoiceViewModel>(),
        reactive: true,
        onViewModelReady: (model) {
          model.fetchDataInvoice(refId);
        },
        backgroundColor: Colors.white,
        brightnessColor: Brightness.light,
        statusBarColor: Colors.transparent,
        builder: (context, model, child) {
          return CustomScrollView(
            slivers: [     
              MSEShopSliverAppBar(
                pinned: true,
                title: "Chi tiết hóa đơn",
                onLeadingTap: () {
                  Navigator.of(context).maybePop();
                },
                automaticallyImplyTrailing: true,
              ),
              SliverToBoxAdapter(child: DetailInvoiceView())
            ],
          );
        });
  }
}
