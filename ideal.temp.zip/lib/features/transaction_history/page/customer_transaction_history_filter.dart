import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/features/transaction_history/provider/customer_transaction_history_filter_view_model.dart';
import 'package:MShopManager/features/transaction_history/provider/customer_transaction_history_view_model.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_customer_transaction_history_view_by_type.dart';
import 'package:MShopManager/enums/enum_time_sort_status.dart';
import 'package:MShopManager/widget/many_option_view.dart';
import 'package:MShopManager/widget/ms_flow_layout.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:stacked/stacked.dart';
import 'package:tuple/tuple.dart';

class CustomerTransactionHistoryFilterPage extends StatefulWidget {
  @override
  _CustomerTransactionHistoryFilterPageState createState() =>
      _CustomerTransactionHistoryFilterPageState();
}

class _CustomerTransactionHistoryFilterPageState
    extends State<CustomerTransactionHistoryFilterPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<
        CustomerTransactionHistoryFilterViewModel>(
      viewModelBuilder: (context) => LocatorService.shared
          .get<CustomerTransactionHistoryFilterViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {},
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          isPrimary: false,
          isCenterTitleCollapsed: false,
          titleExpanded: "Bộ lọc",
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          body: _TransactionFilterContentView(),
          bottomContainer: ExpandedView.horizontal(
              child: Container(
            margin: const EdgeInsets.only(bottom: kVerticalSpaceLarge),
            padding:
                const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
            child: MSButton(
                onPressed: () {
                  model?.applyFilter();
                  NavigationHelper.shared.pop(data: true);
                },
                label: "Lọc"),
          )),
        );
      },
    );
  }
}

class _TransactionFilterContentView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print("_TransactionFilterContentView build");
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ListBranchView(),
          _ViewTypeFilterView(),
          _SortFilterView(),
          _InvoiceStatusChipView(),
          kVerticalSpaceLargeBox
        ],
      ),
    );
  }
}

///
/// Ds chi nhánh cửa hàng
///
class _ListBranchView extends StatelessWidget {
  const _ListBranchView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print("_ListBranchView build");
    final model =
        Provider.of<CustomerTransactionHistoryFilterViewModel>(context);
    return BranchFilterView(
      controller: model.branchFilterController,
    );
  }
}

class _ViewTypeFilterView extends StatelessWidget {
  const _ViewTypeFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model =
        Provider.of<CustomerTransactionHistoryFilterViewModel>(context);
    print("_ViewTypeFilterView build");

    return ManyOptionView<ECustomerTransactionHistoryViewType>(
      title: 'Xem theo',
      groupValue: model.viewType,
      itemCount: model.viewTypeList.length,
      valueBuilder: (index) => model.viewTypeList[index],
      titleBuilder: (value) => Text(
        value.getTitle(),
        style: Theme.of(context).textTheme.bodyText1,
      ),
      onChanged: (value) {
        model.viewType = value;
      },
    );
  }
}

class _SortFilterView extends StatelessWidget {
  const _SortFilterView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Selector<CustomerTransactionHistoryFilterViewModel,
        Tuple2<ETimeSortStatus, List<ETimeSortStatus>>>(
      selector: (_, model) => Tuple2(model.sortByTime, model.sortByTimeList),
      builder: (context, tuple, child) {
        print("_SortFilterView build");
        return ManyOptionView<ETimeSortStatus>(
          title: 'Sắp xếp',
          groupValue: tuple.item1,
          itemCount: tuple.item2.length,
          valueBuilder: (index) => tuple.item2[index],
          titleBuilder: (value) => Text(
            value.getTitle(),
            style: Theme.of(context).textTheme.bodyText1,
          ),
          onChanged: (value) {
            context
                .read<CustomerTransactionHistoryFilterViewModel>()
                .sortByTime = value;
          },
        );
      },
    );
  }
}

class _InvoiceStatusChipView
    extends ViewModelWidget<CustomerTransactionHistoryFilterViewModel> {
  @override
  Widget build(BuildContext rootContext,
      CustomerTransactionHistoryFilterViewModel model) {
    print("_InvoiceStatusChipView build");

    return MSFlowLayout<EPaymentStatus>(
        title: "Trạng thái",
        data: model.ePaymentStatusList,
        onTap: (item) {
          rootContext
              .read<CustomerTransactionHistoryFilterViewModel>()
              .performPaymentStatus(item);
        },
        onBindLabel: (item) {
          return item.getTitle();
        },
        isSelected: (item) {
          return model?.ePaymentStatusSelectedList?.contains(item) == true;
        });

    // return Selector<CustomerTransactionHistoryFilterViewModel,
    //         Tuple2<List<EPaymentStatus>, List<EPaymentStatus>>>(
    //     builder: (context, valueSelector, child) {
    //       print("Selector<CustomerTransactionHistoryFilterViewModel>");
    //       return MSFlowLayout<EPaymentStatus>(
    //           title: "Trạng thái",
    //           data: valueSelector.item1,
    //           onTap: (item) {
    //             context
    //                 .read<CustomerTransactionHistoryFilterViewModel>()
    //                 .onPerformPaymentStatus(item);
    //           },
    //           onBindLabel: (item) {
    //             return item.getTitle();
    //           },
    //           isSelected: (item) {
    //             bool check = valueSelector.item2?.contains(item) == true;
    //             print(
    //                 "Selector<CustomerTransactionHistoryFilterViewModel> $check");
    //             return check;
    //           });
    //     },
    //     selector: (c, model) =>
    //         Tuple2(model.ePaymentStatusList, model.ePaymentStatusSelectedList));

    // return MSFlowLayout<EPaymentStatus>(
    //     title: "Trạng thái",
    //     data: [
    //       EPaymentStatus.ALL,
    //       EPaymentStatus.NOT_PAID,
    //       EPaymentStatus.DEBIT,
    //       EPaymentStatus.PAID,
    //       EPaymentStatus.CANCELED,
    //       EPaymentStatus.WAIT_FOR_DELIVERY,
    //       EPaymentStatus.DELIVERING,
    //       EPaymentStatus.FAIL,
    //       EPaymentStatus.DONE,
    //       EPaymentStatus.REFUND,
    //       EPaymentStatus.WAIT_FOR_COD,
    //     ],
    //     onTap: (item) {
    //       model.ePaymentStatus = item;
    //     },
    //     onBindLabel: (item) {
    //       return item.getTitle();
    //     },
    //     isSelected: (item) {
    //       return item == model.ePaymentStatus;
    //     });
  }
}
