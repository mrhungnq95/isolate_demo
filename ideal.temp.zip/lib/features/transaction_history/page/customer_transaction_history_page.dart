import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/features/transaction_history/bottomsheet/detail_invoice_bottom_sheet_view.dart';
import 'package:MShopManager/features/transaction_history/provider/customer_transaction_history_view_model.dart';
import 'package:MShopManager/model/drop_down_item_object.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/info_filter_view.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:MShopManager/widget/msview/ms_drop_down_view.dart';
import 'package:MShopManager/widget/sheet/list_item_bottom_sheet.dart';
import 'package:MShopManager/widget/total_style_border_value_view.dart';
import 'package:flutter/material.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';
import 'package:tuple/tuple.dart';

class CustomerTransactionHistoryPage extends StatefulWidget {
  @override
  _CustomerTransactionHistoryPageState createState() =>
      _CustomerTransactionHistoryPageState();
}

class _CustomerTransactionHistoryPageState
    extends State<CustomerTransactionHistoryPage> {
  @override
  Widget build(BuildContext context) {
    final customerId = ModalRoute.of(context).settings.arguments;

    return MSBaseCupertinoWidgetBuilderV2<CustomerTransactionHistoryViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<CustomerTransactionHistoryViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {
        model.initData(customerId);
        model.fetchData();
      },
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          isPrimary: true,
          isCenterTitleCollapsed: false,
          titleExpanded: "Lịch sử mua hàng",
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          bottomExpanded: _BottomAppBar(),
          actions: [
            MSCircleButton(
                elevation: 0,
                color: Colors.white.withOpacity(0.1),
                size: 40,
                imageAsset: AppResources.icSearch,
                imageAssetColor: null,
                onTap: () async {}),
            MSCircleButton(
                elevation: 0,
                color: Colors.white.withOpacity(0.1),
                size: 40,
                imageAsset: AppResources.icFilledFilter,
                imageAssetColor: null,
                onTap: () async {
                  final result =
                      await Navigator.of(context, rootNavigator: true)
                          .pushNamed(AppRouterName
                              .customer_transaction_history_filter
                              .value());

                  if (result == true) {
                    /// Fetch lại data
                    model.fetchData(isRefreshFilterSetting: true);
                  }
                })
          ],
          body: _TransactionContentView(),
        );
      },
    );
  }
}

class _BottomAppBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Selector<CustomerTransactionHistoryViewModel,
        Tuple2<EReportPeriodType, String>>(
      selector: (_, model) =>
          Tuple2(model.timePeriodFilter, model.getPeriodDateTitle()),
      builder: (context, value, child) {
        return InfoFilterView(
          horizontalPadding: 0,
          title: value.item1.title,
          titleColor: AppColor.white,
          compareTitleColor: AppColor.white,
          isShowCompareInfo: false,
          description: value.item2,
          compareTitle: "",
          onFilterPressed: () => _onFilterPressed(context),
        );
      },
    );
  }

  ///
  /// Xử lý khi chọn vào nút filter
  ///
  void _onFilterPressed(BuildContext context) async {
    final model = context.read<CustomerTransactionHistoryViewModel>();

    final result = await showCupertinoModalBottomSheet(
      expand: true,
      context: context,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ListItemBottomSheetView<EReportPeriodType>(
        title: "Chọn thời gian",
        dataSourceList: model.timePeriodOptionList,
        titleBuilder: (EReportPeriodType item) {
          return item.title;
        },
        isChecked: (item) => item == model.timePeriodFilter,
      ),
    );

    if (result != null && result is EReportPeriodType) {
      model.fetchDataWithNewTimePeriod(result);
    }
  }
}

class _TransactionContentView
    extends ViewModelWidget<CustomerTransactionHistoryViewModel> {
  @override
  Widget build(BuildContext context, viewModel) {
    return viewModel.obs(
        widget: (state) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _TotalStyleBorderValueView(),
                kVerticalSpaceMediumBox,
                Expanded(
                    child: SmartRefresher(
                  controller: viewModel.refreshController,
                  enablePullDown: true,
                  enablePullUp: true,
                  onRefresh: () {
                    viewModel.fetchData();
                  },
                  onLoading: () {
                    viewModel.fetchData(isLoadMore: true);
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: kVerticalSpaceLarge),
                    itemBuilder: ((BuildContext context, int index) {
                      final invoice = state[index];
                      return _TransactionHistoryView(
                        titleLeading: invoice.refNo,
                        subTitleLeading: DateTimeFormatHelper.formatDate2String(
                            invoice.refDate,
                            format: DateTimeFormatConstant.DD_MM_YYYY_HH_MM_24),
                        titleTrailing: NumberFormatHelper.shared
                            .formatMoney(invoice.totalAmount),
                        subTitleTrailing:
                            EPaymentStatusExt.fromValue(invoice.paymentStatus)
                                .getTitle(),
                        txStylesubTitleTrailing: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(
                                color: EPaymentStatusExt.fromValue(
                                        invoice.paymentStatus)
                                    .getTitleColor()),
                        onPressed: () {
                          showDetailInvoiceSheetView(context, invoice.refID);
                        },
                      );
                    }),
                    itemCount: state.length,
                  ),
                ))
              ],
            ));
  }

  ///
  /// Hiển thị bottom sheet hiển thị chi tiết hoá đơn
  ///
  void showDetailInvoiceSheetView(BuildContext context, String refId) {
    showModalBottomSheet(
        elevation: 10,
        context: context,
        backgroundColor: Colors.transparent,
        isScrollControlled: true,
        useRootNavigator: true,
        builder: (c) => DetailInvoiceViewBottomSheet(
              refId: refId,
            ));
  }
}

class _TotalStyleBorderValueView extends StatelessWidget {
  const _TotalStyleBorderValueView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Selector<CustomerTransactionHistoryViewModel,
        Tuple2<double, double>>(
      selector: (_, model) => Tuple2(model.totalAmount, model.quantity),
      builder: (context, tuple, child) {
        return Column(
          children: [
            Container(
              height: 48,
              padding:
                  const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
              child: TotalStyleBorderValueView(
                title: 'Tổng ',
                totalItem: tuple.item2,
                isBorderQuantityView: false,
                value: tuple.item1,
              ),
            ),
            Divider(
              height: 4,
              thickness: 4,
              color: AppColor.grey400,
            )
          ],
        );
      },
    );
  }
}

///
/// Lịch sử giao dịch
///
class _TransactionHistoryView extends StatelessWidget {
  final String titleLeading;
  final String subTitleLeading;
  final String titleTrailing;
  final String subTitleTrailing;

  final TextStyle txStyleTitleLeading;
  final TextStyle txStyleSubTitleLeading;
  final TextStyle txStyleTitleTrailing;
  final TextStyle txStylesubTitleTrailing;

  final VoidCallback onPressed;

  _TransactionHistoryView({
    this.titleLeading,
    this.subTitleLeading,
    this.titleTrailing,
    this.subTitleTrailing,
    this.txStyleTitleLeading,
    this.txStyleSubTitleLeading,
    this.txStyleTitleTrailing,
    this.txStylesubTitleTrailing,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: kHorizontalSpaceLarge, vertical: kVerticalSpaceSmall),
      child: InkWellView(
        borderRadius: 10,
        onPressed: onPressed,
        colorBackground: AppColor.grey50,
        child: Container(
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge,
              vertical: kVerticalSpaceMedium),
          decoration: BoxDecoration(
              border: Border.all(color: AppColor.grey300),
              borderRadius: BorderRadius.circular(10)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titleLeading ?? '',
                      style: txStyleTitleLeading ??
                          Theme.of(context).textTheme.bodyText1,
                    ),
                    kVerticalSpaceTinyBox,
                    Text(subTitleLeading ?? '',
                        style: txStyleSubTitleLeading ??
                            Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(color: AppColor.textSecondaryColor)),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(titleTrailing ?? '',
                        style: txStyleTitleTrailing ??
                            Theme.of(context).textTheme.bodyText1),
                    kVerticalSpaceTinyBox,
                    Text(subTitleTrailing ?? '',
                        style: txStylesubTitleTrailing ??
                            Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(color: AppColor.green)),
                  ],
                ),
              ),
              kHorizontalSpaceMediumBox,
              Icon(
                Icons.chevron_right,
                color: AppColor.grey600,
                size: 22,
              )
            ],
          ),
        ),
      ),
    );
  }
}
