import 'dart:async';

import 'package:MShopManager/base/mixin/filter_feature_mixin.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/enums/enum_customer_transaction_history_view_by_type.dart';
import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_time_sort_status.dart';
import 'package:MShopManager/model/customer_transaction_history/customer_transaction_history_filter_setting.dart';
import 'package:MShopManager/model/drop_down_item_object.dart';
import 'package:MShopManager/model/invoice/invoice.dart';
import 'package:MShopManager/model/service/request/list_order_for_customer_param.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:rxdart/rxdart.dart';

class CustomerTransactionHistoryViewModel extends MSBaseViewModel
    with
        FilterFeatureMixin<CustomerTransactionHistoryFilterSetting>,
        MSStateMixin<List<SAInvoice>> {
  static const int TOTAL_ITEM_PER_PAGE = 25;

  /// Repository
  MobileRepository _mobileRepository;

  /// Mã Khách hàng
  String _customerId;

  /// Controller
  RefreshController refreshController =
      RefreshController(initialRefresh: false);

  ///
  final _searchSubject = BehaviorSubject<String>();
  BehaviorSubject<String> get searchSubject => _searchSubject;
  StreamSubscription<String> _searchSubcription;

  /// DS các kỳ báo cáo
  List<EReportPeriodType> _timePeriodOptionList = [
    EReportPeriodType.thisDay,
    EReportPeriodType.yesterday,
    EReportPeriodType.thisWeek,
    EReportPeriodType.lastWeek,
    EReportPeriodType.thisMonth,
    EReportPeriodType.lastMonth,
    EReportPeriodType.thisQuarter,
    EReportPeriodType.sixLastMonth,
    EReportPeriodType.thisYear,
    EReportPeriodType.lastYear
  ];

  List<EReportPeriodType> get timePeriodOptionList => _timePeriodOptionList;

  /// Filter
  EReportPeriodType _timePeriodFilter;
  EReportPeriodType get timePeriodFilter => _timePeriodFilter;

  /// Tổng doanh thu của các hoá đơn từ KH
  double _totalAmount;
  double get totalAmount => _totalAmount;

  /// Tổng KH
  double _quantity;
  double get quantity => _quantity;

  /// Param để lấy DS Hoá đơn của KH
  GetOrderForCustomerParam _param;

  CustomerTransactionHistoryViewModel(MobileRepository mobileRepository) {
    this._mobileRepository = mobileRepository;

    _searchSubcription = _searchSubject
        .debounce((_) => TimerStream(true, Duration(milliseconds: 500)))
        .listen((searchText) {
      fetchData(searchText: searchText);
    });
  }

  @override
  CustomerTransactionHistoryFilterSetting createDefaultFilterSetting() {
    return CustomerTransactionHistoryFilterSetting.newDefault();
  }

  @override
  void filterSettingLoaded(
      CustomerTransactionHistoryFilterSetting filterSetting) {
    /// Khởi tạo thời gian lấy báo cáo mặc định: Hôm nay, Tuần này, Tháng này

    if (_timePeriodFilter == null) {
      _timePeriodFilter = _timePeriodOptionList[2];
    }

    /// Khởi tạo param lấy DS Khách hàng
    _initInvoicePagingParam();
  }

  @override
  EFilterViewModelKey get filterViewModelKey =>
      EFilterViewModelKey.customer_transaction_history;

  @override
  void dispose() {
    _searchSubcription?.cancel();
    super.dispose();
  }

  ///
  /// Khởi tạo dữ liệu
  ///
  void initData(String customerId) {
    _customerId = customerId;
  }

  ///
  /// Khởi tạo param lấy DS Khách hàng
  /// [keySearch] nội dung search
  ///
  void _initInvoicePagingParam() {
    _param = GetOrderForCustomerParam();

    _param.viewType = filterSetting.viewType.rawValue;
    _param.sortType = filterSetting.sortStatus.rawValue;
    _param.pageIndex = 1;
    _param.pageSize = TOTAL_ITEM_PER_PAGE;

    final waitReceiveCODStatus = filterSetting.paymentStatus?.firstWhere(
        (element) => element == EPaymentStatus.waitReceiveCOD,
        orElse: () => null);
    _param.isReceiveCOD = waitReceiveCODStatus != null;

    _param.keySearch = null;
    _param.branchID = filterSetting.branchId;
    _param.listPaymentStatus =
        filterSetting.paymentStatus?.map((e) => e.rawValue)?.join(";");

    _initPeriodFilter();
  }

  ///
  /// Khởi tạo kỳ báo cáo
  ///
  void _initPeriodFilter() {
    final currentPeriod =
        DateTimeHelper.getDateRangeByPeriod(DateTime.now(), _timePeriodFilter);
    _param.fromDate = currentPeriod?.startDate;
    _param.toDate = currentPeriod?.endDate;
  }

  ///
  /// Lấy thông tin Invoice của Người dùng theo kỳ báo cáo mới nhất
  ///
  void fetchDataWithNewTimePeriod(EReportPeriodType value) {
    _timePeriodFilter = value;

    _initPeriodFilter();
    fetchData();
  }

  ///
  /// Lấy thông tin Invoice của Người dùng
  /// [searchText] nội dung search
  /// [isRefreshFilterSetting] true nếu refresh lại filter setting
  /// [isLoadMore] true nếu hàm này được trigger từ load more
  ///
  void fetchData(
      {String searchText,
      bool isRefreshFilterSetting = false,
      bool isLoadMore = false}) {
    if (isRefreshFilterSetting) {
      reloadFilterSetting();
      _initInvoicePagingParam();
    }

    _param.customerID = _customerId;
    _param.keySearch = searchText;

    /// Bắt buộc phải tạo 1 state mới để StateMixin có thể kiểm tra được
    /// có sự thay đổi hay không trước khi đánh dấu để build lại UI
    List<SAInvoice> invoiceList = [];

    if (isLoadMore) {
      _param.pageIndex += 1;

      /// Loadmore thì add những Item hiện tại vào DS mới
      if (isValueNotNull) {
        invoiceList.addAll(value);
      }
    } else {
      _param.pageIndex = 1;

      /// Load dữ liệu bình thường, để value mặc định là null
      /// và status là Loading
      changeState(null, status: ViewStatus.loading());
    }

    _mobileRepository.fetchSaleHistoryMobilePaging(_param).then((value) {
      value?.when(success: (response) {
        final hasData = response != null && response.hasData();

        if (hasData) {
          invoiceList.addAll(response.data);
        }

        if (response.summaryData != null) {
          _totalAmount = response?.summaryData["TotalAmount"] ?? 0;
        } else {
          _totalAmount = 0;
        }
        _quantity = response?.total?.toDouble() ?? 0;

        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        if (isLoadMore) {
          hasData
              ? refreshController?.loadComplete()
              : refreshController?.loadNoData();

          changeState(invoiceList, status: ViewStatus.success());
        } else {
          changeState(invoiceList,
              status: hasData ? ViewStatus.success() : ViewStatus.empty());
        }
        refreshController?.refreshCompleted();
      }, commonError: (e) {
        /// Lỗi common, hiện tại chưa xử lý gì
        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        _handleFetchDataError(isLoadMore);
      }, apiError: (errorData, exception) {
        /// Lỗi common, hiện tại chưa xử lý gì
        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        _handleFetchDataError(isLoadMore);
      });
    });
  }

  ///
  /// Xử lý việc lấy dữ liệu lỗi
  /// [isLoadMore] true nếu là đang loadmore
  ///
  void _handleFetchDataError(bool isLoadMore) {
    /// Lỗi common, hiện tại chưa xử lý gì
    /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
    /// để không kéo thêm nữa
    if (isLoadMore) {
      refreshController?.loadNoData();
    } else {
      changeState(null, status: ViewStatus.error());
    }

    refreshController?.refreshCompleted();
  }

  ///
  /// Lấy khoảng thời gian của kỳ báo cáo
  ///
  String getPeriodDateTitle() {
    final currentPeriod =
        DateTimeHelper.getDateRangeByPeriod(DateTime.now(), _timePeriodFilter);
    return _timePeriodFilter?.getPeriodDateTitle(currentPeriod) ?? "";
  }
}
