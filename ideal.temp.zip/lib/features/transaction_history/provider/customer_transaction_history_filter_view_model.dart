import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/base/mixin/filter_feature_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_customer_transaction_history_view_by_type.dart';
import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_time_sort_status.dart';
import 'package:MShopManager/model/customer_transaction_history/customer_transaction_history_filter_setting.dart';
import 'package:MShopManager/widget/branch_filter_view.dart';

class CustomerTransactionHistoryFilterViewModel extends MSBaseViewModel
    with FilterFeatureMixin<CustomerTransactionHistoryFilterSetting> {
  ///
  /// Controller quản lý View Cửa hàng
  ///
  BranchFilterController _branchFilterController;
  BranchFilterController get branchFilterController => _branchFilterController;

  ECustomerTransactionHistoryViewType _viewType =
      ECustomerTransactionHistoryViewType.createdDate;
  ECustomerTransactionHistoryViewType get viewType => _viewType;
  set viewType(ECustomerTransactionHistoryViewType newValue) {
    _viewType = newValue;

    notifyListeners();
  }

  /// Trạng thái
  List<ECustomerTransactionHistoryViewType> _viewTypeList = [
    ECustomerTransactionHistoryViewType.createdDate,
    ECustomerTransactionHistoryViewType.refDate,
  ];
  List<ECustomerTransactionHistoryViewType> get viewTypeList => _viewTypeList;

  /// Săp xếp
  ETimeSortStatus _sortByTime = ETimeSortStatus.asc;
  ETimeSortStatus get sortByTime => _sortByTime;
  set sortByTime(ETimeSortStatus newValue) {
    _sortByTime = newValue;

    notifyListeners();
  }

  /// Săp xếp
  List<ETimeSortStatus> _sortByTimeList = [
    ETimeSortStatus.asc,
    ETimeSortStatus.desc,
  ];
  List<ETimeSortStatus> get sortByTimeList => _sortByTimeList;

  /// Trạng thái hoá đơn
  List<EPaymentStatus> _ePaymentStatusList = [
    EPaymentStatus.all,
    EPaymentStatus.notpay,
    EPaymentStatus.debit,
    EPaymentStatus.payed,
    EPaymentStatus.cancelled,
    EPaymentStatus.waitDelivery,
    EPaymentStatus.delivering,
    EPaymentStatus.fail,
    EPaymentStatus.invoiceDone,
    EPaymentStatus.refund,
    EPaymentStatus.waitReceiveCOD,
  ];
  List<EPaymentStatus> get ePaymentStatusList => _ePaymentStatusList;

  /// DS các trạng thái hoá đơn được chọn
  List<EPaymentStatus> _ePaymentStatusSelectedList = [EPaymentStatus.all];
  List<EPaymentStatus> get ePaymentStatusSelectedList =>
      _ePaymentStatusSelectedList;

  @override
  CustomerTransactionHistoryFilterSetting createDefaultFilterSetting() {
    return CustomerTransactionHistoryFilterSetting.newDefault();
  }

  @override
  void filterSettingLoaded(
      CustomerTransactionHistoryFilterSetting filterSetting) {
    /// Khởi tạo controller cho widget Cửa hàng
    /// TODO check quyền, nếu không cho phép chọn nhóm nhà hàng thì ẩn widget này đi
    /// xem cờ [isAllowChooseGroupStore]
    _branchFilterController = BranchFilterController(listAllBranch: branchList);

    /// Cửa hàng
    _branchFilterController.mode = BranchFilterMode.ALL;

    _viewType = filterSetting.viewType;
    _sortByTime = filterSetting.sortStatus;

    _ePaymentStatusSelectedList = filterSetting.paymentStatus;
  }

  @override
  EFilterViewModelKey get filterViewModelKey =>
      EFilterViewModelKey.customer_transaction_history;

  ///
  /// Join những Branch đã chọn ở trong List vào 1 chuỗi cách nhau dấu phẩy ,
  ///
  String _getBranchSelectedId() {
    if (_branchFilterController.mode == BranchFilterMode.ALL) {
      return AppConstant.UUID_EMPTY;
    }
    return _branchFilterController?.getBranchIDSelected();
  }

  ///
  /// Xử lý khi chọn vào trạng thái hoá đơn
  ///
  void performPaymentStatus(EPaymentStatus item) {
    ///
    /// Nếu chọn tất cả => xoá hết, add mỗi Tất cả.
    ///

    if (_ePaymentStatusSelectedList?.contains(item) == true) {
      _ePaymentStatusSelectedList.remove(item);
    } else {
      _ePaymentStatusSelectedList.add(item);
    }
    notifyListeners();
  }

  ///
  /// Lưu thiết lập
  ///
  void applyFilter() {
    /// Cửa hàng
    filterSetting.branchId = _getBranchSelectedId();
    filterSetting?.paymentStatus = _ePaymentStatusSelectedList;
    filterSetting?.viewType = _viewType;
    filterSetting?.sortStatus = _sortByTime;
    saveFilterSetting();
  }
}
