import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/data/repository/dashboard_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_apply_number.dart';
import 'package:MShopManager/enums/enum_invoice_detail_type.dart';
import 'package:MShopManager/enums/enum_payment_status.dart';
import 'package:MShopManager/enums/enum_payment_type.dart';
import 'package:MShopManager/enums/enum_ref_type.dart';
import 'package:MShopManager/model/invoice/invoice_coupon.dart';
import 'package:MShopManager/model/invoice/invoice_detail.dart';
import 'package:MShopManager/model/invoice/invoice_detail_item_display.dart';
import 'package:MShopManager/model/service/get_detail_invoice_response.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/logger_utils.dart';
import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/material.dart';

class DetailInvoiceViewModel extends MSBaseViewModel with MSStateMixin<List<InvoiceDetailItemDisplay>> {
  DashboardRepository _dashboardRepository =
      LocatorService.shared.get<DashboardRepository>();
  GetDetailInvoiceResponse detailInvoice;
  // Danh sách item hiển thị
  List<InvoiceDetailItemDisplay> dataInvoiceDisplay = [];
  // Danh sách chương trình khuyến mại
  List<String> listPromotionName = [];

  ///
  /// Lấy ds hóa đơn theo page
  /// VNLONG - 04/01/2021
  ///
  void fetchDataInvoice(String refID) async {
    changeState(null, status: ViewStatus.loading());

    /// Request API lấy ds detail Hóa đơn
    final getDetailInvoiceRequest =
        await _dashboardRepository.getDetailInvoice(refId: refID ?? '');

    getDetailInvoiceRequest.when(success: (response) {
      FLogger.shared.log("Get Detail Invoice Success!");
      detailInvoice = response;
      buildListPromotion();
      buildListItemInvoice();
      changeState(dataInvoiceDisplay, status: ViewStatus.success());
    }, commonError: (error) {
      changeState(null, status: ViewStatus.error());
    }, apiError: (errorData, error) {
      changeState(null, status: ViewStatus.error());
    });
    
  }

  ///
  /// Build danh sách item hiển thị
  /// VNLONG - 09/01/2021
  ///
  void buildListItemInvoice() {
    dataInvoiceDisplay = [];
    buildHeaderInvoice();
    // Danh sách các hàng hóa
    dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
      type: EInvoiceDetailType.listDetail,
    ));
    buildPaymentInfo();
  }

  ///
  /// Build thông tin thanh toán của hóa đơn
  /// VNLONG - 09/01/2021
  ///
  void buildPaymentInfo() {
    /// Tiền hàng trả lại khách
    final returnAmount = getReturnAmount();
    if (detailInvoice?.saInvoice?.refType == ERefType.returnInvoice.toValue &&
        returnAmount < 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Tiền hàng trả lại: ',
          isBoldTitle: true,
          isBoldValue: true,
          value: returnAmount.toStringFormat(EDoubleFormat.money)));
    }

    /// Khuyến mại (Trả lại)
    final promotionAmount = getPromotionAmount();
    if (detailInvoice?.saInvoice?.refType == ERefType.returnInvoice.toValue &&
        promotionAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Tiền hàng trả lại: ',
          value: promotionAmount.toStringFormat(EDoubleFormat.money)));
    }

    /// Giá trị trả lại
    final returnValueAmount = getReturnAmount();
    final promotionValueAmount = getPromotionAmount();
    if (detailInvoice?.saInvoice?.refType == ERefType.returnInvoice.toValue) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldTitle: true,
          isBoldValue: true,
          title: 'Giá trị trả lại',
          value: (returnValueAmount + promotionValueAmount)
              .toStringFormat(EDoubleFormat.money)));
    }

    /// Tiền hàng
    final totalAmount = getTotalAmount();
    final isShowTotalAmountItem =
        (totalAmount != detailInvoice?.saInvoice?.totalAmount ?? 0.0) &&
            totalAmount > 0;
    if (isShowTotalAmountItem) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldTitle: true,
          isBoldValue: true,
          title: 'Tiền hàng',
          value: totalAmount.toStringFormat(EDoubleFormat.money)));
    }

    final invoiceCoupon = detailInvoice?.invoiceCoupon;
    final isCouponApplyBeforePromotion = invoiceCoupon?.applyNumber == EApplyNumber.beforePromotion.toValue;
    if (isCouponApplyBeforePromotion) {
      _addCouponInfo(invoiceCoupon: invoiceCoupon);
    }

    /// Chi tiết khuyễn mãi
    // Chỉ hiển thị khi giá trị > 0 và có ít nhất 2 dòng con (Tính = KM theo mặt hàng + KM theo hóa đơn + Ưu đãi).
    // Nếu chỉ có 1 dòng con thì chỉ hiển thị "Khuyến mại", ẩn dòng con đi
    // Kiểm tra xem có ít nhất 2 dòng con hay ko
    final discountAmount = detailInvoice?.saInvoice?.discountAmount ?? 0;
    final itemDiscountAmount =
        detailInvoice?.saInvoice?.totalItemDiscountAmount ?? 0;
    if (discountAmount > 0 && itemDiscountAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Khuyến mại',
          value: (discountAmount + itemDiscountAmount)
              .toStringFormat(EDoubleFormat.money)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'KM theo mặt hàng',
          value: itemDiscountAmount.toStringFormat(EDoubleFormat.money)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'KM theo hóa đơn',
          value: discountAmount.toStringFormat(EDoubleFormat.money)));
    } else if (discountAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Khuyến mại',
          value: discountAmount.toStringFormat(EDoubleFormat.money)));
    } else if (itemDiscountAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Khuyến mại',
          value: itemDiscountAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Áp dụng sau khuyễn mãi
    final isCouponApplyAfterPromotion = invoiceCoupon?.applyNumber == EApplyNumber.afterPromotion.toValue;
    if (isCouponApplyAfterPromotion) {
      _addCouponInfo(invoiceCoupon: invoiceCoupon);
    }

    ///
    /// Phí đổi trả
    /// Nếu phí đổi trả > 0 và là hóa đơn đổi trả thì hiển thị dòng này
    /// Hóa đơn đổi trả giao hàng cũng hiển thị dòng này
    /// VNLONG - 06/01/2021
    ///
    final returnExchangeAmount =
        detailInvoice?.saInvoice?.returnExchangeAmount ?? 0;
    final isShowReturnExchangeAmount = returnExchangeAmount > 0 &&
        (detailInvoice?.saInvoice?.refType == ERefType.returnInvoice.toValue &&
            detailInvoice?.saInvoice?.refType == ERefType.delivery.toValue);
    if (isShowReturnExchangeAmount) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldTitle: true,
          isBoldValue: true,
          titleFontSize: 14,
          valueFontSize: 14,
          title: 'Phí đổi trả',
          value: returnAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Phí giao hàng
    if ((detailInvoice?.saInvoice?.deliveryAmount ?? 0) > 0 &&
        detailInvoice?.saInvoice?.refType == ERefType.delivery.toValue) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Phí giao hàng',
          value: (detailInvoice?.saInvoice?.deliveryAmount ?? 0)
              .toStringFormat(EDoubleFormat.money)));
    }

    // Tổng thanh toán
    final totalPayAmount = detailInvoice?.saInvoice?.totalAmount ?? 0;
    dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
        type: EInvoiceDetailType.info,
        isBoldTitle: true,
        isBoldValue: true,
        titleFontSize: 14,
        valueFontSize: 14,
        title: 'Tổng thanh toán',
        value: totalPayAmount.toStringFormat(EDoubleFormat.money)));
    dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
      type: EInvoiceDetailType.space,
    ));
    dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
      type: EInvoiceDetailType.divider,
    ));

    // Đặt cọc
    final depositAmount = detailInvoice?.saInvoice?.depositAmount ?? 0;

    /// TODO - VNLONG Thi công thêm phần xem thông tin đặt coc tại đây
    if (depositAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Đặt cọc',
          value: depositAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Voucher
    final voucherAmount = detailInvoice?.saInvoice?.voucherAmount ?? 0;
    if (voucherAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Voucher',
          value: voucherAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Thẻ NH
    final cardAmount = detailInvoice?.saInvoice?.cardAmount ?? 0;
    if (cardAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Thẻ NH',
          value: cardAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Tiền mặt
    final cashAmount = detailInvoice?.saInvoice?.cashAmount ?? 0;
    if (cashAmount != 0 &&
        detailInvoice?.saInvoice?.paymentStatus !=
            EPaymentStatus.delivering.rawValue &&
        detailInvoice?.saInvoice?.paymentStatus !=
            EPaymentStatus.waitDelivery.rawValue) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Tiền mặt',
          value: cashAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Điểm
    final pointPayment = detailInvoice?.saInvoicePayments?.firstWhere(
        (paymentItem) => paymentItem.paymentType == EPaymentType.point.toValue,
        orElse: () => null);
    if ((pointPayment?.amount ?? 0) > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Điểm (${detailInvoice?.saInvoice?.usedPoint ?? 0})',
          value:
              (pointPayment?.amount ?? 0).toStringFormat(EDoubleFormat.money)));
    }

    // Chuyển khoản
    final transferAmount = detailInvoice?.saInvoice?.transferAmount ?? 0;
    if (transferAmount != 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Chuyển khoản',
          value: transferAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Giảm nợ
    final debtReductionAmount =
        detailInvoice?.saInvoice?.debtReductionAmount ?? 0;
    if (debtReductionAmount != 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Giảm nợ',
          value:
              debtReductionAmount.abs().toStringFormat(EDoubleFormat.money)));
    }

    // Trả lại khách
    if (cashAmount < 0 || transferAmount < 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
        type: EInvoiceDetailType.info,
        title: '(Trả lại khách)',
      ));
    }

    ///
    /// Detail Trả lại khách
    /// Nếu là hóa đơn: Vẫn hiển thị khi giá trị = 0
    /// Nếu check vào ô khách không lấy tiền thừa thì hiển thị số tiền = 0.
    /// (Tính = Đặt cọc + Voucher + Thẻ NH + Tiền mặt - Tổng tiền thanh toán). Ẩn khi giá trị < 0
    /// Nếu là phiếu giao hàng thì không hiển thị
    bool isShowChangeAmount = true;
    if (detailInvoice?.saInvoice?.refType == ERefType.delivery.toValue ||
        cashAmount < 0) {
      isShowChangeAmount = false;
    }

    if ((detailInvoice?.saInvoice?.debtReductionAmount ?? 0) != 0) {
      // Nếu có giảm nợ thì ẩn dòng trả lại khách
      isShowChangeAmount = false;
    }

    final isShowReturnValue =
        isShowChangeAmount && transferAmount >= 0 && cashAmount >= 0;
    if (isShowReturnValue) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Trả lại khách',
          value: (detailInvoice?.saInvoice?.changeAmount ?? 0)
              .toStringFormat(EDoubleFormat.money)));
    }

    // Khách tip/không lấy tiền thừa
    final notTakeChangeAmount =
        detailInvoice?.saInvoice?.notTakeChangeAmount ?? 0;
    if (notTakeChangeAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldValue: true,
          isBoldTitle: true,
          titleFontSize: 14,
          valueFontSize: 14,
          title: 'Khách không lấy tiền thừa',
          value: notTakeChangeAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Bớt tiền lẻ cho khách
    final changeDeductedAmount =
        detailInvoice?.saInvoice?.changeDeductedAmount ?? 0;
    final changeAmount = (detailInvoice?.saInvoice?.changeAmount ?? 0);
    if (changeDeductedAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldValue: true,
          isBoldTitle: true,
          title: 'Bớt tiền lẻ cho khách',
          value: changeAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Khách nợ
    final debitAmount = detailInvoice?.saInvoice?.debitAmount ?? 0;
    if (debitAmount > 0) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldValue: true,
          isBoldTitle: true,
          titleFontSize: 14,
          valueFontSize: 14,
          title: 'Khách nợ',
          value: debitAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Còn phải thu
    // Còn phải thu chỉ hiển thị khi là hóa đơn giao hàng
    final remainAmount = detailInvoice?.saInvoice?.remainAmount ?? 0;
    final isShowRemainAmount = remainAmount > 0 &&
        detailInvoice?.saInvoice?.refType == ERefType.delivery.toValue &&
        detailInvoice?.saInvoice?.paymentStatus !=
            EPaymentStatus.invoiceDone.rawValue;
    if (isShowRemainAmount) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldValue: true,
          isBoldTitle: true,
          titleFontSize: 14,
          valueFontSize: 14,
          title: 'Còn phải thu',
          value: remainAmount.toStringFormat(EDoubleFormat.money)));
    }

    // Thu hộ
    double codAmount = detailInvoice?.saInvoice?.remainAmount ?? 0;
    if (detailInvoice?.saInvoice?.isReceiveCOD == true) {
      codAmount = detailInvoice?.saInvoice?.receiveAmount ?? 0;
    }
    if (detailInvoice?.saInvoice?.isCOD == true) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldValue: true,
          isBoldTitle: true,
          titleFontSize: 14,
          valueFontSize: 14,
          title: 'Thu hộ',
          value: codAmount.toStringFormat(EDoubleFormat.money)));
    }

    // HĐ được KM
    final isHavePromotion = listPromotionName.isNotEmpty;
    if (isHavePromotion) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
        type: EInvoiceDetailType.info,
        isBoldTitle: true,
        title: 'HĐ đã được KM: ',
      ));

      listPromotionName.forEach((promotionItem) {
        dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: promotionItem ?? '',
        ));
      });
    }

    // Thông tin điểm
    _buildPointInfo();
  }

  ///
  /// Thông tin điểm tích lũy
  ///
  void _buildPointInfo() {
    final invoice = detailInvoice?.saInvoice;
    final addPoint = (invoice?.addPoint ?? 0);
    final availablePoint = (invoice?.availablePoint ?? 0);
    final usedPoint = (invoice?.usedPoint ?? 0);
    final currentPoint = availablePoint + addPoint - usedPoint;

    // Add điểm nếu có thông tin
    // Case thời gian áp dụng tích điểm chưa đến thì service addPoint sẽ trả về AvailablePoint = 0
    // và AddPoint == 0 --> Check AvailablePoint > 0
    final isDisplayPointInfo =
        (addPoint > 0 || availablePoint > 0) && (usedPoint > 0 || addPoint > 0);

    if (isDisplayPointInfo) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
        type: EInvoiceDetailType.info,
        isBoldTitle: true,
        titleFontSize: 14,
        title: 'Điểm tích lũy',
      ));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'Điểm ban đầu',
          value: availablePoint
              .toDouble()
              .toStringFormat(EDoubleFormat.quantity)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'Cộng điểm',
          value: addPoint.toDouble().toStringFormat(EDoubleFormat.quantity)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'Điểm sử dụng',
          value: usedPoint.toDouble().toStringFormat(EDoubleFormat.quantity)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isChild: true,
          title: 'Điểm còn lại',
          value:
              currentPoint.toDouble().toStringFormat(EDoubleFormat.quantity)));
    }
  }

  ///
  /// Build dữ liệu header của hóa đơn
  /// VNLONG - 11/01/2021
  ///
  void buildHeaderInvoice() {
    /// Build header
    // Tiêu đề hóa đơn
    dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
      type: EInvoiceDetailType.header,
    ));

    dataInvoiceDisplay
        .add(InvoiceDetailItemDisplay(type: EInvoiceDetailType.space));

    /// Thông tin hóa đơn
    // Ngày hóa đơn
    if (detailInvoice?.saInvoice?.refDate != null) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isUsedOneColumn: true,
          title: 'Ngày: ',
          isBoldTitle: true,
          value: DateTimeFormatHelper.formatDate2String(
              detailInvoice?.saInvoice?.refDate?.toLocal() ?? DateTime.now(),
              format: DateTimeFormatConstant.DD_MM_YYYY_HH_MM_24)));
    }

    // Trả hàng cho hóa đơn số
    if (getContentReturnExchange().isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Trả hàng cho hóa đơn số: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: getContentReturnExchange()));
    }

    // Bán hàng
    if (detailInvoice?.saInvoice?.employeeName?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Bán hàng: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.employeeName ?? ''));
    }

    // Thu ngân
    if (detailInvoice?.saInvoice?.cashierName?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Thu ngân: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.cashierName ?? ''));
    }

    // Kênh bán hàng
    if (detailInvoice?.saInvoice?.saleChannelName?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Kênh bán hàng: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.saleChannelName ?? ''));
    }

    // Khách hàng Hoá đơn
    if (detailInvoice?.saInvoice?.customerName?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'KH: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.customerName ?? ''));
    }

    // Số điện thoại khách hàng
    if (detailInvoice?.saInvoice?.customerTel?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'SĐT: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.customerTel ?? ''));
    }

    // Ngày giao hàng
    if (detailInvoice?.saInvoice?.deliveryDate != null) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Ngày giao hàng: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: DateTimeFormatHelper.formatDate2String(
              detailInvoice?.saInvoice?.deliveryDate,
              format: DateTimeFormatConstant.DD_MM_YYYY)));
    }

    // Địa chỉ giao hàng
    final isShowAddress =
        detailInvoice?.saInvoice?.deliveryAddress?.isEmptyOrNull == false &&
            detailInvoice?.saInvoice?.refType == ERefType.delivery.toValue;
    if (isShowAddress) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Đ/c: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.deliveryAddress ?? ''));
    }

    // Ghi chú hóa đơn
    if (detailInvoice?.saInvoice?.description?.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          title: 'Ghi chú: ',
          isBoldTitle: true,
          isUsedOneColumn: true,
          value: detailInvoice?.saInvoice?.description ?? ''));
    }

    dataInvoiceDisplay
        .add(InvoiceDetailItemDisplay(type: EInvoiceDetailType.space));
  }


  /// 
  /// Thông tin mã ưu đãi
  /// 
  void _addCouponInfo({@required SAInvoiceCoupon invoiceCoupon}) {
    if (invoiceCoupon?.couponCode?.isEmptyOrNull == false &&
        (invoiceCoupon.invoiceDiscountAmount ?? 0) > 0 &&
        invoiceCoupon.promotionName.isEmptyOrNull == false) {
      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
          type: EInvoiceDetailType.info,
          isBoldTitle: true,
          isBoldValue: true,
          title: 'Mã ưu đãi (${invoiceCoupon.couponCode ?? ''})',
          value: (invoiceCoupon.invoiceDiscountAmount ?? 0)
              .toStringFormat(EDoubleFormat.money)));

      dataInvoiceDisplay.add(InvoiceDetailItemDisplay(
        type: EInvoiceDetailType.info,
        isChild: true,
        title: '${invoiceCoupon.promotionName ?? ''}',
      ));
    }
  }


  ///
  /// Get title của hóa đơn theo type
  /// VNLONG - 06/01/2021
  ///
  String getTitleScreen() {
    return (detailInvoice?.saInvoice?.refType == ERefType.returnInvoice.toValue
            ? 'Hóa đơn đổi trả'
            : 'Hóa đơn')
        .toUpperCase();
  }

  ///
  /// Lấy trạng thái của hóa đơn
  /// VNLONG - 06/01/2021
  ///
  EPaymentStatus getStatusInvoice() {
    final paymentStatus = detailInvoice?.saInvoice?.paymentStatus;
    if (paymentStatus == null) return null;

    // Nếu là Hóa đơn đã thanh toán hoăc (Hóa đơn giao hàng hoàn thành + Không ghi nợ)
    if (paymentStatus == EPaymentStatus.payed.rawValue ||
        (paymentStatus == EPaymentStatus.invoiceDone.rawValue &&
            (detailInvoice?.saInvoice?.debitAmount ?? 0) == 0)) {
      return EPaymentStatus.payed;
    } else if (paymentStatus == EPaymentStatus.debit.rawValue ||
        (paymentStatus == EPaymentStatus.invoiceDone.rawValue &&
            (detailInvoice?.saInvoice?.debitAmount ?? 0) > 0)) {
      // Nếu là Hóa đơn Thu nợ hoặc (Hóa đơn giao hàng hoàn thành + Có ghi nợ)
      return EPaymentStatus.debit;
    } else if (paymentStatus == EPaymentStatus.cancelled.rawValue ||
        paymentStatus == EPaymentStatus.fail.rawValue ||
        paymentStatus == EPaymentStatus.refund.rawValue) {
      // Nếu là hóa đơn Hủy hoặc Hóa đơn giao hàng Thất bại Hoặc hóa đơn giao hàng đã chuyển hoàn
      return EPaymentStatus.cancelled;
    }

    return null;
  }

  ///
  /// Build chương trình khuyến mãi
  /// VNLONG - 07/01/2021
  ///
  void buildListPromotion() {
    // Khuyễn mãi hóa đơn
    if (detailInvoice?.saInvoice?.promotionName?.isEmptyOrNull == false) {
      listPromotionName.add(detailInvoice?.saInvoice?.promotionName ?? '');
    }
    // Khuyễn mãi theo mặt hàng
    detailInvoice?.saInvoiceDetails?.forEach((invoiceDetail) {
      if (invoiceDetail?.promotionName?.isEmptyOrNull == false) {
        final promotionName = invoiceDetail?.promotionName ?? '';
        if (!listPromotionName.contains(promotionName)) {
          listPromotionName.add(promotionName);
        }
      }
    });
  }

  ///
  /// Build thông tin của hóa đơn đổi trả nếu có
  /// VNLONG - 06/01/2021
  ///
  String getContentReturnExchange() {
    if (detailInvoice?.saInvoice?.returnExchangeRefNo?.isEmptyOrNull == false) {
      final returnExchangeBranchName =
          detailInvoice?.saInvoice?.returnExchangeBranchName ?? '';
      final spaceStr =
          returnExchangeBranchName?.isEmptyOrNull == false ? '-' : '';
      final returnExchangeRefNo =
          detailInvoice?.saInvoice?.returnExchangeRefNo ?? '';

      return '${returnExchangeRefNo} $spaceStr ${returnExchangeBranchName}';
    } else {
      return null;
    }
  }

  ///
  /// Tính tổng tiền hàng
  /// VNLONG 06/01/2021
  ///
  double getTotalAmount() {
    double totalAmount = 0;
    (detailInvoice?.saInvoiceDetails ?? [])
        .forEach((SAInvoiceDetail invoiceDetailItem) {
      if ((invoiceDetailItem?.quantity ?? 0) > 0) {
        totalAmount += invoiceDetailItem?.amount ?? 0.0;
      }
    });
    return totalAmount;
  }

  ///
  /// Tính tổng tiền trả lại khách
  /// VNLONG 06/01/2021
  ///
  double getReturnAmount() {
    double returnAmount = 0;
    (detailInvoice?.saInvoiceDetails ?? [])
        .forEach((SAInvoiceDetail invoiceDetailItem) {
      if ((invoiceDetailItem?.quantity ?? 0) < 0) {
        returnAmount += invoiceDetailItem?.amount ?? 0.0;
      }
    });
    return returnAmount;
  }

  ///
  /// Khuyến mại (Trả lại)
  /// VNLONG - 06/01/2021
  ///
  double getPromotionAmount() {
    double promotionAmount = 0;
    (detailInvoice?.saInvoiceDetails ?? [])
        .forEach((SAInvoiceDetail invoiceDetailItem) {
      if ((invoiceDetailItem?.quantity ?? 0) < 0) {
        promotionAmount += invoiceDetailItem?.discountAmount ?? 0.0;
      }
    });
    return promotionAmount;
  }
}
