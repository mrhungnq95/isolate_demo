import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/ms_base_blank_vm_builder_widget.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/invoice/view/detail_invoice_view.dart';
import 'package:MShopManager/features/transaction_history/provider/detail_invoice_view_model.dart';
import 'package:MShopManager/model/invoice/invoice_detail_item_display.dart';
import 'package:MShopManager/widget/msview/ms_circle_style_bottom_sheet_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:stacked/stacked.dart';

class DetailInvoiceViewBottomSheet extends StatefulWidget {
  final String refId;

  const DetailInvoiceViewBottomSheet({Key key, this.refId}) : super(key: key);

  @override
  _DetailInvoiceViewBottomSheetState createState() =>
      _DetailInvoiceViewBottomSheetState();
}

class _DetailInvoiceViewBottomSheetState
    extends State<DetailInvoiceViewBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return _DetailInvoiceSheetView(widget.refId);
  }
}

class _DetailInvoiceSheetView
    extends MSBaseBlankViewModelBuilder<DetailInvoiceViewModel> {
  final String refId;

  _DetailInvoiceSheetView(this.refId);

  @override
  Widget onBuildStaticChild(BuildContext context) {
    return null;
  }

  @override
  Widget onBuildUI(
      BuildContext context, DetailInvoiceViewModel model, Widget child) {
    return Container(
      padding: EdgeInsets.only(top: kVerticalSpaceWithSafeArea),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(12), topLeft: Radius.circular(12))),
      child: MSCircleStyleBottomSheetView(
          title: "Chi tiết hóa đơn",
          children: [Expanded(child: DetailInvoiceView())]),
    );
  }

  @override
  DetailInvoiceViewModel onCreateViewModel(BuildContext context) {
    return LocatorService.shared.get<DetailInvoiceViewModel>();
  }

  @override
  void onViewModelCreated(DetailInvoiceViewModel model) {
    model.fetchDataInvoice(refId);
  }
}