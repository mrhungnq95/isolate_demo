//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/features/overview/provider/overview_filter_view_model.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PeriodFilterView extends StatelessWidget {
  final ValueChanged<int> onPeriodChanged;

  const PeriodFilterView({Key key, this.onPeriodChanged}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model = context.watch<OverviewFilterViewModel>();

    return GridView.builder(
      padding: EdgeInsets.zero,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          childAspectRatio: 6 / 3,
          mainAxisSpacing: kVerticalSpaceMedium,
          crossAxisSpacing: kHorizontalSpaceSmall),
      itemBuilder: (context, index) {
        final isSelected = model.periodCategoryPosition == index;
        final item = model.periodFilterCategoryTypeList[index];

        return _ItemPeriodFilterButton(
          index: index,
          title: item.type.getTitle(),
          isSelected: isSelected,
          onPressed: (index) {
            model.periodCategoryPosition = index;

            onPeriodChanged?.call(index);
          },
        );
      },
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: model.periodFilterCategoryTypeList.length ?? 0,
    );
  }
}

class _ItemPeriodFilterButton extends StatelessWidget {
  final String title;
  final int index;
  final bool isSelected;
  final Function(int index) onPressed;

  const _ItemPeriodFilterButton(
      {Key key, this.index, this.title, this.isSelected, this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      borderRadius: 12,
      colorBackground: isSelected ? AppColor.indigo900 : AppColor.grey50,
      onPressed: () {
        onPressed(index);
      },
      child: Container(
        //margin: const EdgeInsets.only(right: kHorizontalSpaceSmall),
        alignment: Alignment.center,
        height: ScreenUtils.width - (kHorizontalSpaceLarge * 2) / 4,
        width: 78,
        child: Text(
          title,
          style: Theme.of(context).textTheme.bodyText1.copyWith(
              color: isSelected ? AppColor.white : AppColor.textDisableColor),
        ),
        decoration: BoxDecoration(
          border: Border.all(
              color: isSelected ? AppColor.indigo900 : AppColor.grey300),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
