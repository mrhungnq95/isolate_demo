//
// Created by  on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:flutter/widgets.dart';

import 'overview_icon_card_info_view.dart';

class OrderNCustomerView extends StatelessWidget {
  final OverviewOrderNCustomerObject object;
  final VoidCallback onOrderPressed;
  final VoidCallback onCustomerPressed;
  const OrderNCustomerView(
      {Key key,
      this.object,
      @required this.onOrderPressed,
      @required this.onCustomerPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: IconCardInfoView(
          onPressed: onOrderPressed,
          viewType: EOverviewSheetType.order,
          imageAssetName: AppResources.icOrder,
          title: "Đơn hàng",
          diff: object.orderDiff,
          description: object.orderQuantity,
          isShowRightIcon: false,
        )),
        kHorizontalSpaceSmallBox,
        Expanded(
            child: IconCardInfoView(
                onPressed: onCustomerPressed,
                viewType: EOverviewSheetType.customer,
                imageAssetName: AppResources.icCustomer,
                title: "Khách hàng",
                diff: object.customerDiff,
                description: object.customerQuantity,
                isShowRightIcon: false)),
      ],
    );
  }
}
