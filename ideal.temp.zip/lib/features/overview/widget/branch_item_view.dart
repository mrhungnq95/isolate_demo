import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/overview/widget/overview_header_sheet.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/msview/ms_card_shadow_view.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';

class SummaryBranchItemView extends StatelessWidget {
  final String title;
  final double totalInvoice;
  final double totalAmount;
  final VoidCallback onSharePressed;

  const SummaryBranchItemView(
      {Key key,
      this.title,
      this.totalInvoice,
      this.totalAmount,
      @required this.onSharePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSCardShadowView(
        height: 160,
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        child: Column(
          children: [
            Row(
              children: [
                Image.asset(
                  AppResources.icCoinCard,
                  width: 40,
                  height: 40,
                ),
                kHorizontalSpaceLargeBox,
                Column(
                  children: [
                    Text(
                      title ?? "",
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                    Row(
                      children: [
                        TextValueBorderView(
                            value: NumberFormatHelper.shared
                                .formatQuantity(totalInvoice)),
                        kHorizontalSpaceLargeBox,
                        Text(
                          NumberFormatHelper.shared.formatQuantity(totalAmount),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .headline2
                              .copyWith(fontSize: 23),
                        )
                      ],
                    )
                  ],
                ),
                GestureDetector(
                  onTap: onSharePressed,
                  child: Image.asset(
                    AppResources.icShare,
                    width: 25,
                    height: 25,
                    color: AppColor.grey700,
                    fit: BoxFit.fill,
                  ),
                )
              ],
            ),
            Divider(
              height: 1,
              thickness: 1,
              color: AppColor.grey300,
            ),
            _ReportItemCompareView(title: "So với hôm qua"),
            _ReportItemCompareView(title: "So với ngày này tuần trước"),
          ],
        ));
  }
}

class BranchItemView extends StatelessWidget {
  final String title;
  final double totalInvoice;
  final double totalAmount;

  const BranchItemView(
      {Key key, this.title, this.totalInvoice, this.totalAmount})
      : super(key: key);

  String _getTotalAmount() {
    return totalAmount != null
        ? NumberFormatHelper.shared.formatQuantity(totalAmount)
        : "45.250.000";
  }

  String _getTotalInvoice() {
    return totalInvoice != null
        ? NumberFormatHelper.shared.formatQuantity(totalInvoice)
        : "123";
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: kVerticalSpaceSmall),
      child: MSCardShadowView(
          height: 160,
          padding: const EdgeInsets.all(kVerticalSpaceLarge),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title ?? "Chi nhánh Trần Duy Hưng",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyText2,
              ),
              kVerticalSpaceSmallBox,
              Row(
                children: [
                  TextValueBorderView(value: _getTotalInvoice()),
                  kHorizontalSpaceLargeBox,
                  Text(
                    _getTotalAmount(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context)
                        .textTheme
                        .headline2
                        .copyWith(fontSize: 23, color: AppColor.primaryColor),
                  )
                ],
              ),
              kVerticalSpaceSmallBox,
              Divider(
                height: 1,
                thickness: 1,
                color: AppColor.grey300,
              ),
              kVerticalSpaceSmallBox,
              Expanded(
                  child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _ReportItemCompareView(title: "So với hôm qua"),
                  _ReportItemCompareView(title: "So với ngày này tuần trước"),
                ],
              ))
            ],
          )),
    );
  }
}

class _ReportItemCompareView extends StatelessWidget {
  final String title;
  final ReportCompareResult diff;

  const _ReportItemCompareView({Key key, this.title, this.diff})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 2,
          child: Text(title ?? "",
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Theme.of(context).textTheme.bodyText1),
        ),
        kHorizontalSpaceSmallBox,
        Expanded(
            flex: 1,
            child: FluctuationsView(
              diff: diff ?? ReportCompareResult(),
            ))
      ],
    );
  }
}
