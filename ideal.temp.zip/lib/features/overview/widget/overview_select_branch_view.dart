//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/enums/enum_branch_filter.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/widget/checkbox_title_view.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/item_radio_title_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_card_shadow_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';
import 'package:tuple/tuple.dart';

class SelectBranchView extends StatelessWidget {
  final EOverviewBranchFilter branchFilter;

  final List<Branch> branchList;
  final List<Branch> branchSelectedList;

  const SelectBranchView(
      {Key key,
      @required this.branchFilter,
      @required this.branchList,
      @required this.branchSelectedList})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.of(context).pop();
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: ExpandedView.both(
          child: Container(
            padding: EdgeInsets.all(kVerticalSpaceLarge),
            margin: const EdgeInsets.only(top: kToolbarHeight),
            child: Material(
              color: Colors.transparent,
              elevation: 0.0,
              child: Wrap(
                children: [
                  _SelectBranchContentView(
                    branchFilter: branchFilter,
                    branchList: branchList,
                    branchSelectedList: branchSelectedList,
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SelectBranchViewModel extends MSBaseViewModel {
  EOverviewBranchFilter _branchFilter;
  EOverviewBranchFilter get branchFilter => _branchFilter;

  List<Branch> _branchSelectedList = [];
  List<Branch> get branchSelectedList => _branchSelectedList;

  bool _isGroupBranchExpanded = false;
  bool get isGroupBranchExpanded => _isGroupBranchExpanded;
  set isGroupBranchExpanded(bool newValue) {
    _isGroupBranchExpanded = newValue;
    notifyListeners();
  }

  SelectBranchViewModel(
      EOverviewBranchFilter branchFilter, List<Branch> branchSelectedList) {
    this._branchFilter = branchFilter;
    this._branchSelectedList = branchSelectedList;
    if (branchFilter == EOverviewBranchFilter.groupBranch) {
      this._isGroupBranchExpanded = true;
    }
  }

  ///
  /// Chọn/bỏ chọn cửa hàng
  /// [branch] cửa hàng
  ///
  void performSelectBranch(Branch branch) {
    if (branchSelectedList?.contains(branch) == true) {
      branchSelectedList?.remove(branch);
    } else {
      branchSelectedList?.add(branch);
    }
    notifyListeners();
  }

  ///
  /// Chọn Toàn chuỗi
  ///
  void performChainBranch() {
    _branchFilter = EOverviewBranchFilter.allBranch;
    branchSelectedList?.clear();
    _isGroupBranchExpanded = false;

    notifyListeners();
  }

  ///
  /// Chọn Nhóm cửa hàng
  ///
  void performChooseGroupBranch() {
    _branchFilter = EOverviewBranchFilter.groupBranch;
    _isGroupBranchExpanded = true;

    notifyListeners();
  }

  ///
  /// Kiểm tra xem Branch có được chọn không?
  /// [branch] Branch cần kiểm tra
  ///
  bool isBranchSelected(Branch branch) {
    return branchSelectedList?.contains(branch) == true;
  }
}

class _SelectBranchContentView extends StatelessWidget {
  final EOverviewBranchFilter branchFilter;
  final List<Branch> branchList;
  final List<Branch> branchSelectedList;

  const _SelectBranchContentView(
      {Key key,
      @required this.branchFilter,
      @required this.branchList,
      @required this.branchSelectedList})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        /// Overwrite
      },
      child: MSCardShadowView(
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        child: ViewModelBuilder<SelectBranchViewModel>.reactive(
            builder: (context, model, child) {
              return Column(
                children: [
                  Visibility(
                      visible: true,
                      child: ItemRadioTitle(
                        title: EOverviewBranchFilter.allBranch.getTitle(),
                        value: EOverviewBranchFilter.allBranch,
                        groupValue: model.branchFilter,
                        onChanged: (value) {
                          context
                              .read<SelectBranchViewModel>()
                              .performChainBranch();
                        },
                      )),
                  ItemRadioTitle(
                    title: EOverviewBranchFilter.groupBranch.getTitle(),
                    value: EOverviewBranchFilter.groupBranch,
                    groupValue: model.branchFilter,
                    onChanged: (value) {
                      context
                          .read<SelectBranchViewModel>()
                          .performChooseGroupBranch();
                    },
                  ),
                  ExpandedSection(
                    child: SizedBox(
                      height: 280,
                      child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: kHorizontalSpaceLarge),
                          child: ListView.builder(
                            padding: EdgeInsets.zero,
                            itemBuilder: (context, index) {
                              final branch = branchList[index];
                              return CheckboxTitle(
                                title: Text(
                                  branch.branchName,
                                  style: Theme.of(context).textTheme.bodyText1,
                                ),
                                isChecked: model.isBranchSelected(branch),
                                onChanged: (value) {
                                  context
                                      .read<SelectBranchViewModel>()
                                      .performSelectBranch(branch);
                                },
                              );
                            },
                            itemCount: branchList.length,
                          )),
                    ),
                    expand: model.isGroupBranchExpanded,
                  ),
                  kVerticalSpaceLargeBox,
                  ExpandedView.horizontal(
                      child: MSButton(
                          onPressed: () {
                            NavigationHelper.shared.pop(
                                data:
                                    Tuple2<EOverviewBranchFilter, List<Branch>>(
                                        model.branchFilter,
                                        model.branchSelectedList));
                          },
                          label: "Đồng ý"))
                ],
              );
            },
            viewModelBuilder: () =>
                SelectBranchViewModel(branchFilter, branchSelectedList)),
      ),
    );
  }
}
