//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/widget/msview/ms_card_shadow_view.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class OrderPendingView extends StatelessWidget {
  final OverviewTitleNListValueObject object;

  const OrderPendingView({Key key, this.object}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MSCardShadowView(
        margin: const EdgeInsets.only(top: kVerticalSpaceLarge),
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              object.title,
              style: Theme.of(context)
                  .textTheme
                  .bodyText2
                  .copyWith(fontWeight: FontWeight.bold),
            ),
            kVerticalSpaceSmallBox,
            ListView.builder(
              padding: EdgeInsets.zero,
              itemBuilder: (context, position) {
                var item = object.childList[position];
                return _ItemOrderPendingView(
                  object: item,
                );
              },
              itemCount: object.childList.length,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
            )
          ],
        ));
  }
}

class _ItemOrderPendingView extends StatelessWidget {
  final ValuePropertyObject object;

  const _ItemOrderPendingView({Key key, this.object}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35,
      color: AppColor.white,
      child: Row(
        children: [
          Expanded(
              child: Text(object.title,
                  style: Theme.of(context).textTheme.bodyText1)),
          TextValueBorderView(
            value: object.quantity,
            backgroundColor: AppColor.indigo900,
            textColor: AppColor.white,
          ),
          kHorizontalSpaceSmallBox,
          Icon(
            Icons.chevron_right,
            size: 25,
            color: AppColor.grey600,
          )
        ],
      ),
    );
  }
}
