import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/overview/widget/overview_header_sheet.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:flutter/material.dart';

class OverviewCarouselItemView extends StatelessWidget {
  /// Item
  final OverviewHeaderMasterObject item;

  const OverviewCarouselItemView({
    Key key,
    this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: AppColor.indigo900,
        ),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 23,
                  backgroundColor: AppColor.white.withOpacity(0.2),
                  child: Image.asset(
                    item?.imageAsset,
                    width: 30,
                    height: 30,
                  ),
                ),
                kHorizontalSpaceLargeBox,
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item?.header?.title ?? "",
                      style: Theme.of(context)
                          .textTheme
                          .bodyText2
                          .copyWith(color: AppColor.white),
                    ),
                    Row(
                      children: [
                        Text(
                          item?.header?.amount ?? "0",
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .headline2
                              .copyWith(fontSize: 23, color: AppColor.white),
                        ),
                        kHorizontalSpaceSmallBox,
                        Expanded(
                            child: FluctuationsView(
                          diff: item?.header?.diff,
                        ))
                      ],
                    ),
                  ],
                )),
                GestureDetector(
                  onTap: () {},
                  child: Image.asset(
                    AppResources.icShare,
                    width: 25,
                    height: 25,
                    color: AppColor.white,
                    fit: BoxFit.fill,
                  ),
                )
              ],
            ),
            kVerticalSpaceMediumBox,
            Divider(
              height: 1,
              thickness: 1,
              color: AppColor.grey300,
            ),
            ListView.builder(
              padding: EdgeInsets.zero,
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemBuilder: (context, index) {
                final object = item?.childList[index];
                return SizedBox(
                  height: 30,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        object.title,
                        style: Theme.of(context)
                            .textTheme
                            .caption
                            .copyWith(color: AppColor.white),
                      ),
                      Text(
                        object.amount,
                        textAlign: TextAlign.right,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.white, fontSize: 16),
                      )
                    ],
                  ),
                );
              },
              itemCount: item?.childList?.length ?? 0,
            )
          ],
        ));
  }
}
