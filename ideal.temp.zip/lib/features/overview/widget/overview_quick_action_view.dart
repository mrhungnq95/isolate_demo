import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';

class OverviewQuickActionView extends StatelessWidget {
  final List<QuickActionItem> quickActionList;
  final Function(QuickActionItem item) onPressed;

  const OverviewQuickActionView({Key key, this.quickActionList, this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // return Container(
    //   height: 90,
    //   margin: const EdgeInsets.symmetric(vertical: kVerticalSpaceLarge),
    //   padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
    //   child: Row(
    //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //     crossAxisAlignment: CrossAxisAlignment.center,
    //     children: quickActionList
    //         ?.map((e) => Expanded(
    //             child: ItemQuickActionView(item: e, onPressed: onPressed)))
    //         ?.toList(),
    //   ),
    // );

    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
      height: 110,
      padding: const EdgeInsets.symmetric(horizontal: kHorizontalSpaceLarge),
      child: GridView.builder(
        padding: EdgeInsets.zero,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 66 / 80,
            mainAxisSpacing: kVerticalSpaceMedium,
            crossAxisSpacing: kHorizontalSpaceMedium),
        itemBuilder: (context, index) {
          return ItemQuickActionView(
            item: quickActionList[index],
            onPressed: (QuickActionItem item) => onPressed(item),
          );
        },
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: quickActionList?.length ?? 0,
      ),
    );
  }
}

class ItemQuickActionView extends StatelessWidget {
  final String actionImageAsset;

  final QuickActionItem item;
  final Function(QuickActionItem item) onPressed;

  const ItemQuickActionView(
      {Key key,
      @required this.item,
      @required this.onPressed,
      this.actionImageAsset})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWellView(
      colorBackground: Colors.transparent,
      borderRadius: 10,
      onPressed: () => onPressed(item),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  item.imageAssets,
                  width: 65,
                  height: 55,
                ),
                Expanded(
                  child: Text(
                    item.title ?? '',
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.caption,
                  ),
                )
              ],
            ),
          ),
          _renderActionButtonImage()
        ],
      ),
    );
  }

  ///
  /// Render nút biểu trưng cho hành động
  ///
  Widget _renderActionButtonImage() {
    if (actionImageAsset != null && actionImageAsset.isNotEmpty) {
      return Positioned(
          top: 0,
          right: 10,
          child: Image.asset(
            actionImageAsset,
            width: 25,
            height: 25,
          ));
    }
    return kSpaceShrinkBox;
  }
}
