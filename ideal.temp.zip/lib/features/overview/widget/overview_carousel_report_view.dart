import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/overview/widget/overview_carousel_item_view.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter/material.dart';

class OverviewCarouselReportView extends StatelessWidget {
  final List<OverviewHeaderMasterObject> cardItemList;

  const OverviewCarouselReportView({Key key, this.cardItemList})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      //margin: const EdgeInsets.only(top: kVerticalSpaceLarge),
      height: 230,
      child: Carousel(
        boxFit: BoxFit.cover,
        autoplay: true,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(seconds: 3),
        autoplayDuration: Duration(seconds: 5),
        dotSize: 5.0,
        dotIncreasedColor: Color(0xFFFFFFFF),
        dotBgColor: Colors.transparent,
        dotPosition: DotPosition.bottomCenter,
        dotVerticalPadding: kVerticalSpaceSmall,
        dotHorizontalPadding: kVerticalSpaceSmall,
        showIndicator: true,
        indicatorBgPadding: 1.5,
        images: cardItemList
            ?.map((e) => OverviewCarouselItemView(item: e))
            ?.toList(),
      ),
    );
  }
}
