//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/overview/provider/overview_view_model.dart';
import 'package:MShopManager/model/chart_data_source.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/chart/line_chart_view.dart';
import 'package:MShopManager/widget/chart/value_formatter/bottom_axis_formatter.dart';
import 'package:MShopManager/widget/chart/value_formatter/simple_milion_value_formater.dart';
import 'package:MShopManager/widget/header_chart_view.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:MShopManager/utils/extension/async_ext.dart';

class RevenueChartView extends StatelessWidget {
  final double receiptAmountInDay;
  final ReportCompareResult diff;
  final VoidCallback onSharePressed;
  const RevenueChartView(
      {Key key,
      @required this.receiptAmountInDay,
      this.diff,
      this.onSharePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: AppColor.indigo900,
        ),
        child: _ContentView(
            receiptAmountInDay: receiptAmountInDay,
            diff: diff,
            onSharePressed: onSharePressed));
  }
}

class _ContentView extends StatelessWidget {
  final double receiptAmountInDay;
  final ReportCompareResult diff;
  final VoidCallback onSharePressed;

  const _ContentView(
      {Key key,
      @required this.receiptAmountInDay,
      @required this.diff,
      @required this.onSharePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model = context.watch<OverviewViewModel>();

    return _ChartView(
        receiptAmountInDay: receiptAmountInDay,
        diff: diff,
        onSharePressed: onSharePressed);

    // if (model.isShowReportDataForOneDay()) {
    //   return _OneDayRevenueAmountView(
    //       receiptAmountInDay: receiptAmountInDay,
    //       diff: diff,
    //       onSharePressed: onSharePressed);
    // } else {
    //   return _ChartView(
    //       receiptAmountInDay: receiptAmountInDay,
    //       diff: diff,
    //       onSharePressed: onSharePressed);
    // }
  }
}

class _OneDayRevenueAmountView extends StatelessWidget {
  final double receiptAmountInDay;
  final ReportCompareResult diff;
  final VoidCallback onSharePressed;
  const _OneDayRevenueAmountView(
      {Key key,
      @required this.receiptAmountInDay,
      @required this.diff,
      @required this.onSharePressed})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 280,
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topRight,
            child: GestureDetector(
              onTap: onSharePressed,
              child: Image.asset(
                AppResources.icShare,
                width: 25,
                height: 25,
                color: AppColor.white,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.show_chart,
                  color: AppColor.white,
                  size: 100,
                ),
                Text("DOANH THU",
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1
                        .copyWith(color: AppColor.white)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                        NumberFormatHelper.shared
                            .formatMoney(receiptAmountInDay),
                        style: Theme.of(context)
                            .textTheme
                            .headline1
                            .copyWith(color: AppColor.white, fontSize: 28)),
                    Visibility(
                      visible: diff != null,
                      child: Row(
                        children: [
                          kHorizontalSpaceSmallBox,
                          Icon(
                            diff?.fluctuationsIcon ?? Icons.arrow_upward,
                            color: diff?.fluctuationsColor ?? Colors.green,
                            size: 15,
                          ),
                          Text(
                            diff?.fluctuationsTitle ?? "--",
                            style: Theme.of(context)
                                .textTheme
                                .bodyText1
                                .copyWith(
                                    color: diff?.fluctuationsColor ??
                                        Colors.green),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class _ChartView extends StatelessWidget {
  final double receiptAmountInDay;
  final ReportCompareResult diff;
  final VoidCallback onSharePressed;

  const _ChartView(
      {Key key,
      @required this.receiptAmountInDay,
      @required this.diff,
      @required this.onSharePressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final model = context.watch<OverviewViewModel>();
    return FutureBuilder<LineChartEntry>(
      future: model.fetchOverViewChartDataReport(),
      builder: (BuildContext context, AsyncSnapshot<LineChartEntry> snapshot) {
        var chartState = snapshot.connectionState.toChartState;

        if (chartState == EChartState.done && !snapshot.hasData) {
          chartState = EChartState.noData;
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  top: kVerticalSpaceLarge,
                  left: kVerticalSpaceLarge,
                  right: kVerticalSpaceLarge,
                  bottom: kVerticalSpaceSmall),
              child: HeaderChartView(
                title: "Doanh thu",
                amount:
                    NumberFormatHelper.shared.formatMoney(receiptAmountInDay),
                isCompare: diff != null,
                onSharePressed: onSharePressed,
                fluctuationsColor: diff?.fluctuationsColor,
                fluctuationsIcon: diff?.fluctuationsIcon,
                fluctuationsTitle: diff?.fluctuationsTitle,
              ),
            ),
            Divider(
              height: 1,
              thickness: 1,
              color: AppColor.grey300,
            ),
            LineChartView(
              key: UniqueKey(),
              state: chartState,
              noDataTitleColor: AppColor.white,
              axistTitleColor: AppColor.grey100,
              highLightColor: AppColor.white,
              axisLeftTitle: "Triệu đồng",
              axisBottomTitle: model.getAxisBottomTitle(),
              axisLeftGridColor: AppColor.grey100.withOpacity(0.2),
              circleColor: AppColor.white,
              leftAxistValueFormatter: SimpleMilionValueFormater(),
              strokeCircleColor: AppColor.white,
              lineColor: AppColor.yellow,
              textColorAxis: AppColor.white,
              textColorAxisLeft: AppColor.white,
              progressColor: AppColor.white,
              bottomAxistValueFormatter: BottomAxisValueFormater(
                  label: snapshot.data?.label,
                  type: EBottomAxisValueVisble.three),
              values: snapshot.data?.entry,
            ),
            kVerticalSpaceSmallBox
          ],
        );
      },
    );
  }
}
