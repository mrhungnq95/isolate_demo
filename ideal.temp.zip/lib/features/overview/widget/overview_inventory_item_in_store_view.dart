//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:MShopManager/widget/icon_circle_background_view.dart';
import 'package:MShopManager/widget/msview/ms_card_shadow_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class InventoryItemInStore extends StatelessWidget {
  final OverviewInventoryItemInStoreObject object;

  const InventoryItemInStore({Key key, this.object}) : super(key: key);

  Widget _childView(int flex, {String title, String description}) {
    return Builder(
      builder: (context) {
        return Expanded(
            flex: flex,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyText1),
                Text(
                  description,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2
                      .copyWith(fontWeight: FontWeight.bold),
                )
              ],
            ));
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MSCardShadowView(
      height: 80,
      margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Row(
        children: [
          IconCircleBackgroundView(imageAssetName: AppResources.icItem),
          kHorizontalSpaceMediumBox,
          Expanded(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _childView(2,
                  title: "Tồn kho", description: object.inventoryItemQuantity),
              kHorizontalSpaceSmallBox,
              _childView(3,
                  title: "Tổng giá trị",
                  description: object.inventoryItemAmount)
            ],
          )),
        ],
      ),
    );
  }
}
