import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/widget/msview/ms_circle_button.dart';
import 'package:flutter/material.dart';

class OverviewHeaderSheetView extends StatelessWidget {
  final OverviewSheetHeaderDataObject object;
  final double height;
  const OverviewHeaderSheetView({Key key, this.height, this.object})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
      height: height,
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                object.title,
                style: Theme.of(context).textTheme.bodyText2,
              ),
              Row(
                children: [
                  Text(object.amount,
                      style: Theme.of(context).textTheme.headline1.copyWith(
                          color: AppColor.indigoA200,
                          fontWeight: FontWeight.bold)),
                  kHorizontalSpaceSmallBox,
                  FluctuationsView(
                    diff: object.diff,
                  )
                ],
              ),
              Visibility(
                visible:
                    object.totalAmount != null && object.totalAmount.isNotEmpty,
                child: Container(
                  margin: const EdgeInsets.only(top: kVerticalSpaceSmall),
                  child: RichText(
                    text: TextSpan(
                        text: "Tổng: ",
                        children: [
                          TextSpan(
                              text: object.totalAmount ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText2
                                  .copyWith(fontWeight: FontWeight.bold))
                        ],
                        style: Theme.of(context).textTheme.bodyText2),
                  ),
                ),
              )
            ],
          ),
          Expanded(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              MSCircleButton(
                  elevation: 10,
                  color: AppColor.white,
                  size: 40,
                  imageAsset: AppResources.icShare,
                  imageAssetColor: AppColor.indigo900,
                  onTap: () {}),
              kHorizontalSpaceLargeBox,
              MSCircleButton(
                  elevation: 10,
                  color: AppColor.white,
                  size: 40,
                  icon: Icon(
                    Icons.clear,
                    color: Colors.red,
                  ),
                  imageAssetColor: AppColor.indigo900,
                  onTap: () {
                    Navigator.of(context).pop();
                  }),
            ],
          ))
        ],
      ),
    );
  }
}

class FluctuationsView extends StatelessWidget {
  final ReportCompareResult diff;

  const FluctuationsView({Key key, this.diff}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (diff != null) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            diff.fluctuationsIcon,
            color: diff.fluctuationsColor,
            size: 15,
          ),
          Flexible(
            child: Text(
              diff.fluctuationsTitle ?? "",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context)
                  .textTheme
                  .caption
                  .copyWith(color: diff.fluctuationsColor),
            ),
          )
        ],
      );
    }
    return kSpaceShrinkBox;
  }
}
