//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/widget/icon_circle_background_view.dart';
import 'package:MShopManager/widget/msview/ms_card_shadow_view.dart';
import 'package:flutter/material.dart';

import 'overview_header_sheet.dart';

class IconCardInfoView extends StatelessWidget {
  final EOverviewSheetType viewType;
  final String imageAssetName;
  final String title;
  final String description;
  final bool isShowRightIcon;
  final ReportCompareResult diff;
  final VoidCallback onPressed;
  const IconCardInfoView(
      {Key key,
      @required this.viewType,
      @required this.imageAssetName,
      this.title,
      this.description,
      this.diff,
      this.isShowRightIcon = true,
      this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: MSCardShadowView(
        height: 80,
        margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IconCircleBackgroundView(imageAssetName: imageAssetName),
            kHorizontalSpaceSmallBox,
            Expanded(
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    title,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.caption,
                  ),
                ),
                Row(
                  children: [
                    Text(description,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Theme.of(context)
                            .textTheme
                            .subtitle2
                            .copyWith(fontWeight: FontWeight.bold)),
                    kHorizontalSpaceSmallBox,
                    Expanded(
                        child: FluctuationsView(
                      diff: diff,
                    ))
                  ],
                ),
              ],
            )),
            Visibility(
              visible: this.isShowRightIcon,
              child: Icon(
                Icons.chevron_right,
                size: 25,
                color: AppColor.grey600,
              ),
            )
          ],
        ),
      ),
    );
  }
}
