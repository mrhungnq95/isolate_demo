//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/model/period_filter_object.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class GroupItemFilterByPeriodView extends StatelessWidget {
  final PeriodFilterCategoryType periodFilterCategoryType;
  final List<ItemPeriodFilterObject> itemPeriodFilterChild;
  final int positionSelected;
  final ValueChanged<int> onValueChanged;
  const GroupItemFilterByPeriodView(
      {Key key,
      @required this.periodFilterCategoryType,
      @required this.itemPeriodFilterChild,
      this.positionSelected = 0,
      this.onValueChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemBuilder: (context, index) {
        final itemPeriodFilter = itemPeriodFilterChild[index];

        bool isSelected =
            periodFilterCategoryType.type == EDateFilterType.custom
                ? true
                : positionSelected == index;
        if (itemPeriodFilter.isCustomizeDate) {
          return _ItemFilterSelectableView(
            title: itemPeriodFilter.title,
            description: itemPeriodFilter.description,
            index: index,
            isSelected: isSelected,
            onValueChanged: onValueChanged,
          );
        } else {
          return _ItemFilterView(
              title: itemPeriodFilter.title,
              description: itemPeriodFilter.description,
              index: index,
              onValueChanged: onValueChanged,
              isSelected: isSelected);
        }
      },
      itemCount: itemPeriodFilterChild.length,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
    );
  }
}

class _ItemFilterView extends StatelessWidget {
  final String title;
  final String description;
  final int index;
  final bool isSelected;
  final ValueChanged<int> onValueChanged;

  const _ItemFilterView(
      {Key key,
      this.index,
      this.title,
      this.description,
      this.isSelected,
      this.onValueChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        onValueChanged?.call(index);
      },
      child: Container(
        margin: const EdgeInsets.only(top: kHorizontalSpaceSmall),
        padding: const EdgeInsets.all(kVerticalSpaceLarge),
        alignment: Alignment.center,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.bodyText1.copyWith(
                        color: AppColor.textBoldColor,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    description,
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1
                        .copyWith(color: AppColor.textCaptionColor),
                  )
                ],
              ),
            ),
            Visibility(
              visible: isSelected,
              child: Icon(
                Icons.check,
                color: AppColor.indigo900,
              ),
            )
          ],
        ),
        decoration: BoxDecoration(
          color: AppColor.grey50,
          border: Border.all(color: AppColor.grey300),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}

class _ItemFilterSelectableView extends StatelessWidget {
  final String title;
  final String description;
  final int index;
  final ValueChanged<int> onValueChanged;
  final bool isSelected;

  const _ItemFilterSelectableView(
      {Key key,
      this.index,
      this.title,
      this.description,
      this.onValueChanged,
      this.isSelected})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0),
      child: InkWellView(
        onPressed: () {
          onValueChanged?.call(index);
        },
        borderRadius: 12,
        colorBackground: AppColor.grey50,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            border: Border.all(color: AppColor.grey300),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(kVerticalSpaceLarge),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: Theme.of(context).textTheme.bodyText1.copyWith(
                            color: AppColor.textBoldColor,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        description,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(color: AppColor.textCaptionColor),
                      )
                    ],
                  ),
                ),
                Image.asset(
                  AppResources.icCalendar,
                  color: isSelected ? AppColor.indigo900 : AppColor.grey600,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
