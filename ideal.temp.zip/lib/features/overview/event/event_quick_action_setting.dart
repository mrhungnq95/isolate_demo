import 'package:freezed_annotation/freezed_annotation.dart';

part 'event_quick_action_setting.freezed.dart';

@freezed
abstract class EventQuickActionSetting with _$EventQuickActionSetting {
  const factory EventQuickActionSetting.noSelectedItem() = NoSelectedItem;
  const factory EventQuickActionSetting.noSelectable() = NoSelectable;
  const factory EventQuickActionSetting.numberOfItemShouldNotBeLessThanFour() =
      NumberOfItemShouldNotBeLessThanFour;
  const factory EventQuickActionSetting.ok() = Ok;
}
