// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies

part of 'event_quick_action_setting.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

/// @nodoc
class _$EventQuickActionSettingTearOff {
  const _$EventQuickActionSettingTearOff();

// ignore: unused_element
  NoSelectedItem noSelectedItem() {
    return const NoSelectedItem();
  }

// ignore: unused_element
  NoSelectable noSelectable() {
    return const NoSelectable();
  }

// ignore: unused_element
  NumberOfItemShouldNotBeLessThanFour numberOfItemShouldNotBeLessThanFour() {
    return const NumberOfItemShouldNotBeLessThanFour();
  }

// ignore: unused_element
  Ok ok() {
    return const Ok();
  }
}

/// @nodoc
// ignore: unused_element
const $EventQuickActionSetting = _$EventQuickActionSettingTearOff();

/// @nodoc
mixin _$EventQuickActionSetting {
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result noSelectedItem(),
    @required Result noSelectable(),
    @required Result numberOfItemShouldNotBeLessThanFour(),
    @required Result ok(),
  });
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result noSelectedItem(),
    Result noSelectable(),
    Result numberOfItemShouldNotBeLessThanFour(),
    Result ok(),
    @required Result orElse(),
  });
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result noSelectedItem(NoSelectedItem value),
    @required Result noSelectable(NoSelectable value),
    @required
        Result numberOfItemShouldNotBeLessThanFour(
            NumberOfItemShouldNotBeLessThanFour value),
    @required Result ok(Ok value),
  });
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result noSelectedItem(NoSelectedItem value),
    Result noSelectable(NoSelectable value),
    Result numberOfItemShouldNotBeLessThanFour(
        NumberOfItemShouldNotBeLessThanFour value),
    Result ok(Ok value),
    @required Result orElse(),
  });
}

/// @nodoc
abstract class $EventQuickActionSettingCopyWith<$Res> {
  factory $EventQuickActionSettingCopyWith(EventQuickActionSetting value,
          $Res Function(EventQuickActionSetting) then) =
      _$EventQuickActionSettingCopyWithImpl<$Res>;
}

/// @nodoc
class _$EventQuickActionSettingCopyWithImpl<$Res>
    implements $EventQuickActionSettingCopyWith<$Res> {
  _$EventQuickActionSettingCopyWithImpl(this._value, this._then);

  final EventQuickActionSetting _value;
  // ignore: unused_field
  final $Res Function(EventQuickActionSetting) _then;
}

/// @nodoc
abstract class $NoSelectedItemCopyWith<$Res> {
  factory $NoSelectedItemCopyWith(
          NoSelectedItem value, $Res Function(NoSelectedItem) then) =
      _$NoSelectedItemCopyWithImpl<$Res>;
}

/// @nodoc
class _$NoSelectedItemCopyWithImpl<$Res>
    extends _$EventQuickActionSettingCopyWithImpl<$Res>
    implements $NoSelectedItemCopyWith<$Res> {
  _$NoSelectedItemCopyWithImpl(
      NoSelectedItem _value, $Res Function(NoSelectedItem) _then)
      : super(_value, (v) => _then(v as NoSelectedItem));

  @override
  NoSelectedItem get _value => super._value as NoSelectedItem;
}

/// @nodoc
class _$NoSelectedItem implements NoSelectedItem {
  const _$NoSelectedItem();

  @override
  String toString() {
    return 'EventQuickActionSetting.noSelectedItem()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is NoSelectedItem);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result noSelectedItem(),
    @required Result noSelectable(),
    @required Result numberOfItemShouldNotBeLessThanFour(),
    @required Result ok(),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return noSelectedItem();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result noSelectedItem(),
    Result noSelectable(),
    Result numberOfItemShouldNotBeLessThanFour(),
    Result ok(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (noSelectedItem != null) {
      return noSelectedItem();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result noSelectedItem(NoSelectedItem value),
    @required Result noSelectable(NoSelectable value),
    @required
        Result numberOfItemShouldNotBeLessThanFour(
            NumberOfItemShouldNotBeLessThanFour value),
    @required Result ok(Ok value),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return noSelectedItem(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result noSelectedItem(NoSelectedItem value),
    Result noSelectable(NoSelectable value),
    Result numberOfItemShouldNotBeLessThanFour(
        NumberOfItemShouldNotBeLessThanFour value),
    Result ok(Ok value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (noSelectedItem != null) {
      return noSelectedItem(this);
    }
    return orElse();
  }
}

abstract class NoSelectedItem implements EventQuickActionSetting {
  const factory NoSelectedItem() = _$NoSelectedItem;
}

/// @nodoc
abstract class $NoSelectableCopyWith<$Res> {
  factory $NoSelectableCopyWith(
          NoSelectable value, $Res Function(NoSelectable) then) =
      _$NoSelectableCopyWithImpl<$Res>;
}

/// @nodoc
class _$NoSelectableCopyWithImpl<$Res>
    extends _$EventQuickActionSettingCopyWithImpl<$Res>
    implements $NoSelectableCopyWith<$Res> {
  _$NoSelectableCopyWithImpl(
      NoSelectable _value, $Res Function(NoSelectable) _then)
      : super(_value, (v) => _then(v as NoSelectable));

  @override
  NoSelectable get _value => super._value as NoSelectable;
}

/// @nodoc
class _$NoSelectable implements NoSelectable {
  const _$NoSelectable();

  @override
  String toString() {
    return 'EventQuickActionSetting.noSelectable()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is NoSelectable);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result noSelectedItem(),
    @required Result noSelectable(),
    @required Result numberOfItemShouldNotBeLessThanFour(),
    @required Result ok(),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return noSelectable();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result noSelectedItem(),
    Result noSelectable(),
    Result numberOfItemShouldNotBeLessThanFour(),
    Result ok(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (noSelectable != null) {
      return noSelectable();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result noSelectedItem(NoSelectedItem value),
    @required Result noSelectable(NoSelectable value),
    @required
        Result numberOfItemShouldNotBeLessThanFour(
            NumberOfItemShouldNotBeLessThanFour value),
    @required Result ok(Ok value),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return noSelectable(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result noSelectedItem(NoSelectedItem value),
    Result noSelectable(NoSelectable value),
    Result numberOfItemShouldNotBeLessThanFour(
        NumberOfItemShouldNotBeLessThanFour value),
    Result ok(Ok value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (noSelectable != null) {
      return noSelectable(this);
    }
    return orElse();
  }
}

abstract class NoSelectable implements EventQuickActionSetting {
  const factory NoSelectable() = _$NoSelectable;
}

/// @nodoc
abstract class $NumberOfItemShouldNotBeLessThanFourCopyWith<$Res> {
  factory $NumberOfItemShouldNotBeLessThanFourCopyWith(
          NumberOfItemShouldNotBeLessThanFour value,
          $Res Function(NumberOfItemShouldNotBeLessThanFour) then) =
      _$NumberOfItemShouldNotBeLessThanFourCopyWithImpl<$Res>;
}

/// @nodoc
class _$NumberOfItemShouldNotBeLessThanFourCopyWithImpl<$Res>
    extends _$EventQuickActionSettingCopyWithImpl<$Res>
    implements $NumberOfItemShouldNotBeLessThanFourCopyWith<$Res> {
  _$NumberOfItemShouldNotBeLessThanFourCopyWithImpl(
      NumberOfItemShouldNotBeLessThanFour _value,
      $Res Function(NumberOfItemShouldNotBeLessThanFour) _then)
      : super(_value, (v) => _then(v as NumberOfItemShouldNotBeLessThanFour));

  @override
  NumberOfItemShouldNotBeLessThanFour get _value =>
      super._value as NumberOfItemShouldNotBeLessThanFour;
}

/// @nodoc
class _$NumberOfItemShouldNotBeLessThanFour
    implements NumberOfItemShouldNotBeLessThanFour {
  const _$NumberOfItemShouldNotBeLessThanFour();

  @override
  String toString() {
    return 'EventQuickActionSetting.numberOfItemShouldNotBeLessThanFour()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is NumberOfItemShouldNotBeLessThanFour);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result noSelectedItem(),
    @required Result noSelectable(),
    @required Result numberOfItemShouldNotBeLessThanFour(),
    @required Result ok(),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return numberOfItemShouldNotBeLessThanFour();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result noSelectedItem(),
    Result noSelectable(),
    Result numberOfItemShouldNotBeLessThanFour(),
    Result ok(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (numberOfItemShouldNotBeLessThanFour != null) {
      return numberOfItemShouldNotBeLessThanFour();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result noSelectedItem(NoSelectedItem value),
    @required Result noSelectable(NoSelectable value),
    @required
        Result numberOfItemShouldNotBeLessThanFour(
            NumberOfItemShouldNotBeLessThanFour value),
    @required Result ok(Ok value),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return numberOfItemShouldNotBeLessThanFour(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result noSelectedItem(NoSelectedItem value),
    Result noSelectable(NoSelectable value),
    Result numberOfItemShouldNotBeLessThanFour(
        NumberOfItemShouldNotBeLessThanFour value),
    Result ok(Ok value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (numberOfItemShouldNotBeLessThanFour != null) {
      return numberOfItemShouldNotBeLessThanFour(this);
    }
    return orElse();
  }
}

abstract class NumberOfItemShouldNotBeLessThanFour
    implements EventQuickActionSetting {
  const factory NumberOfItemShouldNotBeLessThanFour() =
      _$NumberOfItemShouldNotBeLessThanFour;
}

/// @nodoc
abstract class $OkCopyWith<$Res> {
  factory $OkCopyWith(Ok value, $Res Function(Ok) then) =
      _$OkCopyWithImpl<$Res>;
}

/// @nodoc
class _$OkCopyWithImpl<$Res> extends _$EventQuickActionSettingCopyWithImpl<$Res>
    implements $OkCopyWith<$Res> {
  _$OkCopyWithImpl(Ok _value, $Res Function(Ok) _then)
      : super(_value, (v) => _then(v as Ok));

  @override
  Ok get _value => super._value as Ok;
}

/// @nodoc
class _$Ok implements Ok {
  const _$Ok();

  @override
  String toString() {
    return 'EventQuickActionSetting.ok()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) || (other is Ok);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  Result when<Result extends Object>({
    @required Result noSelectedItem(),
    @required Result noSelectable(),
    @required Result numberOfItemShouldNotBeLessThanFour(),
    @required Result ok(),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return ok();
  }

  @override
  @optionalTypeArgs
  Result maybeWhen<Result extends Object>({
    Result noSelectedItem(),
    Result noSelectable(),
    Result numberOfItemShouldNotBeLessThanFour(),
    Result ok(),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ok != null) {
      return ok();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  Result map<Result extends Object>({
    @required Result noSelectedItem(NoSelectedItem value),
    @required Result noSelectable(NoSelectable value),
    @required
        Result numberOfItemShouldNotBeLessThanFour(
            NumberOfItemShouldNotBeLessThanFour value),
    @required Result ok(Ok value),
  }) {
    assert(noSelectedItem != null);
    assert(noSelectable != null);
    assert(numberOfItemShouldNotBeLessThanFour != null);
    assert(ok != null);
    return ok(this);
  }

  @override
  @optionalTypeArgs
  Result maybeMap<Result extends Object>({
    Result noSelectedItem(NoSelectedItem value),
    Result noSelectable(NoSelectable value),
    Result numberOfItemShouldNotBeLessThanFour(
        NumberOfItemShouldNotBeLessThanFour value),
    Result ok(Ok value),
    @required Result orElse(),
  }) {
    assert(orElse != null);
    if (ok != null) {
      return ok(this);
    }
    return orElse();
  }
}

abstract class Ok implements EventQuickActionSetting {
  const factory Ok() = _$Ok;
}
