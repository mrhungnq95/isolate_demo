//
// Created by nqhung on 04/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/features/overview/provider/overview_view_model.dart';
import 'package:MShopManager/features/overview/widget/overview_header_sheet.dart';
import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/utils/screen_utils.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:stacked/stacked.dart';

class HomeDetailSheetView extends StatelessWidget {
  final EOverviewSheetType detailSheetType;
  final OverviewViewModel overviewViewModel;
  const HomeDetailSheetView(
      {@required this.overviewViewModel, @required this.detailSheetType});

  @override
  Widget build(BuildContext context) {
    double heightHeader = (detailSheetType == EOverviewSheetType.order ||
            detailSheetType == EOverviewSheetType.customer)
        ? 100
        : 65;
    return ViewModelBuilder<OverviewViewModel>.nonReactive(
      viewModelBuilder: () => overviewViewModel,
      disposeViewModel: false,
      builder: (context, model, child) {
        return Container(
          padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topRight: Radius.circular(12), topLeft: Radius.circular(12))),
          height: ScreenUtils.height * 0.85,
          child: FutureBuilder<OverviewSheetChildDataWrapper>(
            initialData: null,
            future: model.buildDetailSheetDataSource(detailSheetType),
            builder: (context, snapShot) {
              if (snapShot.connectionState == ConnectionState.waiting &&
                  snapShot.data == null) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              return Column(
                children: [
                  OverviewHeaderSheetView(
                      height: heightHeader, object: snapShot.data.headerObject),
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.only(
                          left: kHorizontalSpaceLarge,
                          right: kHorizontalSpaceLarge,
                          bottom: kNavPaddingContent,
                          top: kVerticalSpaceSmall),
                      itemBuilder: (context, index) {
                        final dataSource = snapShot.data.childObject[index];

                        if (dataSource is ExpandedChildObject) {
                          return _ItemRevenueSectionView(dataSource);
                        } else if (dataSource is GroupPaymentTypeObject) {
                          return _GroupPaymentTypeView(dataSource);
                        } else if (dataSource is IncomingMoneyObject) {
                          return _IncomingMoneyTypeView(dataSource);
                        } else if (dataSource is OrderTypeObject) {
                          return _OrderTypeView(dataSource);
                        }

                        return SizedBox.shrink();
                        //_ItemRevenueSectionView()
                        //_GroupPaymentTypeView()
                        //_IncomingMoneyTypeView()
                        //_ItemOrderTitleView()
                      },
                      itemCount: snapShot.data.childObject.length,
                    ),
                  )
                ],
              );
            },
          ),
        );
      },
    );
  }
}

//Doanh thu ước tính =======================================
class _ItemRevenueSectionView extends StatelessWidget {
  final ExpandedChildObject object;

  _ItemRevenueSectionView(this.object);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
      decoration: BoxDecoration(
          color: AppColor.grey200, borderRadius: BorderRadius.circular(10)),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: kVerticalSpaceLarge, vertical: kVerticalSpaceSmall),
            height: 60,
            child: Row(
              children: [
                Image.asset(
                  object.imageAssets,
                  width: 36,
                  height: 36,
                  fit: BoxFit.fill,
                ),
                kHorizontalSpaceMediumBox,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        object.titleSection,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(fontSize: 13),
                      ),
                      Text(
                        object.totalAmount,
                        style: Theme.of(context).textTheme.subtitle2,
                      )
                    ],
                  ),
                ),
                TextValueBorderView(
                  value: object.totalQuantity,
                  textSize: 16,
                )
              ],
            ),
          ),
          Divider(
            height: 1,
            thickness: 1,
            color: AppColor.grey400,
          ),
          ListView.builder(
            padding: const EdgeInsets.symmetric(
                horizontal: kVerticalSpaceLarge, vertical: kVerticalSpaceSmall),
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (context, index) {
              var itemChild = object.childList[index];
              return _ItemRevenueTitleView(itemChild);
            },
            itemCount: object.childList.length,
          )
        ],
      ),
    );
  }
}

class _ItemRevenueTitleView extends StatelessWidget {
  final ValuePropertyObject object;
  const _ItemRevenueTitleView(this.object);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceSmall),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  object.title,
                  style: Theme.of(context).textTheme.bodyText1,
                ),
                Text(
                  object.amount,
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontSize: 16),
                ),
              ],
            ),
          ),
          TextValueBorderView(
            value: object.quantity,
            textSize: 16,
          )
        ],
      ),
    );
  }
}
//Doanh thu ước tính =======================================

//Tiền thu trong kì ========================================

class _GroupPaymentTypeView extends StatelessWidget {
  final GroupPaymentTypeObject object;

  _GroupPaymentTypeView(this.object);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: kVerticalSpaceMedium),
      child: GridView.builder(
        padding: EdgeInsets.zero,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 2,
            crossAxisSpacing: kHorizontalSpaceMedium,
            mainAxisSpacing: kHorizontalSpaceMedium),
        itemBuilder: (context, index) {
          var item = object.childList[index];
          return _PaymentTypeView(item);
        },
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: object.childList.length,
      ),
    );
  }
}

class _PaymentTypeView extends StatelessWidget {
  final ValuePropertyObject object;
  const _PaymentTypeView(this.object);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppColor.indigoA200.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(kVerticalSpaceLarge),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            object.title,
            style: Theme.of(context).textTheme.caption,
          ),
          kVerticalSpaceSmallBox,
          Text(
            object.amount,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.subtitle2,
          ),
        ],
      ),
    );
  }
}

class _IncomingMoneyTypeView extends StatefulWidget {
  final IncomingMoneyObject object;

  _IncomingMoneyTypeView(this.object);

  @override
  _IncomingMoneyTypeViewState createState() => _IncomingMoneyTypeViewState();
}

class _IncomingMoneyTypeViewState extends State<_IncomingMoneyTypeView> {
  bool expand = false;

  @override
  Widget build(BuildContext context) {
    return _ItemExpandable<ValuePropertyObject>(
      imageAsset: widget.object.imageAssets,
      titleSection: widget.object.titleSection,
      totalAmount: widget.object.totalAmount,
      childList: widget.object.childList,
      expand: expand,
      onExpanedPressed: () {
        setState(() {
          expand = !expand;
        });
      },
      itemBuilder: (context, object) {
        return _ItemOrderTitleView(
          object: object,
        );
      },
    );

    return Container(
      margin: const EdgeInsets.only(bottom: kVerticalSpaceMedium),
      decoration: BoxDecoration(
          border: Border.all(color: AppColor.grey300),
          color: AppColor.grey200,
          borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(kVerticalSpaceMedium),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  widget.object.imageAssets,
                  width: 30,
                  height: 30,
                ),
                kHorizontalSpaceMediumBox,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.object.titleSection,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText1
                            .copyWith(fontSize: 13)),
                    Text(widget.object.totalAmount,
                        style: Theme.of(context).textTheme.subtitle2)
                  ],
                )
              ],
            ),
          ),
          Icon(
            Icons.chevron_right,
            color: AppColor.grey600,
          )
        ],
      ),
    );
  }
}

//Tiền thu trong kì ========================================

//Đơn hàng =================================================

class _OrderTypeView extends StatefulWidget {
  final OrderTypeObject object;

  _OrderTypeView(this.object);

  @override
  _OrderTypeViewState createState() => _OrderTypeViewState();
}

class _OrderTypeViewState extends State<_OrderTypeView> {
  bool expand = false;

  @override
  Widget build(BuildContext context) {
    return _ItemExpandable<ValuePropertyObject>(
      imageAsset: widget.object.imageAssets,
      titleSection: widget.object.titleSection,
      totalAmount: widget.object.totalAmount,
      childList: widget.object.childList,
      expand: expand,
      onExpanedPressed: () {
        setState(() {
          expand = !expand;
        });
      },
      itemBuilder: (context, object) {
        return _ItemOrderTitleView(
          object: object,
        );
      },
    );
  }
}

//Đơn hàng =================================================
class _ItemExpandable<T> extends StatelessWidget {
  final VoidCallback onExpanedPressed;
  final String imageAsset;
  final String titleSection;
  final String totalAmount;
  final Widget Function(BuildContext context, T object) itemBuilder;
  final List<T> childList;
  final bool expand;

  const _ItemExpandable(
      {Key key,
      this.imageAsset,
      this.onExpanedPressed,
      this.titleSection,
      this.totalAmount,
      this.itemBuilder,
      this.childList,
      this.expand})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
      decoration: BoxDecoration(
          border: Border.all(color: AppColor.grey300),
          color: AppColor.grey200,
          borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(kVerticalSpaceMedium),
      child: Column(
        children: [
          InkWell(
            onTap: onExpanedPressed,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        imageAsset,
                        width: 36,
                        height: 36,
                      ),
                      kHorizontalSpaceMediumBox,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(titleSection,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1
                                  .copyWith(fontSize: 13)),
                          Text(totalAmount,
                              style: Theme.of(context).textTheme.subtitle2)
                        ],
                      )
                    ],
                  ),
                ),
                Visibility(
                  visible: childList != null && childList.isNotEmpty,
                  child: Icon(
                    expand
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    color: AppColor.grey600,
                  ),
                )
              ],
            ),
          ),
          _childPropertyListView()
        ],
      ),
    );
  }

  Widget _childPropertyListView() {
    return ExpandedSection(
      child: ListView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          return itemBuilder(context, childList[index]);
        },
        itemCount: childList?.length ?? 0,
      ),
      expand: expand,
    );
  }
}

class _ItemOrderTitleView extends StatelessWidget {
  final ValuePropertyObject object;

  const _ItemOrderTitleView({Key key, this.object}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: kVerticalSpaceSmall),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  object.title,
                  style: Theme.of(context).textTheme.bodyText1,
                ),
              ],
            ),
          ),
          TextValueBorderView(
            value: object.amount,
            textSize: 16,
          )
        ],
      ),
    );
  }
}
