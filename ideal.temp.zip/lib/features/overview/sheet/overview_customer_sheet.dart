import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/features/overview/provider/overview_customer_view_model.dart';
import 'package:MShopManager/features/overview/widget/overview_header_sheet.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:MShopManager/widget/text/text_value_border_view.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';

class OverviewCustomerSheetView extends StatelessWidget {
  final CustomerToday customerToday;
  const OverviewCustomerSheetView({Key key, @required this.customerToday})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<OverviewCustomerViewModel>.nonReactive(
      viewModelBuilder: () => OverviewCustomerViewModel(),
      onModelReady: (model) {
        model.initCustomerHeaderData(customerToday);
        model.fetchCustomerList();
      },
      createNewModelOnInsert: false,
      initialiseSpecialViewModelsOnce: true,
      builder: (context, model, child) {
        return _ContentView();
      },
    );
  }
}

class _ContentView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = context.watch<OverviewCustomerViewModel>();
    return Container(
      padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(12), topLeft: Radius.circular(12))),
      height: ScreenUtils.height * 0.85,
      child: Column(
        children: [
          OverviewHeaderSheetView(height: 100, object: model.itemHeader),
          Expanded(child: _CustomerListView())
        ],
      ),
    );
  }
}

class _CustomerListView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final model = context.watch<OverviewCustomerViewModel>();
    if (model.isBusy) {
      return Center(
        child: CircularProgressIndicator(),
      );
    }
    if (model.customerList.isEmpty) {
      return Center(
        child: Text(
          "Không có dữ liệu",
          style: Theme.of(context).textTheme.bodyText1,
        ),
      );
    } else {
      return SmartRefresher(
        controller: model.refreshController,
        enablePullDown: true,
        enablePullUp: true,
        onRefresh: () {
          model.fetchCustomerList();
        },
        onLoading: () {
          model.fetchCustomerList(isLoadMore: true);
        },
        child: ListView.builder(
          padding: const EdgeInsets.only(
              left: kHorizontalSpaceLarge,
              right: kHorizontalSpaceLarge,
              bottom: kVerticalSpaceSmall,
              top: kVerticalSpaceSmall),
          itemBuilder: (context, index) {
            final customer = model.customerList[index];
            return _ItemCustomerView(
              amount:
                  NumberFormatHelper.shared.formatMoney(customer.totalAmount),
              customerCode: customer.customerCode,
              customerName: customer.customerName,
              firstNameChar: customer.avatarName,
              avatarColor: customer.avatarColor,
              refDate: DateTimeFormatHelper.formatDate2String(
                  customer.createdDate,
                  format: DateTimeFormatConstant.DD_MM_YYYY),
            );
          },
          itemCount: model.customerList?.length ?? 0,
        ),
      );
    }
  }
}

// Khách hàng ==============================================
class _ItemCustomerView extends StatelessWidget {
  final String firstNameChar;
  final String customerName;
  final String customerCode;
  final String refDate;
  final String amount;
  final Color avatarColor;
  const _ItemCustomerView(
      {Key key,
      @required this.firstNameChar,
      @required this.customerName,
      @required this.customerCode,
      @required this.refDate,
      @required this.amount,
      this.avatarColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: AppColor.grey300),
          color: AppColor.grey200,
          borderRadius: BorderRadius.circular(10)),
      padding: const EdgeInsets.all(kVerticalSpaceMedium),
      margin: const EdgeInsets.only(top: kVerticalSpaceMedium),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            child: Text(
              firstNameChar ?? "",
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(color: AppColor.white),
            ),
            backgroundColor: avatarColor,
            radius: 20,
          ),
          kHorizontalSpaceMediumBox,
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        customerName ?? "",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.subtitle1,
                      ),
                      kVerticalSpaceSmallBox,
                      Text(
                        customerCode ?? "",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodyText1.copyWith(
                            fontSize: 14, color: AppColor.textDisableColor),
                      ),
                      Text(
                        refDate ?? "",
                        maxLines: 1,
                        style: Theme.of(context).textTheme.bodyText1.copyWith(
                            fontSize: 14, color: AppColor.textDisableColor),
                      )
                    ],
                  ),
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextValueBorderView(
                      value: amount ?? "0",
                    )
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Khách hàng ==============================================
