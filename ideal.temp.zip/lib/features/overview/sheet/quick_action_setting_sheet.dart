import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/mixin/ms_vm_event_validate_mixin.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/overview/event/event_quick_action_setting.dart';
import 'package:MShopManager/features/overview/provider/quick_action_setting_view_model.dart';
import 'package:MShopManager/features/overview/widget/overview_quick_action_view.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:MShopManager/widget/msview/ms_circle_style_bottom_sheet_view.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:provider/provider.dart';

class OverviewQuickActionSettingSheet extends StatelessWidget {
  const OverviewQuickActionSettingSheet({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<QuickActionSettingViewModel>.nonReactive(
        builder: (context, model, child) {
          return _ContentView();
        },
        onModelReady: (viewModel) {
          viewModel.initQuickActionList();
        },
        viewModelBuilder: () => QuickActionSettingViewModel(
            LocatorService.shared.get<QuickActionBusiness>()));
  }
}

class _ContentView extends StatefulWidget {
  @override
  _ContentViewState createState() => _ContentViewState();
}

class _ContentViewState extends State<_ContentView>
    with
        MSEventValidateListenerMixin<_ContentView, EventQuickActionSetting,
            QuickActionSettingViewModel> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: ScreenUtils.height * 0.9,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(12), topLeft: Radius.circular(12))),
      padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
      child: MSCircleStyleBottomSheetView(title: "Tùy chỉnh", children: [
        kVerticalSpaceLargeBox,
        _QuickActionSelectedView(),
        kVerticalSpaceLargeBox,
        Divider(
          thickness: 1,
          height: 1,
          color: AppColor.grey300,
        ),
        kVerticalSpaceLargeBox,
        Expanded(child: _QuickActionGridView()),
        ExpandedView.horizontal(
          child: Padding(
            padding:
                const EdgeInsets.symmetric(vertical: kHorizontalSpaceLarge),
            child: MSButton(
                onPressed: () {
                  context
                      .read<QuickActionSettingViewModel>()
                      .validateBeforeSave();
                },
                buttonColor: AppColor.primaryColor,
                textColor: AppColor.white,
                imageAssetColor: Colors.indigo,
                borderColor: AppColor.indigo900,
                label: "Lưu lại"),
          ),
        )
      ]),
    );
  }

  @override
  get validateEvent => handleValidateEvent;

  ///
  /// Xử lý event
  /// [context] context
  /// [event] sự kiện khi obs view model
  ///
  void handleValidateEvent(
      BuildContext context, EventQuickActionSetting event) {
    event?.when(
        noSelectedItem: () => showToast("Bạn chưa có phím tắt nào được chọn."),
        noSelectable: () => showToast("Số phím tắt không được vượt quá 4"),
        ok: () {
          context.read<QuickActionSettingViewModel>().saveQuickAction();
          NavigationHelper.shared.pop(data: true);
        },
        numberOfItemShouldNotBeLessThanFour: () =>
            showToast("Bạn chưa thiết lập đủ phím tắt."));
  }
}

class _QuickActionSelectedView
    extends ViewModelWidget<QuickActionSettingViewModel> {
  @override
  Widget build(BuildContext context, QuickActionSettingViewModel viewModel) {
    return GridView.builder(
      padding: EdgeInsets.zero,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          childAspectRatio: 66 / 80,
          mainAxisSpacing: kVerticalSpaceMedium,
          crossAxisSpacing: kHorizontalSpaceMedium),
      itemBuilder: (context, index) {
        return ItemQuickActionView(
          actionImageAsset: AppResources.icRedCircleRemove,
          item: viewModel.actionItemSelected[index],
          onPressed: (QuickActionItem item) {
            viewModel?.removeQuickActionFeature(item);
          },
        );
      },
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: viewModel.actionItemSelected?.length ?? 0,
    );
  }
}

class _QuickActionGridView
    extends ViewModelWidget<QuickActionSettingViewModel> {
  _QuickActionGridView();

  @override
  Widget build(BuildContext context, viewModel) {
    return GridView.builder(
      padding: EdgeInsets.zero,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          childAspectRatio: 66 / 80,
          mainAxisSpacing: kVerticalSpaceMedium,
          crossAxisSpacing: kHorizontalSpaceMedium),
      itemBuilder: (context, index) {
        return ItemQuickActionView(
          actionImageAsset: AppResources.icGreenCircleAdd,
          item: viewModel.allQuickActionList[index],
          onPressed: (QuickActionItem item) {
            viewModel?.addQuickActionFeature(item);
          },
        );
      },
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: viewModel.allQuickActionList?.length ?? 0,
    );
  }
}
