import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/overview/provider/quick_action_view_model.dart';
import 'package:MShopManager/features/overview/widget/overview_quick_action_view.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/widget/msview/ms_circle_style_bottom_sheet_view.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class OverviewQuickActionSheet extends StatelessWidget {
  final Function(QuickActionItem item) onPressed;

  const OverviewQuickActionSheet({Key key, this.onPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<QuickActionViewModel>.nonReactive(
        builder: (context, model, child) {
          return Container(
            height: ScreenUtils.height * 0.8,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(12),
                    topLeft: Radius.circular(12))),
            padding: const EdgeInsets.only(top: kVerticalSpaceMedium),
            child: MSCircleStyleBottomSheetView(title: "Phím tắt", children: [
              kVerticalSpaceLargeBox,
              Expanded(
                  child: _QuickActionGridView(
                onPressed: onPressed,
              ))
            ]),
          );
        },
        onModelReady: (viewModel) {
          viewModel.fetchQuickActionList();
        },
        viewModelBuilder: () => QuickActionViewModel(
            LocatorService.shared.get<QuickActionBusiness>()));
  }
}

class _QuickActionGridView extends ViewModelWidget<QuickActionViewModel> {
  final Function(QuickActionItem item) onPressed;

  _QuickActionGridView({this.onPressed});

  @override
  Widget build(BuildContext context, viewModel) {
    return viewModel.obs(
        widget: (state) => GridView.builder(
              padding: EdgeInsets.zero,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  childAspectRatio: 66 / 80,
                  mainAxisSpacing: kVerticalSpaceMedium,
                  crossAxisSpacing: kHorizontalSpaceMedium),
              itemBuilder: (context, index) {
                return ItemQuickActionView(
                  item: state[index],
                  onPressed: (QuickActionItem item) => onPressed(item),
                );
              },
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: state?.length ?? 0,
            ));
  }
}
