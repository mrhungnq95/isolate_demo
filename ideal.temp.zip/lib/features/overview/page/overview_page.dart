//
// Created by nqhung on 02/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/app/routes/app_route_name.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/enums/enum_branch_filter.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/features/overview/sheet/overview_customer_sheet.dart';
import 'package:MShopManager/features/overview/sheet/quick_action_setting_sheet.dart';
import 'package:MShopManager/features/overview/sheet/quick_action_sheet.dart';
import 'package:MShopManager/features/overview/sheet/overview_sheet_view.dart';
import 'package:MShopManager/features/overview/widget/overview_carousel_report_view.dart';
import 'package:MShopManager/features/overview/widget/overview_quick_action_view.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/overview/abstract_overview_data_object.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/widget/inkwell_view.dart';
import 'package:flutter/material.dart';
import 'package:MShopManager/app/app_color.dart';
import 'package:MShopManager/app/app_spacing.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/overview/provider/overview_view_model.dart';
import 'package:MShopManager/features/overview/widget/overview_icon_card_info_view.dart';
import 'package:MShopManager/features/overview/widget/overview_inventory_item_in_store_view.dart';
import 'package:MShopManager/features/overview/widget/overview_order_and_customer_view.dart';
import 'package:MShopManager/features/overview/widget/overview_order_pending_view.dart';
import 'package:MShopManager/features/overview/widget/overview_revenue_chart_view.dart';
import 'package:MShopManager/features/overview/widget/overview_select_branch_view.dart';
import 'package:MShopManager/widget/info_filter_view.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:stacked/stacked.dart';
import 'package:tuple/tuple.dart';

class OverviewPage extends StatefulWidget {
  @override
  _OverviewPageState createState() => _OverviewPageState();

  static _OverviewPageState of(BuildContext context, {bool root = false}) =>
      root
          ? context.findRootAncestorStateOfType<_OverviewPageState>()
          : context.findAncestorStateOfType<_OverviewPageState>();
}

class _OverviewPageState extends State<OverviewPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<OverviewViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<OverviewViewModel>(),
      reactive: true,
      onViewModelReady: (model) {
        model.fetchOverViewDataReport();
      },
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          key: UniqueKey(),
          reactiveNavigationBottomBar: true,
          titleExpanded: "",
          customFloatingToolbar: _AppBarCollapseView(),
          heightToolbar: 115,
          expandedHeight: 30,
          bottomExpanded: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _BranchSelectionView(isExpanded: true),
              kVerticalSpaceLargeBox,
              _BottomAppBar(isExpanded: true)
            ],
          ),
          body: _OverviewContentReportView(),
        );
      },
    );
  }
}

class _OverviewContentReportView extends ViewModelWidget<OverviewViewModel> {
  ///
  /// Show bottom sheet hiển thị dữ liệu của từng loại thông tin báo cáo
  /// theo [EOverviewSheetType] type
  ///
  void showModalBottomSheetByViewType(
      BuildContext rootContext, EOverviewSheetType type) {
    showCupertinoModalBottomSheet(
      expand: true,
      context: rootContext,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      builder: (context) => HomeDetailSheetView(
          overviewViewModel: rootContext.read<OverviewViewModel>(),
          detailSheetType: type),
    );
  }

  ///
  /// Show bottom sheet hiển thị dữ liệu DS khách hàng
  /// [rootContext] context của widget tree hiện tại
  /// [customerToday]
  ///
  void showModalCustomerSheetView(
      BuildContext rootContext, CustomerToday customerToday) {
    /// Khách hàng thì hiển thị riêng ra một
    /// Bottom sheet khác để xử lý paging

    showCupertinoModalBottomSheet(
      expand: true,
      context: rootContext,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      builder: (context) =>
          OverviewCustomerSheetView(customerToday: customerToday),
    );
  }

  ///
  /// Hiển thị bottom sheet Lối tắt
  /// [rootContext] context của widget tree hiện tại
  /// [item] mục chức năng được chọn, nếu [type] của [item] là null -> Tuỳ chỉnh
  ///
  ///
  void showModelQuickActionSheetView(
      BuildContext rootContext, QuickActionItem item) async {
    switch (item.type) {
      case EFeatureType.import_items:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.return_items:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.store_house:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.stock_issue:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.checking:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.items:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.customer:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.promotion:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.balance:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.provider:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.order_online:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.order_ocm:
        showToastFeatureDeveloping();
        break;
      case EFeatureType.other:

        ///
        /// Show bottom hiển thị Tất cả các DS Phím tắt
        ///
        final result = await showModalBottomSheet(
          //expand: false,
          context: rootContext,
          elevation: 10,
          useRootNavigator: true,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          builder: (context) => OverviewQuickActionSheet(
            onPressed: (item) {
              if (item.type == null) {
                NavigationHelper.shared.pop(data: true);
              } else {
                showModelQuickActionSheetView(context, item);
              }
            },
          ),
        );

        if (result == true) {
          final result = await showModalBottomSheet(
            //expand: false,
            elevation: 10,
            isScrollControlled: true,
            context: rootContext,
            useRootNavigator: true,
            backgroundColor: Colors.transparent,
            builder: (context) => OverviewQuickActionSettingSheet(),
          );

          if (result == true) {
            /// Khi thay đổi về Phím tắt thì coi như là thay đổi về thiết lập bộ lọc
            /// => Gọi chung 1 hàm Re-load
            rootContext.read<OverviewViewModel>().fetchReportWithNewFilter();
          }
        }
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context, OverviewViewModel model) {
    return model.obs(widget: (List<OverviewDataObject> state) {
      return SmartRefresher(
        controller: model.refreshController,
        enablePullDown: true,
        enablePullUp: false,
        onRefresh: () {
          model.fetchOverViewDataReport();
        },
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(
              horizontal: 0, vertical: kVerticalSpaceLarge),
          itemBuilder: ((contex, index) {
            final item = state[index];
            if (item is OverviewQuickActionObject) {
              return OverviewQuickActionView(
                quickActionList: item.quickActionList,
                onPressed: (item) =>
                    showModelQuickActionSheetView(context, item),
              );
            } else if (item is OverviewHeaderObject) {
              return OverviewCarouselReportView(
                cardItemList: item.childList,
              );
            } else if (item is OverviewChartObject) {
              return RevenueChartView(
                  diff: item.diff,
                  receiptAmountInDay:
                      item.cashReceiptStatusDay.receiptAmountInDay,
                  onSharePressed: () {});
            } else if (item is OverviewTitleNValueObject) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
                child: IconCardInfoView(
                  viewType: item.viewType,
                  imageAssetName: item.imageAssets,
                  title: item.title,
                  description: item.value,
                  diff: item.diff,
                  onPressed: () {
                    showModalBottomSheetByViewType(context, item.viewType);
                  },
                ),
              );
            } else if (item is OverviewTitleNListValueObject) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
                child: OrderPendingView(object: item),
              );
            } else if (item is OverviewOrderNCustomerObject) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
                child: OrderNCustomerView(
                  object: item,
                  onCustomerPressed: () {
                    showModalCustomerSheetView(context, item.customerToday);
                  },
                  onOrderPressed: () {
                    showModalBottomSheetByViewType(
                        context, EOverviewSheetType.order);
                  },
                ),
              );
            } else if (item is OverviewInventoryItemInStoreObject) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: kVerticalSpaceLarge),
                child: InventoryItemInStore(object: item),
              );
            }
            return SizedBox.shrink();
          }),
          itemCount: state?.length ?? 0,
        ),
      );
    });
  }
}

class _BranchSelectionView extends ViewModelWidget<OverviewViewModel> {
  final isExpanded;

  _BranchSelectionView({this.isExpanded = true});

  ///
  /// Hiển thị dialog chọn Cửa hàng
  ///
  void showBranchSelectDialog(
      BuildContext contextRoot, OverviewViewModel model) async {
    final Tuple2<EOverviewBranchFilter, List<Branch>> result =
        await showGeneralDialog(
      useRootNavigator: true,
      barrierDismissible: false,
      //barrierColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.5),
      //transitionDuration: Duration(milliseconds: 400),
      context: contextRoot,
      pageBuilder: (context, anim1, anim2) {
        return SelectBranchView(
          branchFilter: model.branchFilter,
          branchList: model.allBranchList,
          branchSelectedList: model.branchSelectedList,
        );
      },
    );

    if (result != null) {
      model.branchSelectedList = result.item2;
      model.branchFilter = result.item1;
      contextRoot.read<OverviewViewModel>()?.fetchReportWithNewFilter();
    }
  }

  @override
  Widget build(BuildContext contextRoot, OverviewViewModel model) {
    return GestureDetector(
      onTap: () => showBranchSelectDialog(contextRoot, model),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            model.branchSelectTitle ?? "",
            style: Theme.of(contextRoot).textTheme.subtitle2.copyWith(
                color: isExpanded ? AppColor.white : AppColor.textBoldColor),
          ),
          Icon(
            Icons.arrow_drop_down,
            color: isExpanded ? AppColor.white : AppColor.textBoldColor,
          )
        ],
      ),
    );
  }
}

class _AppBarCollapseView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(
        horizontal: kHorizontalSpaceLarge,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: kVerticalSpaceMedium + ScreenUtils.topSafeAreaHeight,
          ),
          _BranchSelectionView(isExpanded: false),
          kVerticalSpaceMediumBox,
          Consumer<OverviewViewModel>(
            builder: (context, model, child) {
              return InkWellView(
                borderRadius: 10,
                colorBackground: AppColor.grey200,
                onPressed: () async {
                  final isFetchNewData = await Navigator.of(context,
                          rootNavigator: true)
                      .pushNamed(AppRouterName.overview_date_filter.value());

                  if (isFetchNewData == true) {
                    context
                        .read<OverviewViewModel>()
                        ?.fetchReportWithNewFilter();
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(kVerticalSpaceMedium),
                  decoration: BoxDecoration(
                      border: Border.all(color: AppColor.grey300),
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    children: [
                      Image.asset(
                        AppResources.icCalendar,
                        color: AppColor.indigo900,
                      ),
                      kHorizontalSpaceOverSmallBox,
                      Expanded(
                          child: RichText(
                              text: TextSpan(
                                  text: model.getPeriodFilterTitle(),
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyText2
                                      .copyWith(fontSize: 12),
                                  children: [
                            TextSpan(
                                text:
                                    " ${model.getPreviousPeriodFilterTitle() ?? ''} ",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1
                                    .copyWith(fontSize: 12))
                          ])))
                    ],
                  ),
                ),
              );
            },
          )
        ],
      ),
    );
  }
}

class _BottomAppBar extends ViewModelWidget<OverviewViewModel> {
  final isExpanded;

  _BottomAppBar({this.isExpanded = false});

  @override
  Widget build(BuildContext context, OverviewViewModel model) {
    return InfoFilterView(
      horizontalPadding: 0,
      title: model.getPeriodFilterTitle(),
      titleColor: isExpanded ? AppColor.white : AppColor.textColor,
      compareTitleColor:
          isExpanded ? AppColor.white : AppColor.textCaptionColor,
      isShowCompareInfo: model.isCompareTwoPeriod(),
      description: null, // model.getFetchReportDateTimeTitle(),
      compareTitle: model.getPreviousPeriodFilterTitle(),
      onFilterPressed: () async {
        final isFetchNewData = await NavigationHelper.shared
            .navigateTo(routeName: AppRouterName.overview_date_filter);

        if (isFetchNewData == true) {
          context.read<OverviewViewModel>()?.fetchReportWithNewFilter();
        }
      },
    );
  }
}
