import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/features/overview/provider/overview_chain_view_model.dart';
import 'package:MShopManager/features/overview/widget/branch_item_view.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class OverViewChainPage extends StatefulWidget {
  @override
  _OverViewChainPageState createState() => _OverViewChainPageState();
}

class _OverViewChainPageState extends State<OverViewChainPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<OverviewChainViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<OverviewChainViewModel>(),
      reactive: true,
      onViewModelReady: (model) {},
      backgroundColor: AppColor.backgroundTextField,
      brightnessColor: Brightness.dark,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          onLeadingTap: null,
          reactiveNavigationBottomBar: true,
          titleExpanded: "Toàn chuỗi",
          titleExpandedColor: AppColor.white,
          // bottomExpanded: Column(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: [_PeriodView()],
          // ),
          body: _OverviewContentReportView(),
        );
      },
    );
  }
}

class _OverviewContentReportView
    extends ViewModelWidget<OverviewChainViewModel> {
  @override
  Widget build(BuildContext context, OverviewChainViewModel viewModel) {
    return viewModel.obs(widget: (state) {
      return ListView.builder(
          padding: const EdgeInsets.symmetric(
              horizontal: kHorizontalSpaceLarge, vertical: kVerticalSpaceLarge),
          itemBuilder: ((context, index) {
            return BranchItemView();
          }),
          itemCount: 10);
    });
  }
}

// class _BottomAppBar extends ViewModelWidget<OverviewChainViewModel> {
//   final isExpanded;

//   _BottomAppBar({this.isExpanded = false});

//   @override
//   Widget build(BuildContext context, OverviewChainViewModel model) {
//     return InfoFilterView(
//       horizontalPadding: 0,
//       title: model.getPeriodFilterTitle(),
//       titleColor: isExpanded ? AppColor.white : AppColor.textColor,
//       compareTitleColor:
//           isExpanded ? AppColor.white : AppColor.textCaptionColor,
//       isShowCompareInfo: model.isCompareTwoPeriod(),
//       description: null, // model.getFetchReportDateTimeTitle(),
//       compareTitle: model.getPreviousPeriodFilterTitle(),
//       onFilterPressed: () async {
//         final isFetchNewData = await NavigationHelper.shared
//             .navigateTo(routeName: AppRouterName.overview_date_filter);

//         if (isFetchNewData == true) {
//           context.read<OverviewViewModel>()?.fetchReportWithNewFilter();
//         }
//       },
//     );
//   }
// }
