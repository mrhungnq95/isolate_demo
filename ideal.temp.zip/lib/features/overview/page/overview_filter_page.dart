//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/app/app_expose.dart';
import 'package:MShopManager/app/app_global.dart';
import 'package:MShopManager/app/app_navigation.dart';
import 'package:MShopManager/base/ms_scroll_container_animated.dart';
import 'package:MShopManager/base/v2/ms_base_cupertino_vm_widget_v2.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/features/overview/provider/overview_filter_view_model.dart';
import 'package:MShopManager/features/overview/widget/group_item_by_period_view.dart';
import 'package:MShopManager/features/overview/widget/period_filter_view.dart';
import 'package:MShopManager/widget/common/expanded_section_view.dart';
import 'package:MShopManager/widget/msview/expanded_view.dart';
import 'package:MShopManager/widget/msview/ms_button.dart';
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';

class OverviewFilterPage extends StatefulWidget {
  @override
  _OverviewFilterPageState createState() => _OverviewFilterPageState();
}

class _OverviewFilterPageState extends State<OverviewFilterPage> {
  @override
  Widget build(BuildContext context) {
    return MSBaseCupertinoWidgetBuilderV2<OverviewFilterViewModel>(
      viewModelBuilder: (context) =>
          LocatorService.shared.get<OverviewFilterViewModel>(),
      reactive: false,
      fireOnModelReadyOnce: true,
      onViewModelReady: (model) {},
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      brightnessColor: Brightness.light,
      statusBarColor: Colors.transparent,
      builder: (context, model, child) {
        return MSScrollContainerAnimated(
          titleExpanded: "Bộ lọc",
          isPrimary: false,
          onLeadingTap: () {
            NavigationHelper.shared.pop();
          },
          body: ListView(
            padding: const EdgeInsets.only(
              top: kVerticalSpaceLarge,
              bottom: 70,
              left: kHorizontalSpaceLarge,
              right: kHorizontalSpaceLarge,
            ),
            children: [
              _PeriodFilterView(),
              _CurrentItemFilterByPeriod(),
              _CompareWithPeriodSwitchView(),
            ],
          ),
          bottomContainer: ExpandedView.horizontal(
              child: Padding(
            padding: EdgeInsets.only(
                left: kHorizontalSpaceLarge,
                right: kHorizontalSpaceLarge,
                top: kHorizontalSpaceLarge,
                bottom: kVerticalSpaceWithSafeArea),
            child: MSButton(
                onPressed: () {
                  model.processFilter();
                  NavigationHelper.shared.maybePop(obj: true);
                },
                label: "Lọc"),
          )),
        );
      },
    );
  }
}

class _PeriodFilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        bottom: kHorizontalSpaceLarge,
      ),
      child: PeriodFilterView(),
    );
  }
}

class _CompareWithPeriodSwitchView extends StatelessWidget {
  _CompareWithPeriodSwitchView();

  @override
  Widget build(BuildContext context) {
    return Consumer<OverviewFilterViewModel>(builder: (context, model, child) {
      return Column(
        children: [
          Container(
            child: SwitchListTile(
              activeColor: AppColor.primaryColor,
              contentPadding: EdgeInsets.zero,
              title: Text(
                'So sánh với',
                style: Theme.of(context).textTheme.bodyText1,
              ),
              value: model.isCompareWithPreviousPeriod,
              onChanged: (bool value) {
                context
                    .read<OverviewFilterViewModel>()
                    .toggleComparePreviuosPeriod();
              },
            ),
          ),
          ExpandedSection(
            expand: model.isCompareWithPreviousPeriod,
            child: _CompareItemFilterByPeriod(),
          )
        ],
      );
    });
  }
}

class _CurrentItemFilterByPeriod extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<OverviewFilterViewModel>(
      builder: (context, viewModel, child) {
        final periodFilterCategoryType = viewModel.getPeriodFilterCategory();

        return GroupItemFilterByPeriodView(
          periodFilterCategoryType: periodFilterCategoryType,
          onValueChanged: (value) {
            final currentItem = viewModel.getItemFilterByPosition(value);

            /// Nếu chọn Tuỳ chỉnh
            if (currentItem != null &&
                periodFilterCategoryType.type == EDateFilterType.custom &&
                currentItem.isCustomizeDate) {
              final initDateTime =
                  (currentItem.type == EReportPeriodType.fromDateCustomize
                          ? currentItem.dateRange?.startDate
                          : currentItem.dateRange?.endDate) ??
                      DateTime.now();

              /// Hiển thị dialog chọn ngày
              showDatePickerDialog(
                  context: context,
                  initDateTime: initDateTime,
                  onConfirm: (dateCustomize) {
                    if (currentItem.type ==
                        EReportPeriodType.fromDateCustomize) {
                      //viewModel?.handleStartDateCustomize(
                      //    dateCustomize, currentItem);

                      viewModel?.handleDateCustomize(
                          dateCustomize, dateCustomize, currentItem);
                    }

                    if (currentItem.type == EReportPeriodType.toDateCustomize) {
                      // viewModel?.handleEndDateCustomize(
                      //    dateCustomize, currentItem);

                      viewModel?.handleDateCustomize(
                          dateCustomize, dateCustomize, currentItem);
                    }

                    viewModel?.itemFilterPosition = value;
                  });
            } else {
              viewModel?.itemFilterPosition = value;
            }
          },
          positionSelected: viewModel.itemFilterPosition,
          itemPeriodFilterChild:
              viewModel.getItemPeriodFilterListByPeriodMaster,
        );
      },
    );
  }
}

class _CompareItemFilterByPeriod extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<OverviewFilterViewModel>(
      builder: (context, viewModel, child) {
        final periodFilterCategoryType = viewModel.getPeriodFilterCategory();

        return GroupItemFilterByPeriodView(
          periodFilterCategoryType: periodFilterCategoryType,
          onValueChanged: (value) {
            final previuosItem =
                viewModel.getItemFilterPreviousByPosition(value);

            /// Nếu chọn Tuỳ chỉnh
            if (previuosItem != null && previuosItem.isCustomizeDate) {
              final initDateTime =
                  previuosItem.dateRange?.startDate ?? DateTime.now();

              if (periodFilterCategoryType.type == EDateFilterType.day ||
                  periodFilterCategoryType.type == EDateFilterType.custom) {
                /// Hiển thị dialog chọn ngày
                showDatePickerDialog(
                    context: context,
                    initDateTime: initDateTime,
                    onConfirm: (dateCustomize) {
                      viewModel?.handleDateCustomize(
                          dateCustomize, dateCustomize, previuosItem);
                      viewModel?.itemFilterPreviousPosition = value;
                    });
              } else {
                final fromDate =
                    previuosItem.dateRange?.startDate ?? DateTime.now();
                final toDate =
                    previuosItem.dateRange?.endDate ?? DateTime.now();
                showDateRangePickerDialog(
                    context: context,
                    onConfirm: (fromDate, toDate) {
                      viewModel?.handleDateCustomize(
                          fromDate, toDate, previuosItem);
                      viewModel?.itemFilterPreviousPosition = value;
                    },
                    fromDate: fromDate,
                    toDate: toDate);
              }
            } else {
              /// Reset lại dateRange của itemFilterPrevious trước đó
              /// nếu nó là ngày tháng Customize
              viewModel?.resetCustomizeDateItemFilterPrevious();
              viewModel.itemFilterPreviousPosition = value;
            }
          },
          positionSelected: viewModel.itemFilterPreviousPosition,
          itemPeriodFilterChild: viewModel.previousItemFilterList,
        );
      },
    );
  }
}
