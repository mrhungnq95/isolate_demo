//
// Created by nqhung on 06/11/2020.
//

import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/report/overview_report_business.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/enums/enum_overview_validate_result.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';
import 'package:MShopManager/model/period_filter_object.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/date_time_helper.dart';

class OverviewFilterViewModel extends MSBaseViewModel {
  /// Kỳ báo cáo: ngày, tuần, tháng, tuỳ chỉnh
  int _periodCategoryPosition = 0;
  int get periodCategoryPosition => _periodCategoryPosition;
  set periodCategoryPosition(int newIndex) {
    /// Reset lại dateRange của itemFilterPrevious trước đó
    /// nếu nó là ngày tháng Customize
    resetCustomizeDateItemFilterPrevious();

    _periodCategoryPosition = newIndex;
    _itemFilterPosition = 0;
    _itemFilterPreviousPosition = 0;

    loadItemPeriodFilterPreviousList();
    notifyListeners();
  }

  /// Thời gian cụ thể trong kì báo cáo: Hôm nay, Hôm qua, 7 ngày gần đây, tuần này
  int _itemFilterPosition = 0;
  int get itemFilterPosition => _itemFilterPosition;
  set itemFilterPosition(int newIndex) {
    _itemFilterPosition = newIndex;
    loadItemPeriodFilterPreviousList();
    notifyListeners();
  }

  /// Thời gian cụ thể trong kì báo cáo để đối chiếu, so sánh
  int _itemFilterPreviousPosition = 0;
  int get itemFilterPreviousPosition => _itemFilterPreviousPosition;
  set itemFilterPreviousPosition(int newIndex) {
    /// Set lại vị trí mới được chọn
    _itemFilterPreviousPosition = newIndex;

    notifyListeners();
  }

  /// Bật cờ so sánh: Kì báo cáo hiện tại, kì báo cáo đối chiếu
  bool _isCompareWithPreviousPeriod = false;
  bool get isCompareWithPreviousPeriod => _isCompareWithPreviousPeriod;

  List<PeriodFilterCategoryType> _periodFilterCategoryTypeList = [];
  List<PeriodFilterCategoryType> get periodFilterCategoryTypeList =>
      _periodFilterCategoryTypeList;

  List<ItemPeriodFilterObject> _previousItemFilterList = [];
  List<ItemPeriodFilterObject> get previousItemFilterList =>
      _previousItemFilterList;

  ////
  /// Object thông tin Bộ lọc
  ///
  OverViewFilterSettings _filterSetting;

  OverViewReportBusiness _overViewDateFilterBusiness;

  OverviewFilterViewModel(OverViewReportBusiness overViewDateFilterBusiness)
      : super() {
    this._overViewDateFilterBusiness = overViewDateFilterBusiness;

    _periodFilterCategoryTypeList =
        _overViewDateFilterBusiness.getPeriodFilterList();

    /// Load thiết lập từ cache hoặc tạo mới
    _loadOrCreateDefaultFilterSetting();

    /// Bind dữ liệu đã cache lên các biến cho hiển thị UI
    _bindFilterSetting();
  }

  ///
  /// Load thiết lập từ cache hoặc tạo mới
  ///
  void _loadOrCreateDefaultFilterSetting() {
    /// Đọc filterSetting OverViewFilterSettings từ cache qua CommonRepository
    _filterSetting = filterSettingRepository?.getOverViewFilterSettings();

    /// Hoặc tạo mới:
    if (_filterSetting == null) {
      /// Mặc định: Ngày, hôm nay
      _filterSetting = OverViewFilterSettings();
      _filterSetting.eDateFilterType = EDateFilterType.day;
      _filterSetting.periodReport = _periodFilterCategoryTypeList
          ?.firstWhere((element) => element.type == EDateFilterType.day)
          ?.periodItemList
          ?.firstWhere((element) => element.type == EReportPeriodType.thisDay);
      _filterSetting.previuosPeriodReport = null;
    }
  }

  ///
  /// Thay đổi trạng thái switch: So sánh với
  ///
  void toggleComparePreviuosPeriod() {
    _isCompareWithPreviousPeriod = !_isCompareWithPreviousPeriod;

    /// Reset lại dateRange của itemFilterPrevious trước đó
    /// nếu nó là ngày tháng Customize
    resetCustomizeDateItemFilterPrevious();

    notifyListeners();
  }

  ///
  /// Lấy DS các Khoảng thời gian của kì lấy báo cáo
  /// VD: Ngày: Hôm nay, Hôm qua
  /// Tuần: 7 ngày gần đây, Tuần này...
  ///
  List<ItemPeriodFilterObject> get getItemPeriodFilterListByPeriodMaster {
    return getPeriodFilterCategory().periodItemList;
  }

  ///
  /// Lấy khoảng thời gian để compare tương ứng với khoảng thời gian của Kỳ
  /// được chọn để lấy báo cáo
  ///
  void loadItemPeriodFilterPreviousList() {
    //Kỳ báo cáo: Ngày, Tuần, Tháng, Customize
    final periodFilterCategory = getPeriodFilterCategory();

    /// Khoảng thời gian lấy báo cáo
    final periodFilterReport =
        periodFilterCategory.periodItemList[_itemFilterPosition].dateRange;

    /// Lấy tiếp các Khoảng thời gian cần so sánh từ Khoảng thời gian lấy báo cáo
    _previousItemFilterList =
        _overViewDateFilterBusiness.getPreviousItemPeriodFilterByType(
            periodFilter: periodFilterCategory.type,
            dateRange: periodFilterReport);
  }

  ///
  /// Lấy Kỳ báo cáo đang chọn: Ngày, Tuần, Tháng, Customize
  ///
  PeriodFilterCategoryType getPeriodFilterCategory() {
    return _periodFilterCategoryTypeList[_periodCategoryPosition];
  }

  ///
  /// Lấy khoảng thời gian lấy báo cáo
  ///
  ItemPeriodFilterObject getItemFilter() {
    return getItemFilterByPosition(_itemFilterPosition);
  }

  ///
  /// Lấy khoảng thời gian lấy báo cáo theo vị trí item được chọn [position]
  ///
  ItemPeriodFilterObject getItemFilterByPosition(position) {
    final filterDateType = getPeriodFilterCategory();
    return filterDateType.periodItemList[position];
  }

  ///
  /// Lấy khoảng thời gian để so sánh báo cáo theo vị trí item được chọn [position]
  ///
  ItemPeriodFilterObject getItemFilterPreviousByPosition(position) {
    return _previousItemFilterList[position];
  }

  ///
  /// Bind dữ liệu đã cache lên các biến cho hiển thị UI
  ///
  void _bindFilterSetting() {
    /// Từ cache tìm ra [_periodFilterCategoryTypePosition]
    _periodCategoryPosition = _periodFilterCategoryTypeList?.indexWhere(
        (element) => element.type == _filterSetting.eDateFilterType);

    /// Từ cache tìm ra [_itemFilterPosition]
    if (_filterSetting.periodReport != null) {
      final itemPeriodFilterList = getPeriodFilterCategory().periodItemList;

      /// Nếu chọn Kỳ báo cáo Tuỳ chỉnh thì cần hiển thị lại thời gian đã chọn
      /// trên UI
      if (_filterSetting.eDateFilterType == EDateFilterType.custom) {
        updateDateRangeForCustomizePeriod(
            itemPeriodFilterList, _filterSetting.periodReport.dateRange);
      } else {
        _itemFilterPosition = itemPeriodFilterList?.indexWhere(
            (element) => element.type == _filterSetting.periodReport.type);
      }
    }

    /// Lấy khoảng thời gian để compare tương ứng với khoảng thời gian của Kỳ
    /// được chọn để lấy báo cáo
    loadItemPeriodFilterPreviousList();

    /// Từ cache tìm ra [_itemFilterPreviousPosition]
    if (_filterSetting.previuosPeriodReport != null) {
      _isCompareWithPreviousPeriod = true;

      /// Nếu chọn Kỳ báo cáo Tuỳ chỉnh thì cần hiển thị lại thời gian đã chọn
      /// trên UI
      if (_filterSetting.eDateFilterType == EDateFilterType.custom) {
        updateDateRangeForCustomizePeriod(_previousItemFilterList,
            _filterSetting.previuosPeriodReport.dateRange);
      } else {
        _itemFilterPreviousPosition = _previousItemFilterList?.indexWhere(
            (element) =>
                element.type == _filterSetting.previuosPeriodReport.type);

        /// Lấy ra object của Kỳ so sánh được chọn trên DS để cập nhật lại
        /// [dateRange] và [description]
        final itemFilterPrev =
            getItemFilterPreviousByPosition(_itemFilterPreviousPosition);
        updateDateRange(
            itemFilterPrev, _filterSetting.previuosPeriodReport.dateRange);
      }
    }
  }

  ///
  /// Cập nhật Khoảng thời gian đã chọn từ [dateRangeCache]
  /// của cache [_filterSetting] lên dataSource hiển thị các kỳ báo cáo của tab
  /// Tuỳ chỉnh
  ///
  /// [periodList] DS các Khoảng thời gian của kỳ báo cáo
  /// [dateRangeCache] Khoảng thời gian trong cache
  ///
  void updateDateRangeForCustomizePeriod(
      List<ItemPeriodFilterObject> periodList, DateRange dateRangeCache) {
    periodList?.forEach((element) {
      if (element.type == EReportPeriodType.fromDateCustomize) {
        final dateRange = DateRange(
            startDate: dateRangeCache.startDate,
            endDate: dateRangeCache.startDate);

        updateDateRange(element, dateRange);
      } else if (element.type == EReportPeriodType.toDateCustomize) {
        final dateRange = DateRange(
            startDate: dateRangeCache.endDate, endDate: dateRangeCache.endDate);

        updateDateRange(element, dateRange);
      }
    });
  }

  ///
  /// Cập nhật Khoảng thời gian nếu nó là thời gian được chọn
  /// [item] khoảng thời gian của kỳ để lấy báo cáo
  /// [date] khoảng thời gian
  ///
  void updateDateRange(ItemPeriodFilterObject item, DateRange date) {
    if (item != null && item.isCustomizeDate) {
      item.dateRange = date;
      item.description =
          _genDescriptionDateRange(_filterSetting.eDateFilterType, date);
    }
  }

  ///
  /// Reset lại dateRange của itemFilterPrevious trước nếu nó là Customize
  ///
  void resetCustomizeDateItemFilterPrevious() {
    /// Lấy itemFilterPrevious hiện tại và set Date Range về null
    final currentItemFilterPrevious =
        getItemFilterPreviousByPosition(_itemFilterPreviousPosition);
    if (currentItemFilterPrevious.isCustomizeDate) {
      currentItemFilterPrevious.dateRange = null;
      currentItemFilterPrevious.description = "Chọn ngày";
    }
  }

  ///
  /// Xử lý sau khi chọn thời gian Customize
  /// [date] thời gian customize được chọn
  /// [itemFilter] obj filter được chọn
  ///
  void handleDateCustomize(
      DateTime fromDate, DateTime toDate, ItemPeriodFilterObject itemFilter) {
    ///Kỳ báo cáo: Ngày, Tuần, Tháng, Customize
    final periodFilterCategory = getPeriodFilterCategory();
    final eDateFilterType = periodFilterCategory.type;

    final currentDateRange = DateRange(
        startDate: DateTimeHelper.getStartOfDate(fromDate),
        endDate: DateTimeHelper.getEndOfDate(toDate));

    itemFilter.dateRange = currentDateRange;

    final description =
        _genDescriptionDateRange(eDateFilterType, currentDateRange);
    itemFilter.description = description;
  }

  ///
  /// Lấy Description của date range theo kỳ báo cáo
  /// [eDateFilterType] kỳ báo cáo
  /// [dateRange] khoảng thời gian của kỳ báo cáo
  ///
  String _genDescriptionDateRange(
      EDateFilterType eDateFilterType, DateRange dateRange) {
    if (dateRange == null) {
      return "";
    }
    switch (eDateFilterType) {
      case EDateFilterType.day:
        return DateTimeFormatHelper.formatDate2String(dateRange.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);
        break;
      case EDateFilterType.week:
        final startLastWeekDesc = DateTimeFormatHelper.formatDate2String(
            dateRange.startDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        final endLastWeekDesc = DateTimeFormatHelper.formatDate2String(
            dateRange.endDate,
            format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

        return "$startLastWeekDesc - $endLastWeekDesc";
        break;

      case EDateFilterType.custom:
        return DateTimeFormatHelper.formatDate2String(dateRange.startDate,
            format: DateTimeFormatConstant.DD_MM_YYYY);
        break;
      default:
        return "";
    }
  }

  ///
  /// Lấy date range của kỳ báo cáo Tuỳ chỉnh
  /// [periodList] DS khoảng thời gian của kỳ báo cáo
  /// tuỳ chỉnh: Từ ngày, đến ngày
  ///
  DateRange getDateRangeOfCustomizePeriod(
      List<ItemPeriodFilterObject> periodList) {
    DateTime startDate, endDate;

    periodList?.forEach((element) {
      if (element.type == EReportPeriodType.fromDateCustomize) {
        startDate = element.dateRange?.startDate;
      } else if (element.type == EReportPeriodType.toDateCustomize) {
        endDate = element.dateRange?.endDate;
      }
    });

    return DateRange(startDate: startDate, endDate: endDate);
  }

  ///
  /// Validate thiết lập trên Bộ lọc
  ///
  OverviewValidateResult validateFilter() {
    final filterDateType = getPeriodFilterCategory();

    if (filterDateType.type == EDateFilterType.custom) {
      /// Khoảng thời gian lấy báo cáo
      final filterDateRange =
          getDateRangeOfCustomizePeriod(filterDateType.periodItemList);

      if (filterDateRange.startDate == null) {
        return OverviewValidateResult.fromDateIsNull();
      }

      if (filterDateRange.endDate == null) {
        return OverviewValidateResult.toDateIsNull();
      }

      /// Khoảng thời gian so sánh
      final prevFilterDateRange =
          getDateRangeOfCustomizePeriod(_previousItemFilterList);

      if (prevFilterDateRange.startDate == null) {
        return OverviewValidateResult.prevFromDateIsNull();
      }

      if (prevFilterDateRange.endDate == null) {
        return OverviewValidateResult.prevToDateIsNull();
      }
    } else {
      if (_isCompareWithPreviousPeriod) {
        /// Khoảng thời gian so sánh
        final prevItemFilter =
            getItemFilterPreviousByPosition(_itemFilterPreviousPosition);

        if (prevItemFilter != null && prevItemFilter.isCustomizeDate) {
          if (prevItemFilter.dateRange == null ||
              prevItemFilter.dateRange.startDate == null ||
              prevItemFilter.dateRange.endDate == null) {
            return OverviewValidateResult.customizeDateIsNull();
          }
        }
      }
    }
    return OverviewValidateResult.ok();
  }

  ///
  /// Thực hiện khi nhấn vào button Lọc
  ///
  void processFilter() {
    final validated = validateFilter();
    validated.when(
        ok: () {
          _applyFilter();
          navigationService.maybePop(obj: true);
        },
        customizeDateIsNull: () => print("Thời gian chưa được chọn"),
        fromDateIsNull: () => print("Từ ngày chưa được chọn"),
        toDateIsNull: () => print("Đến ngày chưa được chọn"),
        prevFromDateIsNull: () => print("So sánh Từ ngày chưa được chọn"),
        prevToDateIsNull: () => print("So sánh Đến ngày chưa được chọn"));
  }

  ///
  /// Áp dụng Lọc
  ///
  void _applyFilter() {
    final filterDateType = getPeriodFilterCategory();

    /// Kỳ báo cáo
    _filterSetting.eDateFilterType = filterDateType.type;

    /// Khoảng thời gian lấy báo cáo
    if (_filterSetting.eDateFilterType == EDateFilterType.custom) {
      final filterDateRange =
          getDateRangeOfCustomizePeriod(filterDateType.periodItemList);

      if (filterDateRange.startDate != null &&
          filterDateRange.endDate != null) {
        final periodReport = ItemPeriodFilterObject.createCustomizeDate(
            DateRange(
                startDate: filterDateRange.startDate,
                endDate: filterDateRange.endDate));

        _filterSetting.periodReport = periodReport;
      } else {
        _filterSetting.periodReport = null;
      }
    } else {
      _filterSetting.periodReport =
          filterDateType.periodItemList[_itemFilterPosition];
    }

    /// So sánh với
    if (_isCompareWithPreviousPeriod) {
      if (_filterSetting.eDateFilterType == EDateFilterType.custom) {
        final prevFilterDateRange =
            getDateRangeOfCustomizePeriod(_previousItemFilterList);

        if (prevFilterDateRange.startDate != null &&
            prevFilterDateRange.endDate != null) {
          final periodReport = ItemPeriodFilterObject.createCustomizeDate(
              DateRange(
                  startDate: prevFilterDateRange.startDate,
                  endDate: prevFilterDateRange.endDate));

          _filterSetting.previuosPeriodReport = periodReport;
        } else {
          _filterSetting.previuosPeriodReport = null;
        }
      } else {
        _filterSetting.previuosPeriodReport =
            getItemFilterPreviousByPosition(_itemFilterPreviousPosition);
      }
    } else {
      _filterSetting.previuosPeriodReport = null;
    }

    ///
    /// Cất thông tin thiết lập bộ lọc vào cache
    ///
    filterSettingRepository?.saveOverViewFilterSettings(_filterSetting);
  }
}
