//
// Created by nqhung on 02/11/2020.
//

import 'package:MShopManager/app/app_constant.dart';
import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/branch_business.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/business/report/common_report_business.dart';
import 'package:MShopManager/business/report/overview_report_business.dart';
import 'package:MShopManager/app/user_credential.dart';
import 'package:MShopManager/data/repository/dashboard_repository.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_branch_filter.dart';
import 'package:MShopManager/enums/enum_date_filter_type.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/enums/enum_overview_sheet_type.dart';
import 'package:MShopManager/enums/enum_report_period_type.dart';
import 'package:MShopManager/enums/enum_revenue_report_type.dart';
import 'package:MShopManager/model/branch.dart';
import 'package:MShopManager/model/chart_data_source.dart';
import 'package:MShopManager/model/overview/abstract_overview_data_object.dart';
import 'package:MShopManager/model/overview/abstract_overview_sheet_child_data_object.dart';
import 'package:MShopManager/model/overview/cash_receipt_status_day.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/model/overview/estimate_revenue_status_day.dart';
import 'package:MShopManager/model/overview/instock_today.dart';
import 'package:MShopManager/model/overview/invoice_today.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';
import 'package:MShopManager/model/period_filter_object.dart';
import 'package:MShopManager/model/quick_action_item.dart';
import 'package:MShopManager/utils/date_format_helper.dart';
import 'package:MShopManager/utils/ext/dart_extensions.dart';
import 'package:MShopManager/model/overview/overview_data_objects.dart';
import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/overview/value_property_object.dart';
import 'package:MShopManager/model/service/request/draw_dashboar_for_mobile_param.dart';
import 'package:MShopManager/model/service/request/revenue_setting_dashboard_param.dart';
import 'package:MShopManager/utils/date_time_helper.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:mp_chart/mp/core/entry/entry.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class OverviewViewModel extends MSBaseViewModel
    with MSStateMixin<List<OverviewDataObject>> {
  ////
  /// Repository ===============================================================
  ///

  MobileRepository _mobileRepository =
      LocatorService.shared.get<MobileRepository>();

  DashboardRepository _dashboardRepository =
      LocatorService.shared.get<DashboardRepository>();

  ///
  /// Variable =================================================================
  ///

  /// Controller
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  RefreshController get refreshController => _refreshController;

  OverViewReportBusiness _overViewReportBusiness =
      LocatorService.shared.get<OverViewReportBusiness>();

  QuickActionBusiness _quickActionBusiness;

  String _branchSelectTitle;
  String get branchSelectTitle => _branchSelectTitle;

  ///
  /// Toàn bộ DS nhà hàng
  ///
  List<Branch> _allBranchList = [];
  List<Branch> get allBranchList => _allBranchList;

  ///
  /// DS nhà hàng đang được chọn
  ///
  List<Branch> _branchSelectedList = [];
  List<Branch> get branchSelectedList => _branchSelectedList;
  set branchSelectedList(List<Branch> newValue) {
    _branchSelectedList = newValue;

    /// Lưu vào setting
    _filterSetting?.branchIdList = newValue?.map((e) => e.branchId)?.toList();

    /// Cập nhật ID nhà hàng đang được chọn để lấy báo cáo
    _reportDataParam?.listBranchID = _getBranchSelectedId();
  }

  EOverviewBranchFilter _branchFilter = EOverviewBranchFilter.allBranch;
  EOverviewBranchFilter get branchFilter => _branchFilter;
  set branchFilter(EOverviewBranchFilter newValue) {
    _branchFilter = newValue;

    // Lưu vào setting
    _filterSetting?.eBranchSelected = newValue;

    _branchSelectTitle = _getBranchSelectTitle();

    notifyListeners();
  }

  ///
  /// Setting báo cáo Tổng quan
  ///
  OverViewFilterSettings _filterSetting;

  ///
  /// Param cho request lấy báo cáo Overview
  ///
  DrawDashboarForMobileParam _reportDataParam;
  RevenueSettingDashboardParam _reportChartDataParam;

  /// Variable để cache memory dữ liệu báo cáo ========================================
  CashReceiptStatusDay cashReceiptStatusDay;
  EstimateRevenueStatusDay estimateRevenueStatusDay;
  InvoiceToday invoiceToday;
  CustomerToday customerToday;
  InstockToday instockToday;

  /// Variable để cache memory dữ liệu báo cáo ========================================

  OverviewViewModel(QuickActionBusiness quickActionBusiness) {
    this._quickActionBusiness = quickActionBusiness;

    /// Khởi tạo dữ liệu DS các nhà hàng
    _initBranchList();

    /// Lấy từ cache [filterSetting] ra
    _loadOrCreateDefaultFilterSetting();

    /// Lấy title hiển thị báo cáo
    _branchSelectTitle = _getBranchSelectTitle();

    /// Khởi tạo param mặc định từ cache [filterSetting]
    _reportDataParam = _createDrawDashboardParamDefault();
  }

  ///
  /// Load thiết lập từ cache hoặc tạo mới
  ///
  void _loadOrCreateDefaultFilterSetting() {
    _filterSetting = filterSettingRepository.getOverViewFilterSettings();

    /// Hoặc tạo mới:
    if (_filterSetting == null) {
      /// Mặc định: Ngày, hôm nay
      _filterSetting = OverViewFilterSettings();

      _filterSetting.eDateFilterType = EDateFilterType.day;
      _filterSetting.periodReport = _overViewReportBusiness
          .getPeriodFilterList()
          ?.firstWhere((element) => element.type == EDateFilterType.day)
          ?.periodItemList
          ?.firstWhere((element) => element.type == EReportPeriodType.thisDay);
      _filterSetting.previuosPeriodReport = null;
    }
  }

  ///
  /// Khởi tạo dữ liệu DS các nhà hàng
  ///
  void _initBranchList() {
    _allBranchList = BranchBusiness.getBranchList(
        UserCredential.currentSession.branchList,
        isGetAllChainBranch: false);
  }

  ///
  /// Lấy title hiển thị báo cáo
  ///
  String _getBranchSelectTitle() {
    if (_filterSetting != null) {
      if (_filterSetting.eBranchSelected == EOverviewBranchFilter.groupBranch) {
        int count = _filterSetting.branchIdList?.length ?? 0;
        return "${count.toString()} cửa hàng";
      }
    }

    return "Toàn chuỗi";
  }

  ///
  /// True nếu so sánh với kỳ báo cáo trước
  ///
  bool isCompareTwoPeriod() {
    return (_filterSetting?.previuosPeriodReport != null) ?? false;
  }

  ///
  /// Lấy thời gian lấy báo cáo
  ///
  String getFetchReportDateTimeTitle() {
    final dateTime = _filterSetting?.fetchReportDateTime ?? DateTime.now();

    return MISACommon.getFetchReportDateTimeTitle(dateTime);
  }

  ///
  /// Lấy Title của kỳ chọn báo cáo
  /// VD: Tháng này (12/2020)
  ///
  String getPeriodFilterTitle() {
    if (_filterSetting != null) {
      ItemPeriodFilterObject itemPeriodFilter = _filterSetting.periodReport;
      final dateRange = itemPeriodFilter.dateRange;
      switch (_filterSetting.eDateFilterType) {
        case EDateFilterType.day:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

          if (itemPeriodFilter.type == EReportPeriodType.thisDay) {
            return "Hôm nay ($fromDate)";
          } else if (itemPeriodFilter.type == EReportPeriodType.yesterday) {
            return "Hôm qua ($fromDate)";
          }
          break;
        case EDateFilterType.week:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.DD_MM);

          final toDate = DateTimeFormatHelper.formatDate2String(
              dateRange.endDate,
              format: DateTimeFormatConstant.DD_MM);

          if (itemPeriodFilter.type == EReportPeriodType.lastSevenDay) {
            return "7 ngày gần đây ($fromDate - $toDate)";
          } else if (itemPeriodFilter.type == EReportPeriodType.thisWeek) {
            return "Tuần này ($fromDate - $toDate)";
          }
          break;
        case EDateFilterType.month:
          if (itemPeriodFilter.type == EReportPeriodType.lastThirtyDay) {
            final fromDate = DateTimeFormatHelper.formatDate2String(
                dateRange.startDate,
                format: DateTimeFormatConstant.DD_MM_YYYY);

            final toDate = DateTimeFormatHelper.formatDate2String(
                dateRange.endDate,
                format: DateTimeFormatConstant.DD_MM_YYYY);

            return "$fromDate - $toDate";
          } else if (itemPeriodFilter.type == EReportPeriodType.thisMonth) {
            final fromDate = DateTimeFormatHelper.formatDate2String(
                dateRange.startDate,
                format: DateTimeFormatConstant.MM_YYYY);

            return "Tháng này ($fromDate)";
          } else if (itemPeriodFilter.type == EReportPeriodType.lastMonth) {
            final fromDate = DateTimeFormatHelper.formatDate2String(
                dateRange.startDate,
                format: DateTimeFormatConstant.MM_YYYY);

            return "Tháng trước ($fromDate)";
          }
          break;
        case EDateFilterType.custom:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.DD_MM_YYYY);

          final toDate = DateTimeFormatHelper.formatDate2String(
              dateRange.endDate,
              format: DateTimeFormatConstant.DD_MM_YYYY);
          return "$fromDate - $toDate";
      }
    }
    return "";
  }

  ///
  /// Lấy Title của kỳ chọn báo cáo
  /// VD: Tháng này (12/2020)
  ///
  String getPreviousPeriodFilterTitle() {
    ItemPeriodFilterObject itemPeriodFilter =
        _filterSetting?.previuosPeriodReport;
    if (itemPeriodFilter != null) {
      final dateRange = itemPeriodFilter.dateRange;
      switch (_filterSetting.eDateFilterType) {
        case EDateFilterType.day:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.FORMAT_VI_DATE_TIME_MM_DD);

          if (itemPeriodFilter.type == EReportPeriodType.lastDay) {
            return "So với Ngày trước đó ($fromDate)";
          } else if (itemPeriodFilter.type ==
              EReportPeriodType.toDateCustomize) {
            return "So với ($fromDate)";
          }
          break;
        case EDateFilterType.week:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.DD_MM);

          final toDate = DateTimeFormatHelper.formatDate2String(
              dateRange.endDate,
              format: DateTimeFormatConstant.DD_MM);

          if (itemPeriodFilter.type == EReportPeriodType.lastWeek) {
            return "So với Tuần trước đó ($fromDate - $toDate)";
          } else if (itemPeriodFilter.type ==
              EReportPeriodType.toDateCustomize) {
            return "So với ($fromDate - $toDate)";
          }
          break;
        case EDateFilterType.month:
          if (itemPeriodFilter.type == EReportPeriodType.fourLastWeek) {
            final fromDate = DateTimeFormatHelper.formatDate2String(
                dateRange.startDate,
                format: DateTimeFormatConstant.DD_MM_YYYY);

            final toDate = DateTimeFormatHelper.formatDate2String(
                dateRange.endDate,
                format: DateTimeFormatConstant.DD_MM_YYYY);

            return "So với $fromDate - $toDate";
          } else if (itemPeriodFilter.type == EReportPeriodType.lastMonth) {
            final fromDate = DateTimeFormatHelper.formatDate2String(
                dateRange.startDate,
                format: DateTimeFormatConstant.MM_YYYY);

            return "So với Tháng trước đó ($fromDate)";
          }
          break;
        case EDateFilterType.custom:
          final fromDate = DateTimeFormatHelper.formatDate2String(
              dateRange.startDate,
              format: DateTimeFormatConstant.DD_MM_YYYY);

          final toDate = DateTimeFormatHelper.formatDate2String(
              dateRange.endDate,
              format: DateTimeFormatConstant.DD_MM_YYYY);
          return "So với $fromDate - $toDate";
      }
    }
    return "";
  }

  ///
  /// Tạo object param mặc định lấy thông tin báo cáo
  ///
  DrawDashboarForMobileParam _createDrawDashboardParamDefault() {
    DrawDashboarForMobileParam param = DrawDashboarForMobileParam();
    DateRange dateRangeReport = _filterSetting?.periodReport?.dateRange;
    DateRange previousDateRangeReport =
        _filterSetting?.previuosPeriodReport?.dateRange;
    param.fromDate = dateRangeReport?.startDate;
    param.toDate = dateRangeReport?.endDate;
    param.listBranchID = _getBranchIdSelectedByBranchFilter();

    param.previousPeriodFromDate = previousDateRangeReport?.startDate;
    param.previousPeriodToDate = previousDateRangeReport?.endDate;

    return param;
  }

  ///
  /// Tạo object param mặc định lấy biểu đồ báo cáo
  ///
  RevenueSettingDashboardParam _createOverViewChartDataParam() {
    _reportChartDataParam = RevenueSettingDashboardParam();
    _reportChartDataParam.fromDate = _reportDataParam?.fromDate;
    _reportChartDataParam.toDate = _reportDataParam?.toDate;

    _reportChartDataParam.periodType = EReportPeriodType.thisMonth;
    _reportChartDataParam.isRefresh = true;

    if (_branchFilter == EOverviewBranchFilter.allBranch) {
      _reportChartDataParam.branchID = AppConstant.UUID_EMPTY;
      _reportChartDataParam.listBranchID = null;
    } else {
      _reportChartDataParam.listBranchID = _reportDataParam?.listBranchID;
    }

    /// Khoảng cách giữa 2 khoảng thời gian
    final rangeDayCount = DateExtensions.daysInRange(
                _reportChartDataParam.fromDate, _reportChartDataParam.toDate)
            ?.length ??
        0;

    // Nếu lớn hơn 1 năm thì xem theo năm
    if (rangeDayCount >= 365) {
      _reportChartDataParam.statisticTimeType = ERevenueReportType.byYear;
    } else if (rangeDayCount > 30) {
      // > 30 ngày thì xem theo tháng
      _reportChartDataParam.statisticTimeType = ERevenueReportType.byMonth;
    } else if (rangeDayCount == 1) {
      // Còn lại 1 ngày thì xem theo giờ
      _reportChartDataParam.statisticTimeType = ERevenueReportType.byHour;
    } else {
      // Còn lại thì xem theo ngày của ngày
      _reportChartDataParam.statisticTimeType = ERevenueReportType.byDay;
    }

    return _reportChartDataParam;
  }

  ///
  /// Title của của Ox cho biểu đồ theo Kỳ báo cáo
  ///
  String getAxisBottomTitle() {
    ERevenueReportType eRevenueReportType =
        _reportChartDataParam?.statisticTimeType ?? ERevenueReportType.byDay;
    return eRevenueReportType.getAxisTitle() ?? "";
  }

  ///
  /// Kiểm tra nếu là lấy báo cáo cho 1 ngày cụ thể hoặc khoảng thời gian
  /// nhưng chỉ trong 1 ngày
  ///
  bool isShowReportDataForOneDay() {
    if (_filterSetting.eDateFilterType == EDateFilterType.day) {
      return true;
    } else {
      final startDate = _filterSetting.periodReport?.dateRange?.startDate;
      final endDate = _filterSetting.periodReport?.dateRange?.endDate;

      if (startDate != null && endDate != null) {
        /// Khoảng cách giữa 2 mốc thời gian
        final rangeDayCount =
            DateExtensions.daysInRange(startDate, endDate)?.length ?? 0;

        return rangeDayCount == 1;
      }
      return false;
    }
  }

  ///
  /// Lấy Id của cửa hàng đã chọn theo tuỳ chọn
  /// Nếu chọn Chuỗi cửa hàng -> 00000000-0000-0000-0000-000000000000
  /// Nếu chọn nhóm của hàng -> BranchID_1,BranchID_2,BranchID_3
  ///
  String _getBranchIdSelectedByBranchFilter() {
    if (_branchFilter == EOverviewBranchFilter.allBranch) {
      return AppConstant.UUID_EMPTY;
    } else {
      return _getBranchSelectedId();
    }
  }

  ///
  /// Join những Branch đã chọn ở trong List vào 1 chuỗi cách nhau dấu phẩy ,
  ///
  String _getBranchSelectedId() {
    final branchIdList = _branchSelectedList?.map((e) => e.branchId)?.toList();
    return branchIdList?.join(",");
  }

  ///
  /// Lấy dữ liệu báo cáo hiển thị biểu đồ
  /// Created by NQHung on 21/12/2020
  ///
  Future<LineChartEntry> fetchOverViewChartDataReport() async {
    _reportChartDataParam = _createOverViewChartDataParam();
    return _dashboardRepository
        .fetchRevenueReportByTime(_reportChartDataParam)
        .then((dataResponse) {
      return dataResponse.when<LineChartEntry>(success: (data) {
        final List<Entry> entry = [];
        final List<String> label = [];
        for (int i = 0; i < data.length; i++) {
          final item = data[i];
          label.add(item.timeName);
          entry.add(Entry(x: i.toDouble(), y: item.totalAmount));
        }
        return LineChartEntry(label: label, entry: entry);
      }, commonError: (
        error,
      ) {
        /// Thông báo lỗi, hiện tại chưa cần show ra UI
        print(error);
        return null;
      }, apiError: (error, ex) {
        /// Thông báo lỗi, hiện tại chưa cần show ra UI
        print(error);
        return null;
      });
    });
  }

  ///
  /// Lấy dữ liệu hiển thị cho màn hình Toàn chuỗi
  ///
  void fetchChainOverViewDataReport() async {}

  ///
  /// Khởi tạo thiết lập Phím tắt nếu nó chưa có
  ///
  Future<List<QuickActionItem>> _getOrCreateQuickActionButton() async {
    final quickActionByUser =
        await commonDataRepository.getQuickActionItemListByUser();
    var output = [];
    if (quickActionByUser == null || quickActionByUser.isEmpty) {
      output = _quickActionBusiness.createDefaultQuickActionForUser();
    } else {
      output = _quickActionBusiness.mappingQuickAction(quickActionByUser);
    }

    output = output.sublist(0, 3);

    output.add(QuickActionItem(
        title: "Khác",
        imageAssets: AppResources.icShortcutOther,
        sortOrder: 0,
        type: EFeatureType.other));

    return output;
  }

  ///
  /// Lấy dữ liệu hiển thị cho màn hình Tổng quan
  /// Created by NQHung on 05/11/2020
  ///
  void fetchOverViewDataReport() async {
    changeState([], status: ViewStatus.loading());

    bool isComparePreviousPeriod = isCompareTwoPeriod();

    /// Fetch báo cáo
    final fetchDrawDashboardReport =
        await _mobileRepository.getDrawDashboardReport(_reportDataParam);

    await fetchDrawDashboardReport.when(success: (responseData) async {
      List<OverviewDataObject> _dataSourceList = [];

      /// Cập nhật thời gian lấy báo cáo ở local
      _filterSetting?.fetchReportDateTime = DateTime.now();
      filterSettingRepository?.saveOverViewFilterSettings(_filterSetting);

      final reportDailyData =
          _overViewReportBusiness.buildReportDailyData(responseData);

      /// Tiền thu trong kỳ ====================================================
      cashReceiptStatusDay =
          _overViewReportBusiness.getCashReceiptStatusDay(reportDailyData);

      /// Doanh thu ước tính
      estimateRevenueStatusDay =
          _overViewReportBusiness.getRevenueInDay(reportDailyData);

      /// Hoá đơn
      invoiceToday =
          _overViewReportBusiness.getInvoiceStatusDay(reportDailyData);

      //Collect data cho biểu đồ ===============================================
      // ReportCompareResult diffCashReceipt =
      //     CommonReportBusiness.computeTwoReportData(
      //         cashReceiptStatusDay.receiptAmountInDay ?? 0,
      //         cashReceiptStatusDay.previousPeriodReceiptAmountInDay ?? 0);
      // _dataSourceList.add(OverviewChartObject(
      //   cashReceiptStatusDay: cashReceiptStatusDay,
      //   diff: isComparePreviousPeriod ? diffCashReceipt : null,
      // ));

      /// Collect data cho header hiển thị thông tin chung dạng carousel
      _dataSourceList.add(_overViewReportBusiness.buildOverviewHeader(
          isCompareTwoPeriod(),
          cashReceiptStatusDay,
          estimateRevenueStatusDay,
          invoiceToday));

      /// Chức năng các nút Phím tắt
      List<QuickActionItem> quickActionByUser =
          await _getOrCreateQuickActionButton();

      if (quickActionByUser != null && quickActionByUser.isNotEmpty) {
        _dataSourceList.add(OverviewQuickActionObject(quickActionByUser));
      }

      /// Hoá đơn ==============================================================

      /// Đơn hàng chờ xử lý ===================================================
      List<ValuePropertyObject> childList = [];
      _dataSourceList.add(OverviewTitleNListValueObject(
          viewType: EOverviewSheetType.orderPending,
          title: "Đơn hàng chờ xử lý",
          childList: childList));

      childList.add(ValuePropertyObject(
          title: "Chờ giao hàng",
          quantity: invoiceToday.pendingDeliveryQuantity
                  ?.toStringFormat(EDoubleFormat.money) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Đang giao hàng",
          quantity: invoiceToday.deliveringQuantity
                  ?.toStringFormat(EDoubleFormat.money) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Hoàn thành",
          quantity: invoiceToday.deliveredQuantity
                  ?.toStringFormat(EDoubleFormat.money) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Chờ thu COD",
          quantity: invoiceToday.pendingReceiveCODQuantity
                  ?.toStringFormat(EDoubleFormat.money) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Thất bại",
          quantity: invoiceToday.failedQuantity
                  ?.toStringFormat(EDoubleFormat.quantity) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Đã chuyển hoàn",
          quantity: invoiceToday.reTransferQuantity
                  ?.toStringFormat(EDoubleFormat.quantity) ??
              "0"));
      childList.add(ValuePropertyObject(
          title: "Đã huỷ",
          quantity: invoiceToday.cancelDeliveryQuantity
                  ?.toStringFormat(EDoubleFormat.quantity) ??
              "0"));

      /// Collect data tiền thu trong kỳ
      // _dataSourceList.add(OverviewTitleNValueObject(
      //   viewType: EOverviewSheetType.cashReceipt,
      //   imageAssets: AppResources.icMoney,
      //   title: "Tiền thu trong kỳ",
      //   value: cashReceiptStatusDay.receiptAmountInDay
      //           ?.toStringFormat(EDoubleFormat.money) ??
      //       "0",
      //   diff: isComparePreviousPeriod ? diffCashReceipt : null,
      // ));

      /// Doanh thu ước tính ===================================================

      // _dataSourceList.add(OverviewTitleNValueObject(
      //   viewType: EOverviewSheetType.estimateRevenue,
      //   imageAssets: AppResources.icColumnChart,
      //   title: "Doanh thu ước tính",
      //   value: estimateRevenueStatusDay.estimateRevenue
      //           ?.toStringFormat(EDoubleFormat.money) ??
      //       "0",
      //   diff: isComparePreviousPeriod
      //       ? CommonReportBusiness.computeTwoReportData(
      //           estimateRevenueStatusDay.estimateRevenue ?? 0,
      //           estimateRevenueStatusDay.previousPeriodEstimateRevenue ?? 0)
      //       : null,
      // ));

      /// Khách hàng ===========================================================
      customerToday = _overViewReportBusiness.getCustomerToday(responseData);

      _dataSourceList.add(OverviewOrderNCustomerObject(
        invoiceToday: invoiceToday,
        orderQuantity: invoiceToday
                .getTotalQuantityInvoice()
                ?.toStringFormat(EDoubleFormat.quantity) ??
            "0",
        orderDiff: isComparePreviousPeriod
            ? CommonReportBusiness.computeTwoReportData(
                invoiceToday.getTotalQuantityInvoice() ?? 0,
                invoiceToday.getPreviousPeriodTotalQuantityInvoice() ?? 0)
            : null,
        customerToday: customerToday,
        customerQuantity:
            customerToday.quantity?.toStringFormat(EDoubleFormat.quantity) ??
                "0",
        customerDiff: isComparePreviousPeriod
            ? CommonReportBusiness.computeTwoReportData(
                customerToday.totalAmountCustomer ?? 0,
                customerToday.previousPeriodTotalCustomer ?? 0)
            : null,
      ));

      /// Tồn kho ==============================================================
      instockToday = _overViewReportBusiness.getInstockToday(responseData);
      _dataSourceList.add(OverviewInventoryItemInStoreObject(
          inventoryItemQuantity:
              instockToday.quantity?.toStringFormat(EDoubleFormat.quantity) ??
                  "0",
          inventoryItemAmount:
              instockToday.totalAmount?.toStringFormat(EDoubleFormat.money) ??
                  "0"));

      changeState(_dataSourceList, status: ViewStatus.success());
    }, commonError: (
      error,
    ) {
      /// Thông báo lỗi, hiện tại chưa cần show ra UI
      print(error);

      changeState([], status: ViewStatus.empty());
    }, apiError: (error, ex) {
      /// Thông báo lỗi, hiện tại chưa cần show ra UI
      changeState([], status: ViewStatus.empty());
    });
  }

  ///
  /// * Build dữ liệu hiển thị cho chi tiết một mục theo Type truyền vào
  /// * @param sheetType mục muốn build dữ liệu
  /// + Doanh thu ước tính
  /// + Tiền thu trong kỳ
  /// + Đơn hàng
  /// Không có Khách hàng -> Khách hàng sẽ build 1 hàm riêng để
  ///  đáp ứng việc paging
  /// * Created by NQHung on 05/11/2020
  ///
  Future<OverviewSheetChildDataWrapper> buildDetailSheetDataSource(
      EOverviewSheetType sheetType) async {
    List<OverviewSheetChildDataObject> _childDataSourceList = [];

    OverviewSheetHeaderDataObject itemHeader =
        _overViewReportBusiness.itemHeaderSheetDataSource(
            isCompareTwoPeriod(),
            sheetType,
            cashReceiptStatusDay,
            estimateRevenueStatusDay,
            invoiceToday);

    if (sheetType == EOverviewSheetType.estimateRevenue) {
      /// Doanh thu ước tính
      _childDataSourceList.addAll(_overViewReportBusiness
          .buildEstimateRevenueDataSource(estimateRevenueStatusDay));
    } else if (sheetType == EOverviewSheetType.cashReceipt) {
      _childDataSourceList.addAll(_overViewReportBusiness
          .buildCashReceiptDataSource(cashReceiptStatusDay));
    } else if (sheetType == EOverviewSheetType.order) {
      _childDataSourceList
          .addAll(_overViewReportBusiness.buildOrderDataSource(invoiceToday));
    }
    return OverviewSheetChildDataWrapper(itemHeader, _childDataSourceList);
  }

  ///
  /// Lấy báo cáo theo setting mới từ cache
  ///
  void fetchReportWithNewFilter() {
    /// Load thiết lập từ cache hoặc tạo mới
    _loadOrCreateDefaultFilterSetting();

    /// Khởi tạo param mặc định từ cache [filterSetting]
    _reportDataParam = _createDrawDashboardParamDefault();

    ///Lấy dữ liệu hiển thị cho màn hình Tổng quan
    fetchOverViewDataReport();
  }
}
