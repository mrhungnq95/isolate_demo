import 'package:MShopManager/base/mixin/filter_feature_mixin.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/report/overview_report_business.dart';
import 'package:MShopManager/data/repository/dashboard_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/enums/enum_filter_view_model_key.dart';
import 'package:MShopManager/model/overview/overview_chain_filter_setting.dart';
import 'package:MShopManager/model/overview/report_branch_item.dart';
import 'package:flutter/semantics.dart';

class OverviewChainViewModel extends MSBaseViewModel
    with
        FilterFeatureMixin<OverViewChainFilterSettings>,
        MSStateMixin<List<ReportBranchItem>> {
  ////
  /// Repository ===============================================================
  ///
  DashboardRepository _dashboardRepository =
      LocatorService.shared.get<DashboardRepository>();

  ///
  /// Variable =================================================================
  ///
  OverViewReportBusiness _overViewReportBusiness =
      LocatorService.shared.get<OverViewReportBusiness>();

  @override
  OverViewChainFilterSettings createDefaultFilterSetting() {
    return OverViewChainFilterSettings.newDefault();
  }

  @override
  void filterSettingLoaded(OverViewChainFilterSettings filterSetting) {
    fetchData();
    changeState([], status: ViewStatus.success());
  }

  @SemanticsHintOverrides()
  EFilterViewModelKey get filterViewModelKey =>
      EFilterViewModelKey.overview_chain;

  ///
  ///
  ///
  void _createChainDashboardParamDefault() {}

  ///
  /// Lấy dữ liệu báo cáo Tổng quan chuỗi
  ///
  void fetchData() {}
}
