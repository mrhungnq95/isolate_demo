import 'package:MShopManager/app/resources/resources.dart';
import 'package:MShopManager/base/mixin/ms_state_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/model/quick_action_item.dart';

class QuickActionViewModel extends MSBaseViewModel
    with MSStateMixin<List<QuickActionItem>> {
  final QuickActionBusiness _quickActionBusiness;

  QuickActionViewModel(this._quickActionBusiness);

  ///
  /// Lấy DS các phím tắt của User (đã được user sắp xếp)
  ///
  void fetchQuickActionList() async {
    changeState([], status: ViewStatus.loading());

    List<QuickActionItem> defaultQuickActionList =
        _quickActionBusiness.createDefaultQuickAction();

    final quickActionByUser =
        await commonDataRepository.getQuickActionItemListByUser();

    /// Nếu User đã thiết lập
    if (quickActionByUser != null && quickActionByUser.isNotEmpty) {
      /// Mapping những nút chức năng được người dùng chọn
      /// và remove đi DS gốc để add về đầu DS này
      final quickActionByUserList =
          _quickActionBusiness.selectAndRemoveQuickActionExisted(
              defaultQuickActionList, quickActionByUser);

      /// Add lại những nút này lên trên đầu của [result]
      if (quickActionByUserList.isNotEmpty) {
        defaultQuickActionList?.insertAll(0, quickActionByUserList);
      }
    }

    defaultQuickActionList.add(QuickActionItem(
        title: "Tuỳ chỉnh",
        imageAssets: AppResources.icQuickMenuSettings,
        sortOrder: defaultQuickActionList.length + 1,
        type: null));

    changeState(defaultQuickActionList, status: ViewStatus.success());
  }
}
