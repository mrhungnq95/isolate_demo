import 'dart:math';

import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/report/common_report_business.dart';
import 'package:MShopManager/data/repository/mobile_repository.dart';
import 'package:MShopManager/di/locator.dart';
import 'package:MShopManager/model/base/customer_base.dart';
import 'package:MShopManager/model/overview/customer_today.dart';
import 'package:MShopManager/model/overview/overview_filter_settings.dart';
import 'package:MShopManager/model/overview/overview_sheet_data_objects.dart';
import 'package:MShopManager/model/report_compare_result.dart';
import 'package:MShopManager/model/service/request/get_customer_dashboard_param.dart';
import 'package:MShopManager/utils/misa_common.dart';
import 'package:MShopManager/utils/number_format_helper.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class OverviewCustomerViewModel extends MSBaseViewModel {
  MobileRepository _mobileRepository =
      LocatorService.shared.get<MobileRepository>();

  /// Controller
  RefreshController refreshController =
      RefreshController(initialRefresh: false);

  ///
  /// Setting báo cáo Tổng quan
  ///
  OverViewFilterSettings filterSetting;

  ///
  /// Param để lấy DS Khách hàng
  ///
  GetCustomerDashboardParam _customerDashboardParam;

  ///
  /// Object Header cho việc hiển thị
  ///
  OverviewSheetHeaderDataObject itemHeader;

  ///
  /// DS Customer lấy từ Service cho việc hiển thị
  ///
  List<Customer> customerList;

  /// Random màu
  final Random _randomColor = Random();

  OverviewCustomerViewModel() : super() {
    _initOverViewFilterSettings();
    _initGetCustomerDashboardParams();
  }

  ///
  /// Khởi tạo dữ liệu cache Filter Tổng quan
  ///
  void _initOverViewFilterSettings() {
    filterSetting = filterSettingRepository.getOverViewFilterSettings();
  }

  ///
  /// True nếu so sánh với kỳ báo cáo trước
  ///
  bool isCompareTwoPeriod() {
    return (filterSetting?.previuosPeriodReport != null) ?? false;
  }

  ///
  /// Khởi tạo param lấy DS Khách hàng
  ///
  void _initGetCustomerDashboardParams() {
    _customerDashboardParam = GetCustomerDashboardParam();
    _customerDashboardParam.pageIndex = 1;
    _customerDashboardParam.pageSize = 20;

    _customerDashboardParam.fromDate =
        filterSetting?.periodReport?.dateRange?.startDate;
    _customerDashboardParam.toDate =
        filterSetting?.periodReport?.dateRange?.endDate;
  }

  ///
  /// Lấy thông tin Hearer DS Khách hàng
  /// Created by NQHung on 23/12/2020
  ///
  void initCustomerHeaderData(CustomerToday customerToday) {
    ReportCompareResult diff = CommonReportBusiness.computeTwoReportData(
        customerToday.totalAmountCustomer ?? 0,
        customerToday.previousPeriodTotalCustomer ?? 0);

    /// Khách hàng
    itemHeader = OverviewSheetHeaderDataObject(
        totalAmount:
            NumberFormatHelper.shared.formatMoney(customerToday.quantity),
        title: "Khách hàng",
        amount: "0",
        diff: isCompareTwoPeriod() ? diff : null);
  }

  ///
  /// Lấy DS Khách hàng
  /// [isLoadMore] true nếu hàm này được trigger từ load more
  ///
  void fetchCustomerList({bool isLoadMore = false}) {
    if (isLoadMore) {
      _customerDashboardParam.pageIndex += 1;
    } else {
      _customerDashboardParam.pageIndex = 1;
      setBusy(true);
    }

    if (customerList == null) {
      customerList = [];
    }

    /// Gọi service lấy DS Khách hàng
    _mobileRepository
        ?.getCustomerListDashboard(_customerDashboardParam)
        ?.then((dataResponse) {
      dataResponse?.when(success: (data) {
        final hasData = data != null && data.hasData();

        if (hasData) {
          /// Lấy DS Khách hàng
          customerList.addAll(data.data);

          customerList?.forEach((element) {
            element.avatarName =
                MISACommon.getFirstCharInString(element.customerName);

            element.avatarColor =
                Colors.primaries[_randomColor.nextInt(Colors.primaries.length)];
          });

          if (data.summaryData != null) {
            itemHeader?.amount = NumberFormatHelper.shared
                .formatMoney(data.summaryData["TotalAmount"]);
          }
        }

        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        if (isLoadMore) {
          hasData
              ? refreshController?.loadComplete()
              : refreshController?.loadNoData();
        }
        refreshController?.refreshCompleted();
        setBusy(false);
      }, commonError: (e) {
        /// Lỗi common, hiện tại chưa xử lý gì
        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        if (isLoadMore) {
          refreshController?.loadNoData();
        }
        refreshController?.refreshCompleted();
      }, apiError: (error, errorData) {
        /// Lỗi common, hiện tại chưa xử lý gì
        /// Nếu đang Load more mà không có dữ liệu thì đánh dấu là [loadNoData]
        /// để không kéo thêm nữa
        if (isLoadMore) {
          refreshController?.loadNoData();
        }
        refreshController?.refreshCompleted();
      });
    });
  }
}
