import 'package:MShopManager/base/mixin/ms_vm_event_validate_mixin.dart';
import 'package:MShopManager/base/ms_base_vm.dart';
import 'package:MShopManager/business/quick_action_business.dart';
import 'package:MShopManager/enums/enum_feature_type.dart';
import 'package:MShopManager/features/overview/event/event_quick_action_setting.dart';
import 'package:MShopManager/model/quick_action_item.dart';

class QuickActionSettingViewModel extends MSBaseViewModel
    with MSEventValidateMixin<EventQuickActionSetting> {
  List<QuickActionItem> _actionItemSelected = [];
  List<QuickActionItem> get actionItemSelected => _actionItemSelected;

  List<QuickActionItem> _allQuickActionList = [];
  List<QuickActionItem> get allQuickActionList => _allQuickActionList;

  final QuickActionBusiness _quickActionBusiness;

  QuickActionSettingViewModel(this._quickActionBusiness);

  ///
  /// Lấy DS các phím tắt của User (đã được user sắp xếp)
  ///
  void initQuickActionList() async {
    _allQuickActionList = _quickActionBusiness.createDefaultQuickAction();

    final quickActionByUser =
        await commonDataRepository.getQuickActionItemListByUser();

    /// Nếu User đã thiết lập
    if (quickActionByUser != null && quickActionByUser.isNotEmpty) {
      /// Mapping những nút chức năng được người dùng chọn
      /// và remove đi DS gốc để add về đầu DS này
      _actionItemSelected =
          _quickActionBusiness.selectAndRemoveQuickActionExisted(
              _allQuickActionList, quickActionByUser);
    }
    notifyListeners();
  }

  ///
  /// Thêm chức năng vào ô Phím tắt
  /// [item] object cần thêm
  ///
  void addQuickActionFeature(QuickActionItem item) {
    if (_actionItemSelected.length >= 4) {
      validate(EventQuickActionSetting.noSelectable());
    } else {
      _actionItemSelected.add(item);

      if (_allQuickActionList?.contains(item) == true) {
        _allQuickActionList?.remove(item);
        _allQuickActionList
            ?.sort((a, b) => a.type.rawValue.compareTo(b.type.rawValue));
      }

      notifyListeners();
    }
  }

  ///
  /// Xoá chức năng khỏi ô Phím tắt
  /// [item] object cần xoá
  ///
  void removeQuickActionFeature(QuickActionItem item) {
    if (_actionItemSelected.isNotEmpty) {
      _actionItemSelected.remove(item);
    }

    if (_allQuickActionList?.contains(item) == false) {
      _allQuickActionList?.add(item);
      _allQuickActionList
          ?.sort((a, b) => a.type.rawValue.compareTo(b.type.rawValue));
    }
    notifyListeners();
  }

  ///
  /// Validate trước khi cất dữ liệu
  ///
  bool validateBeforeSave() {
    if (_actionItemSelected.isEmpty) {
      return validate(EventQuickActionSetting.noSelectedItem(), result: false);
    }

    if (_actionItemSelected.length < 4) {
      return validate(
          EventQuickActionSetting.numberOfItemShouldNotBeLessThanFour(),
          result: false);
    }

    return validate(EventQuickActionSetting.ok(), result: true);
  }

  ///
  /// Lưu thiết lập đã chọn
  ///
  void saveQuickAction() {
    final quickActionStr =
        _actionItemSelected.map((e) => e.type.rawValue).join(";");
    commonDataRepository.saveQuickActionItemListByUser(quickActionStr);
  }

  @override
  bool get sync => false;
}
